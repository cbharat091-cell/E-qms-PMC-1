import { User, DocumentWorkflow, DocumentStatus, DocumentCategory, Department, AuditTrailEntry } from './types';

// Simple helper to generate SHA-256 styled fake checksums
export function generateChecksum(text: string): string {
  let hash = 0;
  for (let i = 0; i < text.length; i++) {
    const char = text.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  const positiveHash = Math.abs(hash);
  return 'E9C' + positiveHash.toString(16).toUpperCase().padStart(8, '0') + 'F5D';
}

export const INITIAL_USERS: User[] = [
  {
    id: 'usr_rbarot',
    email: 'rbarot@premiermedcorp.com',
    name: 'Ronak Barot',
    jobTitle: 'Lead Executive Admin',
    isAdmin: true,
    isPreparer: true,
    isReviewer: true,
    isApprover: true,
    assignedRoles: ['Admin', 'Preparer', 'Reviewer', 'Approver'],
    isMR: true,
    createdAt: '2026-06-06T05:42:00Z',
    lastActive: '2026-06-06T05:42:16Z',
    password: 'Boski@01',
    department: 'QA',
    owningQualityDepartment: 'QA'
  },
  {
    id: 'usr_admin',
    email: 'admin@company.com',
    name: 'Dr. Samantha Mercer',
    jobTitle: 'QA Director & Admin',
    isAdmin: true,
    isPreparer: false,
    isReviewer: false,
    isApprover: false,
    assignedRoles: ['Admin'],
    isMR: true,
    createdAt: '2026-01-15T08:00:00Z',
    lastActive: '2026-06-06T05:00:00Z',
    department: 'QA',
    owningQualityDepartment: 'QA'
  },
  {
    id: 'usr_prep',
    email: 'preparer@company.com',
    name: 'Joseph Chen',
    jobTitle: 'Quality Control Associate',
    isAdmin: false,
    isPreparer: true,
    isReviewer: false,
    isApprover: false,
    assignedRoles: ['Preparer'],
    isMR: false,
    createdAt: '2026-02-10T09:30:00Z',
    lastActive: '2026-06-05T14:22:00Z',
    department: 'PD',
    owningQualityDepartment: 'PD'
  },
  {
    id: 'usr_rev',
    email: 'reviewer@company.com',
    name: 'Marcus Vance',
    jobTitle: 'Senior Quality Specialist',
    isAdmin: false,
    isPreparer: false,
    isReviewer: true,
    isApprover: false,
    assignedRoles: ['Reviewer'],
    isMR: true,
    createdAt: '2026-02-12T11:00:00Z',
    lastActive: '2026-06-05T16:45:00Z',
    department: 'QA',
    owningQualityDepartment: 'QA'
  },
  {
    id: 'usr_app',
    email: 'approver@company.com',
    name: 'Eleanor Vance-Kross',
    jobTitle: 'VP of Regulatory Affairs',
    isAdmin: false,
    isPreparer: false,
    isReviewer: false,
    isApprover: true,
    assignedRoles: ['Approver'],
    isMR: false,
    createdAt: '2026-01-20T10:00:00Z',
    lastActive: '2026-06-04T11:15:00Z',
    department: 'QA',
    owningQualityDepartment: 'QA'
  },
  {
    id: 'usr_multi',
    email: 'john.miller@company.com',
    name: 'John Miller',
    jobTitle: 'Operations & Validation Lead',
    isAdmin: false,
    isPreparer: true,
    isReviewer: true,
    isApprover: true,
    assignedRoles: ['Preparer', 'Reviewer', 'Approver'],
    isMR: true,
    createdAt: '2026-03-01T08:00:00Z',
    lastActive: '2026-06-06T04:10:00Z',
    department: 'PD',
    owningQualityDepartment: 'PD'
  },
  {
    id: 'usr_amit',
    email: 'amit.patel@company.com',
    name: 'Amit Patel',
    jobTitle: 'Quality Assurance Preparer',
    isAdmin: false,
    isPreparer: true,
    isReviewer: false,
    isApprover: false,
    assignedRoles: ['Preparer'],
    isMR: false,
    createdAt: '2026-06-06T07:00:00Z',
    lastActive: '2026-06-06T07:30:00Z',
    password: 'password123',
    department: 'QA',
    owningQualityDepartment: 'QA'
  },
  {
    id: 'usr_priya',
    email: 'priya.shah@company.com',
    name: 'Priya Shah',
    jobTitle: 'Operations Preparer',
    isAdmin: false,
    isPreparer: true,
    isReviewer: false,
    isApprover: false,
    assignedRoles: ['Preparer'],
    isMR: false,
    createdAt: '2026-06-06T07:10:00Z',
    lastActive: '2026-06-06T07:45:00Z',
    password: 'password123',
    department: 'PD',
    owningQualityDepartment: 'PD'
  }
];

export const INITIAL_DOCUMENTS: DocumentWorkflow[] = [
  {
    id: 'DOC-2026-104',
    title: 'SOP-2026-104: Quality Assurance Policy Guidance',
    category: DocumentCategory.SOP,
    department: Department.Quality,
    description: 'Manual on quality standards and regulatory compliance documentation workflows.',
    fileName: '(Awaiting MR Soft Copy)',
    fileSize: 'N/A',
    preparedBy: {
      userId: 'usr_amit',
      userName: 'Amit Patel',
      email: 'amit.patel@company.com'
    },
    status: DocumentStatus.RequestedMR,
    submitTimestamp: '2026-06-06T07:30:00Z',
    comments: [],
    draftContent: '',
    version: '1.0',
    createdAt: '2026-06-06T07:30:00Z'
  },
  {
    id: 'DOC-2026-105',
    title: 'SOP-2026-105: Operations Room Validation',
    category: DocumentCategory.SOP,
    department: Department.Operations,
    description: 'Procedures for cleanroom barometric and sterilizing parameter validations.',
    fileName: '(Awaiting MR Soft Copy)',
    fileSize: 'N/A',
    preparedBy: {
      userId: 'usr_priya',
      userName: 'Priya Shah',
      email: 'priya.shah@company.com'
    },
    status: DocumentStatus.RequestedMR,
    submitTimestamp: '2026-06-06T07:45:00Z',
    comments: [],
    draftContent: '',
    version: '1.0',
    createdAt: '2026-06-06T07:45:00Z'
  },
  {
    id: 'doc_101',
    title: 'SOP-2041: Device Testing Procedure',
    category: DocumentCategory.SOP,
    department: Department.Engineering,
    description: 'Guidelines and testing parameters for medical hardware durability, temperature stress constraints, and safety calibration sequences.',
    fileName: 'SOP-2041_Device_Testing_v1.0.docx',
    fileSize: '412 KB',
    preparedBy: {
      userId: 'usr_prep',
      userName: 'Joseph Chen',
      email: 'preparer@company.com'
    },
    status: DocumentStatus.PendingReview,
    submitTimestamp: '2026-06-04T10:15:00Z',
    comments: [
      {
        id: 'c_1',
        userId: 'usr_prep',
        userName: 'Joseph Chen',
        role: 'Preparer',
        text: 'Initial version uploaded. Rigor studies completed as per ASTM standard F2914-12.',
        timestamp: '2026-06-04T10:15:00Z'
      }
    ],
    draftContent: 'STANDARD OPERATING PROCEDURE: DEVICE TESTING REQUIREMENTS\n\n1. SCOPE\nThis procedure outlines testing specifications for thermal resilience.\n\n2. AUDIT MECHANICS\nAll devices must maintain continuous operation under 50°C for 24 hours.\n\n3. SIGNOFF\nReview and Approval cycles mandatory per FDA CFR 820.30.',
    version: '1.0',
    createdAt: '2026-06-03T14:00:00Z'
  },
  {
    id: 'doc_102',
    title: 'POL-0033: Clinical Cyber Security Protocol',
    category: DocumentCategory.Policy,
    department: Department.Quality,
    description: 'Corporate cybersecurity guidelines for electronic quality records (Part 11) data hygiene, encryption keys rotation, and signature authorization verification controls.',
    fileName: 'POL-0033_Cyber_Security_v1.1.docx',
    fileSize: '1.2 MB',
    preparedBy: {
      userId: 'usr_multi',
      userName: 'John Miller',
      email: 'john.miller@company.com'
    },
    status: DocumentStatus.PendingApproval,
    submitTimestamp: '2026-06-05T09:00:00Z',
    reviewedBy: {
      userId: 'usr_rev',
      userName: 'Marcus Vance',
      email: 'reviewer@company.com',
      timestamp: '2026-06-05T14:30:00Z'
    },
    comments: [
      {
        id: 'c_2',
        userId: 'usr_multi',
        userName: 'John Miller',
        role: 'Preparer',
        text: 'SOP draft contains updated network standards mapped from NIST Framework.',
        timestamp: '2026-06-05T09:00:00Z'
      },
      {
        id: 'c_3',
        userId: 'usr_rev',
        userName: 'Marcus Vance',
        role: 'Reviewer',
        text: 'Reviewed and confirmed encryption controls align with FDA directives on electronic storage logs and tamper-evident hashes. Passed verification.',
        timestamp: '2026-06-05T14:30:00Z'
      }
    ],
    draftContent: 'CORPORATE SECURITY POLICY DIRECTIVE: CLINICAL HYGIENE AND DIGITAL SAFETY\n\n1. INTENT\nSecuring operational devices against digital intrusion.\n\n2. COMPLIANCE METRICS\nEncrypted data packages logged with verifiable checksum protocols.',
    version: '1.1',
    createdAt: '2026-06-05T08:15:00Z'
  },
  {
    id: 'doc_103',
    title: 'FORM-4412: Environmental Deviation Log',
    category: DocumentCategory.Form,
    department: Department.Operations,
    description: 'Mandatory form used to log deviations or critical alerts in clean room barometric pressure and particulate matter levels.',
    fileName: 'FORM-4412_Cleanroom_Env_v1.0.docx',
    fileSize: '184 KB',
    preparedBy: {
      userId: 'usr_prep',
      userName: 'Joseph Chen',
      email: 'preparer@company.com'
    },
    status: DocumentStatus.Draft,
    comments: [],
    draftContent: 'CLEANROOM ENVIRONMENT LOG FORM - VERIFICATION RUNS\n\nField 1: Temperature Threshold (18-22C)\nField 2: Relative Humidity Target (30-50%)\nField 3: Air Change Frequency (Min 20/hr)',
    version: '1.0',
    createdAt: '2026-06-06T02:00:00Z'
  },
  {
    id: 'doc_104',
    title: 'WI-0881: Chemical sterilization protocols',
    category: DocumentCategory.WorkInstruction,
    department: Department.Regulatory,
    description: 'Detailed instructions on handling, safety exposure times, and documentation rules for cleanroom chemical bath operations.',
    fileName: 'WI-0881_Sterilization_Guide_v2.0.docx',
    fileSize: '710 KB',
    preparedBy: {
      userId: 'usr_prep',
      userName: 'Joseph Chen',
      email: 'preparer@company.com'
    },
    status: DocumentStatus.Approved,
    submitTimestamp: '2026-05-20T11:00:00Z',
    reviewedBy: {
      userId: 'usr_rev',
      userName: 'Marcus Vance',
      email: 'reviewer@company.com',
      timestamp: '2026-05-21T09:30:00Z'
    },
    approvedBy: {
      signerId: 'usr_app',
      signerName: 'Eleanor Vance-Kross',
      signerEmail: 'approver@company.com',
      signerTitle: 'VP of Regulatory Affairs',
      timestamp: '2026-05-22T15:10:22Z',
      meaning: 'Final Approving Authority',
      ipAddress: '192.168.12.104',
      hash: 'E9C1FA2537D506BF'
    },
    comments: [
      {
        id: 'c_4',
        userId: 'usr_prep',
        userName: 'Joseph Chen',
        role: 'Preparer',
        text: 'Sterilization parameters updated to strictly match ISO 11135.',
        timestamp: '2026-05-20T11:00:00Z'
      },
      {
        id: 'c_5',
        userId: 'usr_rev',
        userName: 'Marcus Vance',
        role: 'Reviewer',
        text: 'Reviewed. Concentration curves are validated against chemical supply models. Pass.',
        timestamp: '2026-05-21T09:30:00Z'
      }
    ],
    draftContent: 'OPERATIONAL WORK INSTRUCTIONS: CHEMICAL BATH STERILIZATION\n\n1. STANDARDS\nExhaustive gas calibration utilizing safe atmospheric scrubbing units.\n\n2. AUTHORIZED PERSONNEL\nAll handling logs must identify specific validation certifications and supervisor signature tags.',
    version: '2.0',
    createdAt: '2026-05-18T16:00:00Z'
  }
];

export const INITIAL_AUDIT_LOGS: AuditTrailEntry[] = [
  {
    id: 'aud_001',
    timestamp: '2026-05-18T16:00:00Z',
    userId: 'usr_prep',
    userName: 'Joseph Chen',
    userEmail: 'preparer@company.com',
    action: 'DOCUMENT_CREATED',
    details: 'Uploaded Draft: WI-0881_Sterilization_Guide_v2.0.docx',
    ipAddress: '192.168.1.53',
    checksum: generateChecksum('aud_001-DOCUMENT_CREATED-Joseph Chen')
  },
  {
    id: 'aud_002',
    timestamp: '2026-05-20T11:00:00Z',
    userId: 'usr_prep',
    userName: 'Joseph Chen',
    userEmail: 'preparer@company.com',
    action: 'DOCUMENT_SUBMITTED',
    details: 'Submitted WI-0881 to Review Pool',
    ipAddress: '192.168.1.53',
    checksum: generateChecksum('aud_002-DOCUMENT_SUBMITTED-Joseph Chen')
  },
  {
    id: 'aud_003',
    timestamp: '2026-05-21T09:30:00Z',
    userId: 'usr_rev',
    userName: 'Marcus Vance',
    userEmail: 'reviewer@company.com',
    action: 'REVIEW_PASSED',
    details: 'Document WI-0881 evaluation passed. Comments logged.',
    ipAddress: '192.168.1.72',
    checksum: generateChecksum('aud_003-REVIEW_PASSED-Marcus Vance')
  },
  {
    id: 'aud_004',
    timestamp: '2026-05-22T15:10:22Z',
    userId: 'usr_app',
    userName: 'Eleanor Vance-Kross',
    userEmail: 'approver@company.com',
    action: 'E_SIGNED',
    details: 'Approved & Signed WI-0881. Meaning of Signature: Final Approving Authority.',
    ipAddress: '192.168.12.104',
    checksum: generateChecksum('aud_004-E_SIGNED-Eleanor Vance-Kross')
  },
  {
    id: 'aud_005',
    timestamp: '2026-06-03T14:00:00Z',
    userId: 'usr_prep',
    userName: 'Joseph Chen',
    userEmail: 'preparer@company.com',
    action: 'DOCUMENT_CREATED',
    details: 'Uploaded Draft: SOP-2041_Device_Testing_v1.0.docx',
    ipAddress: '192.168.1.53',
    checksum: generateChecksum('aud_005-DOCUMENT_CREATED-Joseph Chen')
  },
  {
    id: 'aud_006',
    timestamp: '2026-06-04T10:15:00Z',
    userId: 'usr_prep',
    userName: 'Joseph Chen',
    userEmail: 'preparer@company.com',
    action: 'DOCUMENT_SUBMITTED',
    details: 'Submitted SOP-2041 to Review Pool',
    ipAddress: '192.168.1.53',
    checksum: generateChecksum('aud_006-DOCUMENT_SUBMITTED-Joseph Chen')
  },
  {
    id: 'aud_007',
    timestamp: '2026-06-05T08:15:00Z',
    userId: 'usr_multi',
    userName: 'John Miller',
    userEmail: 'john.miller@company.com',
    action: 'DOCUMENT_CREATED',
    details: 'Uploaded Draft: POL-0033_Cyber_Security_v1.1.docx',
    ipAddress: '192.168.4.11',
    checksum: generateChecksum('aud_007-DOCUMENT_CREATED-John Miller')
  },
  {
    id: 'aud_008',
    timestamp: '2026-06-05T09:00:00Z',
    userId: 'usr_multi',
    userName: 'John Miller',
    userEmail: 'john.miller@company.com',
    action: 'DOCUMENT_SUBMITTED',
    details: 'Submitted POL-0033 to Review Pool',
    ipAddress: '192.168.4.11',
    checksum: generateChecksum('aud_008-DOCUMENT_SUBMITTED-John Miller')
  },
  {
    id: 'aud_009',
    timestamp: '2026-06-05T14:30:00Z',
    userId: 'usr_rev',
    userName: 'Marcus Vance',
    userEmail: 'reviewer@company.com',
    action: 'REVIEW_PASSED',
    details: 'Document POL-0033 evaluation passed. Mapped compliance requirements.',
    ipAddress: '192.168.1.72',
    checksum: generateChecksum('aud_009-REVIEW_PASSED-Marcus Vance')
  },
  {
    id: 'aud_010',
    timestamp: '2026-06-06T02:00:00Z',
    userId: 'usr_prep',
    userName: 'Joseph Chen',
    userEmail: 'preparer@company.com',
    action: 'DOCUMENT_CREATED',
    details: 'Uploaded Draft: FORM-4412_Cleanroom_Env_v1.0.docx',
    ipAddress: '192.168.1.53',
    checksum: generateChecksum('aud_010-DOCUMENT_CREATED-Joseph Chen')
  }
];

/**
 * MASTER SETUP REGISTRY: PRE-ASSIGNED EMPLOYEE SEED
 * 
 * Paste your list of pre-assigned employee records directly into this array block.
 * When the system boots on a local device or Vercel instance, these profiles are 
 * parsed and registered seamlessly. 
 * 
 * Each record must follow the User interface:
 * {
 *   id: string;                      // Unique ID
 *   email: string;                   // Official Email ID
 *   name: string;                    // Full Employee Name
 *   jobTitle: string;                // Job Title
 *   isAdmin: boolean;                // Is Administrative User
 *   isPreparer: boolean;             // Is Document Preparer (Draft writer)
 *   isReviewer: boolean;             // Is Document Reviewer
 *   isApprover: boolean;             // Is Document Approver
 *   password?: string;               // Passcode/Password for logins (Falls back to 'password123' if undefined)
 *   department?: string;             // Active Department (e.g. 'QA', 'PD', 'RA')
 *   owningQualityDepartment?: string; // Quality jurisdiction (e.g. 'QA', 'PD', 'RA')
 *   isMR?: boolean;                  // Management Representative validation
 *   isActive?: boolean;              // User account active status (Defaults to true)
 *   createdAt: string;               // ISO Timestamp
 *   lastActive: string;              // ISO Timestamp
 * }
 */
export const PRE_ASSIGNED_EMPLOYEES_SEED: User[] = [
  {
    id: 'usr_rbarot',
    email: 'rbarot@premiermedcorp.com',
    name: 'Ronak Barot',
    jobTitle: 'Lead Executive Admin',
    isAdmin: true,
    isPreparer: true,
    isReviewer: true,
    isApprover: true,
    assignedRoles: ['Admin', 'Preparer', 'Reviewer', 'Approver'],
    isMR: true,
    createdAt: '2026-06-06T05:42:00Z',
    lastActive: '2026-06-06T05:42:16Z',
    password: 'Boski@01',
    department: 'QA',
    owningQualityDepartment: 'QA',
    isActive: true
  },
  {
    id: 'usr_admin',
    email: 'admin@company.com',
    name: 'Dr. Samantha Mercer',
    jobTitle: 'QA Director & Admin',
    isAdmin: true,
    isPreparer: false,
    isReviewer: false,
    isApprover: false,
    assignedRoles: ['Admin'],
    isMR: true,
    createdAt: '2026-01-15T08:00:00Z',
    lastActive: '2026-06-06T05:00:00Z',
    department: 'QA',
    owningQualityDepartment: 'QA',
    isActive: true,
    password: 'password123'
  },
  {
    id: 'usr_prep',
    email: 'preparer@company.com',
    name: 'Joseph Chen',
    jobTitle: 'Quality Control Associate',
    isAdmin: false,
    isPreparer: true,
    isReviewer: false,
    isApprover: false,
    assignedRoles: ['Preparer'],
    isMR: false,
    createdAt: '2026-02-10T09:30:00Z',
    lastActive: '2026-06-05T14:22:00Z',
    department: 'PD',
    owningQualityDepartment: 'PD',
    isActive: true,
    password: 'password123'
  },
  {
    id: 'usr_rev',
    email: 'reviewer@company.com',
    name: 'Marcus Vance',
    jobTitle: 'Senior Quality Specialist',
    isAdmin: false,
    isPreparer: false,
    isReviewer: true,
    isApprover: false,
    assignedRoles: ['Reviewer'],
    isMR: true,
    createdAt: '2026-02-12T11:00:00Z',
    lastActive: '2026-06-05T16:45:00Z',
    department: 'QA',
    owningQualityDepartment: 'QA',
    isActive: true,
    password: 'password123'
  },
  {
    id: 'usr_app',
    email: 'approver@company.com',
    name: 'Eleanor Vance-Kross',
    jobTitle: 'VP of Regulatory Affairs',
    isAdmin: false,
    isPreparer: false,
    isReviewer: false,
    isApprover: true,
    assignedRoles: ['Approver'],
    isMR: false,
    createdAt: '2026-01-20T10:00:00Z',
    lastActive: '2026-06-04T11:15:00Z',
    department: 'QA',
    owningQualityDepartment: 'QA',
    isActive: true,
    password: 'password123'
  },
  {
    id: 'usr_multi',
    email: 'john.miller@company.com',
    name: 'John Miller',
    jobTitle: 'Operations & Validation Lead',
    isAdmin: false,
    isPreparer: true,
    isReviewer: true,
    isApprover: true,
    assignedRoles: ['Preparer', 'Reviewer', 'Approver'],
    isMR: true,
    createdAt: '2026-03-01T08:00:00Z',
    lastActive: '2026-06-06T04:10:00Z',
    department: 'PD',
    owningQualityDepartment: 'PD',
    isActive: true,
    password: 'password123'
  },
  {
    id: 'usr_amit',
    email: 'amit.patel@company.com',
    name: 'Amit Patel',
    jobTitle: 'Quality Assurance Preparer',
    isAdmin: false,
    isPreparer: true,
    isReviewer: false,
    isApprover: false,
    assignedRoles: ['Preparer'],
    isMR: false,
    createdAt: '2026-06-06T07:00:00Z',
    lastActive: '2026-06-06T07:30:00Z',
    password: 'password123',
    department: 'QA',
    owningQualityDepartment: 'QA',
    isActive: true
  },
  {
    id: 'usr_priya',
    email: 'priya.shah@company.com',
    name: 'Priya Shah',
    jobTitle: 'Operations Preparer',
    isAdmin: false,
    isPreparer: true,
    isReviewer: false,
    isApprover: false,
    assignedRoles: ['Preparer'],
    isMR: false,
    createdAt: '2026-06-06T07:10:00Z',
    lastActive: '2026-06-06T07:45:00Z',
    password: 'password123',
    department: 'PD',
    owningQualityDepartment: 'PD',
    isActive: true
  }
];
