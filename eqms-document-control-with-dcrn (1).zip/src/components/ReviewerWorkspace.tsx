import React, { useState } from 'react';
import { User, DocumentWorkflow, DocumentStatus, DocumentComment, DEPARTMENT_MAP, DCRNRequest, DCRNDecDocument } from '../types';
import { uploadFileToServer } from '../utils/localUpload';
import { 
  CheckCircle, 
  XCircle, 
  Download, 
  MessageSquare, 
  AlertTriangle, 
  ShieldCheck, 
  UploadCloud, 
  FileText, 
  FileCode, 
  ArrowRight, 
  Clock, 
  Award,
  ListFilter,
  FileCheck2,
  FolderDot
} from 'lucide-react';
import DownloadVaultModal from './DownloadVaultModal';
import { formatToIST } from '../utils/dateUtils';

interface ReviewerWorkspaceProps {
  currentUser: User;
  documents: DocumentWorkflow[];
  onPassReview: (
    docId: string,
    commentText: string,
    reviewerVerifiedUrl?: string,
    fileName?: string,
    fileSize?: string,
    assignedApprover?: { userId: string; userName: string; email: string }
  ) => void;
  onRejectReview: (
    docId: string,
    commentText: string,
    reviewerVerifiedUrl?: string,
    fileName?: string,
    fileSize?: string
  ) => void;
  onAddComment: (docId: string, commentText: string) => void;
  onProvideSoftCopy: (docId: string, draftContent: string, fileName: string, fileSize: string, mrTemplateCopyUrl?: string) => void;
  users: User[];
  dcrnRequests?: DCRNRequest[];
  onUpdateDcrnDocumentField?: (
    requestId: string,
    docNumber: string,
    fields: Partial<DCRNDecDocument>,
    auditAction?: string,
    auditDetails?: string
  ) => void;
}

export default function ReviewerWorkspace({
  currentUser,
  documents,
  onPassReview,
  onRejectReview,
  onAddComment,
  onProvideSoftCopy,
  users,
  dcrnRequests = [],
  onUpdateDcrnDocumentField
}: ReviewerWorkspaceProps) {
  // Categorize document pipelines
  const requestedDocs = documents.filter(doc => doc.status === DocumentStatus.RequestedMR);
  const pendingReviews = documents.filter(doc => doc.status === DocumentStatus.PendingReview && doc.assignedReviewer?.userId === currentUser.id);
  const approvedDocs = documents.filter(doc => doc.status === DocumentStatus.Approved);

  // Compute DCRN Reviews assigned to this reviewer under revision sub-workflow
  const pendingDcrnReviews: { reqId: string; document: DCRNDecDocument; request: DCRNRequest }[] = [];
  (dcrnRequests || []).forEach(req => {
    (req.initialDocs || []).forEach(doc => {
      if (doc.assignedReviewerId === currentUser.id && doc.workflowStatus === 'PendingReview') {
        pendingDcrnReviews.push({ reqId: req.id, document: doc, request: req });
      }
    });
  });

  const [activeBoard, setActiveBoard] = useState<'standard' | 'dcrn'>(
    'dcrn'
  );

  const [selectedDcrnIndex, setSelectedDcrnIndex] = useState<number>(0);
  const [dcrnDecision, setDcrnDecision] = useState<'reject' | 'accept'>('accept');
  const [dcrnComments, setDcrnComments] = useState('');
  const [dcrnApproverId, setDcrnApproverId] = useState('');
  const [dcrnFileName, setDcrnFileName] = useState('');
  const [dcrnFileUrl, setDcrnFileUrl] = useState('');
  const [dcrnError, setDcrnError] = useState('');
  const [dcrnSuccess, setDcrnSuccess] = useState('');

  // Sub Tab Navigation
  const [mrSubTab, setMrSubTab] = useState<'requests' | 'reviews' | 'archive'>(
    requestedDocs.length > 0 ? 'requests' : 'reviews'
  );

  // Selected Target Configurations
  const [selectedRequestId, setSelectedRequestId] = useState<string>('');
  const [selectedReviewId, setSelectedReviewId] = useState<string>('');
  const [selectedArchiveId, setSelectedArchiveId] = useState<string>('');

  // Form Fields for MR Template Provision
  const [templateContent, setTemplateContent] = useState('');
  const [templateFileName, setTemplateFileName] = useState('');
  const [templateFileSize, setTemplateFileSize] = useState('120 KB');

  // Review Remarks
  const [commentInput, setCommentInput] = useState('');
  const [reviewActionComment, setReviewActionComment] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Reviewer Corrected File variables
  const [reviewerFileName, setReviewerFileName] = useState('');
  const [reviewerFileSize, setReviewerFileSize] = useState('');
  const [selectedApproverId, setSelectedApproverId] = useState('');

  // 2-Option decision flow states
  const [decisionOption, setDecisionOption] = useState<'send_back' | 'pass_approver'>('pass_approver');
  const [sendBackFileName, setSendBackFileName] = useState('');
  const [sendBackFileSize, setSendBackFileSize] = useState('');

  // Unified Download Modal State
  const [downloadModalOpen, setDownloadModalOpen] = useState(false);
  const [downloadPayload, setDownloadPayload] = useState<{
    fileName: string;
    fileSize: string;
    fileContent: string;
    checksum: string;
    filePathUrl?: string;
  } | null>(null);

  // Predefined Regulatory Templates
  const CORPORATE_TEMPLATES = [
    {
      name: 'ISO-13485 Calibration Outlines',
      fileName: 'ISO_13485_Equipment_Calibration_Outlines_MR.docx',
      text: 'CLINICAL SPECIFICATION DRAFT: ISO-13485 Equipment calibration ledger.\n\n1.0 PURPOSE:\nEstablish routine inspection thresholds for laboratory scales.\n\n2.0 METHOD:\nPerform reference sweep alignments prior to daily assay production.\n\n3.0 ACCEPTABILITY LIMITS:\nAcceptable variance range resides strictly within ±0.015g limits.'
    },
    {
      name: 'FDA Dev Sterile Cleanroom SOP',
      fileName: 'Cleanroom_Gowning_And_Hygiene_Standards_MR.docx',
      text: 'CLINICAL SPECIFICATION DRAFT: Clinical cleanroom sanitization rules.\n\n1.0 GOWNING REGULATIONS:\nEnforce Level-4 sterile coveralls prior to crossing the primary partition.\n\n2.0 AIR DENSITY CONTROLS:\nPerform particulate index sweeps under pressure chamber guidelines.\n\n3.0 SYSTEM LOGS:\nVerify antiseptic wrist wash logs twice daily.'
    },
    {
      name: 'SOP-Pharma Raw Material Receipt',
      fileName: 'Pharma_Raw_Material_Verification_Form_MR.docx',
      text: 'CLINICAL SPECIFICATION DRAFT: SOP Chemical verification receipt registers.\n\n1.0 INGREDIENTS DESIGNATION:\nCapture manufacturer batch indexes, origin tags, and expiration timelines.\n\n2.0 CHEMICAL STABILITY TASKS:\nCross-verify relative concentration volumes using certified infrared scanners.\n\n3.0 SIGNOFF GUIDELINES:\nStore digital ledger certificates immediately on verify completion.'
    }
  ];

  // Align active structures
  const activeRequest = requestedDocs.find(d => d.id === selectedRequestId) || requestedDocs[0];
  if (activeRequest && activeRequest.id !== selectedRequestId) {
    setSelectedRequestId(activeRequest.id);
  }

  const activeReview = pendingReviews.find(d => d.id === selectedReviewId) || pendingReviews[0];
  if (activeReview && activeReview.id !== selectedReviewId) {
    setSelectedReviewId(activeReview.id);
  }

  const activeArchive = approvedDocs.find(d => d.id === selectedArchiveId) || approvedDocs[0];
  if (activeArchive && activeArchive.id !== selectedArchiveId) {
    setSelectedArchiveId(activeArchive.id);
  }

  // Handle MR Template Apply
  const handleApplyTemplateSelection = (text: string, titleName: string, file: string) => {
    setTemplateContent(text);
    setTemplateFileName(file);
    setTemplateFileSize('128 KB');
  };

  // Submit Soft Copy Provision
  const handleMRUploadSoftCopy = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeRequest) return;
    if (!templateContent.trim()) {
      setErrorMsg('A comprehensive template outline must be written or applied.');
      return;
    }

    const finalFile = templateFileName.trim() || `${activeRequest.id}_MR_Template.docx`;
    const finalUrl = `/vault/mr-templates/${finalFile}`;
    onProvideSoftCopy(activeRequest.id, templateContent.trim(), finalFile, templateFileSize, finalUrl);

    setTemplateContent('');
    setTemplateFileName('');
    setErrorMsg('');

    // Transition view
    if (requestedDocs.length <= 1) {
      setMrSubTab('reviews');
    }
  };

  // Write Approved/Draft Document to download Modal
  const handleDownloadFile = (doc: DocumentWorkflow, customPathType?: 'mrTemplateCopyUrl' | 'preparerDraftUrl' | 'reviewerVerifiedUrl') => {
    const formattedContent = `======================================================================
     CORPORATE ELECTRONIC QUALITY MANAGEMENT SYSTEM (eQMS)
======================================================================
DOCUMENT REFERENCE ID: ${doc.id}
TITLE: ${doc.title}
CATEGORY: ${doc.category}
DEPARTMENT: ${doc.department}
VERSION: v${doc.version}
STATUS: ${doc.status}
AUTHOR: ${doc.preparedBy.userName} (${doc.preparedBy.email})

AUDITED TIMESTAMP OF ASSEMBLY: ${formatToIST(doc.createdAt)}

----------------------------------------------------------------------
SYSTEM INTEGRITY REGISTER (Secure Protected Quality Envelope)
----------------------------------------------------------------------
This file represents an authorized corporate export from eQMS secure 
nodes. File integrity and tampering states are certified recursively.

======================================================================
DOCUMENT TEXT BODY DATA
======================================================================

${doc.draftContent || 'No draft content entered.'}

======================================================================
SYSTEM LOG RECORD HISTORICAL AUDIT
======================================================================
* Pre-checks completed by: ${doc.preparedBy.userName}
* Reviewed and Approved by MR Department Representative: ${doc.reviewedBy?.userName || 'N/A'}
* Comment history logged:
${doc.comments.map(c => `  [${c.userName} - ${c.timestamp.substring(11, 19)}]: "${c.text}"`).join('\n')}

======================================================================
SYSTEM DIGITAL SIGNATURE LOGS
======================================================================
Signer Name: ${doc.approvedBy?.signerName || 'N/A'}
Signer Title: ${doc.approvedBy?.signerTitle || 'N/A'}
Certified Date/Time: ${doc.approvedBy?.timestamp || 'N/A'}
E-Certificate Hash: ${doc.approvedBy?.hash || 'N/A'}
Signing Meaning: ${doc.approvedBy?.meaning || 'N/A'}

======================================================================
END OF CONTROLLED STANDARD COPY QUALITY RECORD
======================================================================
`;

    let pathUrl = doc.finalApprovedCopyUrl || doc.reviewerVerifiedUrl || doc.preparerDraftUrl || doc.mrTemplateCopyUrl;
    if (customPathType) {
      pathUrl = doc[customPathType];
    }

    setDownloadPayload({
      fileName: doc.fileName,
      fileSize: doc.fileSize,
      fileContent: formattedContent,
      checksum: 'docx_' + Math.floor(Math.random() * 90000000 + 10000000).toString(16),
      filePathUrl: pathUrl
    });
    setDownloadModalOpen(true);
  };

  const handleDownloadDcrnPreparedFile = (dcrnDoc: DCRNDecDocument, request: DCRNRequest) => {
    const formattedContent = `======================================================================
     CORPORATE ELECTRONIC QUALITY MANAGEMENT SYSTEM (eQMS)
======================================================================
DCRN REFERENCE ID: ${request.mrRegistryNumber || request.id}
DOCUMENT TARGET ID: ${dcrnDoc.docNumber}
TITLE: ${dcrnDoc.title || 'N/A'}
REVISION INDEX DELTA: ${dcrnDoc.currentRevision} -> ${dcrnDoc.nextRevision}
ACTION TYPE: ${dcrnDoc.actionType || 'Change'}
STATUS: Prepared & Submitted for QA Stage 1 Review

PREPARER: ${request.preparedBy.userName} (${request.preparedBy.email || ''})
REASON FOR CHANGE:
${dcrnDoc.reasonForChange || 'No reason specified'}

CHANGES REQUIRED & DESCRIPTION OF ALTERS:
${dcrnDoc.changesRequired || 'No proposed details entered'}

----------------------------------------------------------------------
SYSTEM INTEGRITY REGISTER (Secure Protected Quality Envelope)
----------------------------------------------------------------------
This file represents an authorized corporate export from eQMS secure 
nodes. File integrity and tampering states are certified recursively.
======================================================================
`;

    setDownloadPayload({
      fileName: dcrnDoc.updatedDocName || dcrnDoc.uploadedFileName || `${dcrnDoc.docNumber}_prepared.docx`,
      fileSize: '120 KB',
      fileContent: formattedContent,
      checksum: 'dcrn_prep_' + Math.floor(Math.random() * 90000000 + 10000000).toString(16),
      filePathUrl: dcrnDoc.updatedDocUrl || dcrnDoc.uploadedUrl
    });
    setDownloadModalOpen(true);
  };

  // Minor comments log
  const handlePostComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentInput.trim() || !activeReview) return;
    onAddComment(activeReview.id, commentInput.trim());
    setCommentInput('');
  };

  // SOP final Approved Action
  const handlePassReviewAction = () => {
    if (!activeReview) return;
    if (reviewActionComment.trim() === '') {
      setErrorMsg('A verification remark is required to summarize your official MR Department approval.');
      return;
    }
    // Validate if reviewer uploaded their corrected file!
    if (!reviewerFileName) {
      setErrorMsg('Validation Error: You must pick and upload your verified/corrected Word Document (.doc, .docx) before passing.');
      return;
    }
    // Force selection of active Approver
    if (!selectedApproverId) {
      setErrorMsg('Validation Error: You must select a specific Approver for the next stage before passing.');
      return;
    }
    const approverUser = (users || []).find(u => u.id === selectedApproverId);
    if (!approverUser) {
      setErrorMsg('Validation Error: The selected Approver is invalid.');
      return;
    }
    const assignedApprover = {
      userId: approverUser.id,
      userName: approverUser.name,
      email: approverUser.email
    };

    onPassReview(
      activeReview.id,
      reviewActionComment.trim(),
      `/vault/reviewer-verified/${reviewerFileName}`,
      reviewerFileName,
      reviewerFileSize,
      assignedApprover
    );
    setReviewerFileName('');
    setReviewerFileSize('');
    setSelectedApproverId('');
    setReviewActionComment('');
    setErrorMsg('');
  };

  // SOP Reject Action
  const handleRejectReviewAction = () => {
    if (!activeReview) return;
    if (reviewActionComment.trim() === '') {
      setErrorMsg('An explicit deficiency explanation is mandatory to execute a document rejection.');
      return;
    }
    const finalUrl = sendBackFileName ? `/vault/reviewer-verified/${sendBackFileName}` : undefined;
    onRejectReview(
      activeReview.id,
      reviewActionComment.trim(),
      finalUrl,
      sendBackFileName || undefined,
      sendBackFileSize || undefined
    );
    setSendBackFileName('');
    setSendBackFileSize('');
    setReviewActionComment('');
    setErrorMsg('');
  };

  // Self Author Conflict Guard
  const isConflict = activeReview && activeReview.preparedBy.userId === currentUser.id;

  return (
    <div className="space-y-4" id="reviewer-workspace-wrapper">
      {/* Primary Workspace Board Selectors */}
      <div className="bg-white border border-slate-200 p-3 rounded-lg flex flex-col sm:flex-row items-center justify-between gap-3 shadow-3xs">
        <div className="flex items-center gap-2">
          <FolderDot className="w-5 h-5 text-indigo-600 shrink-0" />
          <div>
            <h2 className="text-sm font-sans font-bold text-slate-900 leading-tight">Reviewer Desks & Boards</h2>
            <p className="text-[10px] text-slate-500 font-medium">Virtual draft revision committees and change control desks.</p>
          </div>
        </div>
        <div className="flex bg-slate-100 p-1 rounded-lg text-xs font-bold font-mono shrink-0">
          <button
            onClick={() => setActiveBoard('dcrn')}
            className={`px-3.5 py-1.5 rounded-md cursor-pointer transition-all flex items-center gap-1.5 bg-indigo-600 text-white shadow-sm`}
          >
            <FileCheck2 className="w-3.5 h-3.5" />
            <span>DCRN Reviewer Board</span>
            {pendingDcrnReviews.length > 0 && (
              <span className="px-2 py-0.5 bg-red-600 text-white font-mono text-[10px] font-extrabold rounded-md leading-none animate-pulse shadow-sm">
                {pendingDcrnReviews.length}
              </span>
            )}
          </button>
        </div>
      </div>

      {activeBoard === 'dcrn' ? (
        /* ================= DCRN REVIEWER BOARD WORKSPACE ================= */
        <div className="grid grid-cols-1 md:grid-cols-12 gap-5" id="dcrn-reviewer-board-container">
          {/* Left panel: List of pending DCRN reviews */}
          <div className="md:col-span-4 bg-white border border-slate-200 rounded-lg shadow-sm flex flex-col">
            <div className="bg-slate-50 px-4 py-3 border-b border-slate-200 text-xs font-bold font-mono text-indigo-900 uppercase tracking-wider flex items-center justify-between">
              <span>Revision Reviews Board</span>
              <span className="p-0.5 px-2 bg-indigo-100 text-indigo-805 rounded text-[10px] font-bold">
                {pendingDcrnReviews.length} Assigned
              </span>
            </div>

            <div className="divide-y divide-slate-100 flex-1 overflow-y-auto max-h-[550px] min-h-[300px]">
              {pendingDcrnReviews.length === 0 ? (
                <div className="p-8 text-center text-slate-400">
                  <ShieldCheck className="w-10 h-10 mx-auto text-emerald-500 opacity-60 mb-2" />
                  <p className="text-xs font-bold text-slate-705">No Revision Requests</p>
                  <p className="text-[10px] text-slate-500 mt-1">Select standard SOP workspace to process other pipelines.</p>
                </div>
              ) : (
                pendingDcrnReviews.map((item, idx) => (
                  <button
                    key={`${item.reqId}_${item.document.docNumber}`}
                    onClick={() => {
                      setSelectedDcrnIndex(idx);
                      setDcrnSuccess('');
                      setDcrnError('');
                      setDcrnComments('');
                      setDcrnApproverId('');
                      setDcrnFileName('');
                    }}
                    className={`w-full text-left p-3.5 transition-all block cursor-pointer select-none ${
                      selectedDcrnIndex === idx
                        ? 'bg-indigo-50/60 border-l-4 border-l-indigo-600'
                        : 'hover:bg-slate-50/50'
                    }`}
                  >
                    <div className="text-[9.5px] font-mono text-slate-400 font-bold flex justify-between">
                      <span>DCRN: {item.request.mrRegistryNumber || item.reqId}</span>
                    </div>
                    <h4 className="font-bold text-slate-900 mt-1 text-xs select-all">
                      Current target: <span className="font-mono text-indigo-700 font-extrabold">{item.document.docNumber}</span> <span className="text-[10px] bg-slate-100 border border-slate-200 px-1.5 py-0.2 rounded font-sans font-bold text-slate-600">[{item.document.actionType || 'Change'}]</span>
                      {item.document.title && (
                        <span className="block text-[10px] text-indigo-755 font-bold mt-0.5 font-sans normal-case">
                          Title: {item.document.title}
                        </span>
                      )}
                    </h4>

                    {/* List of all documents in this DCRN with active status and reviewer/approver names */}
                    <div className="mt-2 pt-2 border-t border-slate-100 space-y-1.5 animate-fade-in/75">
                      <p className="text-[9px] font-mono font-bold uppercase text-slate-450 tracking-wider">DCRN Document list & statuses:</p>
                      {(item.request.initialDocs || []).map((doc: any, dIdx: number) => {
                        const reviewerName = doc.assignedReviewerName || 
                          users.find(u => u.id === doc.assignedReviewerId)?.name || 
                          'Reviewer';
                        const approverName = doc.assignedApproverName || 
                          users.find(u => u.id === doc.assignedApproverId)?.name || 
                          'Approver';
                        
                        let statusText = '';
                        let statusColor = 'text-slate-500 bg-slate-50 border-slate-200';
                        
                        if (doc.actionType === 'Removal') {
                          statusText = 'Ready for QA Stage-2';
                          statusColor = 'text-emerald-800 bg-emerald-50 border-emerald-250 font-bold';
                        } else {
                          switch (doc.workflowStatus) {
                            case 'PendingReview':
                              statusText = `At Review (${reviewerName})`;
                              statusColor = 'text-amber-850 bg-amber-50 border-amber-200';
                              break;
                            case 'Downloaded':
                              statusText = `Draft Downloaded (Not Yet Submitted)`;
                              statusColor = 'text-violet-805 bg-violet-50/50 border-violet-200';
                              break;
                            case undefined:
                              statusText = `Draft Prepared (Not Yet Submitted)`;
                              statusColor = 'text-slate-600 bg-slate-50 border-slate-200';
                              break;
                            case 'ReviewRejected':
                              statusText = `Review Rejected (${reviewerName})`;
                              statusColor = 'text-rose-750 bg-rose-50 border-rose-200';
                              break;
                            case 'ReviewAccepted':
                              statusText = `Review Accepted (${reviewerName})`;
                              statusColor = 'text-emerald-700 bg-emerald-50 border-emerald-200';
                              break;
                            case 'PendingApproval':
                              statusText = `Pending Approval (${approverName})`;
                              statusColor = 'text-blue-700 bg-blue-50 border-blue-200';
                              break;
                            case 'ApprovalRejected':
                              statusText = `Approval Rejected (${approverName})`;
                              statusColor = 'text-rose-800 bg-rose-100 border-rose-300';
                              break;
                            case 'ApprovalAccepted':
                              statusText = `Approved (${approverName})`;
                              statusColor = 'text-emerald-800 bg-emerald-100 border-emerald-300';
                              break;
                            default:
                              statusText = `${doc.workflowStatus || 'Prepared'}`;
                              statusColor = 'text-slate-700 bg-slate-50 border-slate-200';
                          }
                        }
                        
                        return (
                          <div key={`${doc.docNumber}-${dIdx}`} className="bg-slate-50/80 p-2 rounded border border-slate-105 text-[10px] space-y-0.5">
                            <div className="flex justify-between font-bold">
                              <span className="text-slate-800 font-mono text-left">
                                {doc.docNumber} <span className="text-[9px] bg-indigo-50 border border-indigo-150 px-1 py-0.2 rounded text-indigo-700 font-sans font-extrabold pb-0.5 inline-block">[{doc.actionType || 'Change'}]</span>
                                {doc.title && (
                                  <span className="block text-[9.5px] text-indigo-755 font-semibold font-sans normal-case mt-0.5">
                                    {doc.title}
                                  </span>
                                )}
                              </span>
                              <span className="text-slate-400 font-normal font-mono">{doc.currentRevision} &rarr; {doc.nextRevision}</span>
                            </div>
                            <div className={`inline-block text-[9px] font-bold px-1.5 py-0.5 rounded border mt-1 ${statusColor}`}>
                              {statusText}
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    <div className="flex justify-between items-center text-[9px] mt-2.5 font-mono text-slate-400">
                      <span>By: {item.request.preparedBy?.userName}</span>
                    </div>
                  </button>
                ))
              )}
            </div>
          </div>

          {/* Right panel: Details & Active evaluation action panel */}
          <div className="md:col-span-8 space-y-4">
            {pendingDcrnReviews[selectedDcrnIndex] ? (() => {
              const selectedItem = pendingDcrnReviews[selectedDcrnIndex];
              const req = selectedItem.request;
              const doc = selectedItem.document;
              // Prevent self-review if reviewer is also preparer
              const dcrnConflict = req.preparedBy.userId === currentUser.id;
              const effectiveDecision = dcrnConflict ? 'reject' : dcrnDecision;

              return (
                <div className="space-y-4 animate-fade-in" key={`${req.id}_${doc.docNumber}`}>
                  {/* Conflict alert */}
                  {dcrnConflict && (
                    <div className="bg-rose-50 border border-rose-300 rounded-lg p-4 flex gap-3 text-rose-900 shrink-0">
                      <AlertTriangle className="w-8 h-8 text-rose-600 shrink-0 mt-0.5" />
                      <div>
                        <h3 className="text-xs font-bold uppercase font-mono text-rose-800">CFR PART 11 CONFLICT DETECTED</h3>
                        <p className="text-[11px] mt-1 text-rose-755 font-medium">
                          You are registered as the creator of this DCRN request. Dual authorship controls prevent you from auditing or signing off on your own draft. However, you can still use the <strong>Action REJECT: Send Back to Preparer</strong> panel below to return this document so it can be re-assigned.
                        </p>
                      </div>
                    </div>
                  )}

                  {/* Header info */}
                  <div className="bg-white p-5 border border-slate-200 rounded-lg shadow-sm">
                    <div className="flex flex-col sm:flex-row justify-between items-start gap-3 border-b border-slate-100 pb-3">
                      <div>
                        <span className="px-2 py-0.5 bg-indigo-100 border border-indigo-200 text-indigo-800 font-bold font-mono text-[9px] rounded uppercase">
                          DCRN Revision Draft Review Stage
                        </span>
                        <h3 className="text-sm font-bold text-slate-905 mt-2">
                          DCRN ID assigned by MR: <span className="font-mono text-indigo-750 font-black">{req.mrRegistryNumber || req.id}</span>
                        </h3>
                        <p className="text-[11px] text-slate-500 font-medium mt-1">
                          Preparer: <span className="text-slate-800 font-bold">{req.preparedBy.userName}</span>{doc.uploadedAt || doc.preparedAt || req.createdAt ? ` at ${formatToIST(doc.uploadedAt || doc.preparedAt || req.createdAt)}` : ''}
                        </p>
                      </div>
                      <div className="flex flex-col gap-1 sm:items-end">
                        {doc.updatedDocUrl ? (
                          <button
                            type="button"
                            onClick={() => handleDownloadDcrnPreparedFile(doc, req)}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-[11.5px] font-bold rounded-md shadow-3xs cursor-pointer transition-all shrink-0 select-none border border-indigo-700"
                          >
                            <Download className="w-3.5 h-3.5" />
                            <span>Download Prepared Document</span>
                          </button>
                        ) : (
                          <span className="text-[10px] text-rose-600 font-bold bg-rose-50 p-1 px-2 border border-rose-200 rounded">
                            No Draft Uploaded
                          </span>
                        )}
                        <span className="text-[10.5px] font-mono font-bold text-slate-550">
                          Document Name: <span className="text-indigo-750">{doc.updatedDocName || doc.docNumber}</span>
                        </span>
                      </div>
                    </div>

                    {/* Meta specifications */}
                    <div className="grid grid-cols-2 gap-4 mt-3 text-xs bg-slate-50/50 p-3 rounded border border-slate-150">
                      <div>
                        <span className="text-slate-400 font-mono text-[9px] uppercase block">Document Target ID</span>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="text-slate-800 font-bold font-mono">{doc.docNumber}</span>
                          <span className="text-[10px] bg-indigo-50 border border-indigo-150 px-1.5 py-0.2 rounded font-sans font-bold text-indigo-705">[{doc.actionType || 'Change'}]</span>
                        </div>
                      </div>
                      <div>
                        <span className="text-slate-400 font-mono text-[9px] uppercase block">Action Type</span>
                        <span className="px-2 py-0.5 bg-blue-50 text-blue-700 font-semibold border border-blue-200 rounded font-mono text-[10px] inline-block mt-0.5">{doc.actionType || 'Change'}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 font-mono text-[9px] uppercase block">Revision Index Delta</span>
                        <span className="text-slate-800 font-bold font-mono">{doc.currentRevision} &rarr; {doc.nextRevision}</span>
                      </div>
                      {doc.title && (
                        <div className="col-span-2">
                          <span className="text-slate-400 font-mono text-[9px] uppercase block">Document Title</span>
                          <span className="text-slate-800 font-bold text-[11px]">{doc.title}</span>
                        </div>
                      )}
                      <div className="col-span-2">
                        <span className="text-slate-400 font-mono text-[9px] uppercase block">Reason</span>
                        <p className="text-slate-700 text-[11px] mt-1 font-medium whitespace-pre-line bg-white p-2 border rounded">{doc.reasonForChange || 'No reason specified'}</p>
                      </div>
                      <div className="col-span-2">
                        <span className="text-slate-400 font-mono text-[9px] uppercase block">Proposed Change</span>
                        <p className="text-slate-700 text-[11px] mt-1 font-medium whitespace-pre-line bg-white p-2 border rounded">{doc.changesRequired || 'No instructions entered'}</p>
                      </div>
                    </div>
                  </div>

                  {/* CFR Interactive Desk Panel */}
                  <div className="bg-white p-5 border border-slate-200 rounded-lg shadow-sm space-y-4">
                    <h3 className="text-xs font-black uppercase font-mono tracking-wider text-slate-500 flex items-center gap-1.5 border-b border-slate-100 pb-2">
                      <ShieldCheck className="w-4 h-4 text-indigo-600" />
                      DCRN Revision Review Panel Actions {dcrnConflict && <span className="text-rose-600 font-mono">(CONFLICT REJECT-ONLY)</span>}
                    </h3>

                    {dcrnSuccess && <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-805 text-xs font-semibold rounded">{dcrnSuccess}</div>}
                    {dcrnError && <div className="p-3 bg-rose-50 border border-rose-200 text-rose-805 text-xs font-semibold rounded">{dcrnError}</div>}
                    {/* Decision Choice buttons */}
                    <div className="flex bg-slate-50 p-1.5 rounded-lg text-xs font-black font-mono gap-2 border border-slate-200/60">
                      <button
                        type="button"
                        onClick={() => {
                          setDcrnDecision('reject');
                          setDcrnError('');
                        }}
                        className={`flex-1 py-2 rounded-md transition-all text-center flex items-center justify-center gap-1.5 cursor-pointer ${
                          effectiveDecision === 'reject' 
                            ? 'bg-rose-600 text-white shadow-sm border border-rose-750' 
                            : 'bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200/60'
                        }`}
                      >
                        <XCircle className="w-3.5 h-3.5" />
                        <span>Action REJECT: Send Back to Preparer</span>
                      </button>
                      <button
                        type="button"
                        disabled={!!dcrnConflict}
                        onClick={() => {
                          if (dcrnConflict) return;
                          setDcrnDecision('accept');
                          setDcrnError('');
                        }}
                        className={`flex-1 py-2 rounded-md transition-all text-center flex items-center justify-center gap-1.5 ${
                          dcrnConflict 
                            ? 'opacity-40 cursor-not-allowed text-slate-400 font-normal bg-slate-100 border border-slate-200' 
                            : effectiveDecision === 'accept'
                              ? 'bg-emerald-600 text-white shadow-sm border border-emerald-750 cursor-pointer'
                              : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200/60 cursor-pointer'
                        }`}
                      >
                        <CheckCircle className="w-3.5 h-3.5" />
                        <span>Action ACCEPT: Upload & Forward to Approver {dcrnConflict && "(LOCKED)"}</span>
                      </button>
                    </div>

                    {effectiveDecision === 'reject' ? (
                      /* Reject form */
                      <div className="space-y-3 animate-fade-in">
                        <div>
                          <label className="block text-[10px] font-mono font-bold text-slate-600 uppercase mb-1">Reason for Rejection / Deficiency Specifications *</label>
                          <textarea
                            rows={4}
                            className="w-full text-xs border border-rose-200 rounded p-2 focus:border-rose-400 focus:ring-1 focus:ring-rose-200 text-slate-800 outline-none font-sans"
                            placeholder="Detail exactly why this draft document revision was rejected, and what modifications the preparer needs to perform..."
                            value={dcrnComments}
                            onChange={(e) => setDcrnComments(e.target.value)}
                          />
                        </div>
                        <button
                          onClick={() => {
                            if (!dcrnComments.trim()) {
                              setDcrnError("Rejection remarks are mandatory to log feedback to the preparer.");
                              return;
                            }
                            if (onUpdateDcrnDocumentField) {
                              onUpdateDcrnDocumentField(
                                req.id,
                                doc.docNumber,
                                {
                                  workflowStatus: "ReviewRejected",
                                  reviewerComments: dcrnComments.trim()
                                },
                                "DCRN_REVISION_REJECTED",
                                `Revision document "${doc.docNumber}" in DCRN "${req.id}" has been REJECTED by Reviewer "${currentUser.name}". Feedback: "${dcrnComments.trim()}".`
                              );
                              setDcrnSuccess("Draft has been rejected and returned to the preparer's workspace.");
                              setDcrnComments('');
                              setSelectedDcrnIndex(0);
                            }
                          }}
                          className="w-full py-2 bg-rose-600 hover:bg-rose-700 text-white text-[11px] rounded font-bold transition-all shadow-3xs cursor-pointer text-center uppercase"
                        >
                          Execute Document Rejection & Return
                        </button>
                      </div>
                    ) : (
                      /* Accept form */
                      <div className="space-y-3.5 animate-fade-in text-xs">
                        <div className="bg-slate-50 p-3 rounded border border-slate-205 space-y-2">
                          <label className="block text-[10px] font-sans font-bold text-slate-700 uppercase tracking-widest font-mono">
                            Upload Reviewed copy *
                          </label>
                          <input
                            type="file"
                            accept=".doc, .docx"
                            className="w-full text-xs text-slate-505 file:mr-4 file:py-1 file:px-3 file:rounded file:border-0 file:text-[10px] file:font-semibold file:bg-indigo-100 file:text-indigo-700 hover:file:bg-indigo-200 cursor-pointer"
                            onChange={async (e) => {
                              if (e.target.files && e.target.files[0]) {
                                const file = e.target.files[0];
                                setDcrnFileName(file.name);
                                try {
                                  const result = await uploadFileToServer(file);
                                  if (result.success) {
                                    setDcrnFileUrl(result.url);
                                  }
                                } catch (err) {
                                  console.error("DCRN Reviewed copy upload failed:", err);
                                  setDcrnError("File upload failed. Please try again.");
                                }
                              }
                            }}
                          />
                        </div>

                        <div>
                          <label className="block text-[10.5px] font-semibold text-slate-705 mb-1">Select Approver *</label>
                          <select
                            className="w-full text-xs border border-slate-200 rounded p-1.5 bg-white font-sans text-slate-805 font-medium"
                            value={dcrnApproverId}
                            onChange={(e) => setDcrnApproverId(e.target.value)}
                          >
                            <option value="">-- Click to Assign Final Approver --</option>
                            {users.filter(u => u.isApprover).map(u => (
                              <option key={u.id} value={u.id}>
                                {u.name} ({u.department || 'Management'})
                              </option>
                            ))}
                          </select>
                        </div>

                        <button
                          onClick={() => {
                            if (!dcrnFileName) {
                              setDcrnError("Compliance Error: You must pick and upload your verified Word Document Copy (.docx) before forwarding.");
                              return;
                            }
                            if (!dcrnApproverId) {
                              setDcrnError("Validation Error: Please select an official Approver from the list.");
                              return;
                            }
                            const appUser = users.find(u => u.id === dcrnApproverId);
                            const appName = appUser ? appUser.name : dcrnApproverId;

                            if (onUpdateDcrnDocumentField) {
                              onUpdateDcrnDocumentField(
                                req.id,
                                doc.docNumber,
                                {
                                  workflowStatus: "PendingApproval",
                                  assignedApproverId: dcrnApproverId,
                                  assignedApproverName: appName,
                                  reviewedDocUrl: dcrnFileUrl || `/vault/reviewed-verified/${dcrnFileName}`,
                                  reviewedDocName: dcrnFileName,
                                  reviewerComments: "",
                                  reviewedAt: new Date().toISOString()
                                },
                                "DCRN_REVISION_ACCEPTED",
                                `Revision document "${doc.docNumber}" in DCRN "${req.id}" was accepted by Reviewer "${currentUser.name}" and forwarded to Approver "${appName}" with copy "${dcrnFileName}".`
                              );
                              setDcrnSuccess("Draft has been accepted and forwarded to the final Approver's Vault!"); setDcrnFileUrl('');
                              setDcrnComments('');
                              setDcrnApproverId('');
                              setDcrnFileName('');
                              setSelectedDcrnIndex(0);
                            }
                          }}
                          className="w-full py-2 bg-indigo-600 hover:bg-slate-800 text-white text-[11px] rounded font-bold transition-all shadow-2xs hover:shadow-md cursor-pointer text-center uppercase"
                        >
                          Forward for Approve
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })() : (
              <div className="bg-white p-12 border border-slate-200 rounded-lg shadow-sm text-center text-slate-400">
                <ShieldCheck className="w-12 h-12 mx-auto text-emerald-500 opacity-65 mb-2.5" />
                <h3 className="text-sm font-bold text-slate-800">CFR Revision Board Queue Clear</h3>
                <p className="text-xs text-slate-500 mt-1">There are no pending DCRN revision documents awaiting your board signature.</p>
              </div>
            )}
          </div>
        </div>
      ) : (
        /* ================= STANDARD SOP WORKSPACE ================= */
        <div className="grid grid-cols-1 md:grid-cols-12 gap-5" id="reviewer-workspace-container">
          {/* Sidebar: Open workflow desks */}
          <div className="md:col-span-4 bg-white border border-slate-200 rounded-lg shadow-sm flex flex-col">
            {/* Navigation Tabs bar */}
            <div className="flex border-b border-slate-200 text-xs font-bold font-mono">
          <button
            onClick={() => setMrSubTab('requests')}
            className={`flex-1 py-3 text-center cursor-pointer border-b-2 transition-all flex items-center justify-center gap-1 ${
              mrSubTab === 'requests'
                ? 'border-blue-600 text-blue-700 bg-blue-50/10'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
            id="btn-tab-soft-copy-requests"
          >
            Requested Copy ({requestedDocs.length})
          </button>
          <button
            onClick={() => setMrSubTab('reviews')}
            className={`flex-1 py-3 text-center cursor-pointer border-b-2 transition-all flex items-center justify-center gap-1 ${
              mrSubTab === 'reviews'
                ? 'border-blue-600 text-blue-700 bg-blue-50/10'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
            id="btn-tab-sop-reviews"
          >
            Reviews Pending ({pendingReviews.length})
          </button>
          <button
            onClick={() => setMrSubTab('archive')}
            className={`flex-1 py-3 text-center cursor-pointer border-b-2 transition-all flex items-center justify-center gap-1 ${
              mrSubTab === 'archive'
                ? 'border-blue-600 text-blue-700 bg-blue-50/10'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
            id="btn-tab-approved-archives"
          >
            Approved SOPs ({approvedDocs.length})
          </button>
        </div>

        {/* Sidebar Roster list */}
        <div className="divide-y divide-slate-100 flex-1 overflow-y-auto max-h-[550px]">
          {mrSubTab === 'requests' && (
            requestedDocs.length === 0 ? (
              <div className="p-8 text-center text-slate-400">
                <ShieldCheck className="w-10 h-10 mx-auto text-emerald-500 opacity-60 mb-2" />
                <p className="text-xs font-bold text-slate-700">No Pending Requests</p>
                <p className="text-[10px] text-slate-500 mt-1">All soft copy templates are provisioned.</p>
              </div>
            ) : (
              requestedDocs.map((doc) => (
                <button
                  key={doc.id}
                  onClick={() => setSelectedRequestId(doc.id)}
                  className={`w-full text-left p-3.5 transition-all block cursor-pointer select-none ${
                    selectedRequestId === doc.id
                      ? 'bg-blue-50/60 border-l-4 border-l-blue-600'
                      : 'hover:bg-slate-50/50'
                  }`}
                  id={`btn-select-req-${doc.id}`}
                >
                  <div className="text-[9px] font-mono text-slate-400 font-bold">{doc.id}</div>
                  <h4 className="font-bold text-slate-900 mt-1 line-clamp-1 text-xs">
                    {doc.title}
                  </h4>
                  <div className="text-[10px] text-slate-500 mt-0.5">{doc.category} - {doc.department}</div>
                  <div className="flex justify-between items-center text-[9px] mt-2 font-mono text-slate-400">
                    <span>By: {doc.preparedBy.userName}</span>
                    <span className="text-blue-600 font-semibold flex items-center gap-0.5">
                      <Clock className="w-2.5 h-2.5" />
                      Pending Provision
                    </span>
                  </div>
                </button>
              ))
            )
          )}

          {mrSubTab === 'reviews' && (() => {
            if (pendingReviews.length === 0) {
              return (
                <div className="p-8 text-center text-slate-400">
                  <ShieldCheck className="w-10 h-10 mx-auto text-emerald-500 opacity-60 mb-2" />
                  <p className="text-xs font-bold text-slate-700">Review Pipeline Clear</p>
                  <p className="text-[10px] text-slate-500 mt-1">No documents in review queues.</p>
                </div>
              );
            }

            const groupedReviews: { [dept: string]: DocumentWorkflow[] } = {};
            pendingReviews.forEach(doc => {
              const creator = (users || []).find(u => u.id === doc.preparedBy.userId);
              const deptKey = creator?.department || 'QA';
              if (!groupedReviews[deptKey]) {
                groupedReviews[deptKey] = [];
              }
              groupedReviews[deptKey].push(doc);
            });

            const sortedDepts = Object.keys(groupedReviews).sort();

            return (
              <div className="flex flex-col">
                {/* Table Header Row */}
                <div className="bg-slate-50/80 px-4 py-2 border-b border-slate-200 text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider grid grid-cols-12 gap-2 select-none">
                  <div className="col-span-8">Document Details</div>
                  <div className="col-span-4 text-right">Requested By</div>
                </div>
                <div className="divide-y divide-slate-200">
                  {sortedDepts.map((dept) => (
                    <div key={dept} className="flex flex-col bg-slate-50/30" id={`reviews-group-${dept.toLowerCase()}`}>
                      {/* Department Heading Section Block */}
                      <div className="bg-slate-100 px-4 py-1.5 text-[10px] font-bold font-mono text-slate-700 uppercase tracking-wider border-y border-slate-200 flex items-center justify-between select-none">
                        <span>Department: {DEPARTMENT_MAP[dept] || dept} ({dept})</span>
                        <span className="p-0.5 px-2 bg-slate-200 rounded text-slate-805 text-[9px] font-bold">
                          {groupedReviews[dept].length} {groupedReviews[dept].length === 1 ? 'Doc' : 'Docs'}
                        </span>
                      </div>
                      <div className="divide-y divide-slate-100 bg-white">
                        {groupedReviews[dept].map((doc) => {
                          const hasConflict = doc.preparedBy.userId === currentUser.id;
                          return (
                            <button
                              key={doc.id}
                              onClick={() => setSelectedReviewId(doc.id)}
                              className={`w-full text-left p-3.5 transition-all block cursor-pointer select-none ${
                                selectedReviewId === doc.id
                                  ? 'bg-blue-50/60 border-l-4 border-l-blue-600'
                                  : 'hover:bg-slate-50/50'
                              }`}
                              id={`btn-select-rev-${doc.id}`}
                            >
                              <div className="grid grid-cols-12 gap-2 items-center">
                                <div className="col-span-8">
                                  <div className="flex justify-between items-center text-[9px] font-mono text-slate-500">
                                    <span className="font-bold text-blue-700">{doc.id}</span>
                                    <span className="font-semibold text-slate-400">{doc.version}</span>
                                  </div>
                                  <h4 className="font-bold text-slate-900 mt-1 line-clamp-1 text-xs">
                                    {doc.title}
                                  </h4>
                                  <div className="text-[10px] text-slate-500 mt-0.5 line-clamp-1">{doc.category}</div>
                                  {hasConflict && (
                                    <span className="inline-block mt-1 bg-rose-100 text-rose-800 px-1.5 py-0.5 rounded text-[8px] font-bold border border-rose-200 uppercase tracking-widest font-mono">
                                      Author Conflict
                                    </span>
                                  )}
                                </div>
                                <div className="col-span-4 text-right shrink-0">
                                  <span className="text-[11px] font-semibold text-slate-800 block truncate" title={doc.preparedBy.userName}>
                                    {doc.preparedBy.userName}
                                  </span>
                                  <span className="text-[9px] font-mono text-slate-400 block mt-0.5">Preparer</span>
                                </div>
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })()}

          {mrSubTab === 'archive' && (
            approvedDocs.length === 0 ? (
              <div className="p-8 text-center text-slate-400">
                <ShieldCheck className="w-10 h-10 mx-auto text-slate-300 opacity-60 mb-2" />
                <p className="text-xs font-bold text-slate-700">No Approved Records Archive</p>
                <p className="text-[10px] text-slate-500 mt-1">SOP records will populate here on MR signature.</p>
              </div>
            ) : (
              approvedDocs.map((doc) => (
                <button
                  key={doc.id}
                  onClick={() => setSelectedArchiveId(doc.id)}
                  className={`w-full text-left p-3.5 transition-all block cursor-pointer select-none ${
                    selectedArchiveId === doc.id
                      ? 'bg-emerald-50/50 border-l-4 border-l-emerald-600'
                      : 'hover:bg-slate-50/50'
                  }`}
                  id={`btn-select-arch-${doc.id}`}
                >
                  <div className="text-[9px] font-mono text-emerald-600 font-bold">SOP APPROVED</div>
                  <h4 className="font-bold text-slate-900 mt-0.5 line-clamp-1 text-xs">
                    {doc.title}
                  </h4>
                  <div className="text-[10px] text-slate-500 mt-0.5">{doc.id} - {doc.category}</div>
                  <div className="flex justify-between items-center text-[9px] mt-2 font-mono text-slate-400">
                    <span>By: {doc.preparedBy.userName}</span>
                    <span className="text-emerald-600 font-bold">RELEASED</span>
                  </div>
                </button>
              ))
            )
          )}
        </div>
      </div>

      {/* Main Board Workspace */}
      <div className="md:col-span-8 space-y-5">
        
        {/* VIEW 1: SOFT COPY PROVISION (MR Department uploads soft copy) */}
        {mrSubTab === 'requests' && (
          activeRequest ? (
            <div className="space-y-4">
              <div className="bg-indigo-50 border border-indigo-205 text-indigo-900 text-xs p-4 rounded-lg flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 shadow-xs">
                <div>
                  <div className="font-bold flex items-center gap-1.5">
                    <span className="inline-block w-2 h-2 rounded-full bg-indigo-600 animate-ping"></span>
                    <span>Dedicated Document Request Roster Active</span>
                  </div>
                  <p className="text-[11px] text-indigo-650 mt-1">
                    Fulfill requests sequentially here, or use the Workspace Dashboard to search, sort, and track existing document records.
                  </p>
                </div>
              </div>

              <div className="bg-white p-5 border border-slate-200 rounded-lg shadow-sm">
                <div className="border-b border-slate-100 pb-3">
                  <span className="text-[9.5px] font-mono font-bold bg-blue-100 text-blue-800 border border-blue-200 px-1.5 py-0.5 rounded uppercase">
                    Soft Copy Requested by Preparer
                  </span>
                  <h3 className="text-base font-bold text-slate-900 mt-2 leading-tight">
                    {activeRequest.title}
                  </h3>
                  <p className="text-xs text-slate-500 font-medium mt-1">
                    Preparer profile: <span className="font-semibold text-slate-800">{activeRequest.preparedBy.userName}</span>{activeRequest.submitTimestamp || activeRequest.createdAt ? ` at ${formatToIST(activeRequest.submitTimestamp || activeRequest.createdAt)}` : ''}
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4 mt-3 text-xs bg-slate-50/50 p-3 rounded border border-slate-150">
                  <div>
                    <span className="text-slate-400 font-mono text-[9px] uppercase block">Procedural Category</span>
                    <span className="text-slate-800 font-bold">{activeRequest.category}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 font-mono text-[9px] uppercase block">Quality Department Scope</span>
                    <span className="text-slate-800 font-bold">{activeRequest.department}</span>
                  </div>
                  <div className="col-span-2">
                    <span className="text-slate-400 font-mono text-[9px] uppercase block">Change Rationale Synopsis</span>
                    <p className="text-slate-700 text-xs mt-1 leading-snug font-medium whitespace-pre-line">{activeRequest.description}</p>
                  </div>
                </div>
              </div>

              {/* Template Formulation and "Upload Soft Copy" Desk */}
              <form onSubmit={handleMRUploadSoftCopy} className="bg-white p-5 border border-slate-200 rounded-lg shadow-sm space-y-4">
                <h3 className="text-xs font-bold uppercase font-mono tracking-wider text-slate-500 flex items-center gap-1 border-b border-slate-100 pb-2">
                  <UploadCloud className="w-4 h-4 text-blue-600" />
                  Upload Corporate Soft Copy Template
                </h3>

                {errorMsg && (
                  <div className="p-3 bg-rose-50 border border-rose-250 text-rose-800 font-semibold text-xs rounded">
                    {errorMsg}
                  </div>
                )}

                <div className="bg-slate-50 p-4 border border-slate-200 rounded-lg space-y-2">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-widest font-mono">
                    Upload Actual Word Copy (.doc, .docx) *
                  </label>
                  <input
                    type="file"
                    accept=".doc, .docx"
                    id="reviewer-mr-upload-file-picker"
                    name="reviewer-mr-upload-file-picker"
                    onChange={async (e) => {
                      if (e.target.files && e.target.files[0]) {
                        const file = e.target.files[0];
                        if (file.name.endsWith('.doc') || file.name.endsWith('.docx')) {
                          setTemplateFileName(file.name);
                          setTemplateFileSize((file.size / 1024).toFixed(0) + ' KB');
                          setErrorMsg('');
                          try {
                            const result = await uploadFileToServer(file);
                            if (result.success) {
                              console.log("Template saved in LAN office storage:", result.url);
                            }
                          } catch (err) {
                            setErrorMsg('LAN local storage write failed. Parameters accepted.');
                          }
                        } else {
                          setErrorMsg('Compliance Error: Only Word Documents (.doc, .docx) are accepted.');
                          setTemplateFileName('');
                        }
                      }
                    }}
                    className="w-full text-xs text-slate-500 file:mr-4 file:py-1.5 file:px-3 file:rounded file:border-0 file:text-[11px] file:font-semibold file:bg-blue-100 file:text-blue-700 hover:file:bg-blue-200 cursor-pointer"
                    required
                  />
                </div>

                <div className="grid md:grid-cols-12 gap-4">
                  {/* Left formulation forms */}
                  <div className="md:col-span-7 space-y-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Corporate File Name Asset (*.docx)</label>
                      <input
                        type="text"
                        value={templateFileName}
                        onChange={(e) => setTemplateFileName(e.target.value)}
                        placeholder="e.g., SOP_Calibration_Template.docx"
                        className="w-full bg-slate-50 border border-slate-250 focus:border-blue-500 focus:bg-white rounded p-2 text-xs font-mono text-slate-800 outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Initial Template Body Content / Quality Instructions</label>
                      <textarea
                        rows={7}
                        value={templateContent}
                        onChange={(e) => setTemplateContent(e.target.value)}
                        placeholder="Inject standard outlines and instructions for the preparer to finalize..."
                        className="w-full bg-slate-50 border border-slate-250 focus:border-blue-500 focus:bg-white rounded p-2.5 text-xs font-mono text-slate-800 outline-none"
                      />
                    </div>
                  </div>

                  {/* Right quick outlines */}
                  <div className="md:col-span-5 bg-slate-50/60 p-3.5 rounded border border-slate-150 space-y-2.5">
                    <h4 className="text-[10px] font-bold font-mono text-slate-400 uppercase tracking-widest flex items-center gap-0.5">
                      <FileCode className="w-3.5 h-3.5 text-blue-600" />
                      Quick Outline library
                    </h4>
                    <p className="text-[10px] text-slate-500 leading-snug">
                      Apply an official corporate skeletal structure to auto-populate the document workspace coordinates instantly:
                    </p>

                    <div className="space-y-1.5 pt-1">
                      {CORPORATE_TEMPLATES.map((tmpl) => (
                        <button
                          key={tmpl.name}
                          type="button"
                          onClick={() => handleApplyTemplateSelection(tmpl.text, tmpl.name, tmpl.fileName)}
                          className="w-full text-left p-2 rounded bg-white hover:bg-blue-50 border border-slate-200 hover:border-blue-300 text-xs transition-colors flex items-center justify-between font-medium text-slate-700 cursor-pointer"
                        >
                          <span className="truncate max-w-[200px]">{tmpl.name}</span>
                          <ArrowRight className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="flex justify-end pt-2 border-t border-slate-100">
                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-slate-100 text-xs font-bold rounded-lg flex items-center gap-2 cursor-pointer border border-blue-400/20"
                    id="btn-upload-soft-copy"
                  >
                    <UploadCloud className="w-4 h-4" />
                    <span>Upload Soft Copy</span>
                  </button>
                </div>
              </form>
            </div>
          ) : (
            <div className="bg-white p-12 border border-slate-200 rounded-lg shadow-sm text-center text-slate-400">
              <ShieldCheck className="w-12 h-12 mx-auto text-emerald-500 opacity-65 mb-2.5" />
              <h3 className="text-base font-bold text-slate-800">Clear of Requests</h3>
              <p className="text-xs text-slate-500 mt-1">There are no pending soft copy template requests from Preparers.</p>
            </div>
          )
        )}

        {/* VIEW 2: SOP PENDING QUALITY REVIEWS & DECISIONS */}
        {mrSubTab === 'reviews' && (
          activeReview ? (
            <div className="space-y-4">
              {/* Conflict banner */}
              {isConflict && (
                <div className="bg-rose-50 border-2 border-rose-300 rounded-lg p-4 flex gap-3 text-rose-900 animate-pulse" id="conflict-compliance-block">
                  <AlertTriangle className="w-8 h-8 text-rose-600 shrink-0 mt-0.5" />
                  <div>
                    <h3 className="text-xs font-bold uppercase font-mono tracking-wider text-rose-800">
                      CFR PART 11 INTERNAL CONFLICT DETECTED
                    </h3>
                    <p className="text-[11px] mt-1 text-rose-700 leading-relaxed">
                      You are logged as the <span className="font-bold underline">Author of Record</span> for this SOP draft ({activeReview.preparedBy.userName}). Security regulations prohibit self-reviewing your own creations. Review actions are locked.
                    </p>
                  </div>
                </div>
              )}

              {/* Review details */}
              <div className="bg-white p-5 border border-slate-200 rounded-lg shadow-sm">
                <div className="flex flex-col sm:flex-row justify-between items-start gap-3 border-b border-slate-100 pb-3.5">
                  <div>
                    <span className="text-[9.5px] font-mono font-bold bg-slate-100 text-slate-500 border border-slate-200 px-1.5 py-0.5 rounded uppercase">
                      {activeReview.version} - Review Draft
                    </span>
                    <h3 className="text-base font-bold text-slate-900 mt-1.5 leading-snug">{activeReview.title}</h3>
                    <p className="text-[11px] text-slate-500 font-medium mt-1">
                      Author: <span className="text-slate-850 font-semibold">{activeReview.preparedBy.userName}</span>{activeReview.submitTimestamp || activeReview.createdAt ? ` at ${formatToIST(activeReview.submitTimestamp || activeReview.createdAt)}` : ''}
                    </p>
                  </div>

                  <div className="flex flex-col items-end gap-1.5 shrink-0 self-start">
                    {activeReview.preparerDraftUrl && (
                      <button
                        type="button"
                        onClick={() => handleDownloadFile(activeReview, 'preparerDraftUrl')}
                        className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded flex items-center gap-1.5 cursor-pointer transition-colors border border-blue-400/20 shadow-xs"
                        id="btn-reviewer-download-preparer-draft"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Download Preparer's Edited Draft (.docx)</span>
                      </button>
                    )}
                    <span className="text-red-650 bg-red-50 border border-red-200 text-[10px] font-mono font-bold px-2 py-1 rounded inline-flex items-center gap-1 select-none mt-1" title="All downloads are strictly locked until approved by the MR department.">
                      <XCircle className="w-3.5 h-3.5 text-red-500" />
                      Final Download Locked
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mt-3 text-xs bg-slate-50/40 p-3 rounded border border-slate-150">
                  <div>
                    <span className="text-slate-400 font-mono text-[9px] uppercase block">Category</span>
                    <span className="text-slate-805 font-bold">{activeReview.category}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 font-mono text-[9px] uppercase block">Quality Department Scope</span>
                    <span className="text-slate-805 font-bold">{activeReview.department}</span>
                  </div>
                  <div className="col-span-2">
                    <span className="text-slate-400 font-mono text-[9px] uppercase block">Change Rationale Summary</span>
                    <p className="text-slate-700 text-xs mt-0.5 leading-snug font-medium whitespace-pre-wrap">{activeReview.description}</p>
                  </div>
                </div>
              </div>

              {/* Document Text Body preview */}
              <div className="bg-white border border-slate-200 rounded-lg shadow-sm">
                <div className="bg-slate-50 border-b border-slate-200 px-4 py-2 font-mono text-[10px] text-slate-500 flex items-center justify-between">
                  <span>Document Editor Preview - Read-Only during verification cycle</span>
                  <span className="text-blue-600 font-bold text-[9px] uppercase tracking-wide">Secure Preview</span>
                </div>
                <div className="p-5 bg-slate-100 max-h-72 overflow-y-auto">
                  <div className="bg-white p-5 shadow-sm border border-slate-200 rounded font-mono text-xs leading-relaxed text-slate-800 whitespace-pre-wrap min-h-48 select-all">
                    {activeReview.draftContent || '(No content has been formulated inside the template yet.)'}
                  </div>
                </div>
              </div>

              {/* History list */}
              <div className="bg-white border border-slate-200 rounded-lg shadow-sm p-4 space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1 border-b border-slate-100 pb-2">
                  <MessageSquare className="w-4 h-4 text-slate-400" />
                  Designated SOP Comments & History ({activeReview.comments.length})
                </h4>

                <div className="space-y-2 max-h-40 overflow-y-auto">
                  {activeReview.comments.length === 0 ? (
                    <p className="text-[11px] text-slate-400 italic">No notes logged for this procedure.</p>
                  ) : (
                    activeReview.comments.map((comment) => (
                      <div key={comment.id} className="p-2.5 rounded bg-slate-50 border border-slate-150 text-xs">
                        <div className="flex justify-between items-center text-[10px] text-slate-400 border-b border-slate-100 pb-1 mb-1 font-mono">
                          <span className="font-semibold text-slate-700">{comment.userName} ({comment.role})</span>
                          <span>{formatToIST(comment.timestamp)} ITC</span>
                        </div>
                        <p className="text-slate-750 font-medium">{comment.text}</p>
                      </div>
                    ))
                  )}
                </div>

                <form onSubmit={handlePostComment} className="flex gap-2 pt-2 border-t border-slate-100">
                  <input
                    type="text"
                    value={commentInput}
                    onChange={(e) => setCommentInput(e.target.value)}
                    placeholder="Log feedback note..."
                    className="flex-1 bg-slate-50 border border-slate-200 rounded px-3 py-1.5 text-xs text-slate-800 outline-none focus:border-blue-500 focus:bg-white"
                  />
                  <button
                    type="submit"
                    disabled={isConflict}
                    className="bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-white text-xs px-4 py-1.5 rounded cursor-pointer disabled:cursor-not-allowed font-semibold"
                  >
                    Post Note
                  </button>
                </form>
              </div>

              {/* Workflow Decision */}
              <div className={`bg-white border border-slate-200 rounded-lg shadow-sm p-5 space-y-4 ${
                isConflict ? 'opacity-40 pointer-events-none' : ''
              }`}>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-650 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-slate-500" />
                  Execute MR Department Official Quality Decision
                </h4>

                {errorMsg && (
                  <div className="p-3 bg-rose-50 border border-rose-220 text-rose-800 text-xs font-semibold rounded">
                    {errorMsg}
                  </div>
                )}

                {/* TWO DESIGNATED WORKSPACE OPTIONS */}
                <div className="flex bg-slate-100 p-1 rounded-lg text-[10.5px] font-bold font-mono">
                  <button
                    type="button"
                    onClick={() => {
                      setDecisionOption('send_back');
                      setErrorMsg('');
                    }}
                    className={`flex-1 py-2 rounded-md transition-all text-center flex items-center justify-center gap-1.5 cursor-pointer ${
                      decisionOption === 'send_back'
                        ? 'bg-rose-600 text-white shadow-sm'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
                    }`}
                  >
                    <XCircle className="w-3.5 h-3.5" />
                    <span>Option 1: Send Back with Remarks</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setDecisionOption('pass_approver');
                      setErrorMsg('');
                    }}
                    className={`flex-1 py-2 rounded-md transition-all text-center flex items-center justify-center gap-1.5 cursor-pointer ${
                      decisionOption === 'pass_approver'
                        ? 'bg-emerald-600 text-white shadow-sm'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
                    }`}
                  >
                    <CheckCircle className="w-3.5 h-3.5" />
                    <span>Option 2: Pass/Upload to Approver</span>
                  </button>
                </div>

                {decisionOption === 'send_back' ? (
                  /* Option 1 UI: Sent back to preparer with additional remarks and upload option */
                  <div className="space-y-3.5 text-xs animate-fade-in">
                    <p className="text-slate-500 leading-relaxed text-[11px]">
                      Specify alignment deficiencies and audit remarks below. You can also optionally upload an edited or annotated copy of the file with your redlines so the preparer can download it.
                    </p>

                    <div className="bg-slate-50 p-4 border border-rose-100 rounded-lg space-y-2">
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider font-mono">
                        Upload Marked-Up/Redlined Copy (Optional)
                      </label>
                      <input
                        type="file"
                        accept=".doc, .docx"
                        id="reviewer-sendback-file-picker"
                        name="reviewer-sendback-file-picker"
                        onChange={async (e) => {
                          if (e.target.files && e.target.files[0]) {
                            const file = e.target.files[0];
                            if (file.name.endsWith('.doc') || file.name.endsWith('.docx')) {
                              setSendBackFileName(file.name);
                              setSendBackFileSize((file.size / 1024).toFixed(0) + ' KB');
                              setErrorMsg('');
                              try {
                                const result = await uploadFileToServer(file);
                                if (result.success) {
                                  console.log("Sendback file saved in LAN storage:", result.url);
                                }
                              } catch (err) {
                                setErrorMsg('LAN local storage write failed. Parameters accepted.');
                              }
                            } else {
                              setErrorMsg('Compliance Error: Only Word Documents (.doc, .docx) are accepted.');
                              setSendBackFileName('');
                            }
                          }
                        }}
                        className="w-full text-xs text-slate-500 file:mr-4 file:py-1.5 file:px-3 file:rounded file:border-0 file:text-[11px] file:font-semibold file:bg-rose-50 file:text-rose-700 hover:file:bg-rose-100 cursor-pointer"
                      />

                      {sendBackFileName && (
                        <div className="text-[11px] text-rose-700 font-mono font-medium flex items-center gap-1.5 bg-rose-50 p-2 border border-rose-200 rounded">
                          <CheckCircle className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                          <span>Redlined Copy Staged: {sendBackFileName} ({sendBackFileSize})</span>
                        </div>
                      )}
                    </div>

                    <div className="space-y-1.5">
                      <label className="block text-xs font-bold text-slate-700">Additional Remarks & Deficiencies *</label>
                      <textarea
                        rows={3}
                        value={reviewActionComment}
                        onChange={(e) => { setReviewActionComment(e.target.value); setErrorMsg(''); }}
                        placeholder="Log instructions specifying missing details or clauses to reformulate..."
                        className="w-full bg-slate-50 border border-slate-255 focus:border-rose-550 focus:bg-white rounded p-2.5 text-xs text-slate-800 outline-none font-sans"
                        id="review-sendback-comment-input"
                      />
                    </div>

                    <div className="flex justify-end pt-1">
                      <button
                        type="button"
                        onClick={handleRejectReviewAction}
                        disabled={isConflict}
                        className="px-5 py-2.5 bg-rose-600 hover:bg-rose-555 text-white border border-rose-500 rounded-lg flex items-center gap-1.5 shadow-sm font-bold text-xs cursor-pointer transition-colors"
                        id="btn-reject-review"
                      >
                        <XCircle className="w-4 h-4" />
                        <span>Send Back to Preparer</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  /* Option 2 UI: Upload final reviewed copy to the approver after selection from list */
                  <div className="space-y-3.5 text-xs animate-fade-in">
                    <p className="text-slate-500 leading-relaxed text-[11px]">
                      Confirm verification to the approver. Standard compliance requires importing a qualified final reviewed Word document, selecting an active approval officer, and logging your summary remarks.
                    </p>

                    <div className="bg-slate-50 p-4 border border-indigo-100 rounded-lg space-y-2">
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider font-mono">
                        Assign Specific Approver for Next Stage *
                      </label>
                      <select
                        value={selectedApproverId}
                        onChange={(e) => {
                          setSelectedApproverId(e.target.value);
                          setErrorMsg('');
                        }}
                        className="w-full text-xs bg-white border border-slate-300 rounded p-2 text-slate-800 outline-none font-sans focus:border-indigo-500 cursor-pointer"
                        required
                      >
                        <option value="">-- Select Active Approver --</option>
                        {(users || [])
                          .filter(u => u.isApprover && u.isActive !== false)
                          .map(user => (
                            <option key={user.id} value={user.id}>
                              {user.name} ({user.jobTitle || 'Executive'})
                            </option>
                          ))}
                      </select>
                    </div>

                    <div className="bg-slate-50 p-4 border border-indigo-100 rounded-lg space-y-2">
                      <label className="block text-xs font-bold text-slate-705 uppercase tracking-wider font-mono">
                        Upload Final Reviewed Copy (.doc, .docx) *
                      </label>
                      <input
                        type="file"
                        accept=".doc, .docx"
                        id="reviewer-verified-file-picker"
                        name="reviewer-verified-file-picker"
                        onChange={async (e) => {
                          if (e.target.files && e.target.files[0]) {
                            const file = e.target.files[0];
                            if (file.name.endsWith('.doc') || file.name.endsWith('.docx')) {
                              setReviewerFileName(file.name);
                              setReviewerFileSize((file.size / 1024).toFixed(0) + ' KB');
                              setErrorMsg('');
                              try {
                                const result = await uploadFileToServer(file);
                                if (result.success) {
                                  console.log("Verified file saved in LAN office storage:", result.url);
                                }
                              } catch (err) {
                                setErrorMsg('LAN local storage write failed. Process parameters accepted.');
                              }
                            } else {
                              setErrorMsg('Compliance Error: Only Word Documents (.doc, .docx) are accepted.');
                              setReviewerFileName('');
                            }
                          }
                        }}
                        className="w-full text-xs text-slate-500 file:mr-4 file:py-1.5 file:px-3 file:rounded file:border-0 file:text-[11px] file:font-semibold file:bg-blue-100 file:text-blue-700 hover:file:bg-blue-200 cursor-pointer"
                        required
                      />

                      {reviewerFileName && (
                        <div className="text-[11px] text-emerald-700 font-mono font-medium flex items-center gap-1.5 bg-emerald-50 p-2 border border-emerald-200 rounded">
                          <CheckCircle className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span>Staged Corrected Copy: {reviewerFileName} ({reviewerFileSize})</span>
                        </div>
                      )}
                    </div>

                    <div className="space-y-1.5">
                      <label className="block text-xs font-bold text-slate-700">Verification Remarks *</label>
                      <textarea
                        rows={2}
                        value={reviewActionComment}
                        onChange={(e) => { setReviewActionComment(e.target.value); setErrorMsg(''); }}
                        placeholder="e.g., All target calibration deviations conform to corporate health benchmarks..."
                        className="w-full bg-slate-50 border border-slate-250 focus:border-blue-500 focus:bg-white rounded p-2 text-xs text-slate-800 outline-none font-sans"
                        id="review-action-comment-input"
                      />
                    </div>

                    <div className="flex justify-end pt-1">
                      <button
                        type="button"
                        onClick={handlePassReviewAction}
                        disabled={isConflict}
                        className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white border border-emerald-450 rounded-lg flex items-center gap-1.5 cursor-pointer text-xs transition-colors shadow-sm font-bold"
                        id="btn-pass-review"
                      >
                        <CheckCircle className="w-4 h-4" />
                        <span>Pass/Upload to Approver</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="bg-white p-12 border border-slate-200 rounded-lg shadow-sm text-center text-slate-400">
              <ShieldCheck className="w-12 h-12 mx-auto text-emerald-500 opacity-65 mb-2.5" />
              <h3 className="text-base font-bold text-slate-805">Review Pipeline Discharged</h3>
              <p className="text-xs text-slate-500 mt-1">There are currently no documents in the system awaiting quality feedback check steps.</p>
            </div>
          )
        )}

        {/* VIEW 3: APPROVED ARCHIVES WITH UNLOCKED DOWNLOADS & SIGNATURES */}
        {mrSubTab === 'archive' && (
          activeArchive ? (
            <div className="space-y-4 animate-fade-in">
              <div className="bg-white p-5 border border-slate-200 rounded-lg shadow-sm">
                <div className="flex flex-col sm:flex-row justify-between items-start gap-4 border-b border-slate-100 pb-3.5">
                  <div>
                    <span className="text-[9.5px] font-semibold bg-emerald-100 text-emerald-850 border border-emerald-250 px-2 py-0.5 rounded uppercase tracking-wide">
                      Active released SOP - Download Unlocked
                    </span>
                    <h3 className="text-base font-bold text-slate-900 mt-2 leading-tight">
                      {activeArchive.title}
                    </h3>
                    <p className="text-xs text-slate-500 mt-1">
                      Author: <span className="font-semibold text-slate-700">{activeArchive.preparedBy.userName}</span>{activeArchive.submitTimestamp || activeArchive.createdAt ? ` at ${formatToIST(activeArchive.submitTimestamp || activeArchive.createdAt)}` : ''}
                    </p>
                  </div>

                  <button
                    onClick={() => handleDownloadFile(activeArchive)}
                    className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 border border-emerald-500 text-white text-xs font-bold rounded-lg flex items-center gap-1.5 transition-all cursor-pointer shrink-0 self-start shadow-sm"
                    title="Download fully approved quality SOP Word document bundle"
                    id="btn-download-final"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Final Copy</span>
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-4 mt-3 text-xs bg-slate-50/50 p-3.5 rounded border border-slate-150">
                  <div>
                    <span className="text-slate-400 font-mono text-[9px] uppercase block text-slate-400">Document Reference ID</span>
                    <span className="text-slate-800 font-mono font-bold text-[11px]">{activeArchive.id}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 font-mono text-[9px] uppercase block text-slate-400">Corporate File Asset</span>
                    <span className="text-slate-800 font-bold truncate text-[11px] block">{activeArchive.fileName}</span>
                  </div>
                </div>
              </div>

              {/* Digital seal certificate block for 21 CFR Compliant authentication */}
              <div className="bg-gradient-to-br from-emerald-50 to-teal-50/40 border-2 border-emerald-300 rounded-lg p-5 shadow-sm space-y-3.5">
                <h4 className="text-xs font-bold font-mono uppercase tracking-wider text-emerald-850 flex items-center gap-1.5">
                  <Award className="w-5 h-5 text-emerald-600" />
                  SECURE SYSTEM DIGITAL CERTIFICATE
                </h4>
                <p className="text-[11px] text-slate-650 leading-relaxed font-sans">
                  The Management Representative (MR) has reviewed, approved, and electronically signed this quality record. This action legally locks the draft content and renders the final file available for download.
                </p>

                <div className="grid sm:grid-cols-2 gap-3 text-xs font-mono bg-white/70 p-3.5 rounded border border-emerald-200">
                  <div>
                    <span className="text-emerald-800 text-[9px] uppercase font-bold block">Certified Signer</span>
                    <span className="text-slate-800 font-medium">{activeArchive.approvedBy?.signerName || 'System Verified'}</span>
                  </div>
                  <div>
                    <span className="text-emerald-800 text-[9px] uppercase font-bold block">Signer Professional Title</span>
                    <span className="text-slate-800 font-medium">{activeArchive.approvedBy?.signerTitle || 'Management Representative / Auditor'}</span>
                  </div>
                  <div>
                    <span className="text-emerald-800 text-[9px] uppercase font-bold block">Signed DateTime (ITC)</span>
                    <span className="text-slate-800 font-medium">{activeArchive.approvedBy?.timestamp ? formatToIST(activeArchive.approvedBy.timestamp) : 'Just Now'}</span>
                  </div>
                  <div>
                    <span className="text-emerald-800 text-[9px] uppercase font-bold block">Authentication Hash Code</span>
                    <span className="text-slate-700 font-medium text-[9.5px] truncate block" title={activeArchive.approvedBy?.hash}>
                      {activeArchive.approvedBy?.hash || '0xFB547120'}
                    </span>
                  </div>
                  <div className="sm:col-span-2 pt-1 border-t border-dashed border-emerald-200 mt-1">
                    <span className="text-emerald-800 text-[9px] uppercase font-bold block">Legal Signing Capacity</span>
                    <span className="text-slate-700 text-[10.5px] leading-snug">{activeArchive.approvedBy?.meaning || 'Management Representative Approval & Release Authority'}</span>
                  </div>
                </div>
              </div>

              {/* Document Text Body view */}
              <div className="bg-white border border-slate-200 rounded-lg shadow-sm">
                <div className="bg-slate-50 border-b border-slate-200 px-4 py-2 font-mono text-[10px] text-slate-500 flex items-center justify-between">
                  <span>Document Editor Preview - Read-Only Completed Version</span>
                  <span className="text-emerald-600 font-bold text-[9px] uppercase tracking-wide">Released Record</span>
                </div>
                <div className="p-5 bg-slate-100 max-h-72 overflow-y-auto">
                  <div className="bg-white p-5 shadow-sm border border-slate-200 rounded font-mono text-xs leading-relaxed text-slate-800 whitespace-pre-wrap min-h-48 select-all">
                    {activeArchive.draftContent}
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white p-12 border border-slate-200 rounded-lg shadow-sm text-center text-slate-400">
              <ShieldCheck className="w-12 h-12 mx-auto text-emerald-500 opacity-65 mb-2.5" />
              <h3 className="text-base font-bold text-slate-805">No Archives Exist</h3>
              <p className="text-xs text-slate-500 mt-1">Perform signature sign-off in the Reviews desk to formulate archived releases.</p>
            </div>
          )
        )}
        </div>
      </div>
      )}

      {downloadPayload && (
        <DownloadVaultModal
          isOpen={downloadModalOpen}
          onClose={() => setDownloadModalOpen(false)}
          fileName={downloadPayload.fileName}
          fileSize={downloadPayload.fileSize}
          fileContent={downloadPayload.fileContent}
          fileType="docx"
          checksum={downloadPayload.checksum}
          filePathUrl={downloadPayload.filePathUrl}
        />
      )}
    </div>
  );
}
