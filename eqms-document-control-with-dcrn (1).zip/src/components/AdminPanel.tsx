import React, { useState } from 'react';
import { User, AuditTrailEntry, DocumentWorkflow, DocumentStatus, DEPARTMENT_MAP } from '../types';
import { Users, UserPlus, ShieldAlert, Key, CheckCircle, Save, BadgeCheck, FileStack, ShieldEllipsis, BookHeart, X, Trash2, ArrowLeftRight } from 'lucide-react';
import { formatToIST } from '../utils/dateUtils';

interface AdminPanelProps {
  currentUser: User;
  users: User[];
  onUpdateUserRoles: (userId: string, roles: { isPreparer: boolean; isReviewer: boolean; isApprover: boolean; isAdmin: boolean; isMR: boolean }) => void;
  onAddUser: (newUser: Omit<User, 'id'>) => boolean;
  onUpdateUserCredentials: (
    userId: string, 
    email: string, 
    name: string, 
    jobTitle: string, 
    isActive: boolean, 
    password?: string,
    department?: string,
    owningQualityDepartment?: string
  ) => void;
  documents?: DocumentWorkflow[];
  onApproveRemoval?: (docId: string) => void;
  onRejectRemoval?: (docId: string) => void;
}

export default function AdminPanel({
  currentUser,
  users,
  onUpdateUserRoles,
  onAddUser,
  onUpdateUserCredentials,
  documents = [],
  onApproveRemoval,
  onRejectRemoval
 }: AdminPanelProps) {
  // Toggle modes: Directory View, Archived Directory, Create User Form, removal requests
  const [activeTab, setActiveTab] = useState<'roster' | 'archived' | 'create' | 'removal_requests'>('roster');

  // Register state inputs
  const [newEmail, setNewEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newName, setNewName] = useState('');
  const [newTitle, setNewTitle] = useState('');
  const [newDepartment, setNewDepartment] = useState('QA');
  const [newOwningDept, setNewOwningDept] = useState('QA');
  const [newPrep, setNewPrep] = useState(false);
  const [newRev, setNewRev] = useState(false);
  const [newApp, setNewApp] = useState(false);
  const [newAdm, setNewAdm] = useState(false);
  const [newMR, setNewMR] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // State for Admin credentials override modal (now complete Profile & Security Panel)
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedEditUser, setSelectedEditUser] = useState<User | null>(null);
  const [modalEmail, setModalEmail] = useState('');
  const [modalPassword, setModalPassword] = useState('');
  const [modalName, setModalName] = useState('');
  const [modalJobTitle, setModalJobTitle] = useState('');
  const [modalDepartment, setModalDepartment] = useState('QA');
  const [modalOwningDept, setModalOwningDept] = useState('QA');
  const [modalIsActive, setModalIsActive] = useState(true);
  const [modalErrorMsg, setModalErrorMsg] = useState('');
  const [showDeactivateConfirm, setShowDeactivateConfirm] = useState(false);
  const [adminPasswordConfirm, setAdminPasswordConfirm] = useState('');

  const handleSaveModalChanges = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedEditUser) return;
    if (!modalEmail.trim()) {
      setModalErrorMsg('Official Email ID is required.');
      return;
    }
    if (!modalName.trim()) {
      setModalErrorMsg('Full Name is required.');
      return;
    }
    if (!modalJobTitle.trim()) {
      setModalErrorMsg('Designation/Job Title is required.');
      return;
    }
    if (!modalEmail.includes('@') || !modalEmail.includes('.')) {
      setModalErrorMsg('Invalid formatting for organizational email address.');
      return;
    }

    const isConflictEmail = users.some(u => u.id !== selectedEditUser.id && u.email.toLowerCase() === modalEmail.trim().toLowerCase());
    if (isConflictEmail) {
      setModalErrorMsg(`The email "${modalEmail}" is already registered to another employee.`);
      return;
    }

    onUpdateUserCredentials(
      selectedEditUser.id, 
      modalEmail.trim(), 
      modalName.trim(), 
      modalJobTitle.trim(), 
      modalIsActive, 
      modalPassword.trim() || undefined,
      modalDepartment,
      modalOwningDept
    );
    
    setIsModalOpen(false);
    setSelectedEditUser(null);
    setSuccessMsg(`Profile and security credentials successfully updated for ${modalName.trim()}.`);
    
    setTimeout(() => {
      setSuccessMsg('');
    }, 4000);
  };

  const handleDeactivateEmployee = () => {
    if (!selectedEditUser) return;
    
    if (selectedEditUser.id === currentUser.id) {
      setModalErrorMsg('Security lockout guard: You are not permitted to deactivate your own administrative session.');
      setShowDeactivateConfirm(false);
      return;
    }

    // Password verification challenge
    const correctPassword = currentUser.password || 'password123';
    if (adminPasswordConfirm !== correctPassword) {
      setModalErrorMsg('Invalid Admin password. Action aborted.');
      setAdminPasswordConfirm('');
      return;
    }

    onUpdateUserCredentials(
      selectedEditUser.id,
      selectedEditUser.email,
      selectedEditUser.name,
      selectedEditUser.jobTitle,
      false, // Sets status to Removed/Inactive
      selectedEditUser.password
    );

    setIsModalOpen(false);
    setSelectedEditUser(null);
    setSuccessMsg(`Security warning: Employee "${selectedEditUser.name}" has been deactivated. System credentials revoked.`);
    setShowDeactivateConfirm(false);
    setAdminPasswordConfirm('');

    setTimeout(() => {
      setSuccessMsg('');
    }, 4000);
  };

  const handleCreateUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEmail.trim() || !newName.trim() || !newTitle.trim() || !newPassword.trim()) {
      setErrorMsg('All personnel fields, including a temporary passcode/password, are mandatory for security enrollment.');
      return;
    }

    if (!newEmail.includes('@') || !newEmail.includes('.')) {
      setErrorMsg('Invalid formatting for organizational email address.');
      return;
    }

    const targetUser: Omit<User, 'id'> = {
      email: newEmail.trim().toLowerCase(),
      password: newPassword.trim(),
      name: newName.trim(),
      jobTitle: newTitle.trim(),
      department: newDepartment,
      owningQualityDepartment: newOwningDept,
      isPreparer: newPrep,
      isReviewer: newRev,
      isApprover: newApp,
      isAdmin: newAdm,
      isMR: newMR,
      createdAt: new Date().toISOString(),
      lastActive: new Date().toISOString()
    };

    const added = onAddUser(targetUser);
    if (!added) {
      setErrorMsg(`Identity enrollment aborted. Email "${newEmail}" already occupies an eQMS folder.`);
      return;
    }

    setSuccessMsg(`Security profile created for ${newName} (${newEmail}). Credentials verified.`);
    setErrorMsg('');
    
    // Reset Form
    setNewEmail('');
    setNewPassword('');
    setNewName('');
    setNewTitle('');
    setNewDepartment('QA');
    setNewOwningDept('QA');
    setNewPrep(false);
    setNewRev(false);
    setNewApp(false);
    setNewAdm(false);
    setNewMR(false);

    // Auto switch to roster list after brief pause
    setTimeout(() => {
      setSuccessMsg('');
      setActiveTab('roster');
    }, 2000);
  };

  return (
    <div className="space-y-6" id="admin-panel-container">
      {/* Header Info */}
      <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold font-sans tracking-tight text-slate-900 flex items-center gap-2">
            <Users className="w-5.5 h-5.5 text-blue-600" />
            Personnel Role Administration Engine
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Enforce segregation of duties & grant workflow clearance credentials. All adjustments are logged instantly to the System Event Logs.
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setActiveTab('roster')}
            className={`px-3.5 py-1.5 rounded text-xs font-semibold cursor-pointer border transition-all flex items-center gap-1 ${
              activeTab === 'roster'
                ? 'bg-blue-50 border-blue-400 text-blue-700 font-bold'
                : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Active Enroll Directory</span>
          </button>
          <button
            onClick={() => setActiveTab('archived')}
            className={`px-3.5 py-1.5 rounded text-xs font-semibold cursor-pointer border transition-all flex items-center gap-1 ${
              activeTab === 'archived'
                ? 'bg-[#fffbeb] border-amber-300 text-amber-800 font-bold'
                : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
            }`}
          >
            <FileStack className="w-3.5 h-3.5 text-amber-500" />
            <span>Archived Inactive Registry</span>
          </button>
          <button
            onClick={() => setActiveTab('create')}
            className={`px-3.5 py-1.5 rounded text-xs font-semibold cursor-pointer border transition-all flex items-center gap-1 ${
              activeTab === 'create'
                ? 'bg-blue-50 border-blue-400 text-blue-700 font-bold'
                : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
            }`}
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>Enroll New Employee</span>
          </button>
          <button
            onClick={() => setActiveTab('removal_requests')}
            className={`px-3.5 py-1.5 rounded text-xs font-semibold cursor-pointer border transition-all flex items-center gap-1 relative ${
              activeTab === 'removal_requests'
                ? 'bg-rose-50 border-rose-300 text-rose-700 font-bold'
                : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
            }`}
            id="btn-goto-removal-requests"
          >
            <Trash2 className="w-3.5 h-3.5 text-rose-500" />
            <span>SOP Removal Queue</span>
            {documents.filter(d => d.status === DocumentStatus.PendingDeletion).length > 0 && (
              <span className="bg-rose-600 text-white rounded-full text-[9px] font-bold px-1.5 py-0.2 animate-pulse font-mono ml-1">
                {documents.filter(d => d.status === DocumentStatus.PendingDeletion).length}
              </span>
            )}
          </button>
        </div>
      </div>

      {(activeTab === 'roster' || activeTab === 'archived') && (
        <div className="space-y-6">
          {/* STATISTICS GRID */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white border border-slate-200 p-4 rounded-lg shadow-xs">
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Active Employees</p>
              <p className="text-2xl font-mono mt-1 font-bold text-slate-800">{users.filter(u => u.isActive !== false).length}</p>
            </div>
            <div className="bg-white border border-slate-200 p-4 rounded-lg shadow-xs border-l-4 border-l-amber-500">
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Archived / Deactivated</p>
              <p className="text-2xl font-mono mt-1 font-bold text-amber-600">{users.filter(u => u.isActive === false).length}</p>
            </div>
            <div className="bg-white border border-slate-200 p-4 rounded-lg shadow-xs border-l-4 border-l-blue-500">
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Active Reviewers</p>
              <p className="text-2xl font-mono mt-1 font-bold text-blue-600">{users.filter(u => u.isActive !== false && u.isReviewer).length}</p>
            </div>
            <div className="bg-white border border-slate-200 p-4 rounded-lg shadow-xs border-l-4 border-l-orange-500">
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Active Approvers</p>
              <p className="text-2xl font-mono mt-1 font-bold text-orange-600">{users.filter(u => u.isActive !== false && u.isApprover).length}</p>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-lg shadow-sm overflow-hidden">
            <div className="p-4 bg-slate-50 border-b border-slate-200 font-mono text-[11px] text-slate-500 flex items-center justify-between">
              <span>System Verification Log - {activeTab === 'roster' ? 'Active Personnel Segregation Console' : 'Archived Inactive Personnel Registry'}</span>
              <span className={activeTab === 'roster' ? 'text-blue-600 font-bold' : 'text-amber-600 font-bold'}>
                {activeTab === 'roster' ? '● IMMUTABLE AUDITING ENABLED' : '● SECURITY READ-ONLY ARCHIVE'}
              </span>
            </div>             
            
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-slate-250 text-left text-xs text-slate-700 font-mono">
                <thead className="bg-[#f8fafc] text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">
                  <tr>
                    <th scope="col" className="px-5 py-3">Employee Details</th>
                    <th scope="col" className="px-5 py-3 text-center">Is Preparer <p className="text-[9px] lowercase font-normal text-slate-400">Can write drafts</p></th>
                    <th scope="col" className="px-5 py-3 text-center">Is Reviewer <p className="text-[9px] lowercase font-normal text-slate-400">Can evaluate drafts</p></th>
                    <th scope="col" className="px-5 py-3 text-center">Is Approver <p className="text-[9px] lowercase font-normal text-slate-400">Can sign off</p></th>
                    <th scope="col" className="px-5 py-3 text-center text-blue-600 font-bold">Is MR <p className="text-[9px] lowercase font-normal text-slate-450">Quality Clearance</p></th>
                    <th scope="col" className="px-5 py-3 text-center">Is Admin <p className="text-[9px] lowercase font-normal text-slate-400">Access role settings</p></th>
                    <th scope="col" className="px-5 py-3 text-center">Actions</th>
                    <th scope="col" className="px-5 py-3 text-right">Date Enrolled</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-150 bg-white">
                  {users.filter(u => activeTab === 'roster' ? u.isActive !== false : u.isActive === false).map((user, idx) => {
                    const isCurrentSelf = user.id === currentUser.id;
                    const rowBgClass = idx % 2 === 0 ? 'bg-blue-50/10' : 'bg-white';
                    return (
                      <tr key={user.id} className={`${rowBgClass} hover:bg-slate-50/80 transition-colors`}>
                        <td className="px-5 py-4">
                          <div className="font-semibold text-slate-900 flex flex-wrap items-center gap-1.5 font-sans">
                            <span>{user.name}</span>
                            {isCurrentSelf && (
                              <span className="bg-slate-250 border border-slate-400 text-slate-800 text-[9px] font-mono px-1 rounded">
                                Current Account
                              </span>
                            )}
                            {user.isActive === false && (
                              <span className="bg-rose-50 border border-rose-200 text-rose-700 text-[9px] font-mono px-1.5 py-0.2 rounded font-bold uppercase tracking-wider">
                                deactivated
                              </span>
                            )}
                          </div>
                          <div className="text-slate-500 text-[11px] mt-0.5 font-sans flex items-center gap-1.5">
                            <span>{user.jobTitle}</span>
                            {user.department && (
                              <span className="p-0.5 px-1.5 bg-slate-100 border border-slate-200 rounded font-mono text-[9px] font-semibold text-slate-600 uppercase">
                                {user.department}
                              </span>
                            )}
                          </div>
                          <div className="text-slate-400 text-[10.5px] font-mono mt-0.5 select-all">{user.email}</div>
                        </td>
                        
                        {/* Preparer Checkbar */}
                        <td className="px-5 py-4 text-center">
                          <input
                            type="checkbox"
                            checked={user.isPreparer}
                            disabled={user.isActive === false}
                            onChange={(e) => {
                              onUpdateUserRoles(user.id, {
                                isPreparer: e.target.checked,
                                isReviewer: user.isReviewer,
                                isApprover: user.isApprover,
                                isAdmin: user.isAdmin,
                                isMR: !!user.isMR
                              });
                            }}
                            className="w-4 h-4 text-blue-600 border-slate-350 focus:ring-blue-500 rounded cursor-pointer transition-all mx-auto duration-150 disabled:opacity-30 disabled:cursor-not-allowed"
                            id={`prep-toggle-${user.id}`}
                          />
                        </td>

                        {/* Reviewer Checkbar */}
                        <td className="px-5 py-4 text-center">
                          <input
                            type="checkbox"
                            checked={user.isReviewer}
                            disabled={user.isActive === false}
                            onChange={(e) => {
                              onUpdateUserRoles(user.id, {
                                isPreparer: user.isPreparer,
                                isReviewer: e.target.checked,
                                isApprover: user.isApprover,
                                isAdmin: user.isAdmin,
                                isMR: !!user.isMR
                              });
                            }}
                            className="w-4 h-4 text-blue-600 border-slate-350 focus:ring-blue-500 rounded cursor-pointer transition-all mx-auto duration-150 disabled:opacity-30 disabled:cursor-not-allowed"
                            id={`rev-toggle-${user.id}`}
                          />
                        </td>

                        {/* Approver Checkbar */}
                        <td className="px-5 py-4 text-center">
                          <input
                            type="checkbox"
                            checked={user.isApprover}
                            disabled={user.isActive === false}
                            onChange={(e) => {
                              onUpdateUserRoles(user.id, {
                                isPreparer: user.isPreparer,
                                isReviewer: user.isReviewer,
                                isApprover: e.target.checked,
                                isAdmin: user.isAdmin,
                                isMR: !!user.isMR
                              });
                            }}
                            className="w-4 h-4 text-blue-600 border-slate-350 focus:ring-blue-500 rounded cursor-pointer transition-all mx-auto duration-150 disabled:opacity-30 disabled:cursor-not-allowed"
                            id={`appr-toggle-${user.id}`}
                          />
                        </td>

                        {/* Is MR Checkbar */}
                        <td className="px-5 py-4 text-center bg-blue-50/10">
                          <input
                            type="checkbox"
                            checked={!!user.isMR}
                            disabled={user.isActive === false}
                            onChange={(e) => {
                              onUpdateUserRoles(user.id, {
                                isPreparer: user.isPreparer,
                                isReviewer: user.isReviewer,
                                isApprover: user.isApprover,
                                isAdmin: user.isAdmin,
                                isMR: e.target.checked
                              });
                            }}
                            className="w-4 h-4 text-blue-600 border-slate-350 focus:ring-blue-500 rounded cursor-pointer transition-all mx-auto duration-150 animate-pulse disabled:opacity-30 disabled:cursor-not-allowed"
                            id={`mr-toggle-${user.id}`}
                          />
                        </td>

                        {/* Admin Checkbar */}
                        <td className="px-5 py-4 text-center bg-slate-50/40">
                          <input
                            type="checkbox"
                            checked={user.isAdmin}
                            disabled={isCurrentSelf || user.isActive === false} // Self lockout prevention or archive
                            onChange={(e) => {
                              onUpdateUserRoles(user.id, {
                                isPreparer: user.isPreparer,
                                isReviewer: user.isReviewer,
                                isApprover: user.isApprover,
                                isAdmin: e.target.checked,
                                isMR: !!user.isMR
                              });
                            }}
                            className="w-4 h-4 text-blue-600 border-slate-350 focus:ring-blue-500 rounded transition-all mx-auto justify-self-center block cursor-pointer disabled:cursor-not-allowed disabled:opacity-50"
                            title={isCurrentSelf ? 'You cannot remove administrative rights from your own active session.' : 'Enables administrative panel access.'}
                            id={`admin-toggle-${user.id}`}
                          />
                        </td>

                        {/* Interactive Edit Credentials column for Admin */}
                        <td className="px-5 py-4 text-center whitespace-nowrap">
                          <button
                            onClick={() => {
                              setSelectedEditUser(user);
                              setModalEmail(user.email);
                              setModalPassword(user.password || '');
                              setModalName(user.name);
                              setModalJobTitle(user.jobTitle);
                              setModalIsActive(user.isActive !== false);
                              setModalDepartment(user.department || 'QA');
                              setModalOwningDept(user.owningQualityDepartment || user.department || 'QA');
                              setModalErrorMsg('');
                              setShowDeactivateConfirm(false);
                              setIsModalOpen(true);
                            }}
                            className={`font-bold border text-[10px] px-2.5 py-1.5 rounded-md cursor-pointer transition-colors inline-flex items-center gap-1 outline-none ${
                              user.isActive !== false
                                ? 'bg-blue-50 hover:bg-blue-100 hover:text-blue-800 text-blue-700 border-blue-200'
                                : 'bg-amber-50 hover:bg-amber-100 hover:text-amber-800 text-amber-700 border-amber-200'
                            }`}
                            id={`btn-edit-credentials-${user.id}`}
                            title={user.isActive !== false ? "Edit employee profile and system authorization credentials" : "Reactivate and update personnel record"}
                          >
                            <Key className={`w-3 h-3 shrink-0 ${user.isActive !== false ? 'text-blue-600' : 'text-amber-600'}`} />
                            <span>{user.isActive !== false ? 'Profile & Security' : 'Reactivate & Edit'}</span>
                          </button>
                        </td>

                        <td className="px-5 py-4 text-right whitespace-nowrap text-[11px] font-mono text-slate-400">
                          {formatToIST(user.createdAt).substring(0, 10)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-200 text-[11px] text-slate-500 flex flex-col gap-1 inline-block">
              <span className="font-bold text-slate-700 flex items-center gap-1">
                <ShieldAlert className="w-3.5 h-3.5 text-amber-500 inline" />
                Organizational Separation Constraints Enforced:
              </span>
              <span>- Any employee can occupy multiple roles simultaneously. For instance, John Miller possesses both Review & Sign capabilities.</span>
              <span>- <span className="text-amber-600 font-semibold font-mono">CRITICAL GAURD:</span> The program will dynamically block John Miller from completing reviews or signing off approvals for documents that originate under his own Preparer credential folder to satisfy standard FDA computer validity protocols.</span>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'create' && (
        <div className="bg-white border border-slate-200 rounded-lg shadow-sm max-w-xl mx-auto overflow-hidden">
          <div className="p-4 bg-slate-50 border-b border-slate-200 font-bold text-slate-700 flex items-center gap-1.5">
            <UserPlus className="w-4 h-4 text-blue-600" />
            <span>Secure Personnel Enrollment Form</span>
          </div>

          <form onSubmit={handleCreateUser} className="p-5 space-y-4">
            {successMsg && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded text-xs font-semibold flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
                <span>{successMsg}</span>
              </div>
            )}

            {errorMsg && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded text-xs font-semibold flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-rose-600" />
                <span>{errorMsg}</span>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Full Name</label>
              <input
                type="text"
                value={newName}
                onChange={(e) => { setNewName(e.target.value); setErrorMsg(''); }}
                placeholder="Dr. Jordan Fields"
                className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white rounded px-3 py-1.5 text-xs text-slate-800 placeholder-slate-400 outline-none transition-all"
                id="admin-form-name"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Official Email ID</label>
              <input
                type="email"
                value={newEmail}
                onChange={(e) => { setNewEmail(e.target.value); setErrorMsg(''); }}
                placeholder="j.fields@company.com"
                className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white rounded px-3 py-1.5 text-xs text-slate-800 placeholder-slate-400 outline-none transition-all"
                id="admin-form-email"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Temporary Passcode/Password</label>
              <input
                type="password"
                value={newPassword}
                onChange={(e) => { setNewPassword(e.target.value); setErrorMsg(''); }}
                placeholder="••••••••••••"
                className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white rounded px-3 py-1.5 text-xs text-slate-800 placeholder-slate-400 outline-none transition-all"
                id="admin-form-password"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Official Job Title</label>
              <input
                type="text"
                value={newTitle}
                onChange={(e) => { setNewTitle(e.target.value); setErrorMsg(''); }}
                placeholder="Associate Compliance Engineer"
                className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white rounded px-3 py-1.5 text-xs text-slate-800 placeholder-slate-400 outline-none transition-all"
                id="admin-form-title"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Department Name/Code</label>
              <select
                value={newDepartment}
                onChange={(e) => {
                  const val = e.target.value;
                  setNewDepartment(val);
                  setNewOwningDept(val); // Real-time synchronizer
                  setErrorMsg('');
                }}
                className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white rounded px-3 py-1.5 text-xs text-slate-800 outline-none transition-all cursor-pointer font-semibold"
                id="admin-form-dept"
              >
                {Object.entries(DEPARTMENT_MAP).map(([code, name]) => (
                  <option key={code} value={code}>
                    {code} ({name})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Owning Quality Department</label>
              <input
                type="text"
                value={newOwningDept}
                readOnly
                className="w-full bg-slate-100 border border-slate-200 rounded px-3 py-1.5 text-xs text-slate-500 cursor-not-allowed outline-none font-mono"
                id="admin-form-owning-dept"
                title="Automated selection based on standard company facilities"
              />
            </div>

            <div className="border-t border-slate-100 pt-4">
              <label className="block text-xs font-bold text-slate-850 mb-2 font-mono">Assign Initial Quality Workflow Clearance Flags:</label>
              
              <div className="grid grid-cols-2 gap-3 bg-slate-50 p-3 rounded-lg border border-slate-100">
                <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={newPrep}
                    onChange={(e) => setNewPrep(e.target.checked)}
                    className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500"
                  />
                  <div>
                    <span className="font-semibold block">Is Preparer</span>
                    <span className="text-[10px] text-slate-400">Can write and submit drafts</span>
                  </div>
                </label>

                <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={newRev}
                    onChange={(e) => setNewRev(e.target.checked)}
                    className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500"
                  />
                  <div>
                    <span className="font-semibold block">Is Reviewer</span>
                    <span className="text-[10px] text-slate-400">Can comment & verify drafts</span>
                  </div>
                </label>

                <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={newApp}
                    onChange={(e) => setNewApp(e.target.checked)}
                    className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500"
                  />
                  <div>
                    <span className="font-semibold block">Is Approver</span>
                    <span className="text-[10px] text-slate-400">Can execute signature modal</span>
                  </div>
                </label>

                <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={newAdm}
                    onChange={(e) => setNewAdm(e.target.checked)}
                    className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500"
                  />
                  <div>
                    <span className="font-semibold block text-amber-700">Is Admin</span>
                    <span className="text-[10px] text-slate-400">Access credential toggles</span>
                  </div>
                </label>

                <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer select-none col-span-2 border-t border-slate-100 pt-2.5 mt-1">
                  <input
                    type="checkbox"
                    checked={newMR}
                    onChange={(e) => setNewMR(e.target.checked)}
                    className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500"
                    id="admin-form-mr"
                  />
                  <div>
                    <span className="font-semibold block text-blue-800 flex items-center gap-1">
                      <span>Is MR</span>
                      <span className="bg-blue-100 text-blue-850 px-1 py-0.2 rounded text-[9px] uppercase font-bold tracking-wider">Management Representative</span>
                    </span>
                    <span className="text-[10px] text-slate-400 select-none">Designates authorized MR agent credentials for official document sign-off clearance.</span>
                  </div>
                </label>
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold py-2 rounded transition-all flex items-center justify-center gap-1.5 cursor-pointer mt-2"
              id="admin-form-submit"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Enroll Employee & Save Security Token</span>
            </button>
          </form>
        </div>
      )}

      {activeTab === 'removal_requests' && (
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-lg shadow-sm overflow-hidden">
            <div className="p-4 bg-slate-50 border-b border-slate-200 font-mono text-[11px] text-slate-500 flex items-center justify-between">
              <span>System Verification Log - Administrative SOP Deletion & Archiving Queue</span>
              <span className="text-rose-600 font-bold">● ACTION AUTHORIZATION REQUIRED</span>
            </div>

            {documents.filter(d => d.status === DocumentStatus.PendingDeletion).length === 0 ? (
              <div className="p-12 text-center text-slate-400">
                <Trash2 className="w-12 h-12 mx-auto text-slate-300 opacity-60 mb-2" />
                <p className="text-sm font-medium">No pending document removal requests in queue.</p>
                <p className="text-xs text-slate-500 mt-1">All operating procedures are currently aligned with active development stages.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-slate-250 text-left text-xs text-slate-700 font-mono">
                  <thead className="bg-[#f8fafc] text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">
                    <tr>
                      <th scope="col" className="px-5 py-3">SOP Details</th>
                      <th scope="col" className="px-5 py-3">Prepared By</th>
                      <th scope="col" className="px-5 py-3 text-center">Original Stage Context</th>
                      <th scope="col" className="px-5 py-3 text-right">Administrative Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-150 bg-white">
                    {documents.filter(d => d.status === DocumentStatus.PendingDeletion).map((doc, idx) => {
                      const rowBgClass = idx % 2 === 0 ? 'bg-rose-50/5' : 'bg-white';
                      return (
                        <tr key={doc.id} className={`${rowBgClass} hover:bg-slate-50/80 transition-colors`}>
                          <td className="px-5 py-4">
                            <div className="font-bold text-slate-900 font-sans text-xs">{doc.title}</div>
                            <div className="text-slate-400 text-[10.5px] font-sans mt-0.5">{doc.category} - {doc.department}</div>
                            <div className="text-[10px] text-slate-500 font-mono mt-1">
                              ID: <span className="font-bold text-blue-700">{doc.id}</span> | Version: {doc.version}
                            </div>
                          </td>
                          <td className="px-5 py-4">
                            <div className="font-medium text-slate-800 font-sans">{doc.preparedBy.userName}</div>
                            <div className="text-slate-400 text-[10px] font-sans">{doc.preparedBy.email}</div>
                          </td>
                          <td className="px-5 py-4 text-center">
                            <span className="inline-flex items-center px-2-accent hover:border-blue-300 px-2 py-0.5 rounded text-[10.5px] font-medium border border-teal-200 bg-teal-50 text-teal-800 font-sans font-bold">
                              {doc.stageBeforeDeletionRequest || 'Unknown Stage'}
                            </span>
                          </td>
                          <td className="px-5 py-4 text-right">
                            <div className="flex gap-2 justify-end">
                              <button
                                onClick={() => onRejectRemoval && onRejectRemoval(doc.id)}
                                className="px-3 py-1 bg-slate-150 hover:bg-slate-205 text-slate-700 text-xs font-bold rounded cursor-pointer transition-all border border-slate-300"
                                id={`btn-reject-removal-${doc.id}`}
                              >
                                Reject & Restore
                              </button>
                              <button
                                onClick={() => onApproveRemoval && onApproveRemoval(doc.id)}
                                className="px-3 py-1 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded cursor-pointer transition-all border border-rose-700"
                                id={`btn-approve-removal-${doc.id}`}
                              >
                                Approve & Archive
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Edit Credentials Modal Overlay */}
      {isModalOpen && selectedEditUser && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 transition-all duration-300 animate-fade-in" id="edit-credentials-modal-backdrop">
          <div className="bg-white border border-slate-200 rounded-lg shadow-xl max-w-md w-full overflow-hidden" id="edit-credentials-modal">
            <div className="p-4 bg-slate-50 border-b border-slate-200 flex justify-between items-center">
              <div className="flex items-center gap-2">
                <ShieldEllipsis className="w-5 h-5 text-blue-600 animate-pulse" />
                <span className="font-bold text-slate-800 text-sm">Profile & Security Edit Panel</span>
              </div>
              <button 
                onClick={() => { setIsModalOpen(false); setSelectedEditUser(null); }}
                className="text-slate-400 hover:text-slate-600 cursor-pointer p-1 rounded hover:bg-slate-100 transition-colors"
                title="Close"
                type="button"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveModalChanges} className="p-5 space-y-4">
              {modalErrorMsg && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded text-xs font-semibold flex items-center gap-2" id="modal-error-alert">
                  <ShieldAlert className="w-4.5 h-4.5 text-rose-600 shrink-0" />
                  <span>{modalErrorMsg}</span>
                </div>
              )}

              <div className="bg-slate-50 border border-slate-150 p-2.5 rounded text-xs space-y-1 text-slate-600">
                <p>System Record ID: <span className="font-mono text-slate-800 font-semibold">{selectedEditUser.id}</span></p>
                <p>Date Enrolled: <span className="text-slate-800">{formatToIST(selectedEditUser.createdAt).substring(0, 10)}</span></p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Full Name</label>
                <input
                  type="text"
                  value={modalName}
                  onChange={(e) => { setModalName(e.target.value); setModalErrorMsg(''); }}
                  placeholder="e.g. John Doe"
                  className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white rounded px-3 py-1.5 text-xs text-slate-800 outline-none transition-all font-sans font-semibold"
                  id="modal-edit-name"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Designation</label>
                <input
                  type="text"
                  value={modalJobTitle}
                  onChange={(e) => { setModalJobTitle(e.target.value); setModalErrorMsg(''); }}
                  placeholder="e.g. Quality Executive"
                  className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white rounded px-3 py-1.5 text-xs text-slate-800 outline-none transition-all font-sans"
                  id="modal-edit-jobtitle"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Department Name/Code</label>
                <select
                  value={modalDepartment}
                  onChange={(e) => {
                    const val = e.target.value;
                    setModalDepartment(val);
                    setModalOwningDept(val); // Real-time synchronizer
                    setModalErrorMsg('');
                  }}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white rounded px-3 py-1.5 text-xs text-slate-800 outline-none transition-all cursor-pointer font-semibold"
                  id="modal-edit-dept"
                >
                  {Object.entries(DEPARTMENT_MAP).map(([code, name]) => (
                    <option key={code} value={code}>
                      {code} ({name})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Owning Quality Department</label>
                <input
                  type="text"
                  value={modalOwningDept}
                  readOnly
                  className="w-full bg-slate-100 border border-slate-200 rounded px-3 py-1.5 text-xs text-slate-500 cursor-not-allowed outline-none font-mono"
                  id="modal-edit-owning-dept"
                  title="Automated selection based on standard company facilities"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Official Email ID</label>
                <input
                  type="email"
                  value={modalEmail}
                  onChange={(e) => { setModalEmail(e.target.value); setModalErrorMsg(''); }}
                  placeholder="name@company.com"
                  className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white rounded px-3 py-1.5 text-xs text-slate-800 outline-none transition-all font-sans"
                  id="modal-edit-email"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Overwrite Passcode / Password (Optional)</label>
                <input
                  type="text"
                  value={modalPassword}
                  onChange={(e) => { setModalPassword(e.target.value); setModalErrorMsg(''); }}
                  placeholder="Leave blank to maintain current password"
                  className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white rounded px-3 py-1.5 text-xs text-slate-800 outline-none transition-all font-mono"
                  id="modal-edit-password"
                />
                <p className="text-[10px] text-slate-400 mt-1">To reset password, enter override text above. Otherwise, leave clear.</p>
              </div>

              <div>
                <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer select-none pt-1">
                  <input
                    type="checkbox"
                    checked={modalIsActive}
                    onChange={(e) => {
                      setModalIsActive(e.target.checked);
                      if (e.target.checked) {
                        setShowDeactivateConfirm(false);
                      }
                    }}
                    className="w-4 h-4 text-blue-600 border-slate-350 focus:ring-blue-500 rounded cursor-pointer transition-all duration-150"
                    id="modal-edit-active-toggle"
                  />
                  <div>
                    <span className="font-semibold block text-slate-800">Authorization Access Granted</span>
                    <span className="text-[10px] text-slate-400">Determines if user is allowed login clearance on the quick-login screens.</span>
                  </div>
                </label>
              </div>

              {/* Secure Deactivation Action Panel Section */}
              <div className="border-t border-slate-100 pt-3.5 space-y-3">
                {showDeactivateConfirm ? (
                  <div className="p-3.5 bg-red-50 border border-red-200 rounded-md space-y-3 animate-fade-in" id="modal-edit-deactivate-confirm">
                    <div className="flex items-start gap-2">
                      <ShieldAlert className="w-5 h-5 text-red-600 shrink-0 mt-0.5 animate-bounce" />
                      <div>
                        <p className="text-xs font-bold text-red-800">
                          You are about to remove {selectedEditUser.name}. This action revokes all system access.
                        </p>
                        <p className="text-[10.5px] text-red-700 leading-normal mt-1">
                          Please enter your Admin Password to authenticate this action.
                        </p>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                        Enter your Admin Password to confirm:
                      </label>
                      <input
                        type="password"
                        value={adminPasswordConfirm}
                        onChange={(e) => {
                          setAdminPasswordConfirm(e.target.value);
                          setModalErrorMsg('');
                        }}
                        placeholder="••••••••"
                        className="w-full bg-white border border-red-200 focus:border-red-500 rounded px-2.5 py-1.5 text-xs text-slate-800 outline-none transition-all font-mono"
                        id="modal-deactivate-password-challenge"
                        required
                      />
                    </div>

                    <div className="flex gap-2 justify-end">
                      <button
                        type="button"
                        onClick={() => {
                          setShowDeactivateConfirm(false);
                          setAdminPasswordConfirm('');
                          setModalErrorMsg('');
                        }}
                        className="px-2.5 py-1 bg-white border border-slate-250 text-slate-700 text-[11px] font-semibold rounded hover:bg-slate-50 transition-all cursor-pointer"
                        id="btn-deactivate-dismiss"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        onClick={handleDeactivateEmployee}
                        className="px-3 py-1 bg-red-600 hover:bg-red-750 text-white text-[11px] font-bold rounded shadow-xs transition-all cursor-pointer"
                        id="btn-deactivate-confirm"
                      >
                        Confirm Removal
                      </button>
                    </div>
                  </div>
                ) : (
                  <div>
                    {selectedEditUser.isActive !== false ? (
                      <button
                        type="button"
                        onClick={() => {
                          setShowDeactivateConfirm(true);
                          setAdminPasswordConfirm('');
                          setModalErrorMsg('');
                        }}
                        className="w-full bg-red-50 hover:bg-red-100 border border-red-200 text-red-700 text-xs font-semibold py-2 rounded transition-all flex items-center justify-center gap-1.5 cursor-pointer outline-none shadow-xs"
                        id="modal-edit-deactivate-btn"
                      >
                        <ShieldAlert className="w-4 h-4 text-red-600 shrink-0 animate-pulse" />
                        <span>Remove Active Employee</span>
                      </button>
                    ) : (
                      <div className="p-2.5 bg-amber-50 border border-amber-200 text-amber-800 rounded text-xs flex items-center gap-2">
                        <span className="text-base font-mono">⚠️</span>
                        <span>Archived registry profile. Select <strong>Authorization Access Granted</strong> to restore login permissions.</span>
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="flex justify-end gap-2.5 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => { setIsModalOpen(false); setSelectedEditUser(null); }}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded cursor-pointer transition-all border border-slate-200 outline-none"
                  id="btn-cancel-modal"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4.5 py-2 bg-blue-600 hover:bg-blue-555 text-white text-xs font-semibold rounded cursor-pointer transition-all flex items-center justify-center gap-1 shadow-sm font-bold outline-none"
                  id="btn-save-modal"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save Changes</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
