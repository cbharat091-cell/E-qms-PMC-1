import React, { useState } from 'react';
import { User, DocumentWorkflow, DocumentStatus, DocumentCategory, Department, DCRNRequest, DCRNDecDocument } from '../types';
import { uploadFileToServer } from '../utils/localUpload';
import { formatToIST } from '../utils/dateUtils';
import { FileText, UploadCloud, Send, FileCode, CheckCircle2, RefreshCw, XCircle, ArrowRight, Eye, Edit2, Download, Trash2, Layers, AlertTriangle, FileSpreadsheet } from 'lucide-react';
import DownloadVaultModal from './DownloadVaultModal';
import DcrnWorkflow from './DcrnWorkflow';

interface PreparerWorkspaceProps {
  currentUser: User;
  documents: DocumentWorkflow[];
  onAddDocument: (doc: Omit<DocumentWorkflow, 'id' | 'createdAt' | 'preparedBy' | 'version' | 'comments'> & { file: File | null; referencedDcrn?: string }) => void;
  onUpdateDraftContent: (docId: string, newContent: string) => void;
  onSubmitDocument: (docId: string, preparerDraftUrl?: string, fileName?: string, fileSize?: string, assignedReviewer?: { userId: string; userName: string; email: string }) => void;
  onDeleteDocument?: (docId: string) => void;
  onRequestRemoval?: (docId: string) => void;
  users: User[];
  dcrnRequests?: DCRNRequest[];
  onDeleteDcrnRequest?: (requestId: string) => void;
  onAddDcrnRequest?: (initialDocs: DCRNDecDocument[]) => void;
  onEvaluateDcrnRequest?: (requestId: string, approved: boolean, remarks: string) => void;
  onSubmitDepartmentAssessment?: (
    requestId: string,
    deptCode: string,
    impacted: 'Yes' | 'No',
    addedDocs: DCRNDecDocument[]
  ) => void;
  onAuthorizeDcrnRequest?: (requestId: string, registryNumber: string) => void;
  onRejectDcrnRemoval?: (requestId: string) => void;
  onUpdateDcrnRequest?: (requestId: string, docNumber: string, reviewerId: string, updatedDocUrl: string, fileName: string) => void;
  onUpdateDcrnDocumentField?: (requestId: string, docNumber: string, fields: Partial<DCRNDecDocument>, auditAction?: string, auditDetails?: string) => void;
  onSubmitToQa?: (requestId: string) => void;
  onDownloadSOP?: (docId: string) => void;
}

export default function PreparerWorkspace({
  currentUser,
  documents,
  onAddDocument,
  onUpdateDraftContent,
  onSubmitDocument,
  onDeleteDocument,
  onRequestRemoval,
  users,
  dcrnRequests = [],
  onDeleteDcrnRequest,
  onAddDcrnRequest,
  onEvaluateDcrnRequest,
  onSubmitDepartmentAssessment,
  onAuthorizeDcrnRequest,
  onRejectDcrnRemoval,
  onUpdateDcrnRequest,
  onUpdateDcrnDocumentField,
  onSubmitToQa,
  onDownloadSOP
}: PreparerWorkspaceProps) {
  // Navigation: Create Document, Track Document List
  const [activeTab, setActiveTab] = useState<'create' | 'track' | 'dcrn_dashboard'>('dcrn_dashboard');
  
  // Filter DCRNs to only show own department's
  const ownDeptDcrnRequests = dcrnRequests.filter(req => 
    !currentUser.department || 
    req.preparedBy?.department === currentUser.department ||
    req.initialDocs.some(doc => doc.addedByDept === currentUser.department)
  );

  const prepDcrnPendingCount = (() => {
    let downloadedIds: string[] = [];
    try {
      const saved = typeof window !== 'undefined' ? localStorage.getItem("dcrn_downloaded_ids") : null;
      if (saved) {
        downloadedIds = JSON.parse(saved);
      }
    } catch (e) {}

    let count = 0;
    dcrnRequests.forEach(req => {
      const isUserPreparerOrSameDept = 
        currentUser.id === req.preparedBy?.userId || 
        currentUser.department === req.preparedBy?.department;

      if (isUserPreparerOrSameDept) {
        (req.initialDocs || []).forEach(doc => {
          const isMRDownloadPending = doc.uploadedUrl && (!doc.workflowStatus || (doc.workflowStatus as string) === 'None');
          const isApprovedDownloadPending = doc.workflowStatus === 'ApprovalAccepted' && 
            doc.approvedDocUrl &&
            !downloadedIds.includes(doc.docNumber + (doc.addedByDept || ""));
          if (isMRDownloadPending || isApprovedDownloadPending) {
            count++;
          }
        });
      }
    });
    return count;
  })();
  
  // DCRN Reference Tracker state
  const [referencedDcrn, setReferencedDcrn] = useState('');

  // Unified Download Modal State
  const [downloadModalOpen, setDownloadModalOpen] = useState(false);
  const [downloadPayload, setDownloadPayload] = useState<{
    fileName: string;
    fileSize: string;
    fileContent: string;
    checksum: string;
    filePathUrl?: string;
  } | null>(null);

  const [localDownloadedIds, setLocalDownloadedIds] = useState<string[]>([]);

  // New Draft inputs
  const [title, setTitle] = useState('');
  const [draftContent, setDraftContent] = useState('');
  const [fileName, setFileName] = useState('');
  const [fileSize, setFileSize] = useState('');
  const [dragActive, setDragActive] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Editing rejected draft parameters
  const [editingDoc, setEditingDoc] = useState<DocumentWorkflow | null>(null);
  const [editedBody, setEditedBody] = useState('');
  const [preparerFileName, setPreparerFileName] = useState('');
  const [preparerFileSize, setPreparerFileSize] = useState('');
  const [editingError, setEditingError] = useState('');
  const [selectedReviewerId, setSelectedReviewerId] = useState('');
  const [deletingDocId, setDeletingDocId] = useState<string | null>(null);
  const [confirmDeleteDcrnId, setConfirmDeleteDcrnId] = useState<string | null>(null);

  // Pre-configured standards templates to make draft writing clean & quick
  const TEMPLATES = [
    {
      name: 'ISO 13485 Equipment Calibration SOP',
      text: 'PROCEDURE_ID: SOP-TEMP-001\n\n1.0 PURPOSE:\nEstablish routine calibration sweeps for lab scales.\n\n2.0 METHOD:\nVerify balance index using standard weight bars certified by NIST prior to active shifts.\n\n3.0 ACCEPTANCE CRITERIA:\nVariances must reside within ±0.02g tolerances.'
    },
    {
      name: 'FDA Dev QC Control Verification Form',
      text: 'FORM_ID: QC-FORM-099\n\n1.0 DEVICE VERIFICATION REGISTER:\nModel Code: [_______]  Batch Index: [_______]\n\n2.0 TEMPERATURE COMPONENT INTEGRITY:\nTested range (31C - 39C): [PASS / FAIL]\n\n3.5 OPERATIONAL SEAL:\nCertified vacuum envelope verified: [YES / NO]'
    },
    {
      name: 'General Sterile Cleanroom Training Guide',
      text: 'INSTRUCTION_ID: WI-STER-22\n\n1.0 PERSONNEL PREPARATION:\nEnforce level-4 gowning regulations before passing barrier gate.\n\n2.0 HYGIENE BARRIERS:\nMaintain 30-second antibacterial scrub protocol on outer gloves and wrist seals.'
    }
  ];

  const handleApplyTemplate = (txt: string, name: string) => {
    setDraftContent(txt);
    if (!title) {
      setTitle(name);
    }
    // Simulate DOCX file assembly
    const cleanName = name.replace(/\s+/g, '_') + '_Draft.docx';
    setFileName(cleanName);
    setFileSize('184 KB');
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (file.name.endsWith('.docx')) {
        setFileName(file.name);
        setFileSize((file.size / 1024).toFixed(0) + ' KB');
        setErrorMsg('');
      } else {
        setErrorMsg('Compliance Error: Only Microsoft Word (.docx) document assets are permitted in eQMS vaults.');
      }
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (file.name.endsWith('.docx')) {
        setFileName(file.name);
        setFileSize((file.size / 1024).toFixed(0) + ' KB');
        setErrorMsg('');
      } else {
        setErrorMsg('Compliance Error: Only Microsoft Word (.docx) document assets are permitted in eQMS vaults.');
      }
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setErrorMsg('A specific title is required.');
      return;
    }

    onAddDocument({
      title: title.trim(),
      category: DocumentCategory.SOP,
      department: Department.Quality,
      description: 'Standard SOP Draft initialization requested.',
      fileName: '(Awaiting MR Soft Copy)',
      fileSize: 'N/A',
      status: DocumentStatus.RequestedMR,
      draftContent: '',
      file: null,
      referencedDcrn: referencedDcrn ? referencedDcrn : undefined
    });

    setSuccessMsg('Soft copy requested from MR Department successfully. View progress in track roster.');
    setErrorMsg('');

    // Reset Form fields
    setTitle('');
    setDraftContent('');
    setFileName('');
    setFileSize('');
    setReferencedDcrn('');

    setTimeout(() => {
      setSuccessMsg('');
      setActiveTab('track');
    }, 2000);
  };

  // Filter documents specific to current logged-in preparer (excluding archived)
  const preparerDocuments = documents.filter(doc => doc.preparedBy.userId === currentUser.id && doc.status !== DocumentStatus.Archived);

  const startEditRejected = (doc: DocumentWorkflow) => {
    setEditingDoc(doc);
    setEditedBody(doc.draftContent || '');
    setPreparerFileName('');
    setPreparerFileSize('');
    setEditingError('');
    setSelectedReviewerId(doc.assignedReviewer?.userId || '');
  };

  const saveAndResubmit = () => {
    if (!editingDoc) return;

    // Validate that status is SoftCopyProvided that they actually uploaded their file!
    if (editingDoc.status === DocumentStatus.SoftCopyProvided && !preparerFileName) {
      setEditingError('Validation Error: You must pick and upload your edited Word draft (.doc, .docx) before submission.');
      return;
    }

    // Force selection of a reviewer
    if (!selectedReviewerId) {
      setEditingError('Validation Error: You must select a specific Reviewer for the next workflow stage before submission.');
      return;
    }

    const reviewerUser = (users || []).find(u => u.id === selectedReviewerId);
    if (!reviewerUser) {
      setEditingError('Validation Error: The selected Reviewer is invalid.');
      return;
    }

    const assignedReviewer = {
      userId: reviewerUser.id,
      userName: reviewerUser.name,
      email: reviewerUser.email
    };

    onUpdateDraftContent(editingDoc.id, editedBody);
    onSubmitDocument(
      editingDoc.id,
      preparerFileName ? `/vault/preparer-drafts/${preparerFileName}` : undefined,
      preparerFileName || undefined,
      preparerFileSize || undefined,
      assignedReviewer
    );
    setEditingDoc(null);
    setSuccessMsg('Corrected draft submitted to Review Pool. Audit updated.');
    setTimeout(() => setSuccessMsg(''), 3000);
  };
  const handleDownloadProposal = (doc: DocumentWorkflow) => {
    const isApproved = doc.status === DocumentStatus.Approved;
    const output = isApproved ? `======================================================================
     CORPORATE ELECTRONIC QUALITY MANAGEMENT SYSTEM (eQMS)
======================================================================
DOCUMENT REFERENCE ID: ${doc.id}
TITLE: ${doc.title}
CATEGORY: ${doc.category}
DEPARTMENT: ${doc.department}
VERSION: v${doc.version}
STATUS: ${doc.status}
AUTHOR: ${doc.preparedBy.userName} (${doc.preparedBy.email})

AUDITED TIMESTAMP OF ASSEMBLY: ${formatToIST(doc.createdAt)}

----------------------------------------------------------------------
SYSTEM INTEGRITY REGISTER (Secure Protected Quality Envelope)
----------------------------------------------------------------------
This file represents an accepted corporate export from eQMS secure 
nodes. File integrity and tampering states are certified recursively.

======================================================================
DOCUMENT TEXT BODY DATA
======================================================================

${doc.draftContent || 'No draft content entered.'}

======================================================================
SYSTEM LOG RECORD HISTORICAL AUDIT
======================================================================
* Pre-checks completed by: ${doc.preparedBy.userName}
* Reviewed and Approved by MR Department Representative: ${doc.reviewedBy?.userName || 'N/A'}
* Comment history logged:
${doc.comments.map(c => `  [${c.userName} - ${c.timestamp.substring(11, 19)}]: "${c.text}"`).join('\n')}

======================================================================
SYSTEM DIGITAL SIGNATURE LOGS
======================================================================
Signer Name: ${doc.approvedBy?.signerName || 'N/A'}
Signer Title: ${doc.approvedBy?.signerTitle || 'N/A'}
Certified Date/Time: ${doc.approvedBy?.timestamp || 'N/A'}
E-Certificate Hash: ${doc.approvedBy?.hash || 'N/A'}
Signing Meaning: ${doc.approvedBy?.meaning || 'N/A'}

======================================================================
END OF CONTROLLED STANDARD COPY QUALITY RECORD
======================================================================` : `======================================================================
     CORPORATE ELECTRONIC QUALITY MANAGEMENT SYSTEM (eQMS)
======================================================================
DOCUMENT REFERENCE ID: ${doc.id}
TITLE: ${doc.title}
STATUS: ${doc.status}
VERSION: v${doc.version}

PREPARED BY: ${doc.preparedBy.userName} [${doc.preparedBy.email}]
DEPARTMENT: ${doc.department}
CATEGORY: ${doc.category}

----------------------------------------------------------------------
SYSTEM INTEGRITY REGISTER (Secure Protected Quality Envelope)
----------------------------------------------------------------------
This file represents a draft quality record owned by ${doc.preparedBy.userName}.

======================================================================
DRAFT CONTENTS
======================================================================

${doc.draftContent || ''}

======================================================================
END OF RECORD
======================================================================`;

    setDownloadPayload({
      fileName: doc.fileName || `${doc.id}_Approved_Release.docx`,
      fileSize: doc.fileSize || '128 KB',
      fileContent: output,
      checksum: 'prep_' + Math.floor(Math.random() * 90000000 + 10000000).toString(16),
      filePathUrl: doc.finalApprovedCopyUrl || doc.reviewerVerifiedUrl || doc.preparerDraftUrl || doc.mrTemplateCopyUrl
    });
    setDownloadModalOpen(true);
    if (onDownloadSOP) {
      onDownloadSOP(doc.id);
    }
    if (!localDownloadedIds.includes(doc.id)) {
      setLocalDownloadedIds(prev => [...prev, doc.id]);
    }
  };

  return (
    <div className="space-y-6" id="preparer-workspace-panel">
      {/* Header Deck */}
      <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold font-sans tracking-tight text-slate-900 flex items-center gap-2">
            <FileText className="w-5.5 h-5.5 text-blue-600" />
            Document Preparation Desk
          </h2>
          <p className="text-xs text-slate-500 mt-1">
          </p>
        </div>
        <div className="flex flex-wrap gap-2 text-xs font-semibold">
          <button
            onClick={() => { setActiveTab('dcrn_dashboard'); setEditingDoc(null); }}
            className={`px-3.5 py-1.5 rounded border cursor-pointer transition-all flex items-center gap-1.5 bg-amber-50 border-amber-400 text-amber-800 font-bold shadow-xs`}
            id="btn-goto-dcrn-dashboard"
          >
            <Layers className="w-3.5 h-3.5 text-amber-600 font-bold" />
            <span>DCRN Change Control Desk</span>
          </button>
        </div>
      </div>

      {successMsg && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded text-emerald-850 text-xs font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-650" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* RETHINK DIALOG IN-PLACE FOR REJECTED DOCS EDITING */}
      {editingDoc && (
        <div className="bg-[#fefce8] border border-amber-300 rounded-lg p-5 shadow-sm space-y-4">
          <div className="flex justify-between items-start border-b border-amber-200 pb-3">
            <div>
              {editingDoc.status === DocumentStatus.SoftCopyProvided ? (
                <>
                  <span className="text-[10px] font-mono font-bold bg-indigo-100 text-indigo-800 px-1.5 py-0.5 rounded border border-indigo-200">SOP DRAFT FORMULATION</span>
                  <h3 className="text-sm font-bold text-slate-900 mt-1.5">Compose Draft: {editingDoc.title}</h3>
                  <p className="text-xs text-slate-500">Formulate the procedure text and upload the edited Word Document draft copy.</p>
                </>
              ) : (
                <>
                  <span className="text-[10px] font-mono font-bold bg-amber-200 text-amber-800 px-1.5 py-0.5 rounded border border-amber-300">ACTION REQUIRED - COMMITTED REJECTION</span>
                  <h3 className="text-sm font-bold text-slate-900 mt-1.5">Revision Loop: {editingDoc.title}</h3>
                  <p className="text-xs text-slate-500">Amend the procedural body text following external review feedback.</p>
                </>
              )}
            </div>
            <button 
              onClick={() => setEditingDoc(null)}
              className="px-2 py-0.5 text-xs font-bold text-slate-500 hover:text-slate-800 border border-slate-300 rounded hover:bg-slate-50"
            >
              Cancel
            </button>
          </div>

          <div className="bg-[#fffdf0] border border-amber-200 p-3 rounded text-xs">
            <h4 className="font-bold text-slate-800 flex items-center gap-1 mb-1 text-amber-805">Review Comments & History:</h4>
            <div className="space-y-2 mt-1.5 max-h-36 overflow-y-auto">
              {editingDoc.comments.map((c) => (
                <div key={c.id} className="p-2 bg-white rounded border border-amber-100/80">
                  <div className="flex justify-between font-mono text-[10px] text-slate-400">
                    <span className="font-semibold text-slate-600">{c.userName} ({c.role})</span>
                    <span>{formatToIST(c.timestamp)} ITC</span>
                  </div>
                  <p className="text-slate-700 mt-0.5 font-medium">{c.text}</p>
                </div>
              ))}
            </div>
          </div>

          {editingDoc.mrTemplateCopyUrl && (
            <div className="bg-blue-50 border border-blue-200 p-3 rounded text-xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div>
                <h4 className="font-bold text-blue-900">MR Corporate Template Uploaded</h4>
                <p className="text-[10.5px] text-blue-700">Use the official MS Word blueprint template to structure this SOP draft.</p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setDownloadPayload({
                    fileName: editingDoc.fileName || `${editingDoc.id}_Template.docx`,
                    fileSize: editingDoc.fileSize || '128 KB',
                    fileContent: editingDoc.draftContent || '',
                    checksum: 'temp_' + Math.floor(Math.random() * 90000000 + 10000000).toString(16),
                    filePathUrl: editingDoc.mrTemplateCopyUrl
                  });
                  setDownloadModalOpen(true);
                }}
                className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded flex items-center gap-1.5 transition-colors cursor-pointer text-xs shrink-0"
                id="btn-edit-download-template"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Fetch Original Template (.docx)</span>
              </button>
            </div>
          )}

          {/* Reviewer Assignment Dropdown */}
          <div className="bg-white p-4 border border-indigo-150 rounded-lg space-y-2.5 shadow-xs">
            <label className="block text-xs font-bold text-indigo-900 uppercase tracking-widest font-mono">
              Assign Specific Reviewer for Next Stage *
            </label>
            <select
              value={selectedReviewerId}
              onChange={(e) => {
                setSelectedReviewerId(e.target.value);
                setEditingError('');
              }}
              className="w-full text-xs bg-slate-50 border border-slate-300 rounded p-2 text-slate-800 outline-none font-sans focus:border-indigo-500 cursor-pointer"
              required
            >
              <option value="">-- Select Active Reviewer --</option>
              {(users || [])
                .filter(u => u.isReviewer && u.isActive !== false)
                .map(user => (
                  <option key={user.id} value={user.id}>
                    {user.name} ({user.jobTitle || 'Reviewer'})
                  </option>
                ))}
            </select>
          </div>

          {(editingDoc.status === DocumentStatus.SoftCopyProvided || editingDoc.status === DocumentStatus.Rejected || editingDoc.status === DocumentStatus.Draft) && (
            <div className="bg-white p-4 border border-indigo-150 rounded-lg space-y-2.5 shadow-xs">
              <label className="block text-xs font-bold text-indigo-900 uppercase tracking-widest font-mono">
                Upload Actual Word Copy (.doc, .docx) *
              </label>
                             <input
                type="file"
                accept=".doc, .docx"
                id="preparer-draft-file-picker"
                name="preparer-draft-file-picker"
                onChange={async (e) => {
                  if (e.target.files && e.target.files[0]) {
                    const file = e.target.files[0];
                    if (file.name.endsWith('.doc') || file.name.endsWith('.docx')) {
                      setPreparerFileName(file.name);
                      setPreparerFileSize((file.size / 1024).toFixed(0) + ' KB');
                      setEditingError('');
                      try {
                        const result = await uploadFileToServer(file);
                        if (result.success) {
                          console.log("Draft saved in LAN office storage:", result.url);
                        }
                      } catch (err) {
                        setEditingError('LAN server host rejected file save. Local parameters accepted.');
                      }
                    } else {
                      setEditingError('Compliance Error: Only Word Documents (.doc, .docx) are accepted.');
                      setPreparerFileName('');
                    }
                  }
                }}
                className="w-full text-xs text-slate-600 file:mr-4 file:py-1.5 file:px-3 file:rounded file:border-0 file:text-[11px] file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100 cursor-pointer"
                required
              />

              {preparerFileName && (
                <div className="text-[11px] text-indigo-805 font-mono font-medium flex items-center gap-1.5 bg-indigo-50/60 p-2 border border-indigo-200 rounded">
                  <CheckCircle2 className="w-4 h-4 text-indigo-600" />
                  <span>Staged Word Document: {preparerFileName} ({preparerFileSize})</span>
                </div>
              )}
            </div>
          )}

          {editingError && (
            <div className="p-3 bg-rose-50 border border-rose-220 text-rose-850 text-xs font-semibold rounded">
              {editingError}
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Amended Document Text Vault:</label>
            <textarea
              rows={8}
              value={editedBody}
              onChange={(e) => setEditedBody(e.target.value)}
              className="w-full bg-white border border-slate-300 focus:border-blue-500 rounded p-3 text-xs font-mono text-slate-800 outline-none"
              placeholder="Inject compliance revisions..."
            />
          </div>

          <div className="flex justify-end gap-2 text-xs">
            <button
              onClick={() => {
                onUpdateDraftContent(editingDoc.id, editedBody);
                setEditingDoc(null);
                setSuccessMsg('Work-In-Progress revisions saved locally in draft.');
                setTimeout(() => setSuccessMsg(''), 2000);
              }}
              className="px-4 py-1.5 rounded border border-slate-300 text-slate-700 hover:bg-slate-100 font-semibold cursor-pointer"
            >
              Save Draft and Stay
            </button>
            <button
              onClick={saveAndResubmit}
              className="px-4 py-1.5 rounded bg-blue-600 hover:bg-blue-500 text-white font-semibold flex items-center gap-1.5 cursor-pointer"
              id="btn-resubmit-corrected"
            >
              <Send className="w-3.5 h-3.5" />
              <span>
                {editingDoc.status === DocumentStatus.SoftCopyProvided
                  ? 'Sign and Submit Draft to Reviewer'
                  : 'Sign Revisions and Submit to Reviewer'}
              </span>
            </button>
          </div>
        </div>
      )}

      {activeTab === 'track' && !editingDoc && (
        <div className="bg-white border border-slate-200 rounded-lg shadow-sm overflow-hidden" id="drafts-history">
          <div className="p-4 bg-slate-50 border-b border-slate-200 font-mono text-[10.5px] text-slate-500">
            Secure Roster: Document drafts created by credential holder {currentUser.name}
          </div>

          {preparerDocuments.length === 0 ? (
            <div className="p-12 text-center text-slate-400">
              <FileText className="w-12 h-12 mx-auto text-slate-300 opacity-60 mb-2" />
              <p className="text-sm font-medium">No procedures loaded under your local profile.</p>
              <p className="text-xs text-slate-500 mt-1">Click the "Author SOP" tab to formulate your first quality draft.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200 text-left text-xs">
                <thead className="bg-gray-50 text-[10px] font-bold text-[#9ca3af] uppercase tracking-widest font-mono">
                  <tr>
                    <th className="px-5 py-3.5">Standard Procedure Title</th>
                    <th className="px-5 py-3.5">Department / Category</th>
                    <th className="px-5 py-3.5">Assigned File Asset</th>
                    <th className="px-5 py-3.5">Workflow Status</th>
                    <th className="px-5 py-3.5 text-right w-24">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-150 bg-white">
                  {preparerDocuments.map((doc, idx) => {
                    let statusColor = "bg-slate-100 text-slate-700 border-slate-300";
                    if (doc.status === DocumentStatus.PendingReview) {
                      statusColor = "bg-blue-50 text-blue-700 border-blue-200";
                    } else if (doc.status === DocumentStatus.PendingApproval) {
                      statusColor = "bg-amber-50 text-amber-700 border-amber-200";
                    } else if (doc.status === DocumentStatus.Approved) {
                      statusColor = "bg-emerald-50 text-emerald-700 border-emerald-200 font-semibold";
                    } else if (doc.status === DocumentStatus.Rejected) {
                      statusColor = "bg-rose-50 text-rose-700 border-rose-200 animate-pulse";
                    } else if (doc.status === DocumentStatus.SoftCopyProvided) {
                      statusColor = "bg-indigo-50 text-indigo-700 border-indigo-200 font-medium";
                    }

                    const rowBgClass = idx % 2 === 0 ? "bg-blue-50/20" : "bg-white";

                    return (
                      <tr key={doc.id} className={`${rowBgClass} hover:bg-slate-50/50 transition-colors`}>
                        <td className="px-5 py-4">
                          <div className="font-bold text-slate-900 leading-tight">{doc.title}</div>
                          <div className="text-slate-400 text-[10.5px] mt-0.5 line-clamp-1">{doc.description}</div>
                          <div className="text-[10px] text-slate-500 font-mono mt-1">
                            CREATED: {formatToIST(doc.createdAt)} IST
                          </div>
                          {doc.referencedDcrn && (
                            <div className="mt-1 flex items-center gap-1">
                              <span className="inline-flex items-center gap-1 p-0.5 px-1.5 bg-indigo-50 text-indigo-700 border border-indigo-150 rounded text-[9px] font-mono font-bold select-none">
                                <Layers className="w-2.5 h-2.5" />
                                Link DCRN: {doc.referencedDcrn}
                              </span>
                            </div>
                          )}
                        </td>

                        <td className="px-5 py-4">
                          <div className="font-semibold text-slate-850 text-[11px]">{doc.category}</div>
                          <div className="text-slate-400 text-[10.5px] font-medium mt-0.5">{doc.department}</div>
                        </td>
                        <td className="px-5 py-4 whitespace-nowrap">
                          {doc.status === DocumentStatus.Approved ? (
                            <div>
                            {(() => {
                              const isDownloaded = doc.mrDownloaded || localDownloadedIds.includes(doc.id);
                              return (
                                <button
                                  onClick={() => handleDownloadProposal(doc)}
                                  className={`flex items-center gap-1.5 ${isDownloaded ? 'text-indigo-600 hover:text-indigo-800' : 'text-emerald-650 hover:text-emerald-800'} font-sans font-bold group cursor-pointer text-left transition-colors`}
                                  title="Click to download approved released corporate quality SOP"
                                  id={`btn-download-final-${doc.id}`}
                                >
                                  <FileText className={`w-4 h-4 ${isDownloaded ? 'text-indigo-500 group-hover:text-indigo-700' : 'text-emerald-500 group-hover:text-emerald-700'} shrink-0`} />
                                  <span className="underline decoration-dotted group-hover:decoration-solid">
                                    {isDownloaded ? 'Download Final Copy (Again)' : 'Download Final Copy'}
                                  </span>
                                  <Download className={`w-3.5 h-3.5 ${isDownloaded ? 'text-indigo-500' : 'text-emerald-500'} opacity-100 transition-opacity shrink-0 ml-0.5`} />
                                </button>
                              );
                            })()}
                              <div className="text-emerald-600 text-[10px] font-mono mt-0.5">{doc.fileSize} - {doc.version}</div>
                            </div>
                          ) : (
                            <div className="flex flex-col gap-1.5 text-slate-450">
                              <span className="flex items-center gap-1.5 font-medium text-[11px]" title="The final download link is strictly locked until approved by the MR department.">
                                <XCircle className="w-3.5 h-3.5 text-slate-300 shrink-0" />
                                <span>Download Locked</span>
                              </span>
                              <span className="text-[10px] font-mono">
                                {doc.status === DocumentStatus.SoftCopyProvided ? 'Soft Copy Uploaded' : doc.fileName === '(Awaiting MR Soft Copy)' ? 'Awaiting Soft Copy' : 'Awaiting Approval'}
                              </span>
                              {doc.mrTemplateCopyUrl && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    setDownloadPayload({
                                      fileName: doc.fileName || `${doc.id}_Template.docx`,
                                      fileSize: doc.fileSize || '128 KB',
                                      fileContent: doc.draftContent || `TEMPLATE CORE FOR ${doc.title}`,
                                      checksum: 'temp_' + Math.floor(Math.random() * 90000000 + 10000000).toString(16),
                                      filePathUrl: doc.mrTemplateCopyUrl
                                    });
                                    setDownloadModalOpen(true);
                                  }}
                                  className="mt-1 flex items-center gap-1 text-blue-600 hover:text-blue-800 font-sans text-[11px] font-bold cursor-pointer transition-colors"
                                  id={`btn-download-template-${doc.id}`}
                                >
                                  <Download className="w-3 h-3 text-blue-500 shrink-0" />
                                  <span className="underline">Download Original Template</span>
                                </button>
                              )}
                              {doc.status === DocumentStatus.Rejected && doc.reviewerVerifiedUrl && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    setDownloadPayload({
                                      fileName: doc.fileName || `${doc.id}_Redlined.docx`,
                                      fileSize: doc.fileSize || '120 KB',
                                      fileContent: doc.draftContent || `REDLINED CORE FOR ${doc.title}`,
                                      checksum: 'red_' + Math.floor(Math.random() * 90000000 + 10000000).toString(16),
                                      filePathUrl: doc.reviewerVerifiedUrl
                                    });
                                    setDownloadModalOpen(true);
                                  }}
                                  className="mt-1 flex items-center gap-1 text-rose-600 hover:text-rose-800 font-sans text-[11px] font-bold cursor-pointer transition-colors"
                                  id={`btn-download-redlines-${doc.id}`}
                                >
                                  <Download className="w-3 h-3 text-rose-500 shrink-0" />
                                  <span className="underline">
                                    {doc.rejectedBy === 'Approver' ? 'Download Approver Redlines' : 'Download Reviewer Redlines'}
                                  </span>
                                </button>
                              )}
                            </div>
                          )}
                        </td>

                        <td className="px-5 py-4 whitespace-nowrap">
                          <div className="flex flex-col gap-1">
                            <span className={`inline-flex items-center w-fit px-2 py-0.5 rounded text-[11px] font-medium border ${statusColor}`}>
                              {doc.status === DocumentStatus.SoftCopyProvided ? 'Soft Copy Loaded' : doc.status}
                            </span>
                            {doc.assignedReviewer && (doc.status === DocumentStatus.PendingReview || doc.status === DocumentStatus.Rejected) && (
                              <span className="text-[10px] text-indigo-700 font-mono font-medium">
                                <span className="text-slate-400">Assigned Reviewer:</span> {doc.assignedReviewer.userName}
                              </span>
                            )}
                            {doc.assignedApprover && doc.status === DocumentStatus.PendingApproval && (
                              <span className="text-[10px] text-amber-700 font-mono font-semibold">
                                <span className="text-slate-400">Assigned Approver:</span> {doc.assignedApprover.userName}
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="px-5 py-4 text-right whitespace-nowrap font-medium">
                          {(doc.status === DocumentStatus.Draft || doc.status === DocumentStatus.SoftCopyProvided) && (
                            <div className="flex flex-col gap-1 items-end">
                              <button
                                onClick={() => startEditRejected(doc)}
                                className="bg-blue-600 hover:bg-blue-500 text-white text-[10px] px-2.5 py-1 rounded transition-colors flex items-center gap-1 cursor-pointer font-bold border border-blue-400/20"
                                id={`btn-edit-draft-${doc.id}`}
                              >
                                <Edit2 className="w-3 h-3" />
                                Fill Out Copy
                              </button>
                              <button
                                onClick={() => onSubmitDocument(doc.id)}
                                className="bg-slate-700 hover:bg-slate-600 text-white text-[9.5px] px-2 py-0.5 rounded transition-colors flex items-center gap-1 cursor-pointer font-semibold"
                                id={`btn-submit-${doc.id}`}
                              >
                                <Send className="w-2.5 h-2.5" />
                                Submit back to MR
                              </button>
                            </div>
                          )}

                          {doc.status === DocumentStatus.RequestedMR && (
                            <span className="text-[10px] font-mono text-slate-400 italic">MR Provisioning Pending</span>
                          )}

                          {doc.status === DocumentStatus.Rejected && (
                            <button
                              onClick={() => startEditRejected(doc)}
                              className="bg-amber-500 hover:bg-amber-400 text-slate-950 text-[10px] px-2.5 py-1 rounded transition-colors flex items-center gap-1 mx-auto cursor-pointer font-bold border border-amber-600/30"
                              id={`btn-correct-reject-${doc.id}`}
                            >
                              <Edit2 className="w-3 h-3" />
                              Revise Draft
                            </button>
                          )}

                          {(doc.status === DocumentStatus.PendingReview || doc.status === DocumentStatus.PendingApproval) && (
                            <span className="text-[11px] font-mono font-bold text-slate-400 tracking-tight">Under MR Review</span>
                          )}

                          {doc.status === DocumentStatus.Approved && (
                            <span className="text-[11px] text-emerald-600 font-mono font-bold flex items-center justify-end gap-0.5 select-none uppercase tracking-wide">
                              ✓ MR Approved
                            </span>
                          )}

                          {/* Unified Administrative Removal Request Flow / Direct Deletion (Active at ALL stages except Pending Deletion or Archived) */}
                          {doc.status === DocumentStatus.RequestedMR ? (
                            <div className="mt-2.5 flex justify-end">
                              {deletingDocId === doc.id ? (
                                <div className="flex items-center gap-1.5 bg-[#fff1f2] border border-rose-200 px-2 py-1 rounded shadow-xs text-right select-none">
                                  <span className="text-[9px] text-rose-700 font-bold font-sans">Delete request permanently?</span>
                                  <button
                                    onClick={() => {
                                      if (onDeleteDocument) {
                                        onDeleteDocument(doc.id);
                                      }
                                      setDeletingDocId(null);
                                    }}
                                    className="bg-rose-600 hover:bg-rose-700 text-white text-[9px] px-1.5 py-0.5 rounded transition-colors font-bold cursor-pointer"
                                    id={`btn-confirm-delete-${doc.id}`}
                                  >
                                    Yes
                                  </button>
                                  <button
                                    onClick={() => setDeletingDocId(null)}
                                    className="bg-slate-200 hover:bg-slate-300 text-slate-800 text-[9px] px-1.5 py-0.5 rounded transition-colors font-medium cursor-pointer"
                                    id={`btn-cancel-delete-${doc.id}`}
                                  >
                                    No
                                  </button>
                                </div>
                              ) : (
                                <button
                                  onClick={() => setDeletingDocId(doc.id)}
                                  className="text-slate-400 hover:text-rose-600 text-[10px] font-sans font-bold flex items-center gap-1.5 hover:underline transition-all cursor-pointer"
                                  id={`btn-trigger-delete-${doc.id}`}
                                >
                                  <Trash2 className="w-3.5 h-3.5 shrink-0" />
                                  Delete Request
                                </button>
                              )}
                            </div>
                          ) : (
                            doc.status !== DocumentStatus.PendingDeletion && doc.status !== DocumentStatus.Archived && (
                              <div className="mt-2.5 flex justify-end">
                                {deletingDocId === doc.id ? (
                                  <div className="flex items-center gap-1.5 bg-[#fff1f2] border border-rose-200 px-2 py-1 rounded shadow-xs text-right select-none">
                                    <span className="text-[9px] text-rose-700 font-bold font-sans">Request removal?</span>
                                    <button
                                      onClick={() => {
                                        if (onRequestRemoval) {
                                          onRequestRemoval(doc.id);
                                        }
                                        setDeletingDocId(null);
                                      }}
                                      className="bg-rose-600 hover:bg-rose-700 text-white text-[9px] px-1.5 py-0.5 rounded transition-colors font-bold cursor-pointer"
                                      id={`btn-confirm-delete-${doc.id}`}
                                    >
                                      Yes
                                    </button>
                                    <button
                                      onClick={() => setDeletingDocId(null)}
                                      className="bg-slate-200 hover:bg-slate-300 text-slate-800 text-[9px] px-1.5 py-0.5 rounded transition-colors font-medium cursor-pointer"
                                      id={`btn-cancel-delete-${doc.id}`}
                                    >
                                      No
                                    </button>
                                  </div>
                                ) : (
                                  <button
                                    onClick={() => setDeletingDocId(doc.id)}
                                    className="text-slate-400 hover:text-rose-600 text-[10px] font-sans font-bold flex items-center gap-1.5 hover:underline transition-all cursor-pointer"
                                    id={`btn-trigger-delete-${doc.id}`}
                                  >
                                    <Trash2 className="w-3.5 h-3.5 shrink-0" />
                                    Request Removal from List
                                  </button>
                                )}
                              </div>
                            )
                          )}

                          {doc.status === DocumentStatus.PendingDeletion && (
                            <div className="mt-1.5 flex justify-end">
                              <span className="inline-flex items-center px-2 py-0.5 border border-dashed border-rose-300 rounded text-[9.5px] font-mono font-bold bg-rose-50 text-rose-700 animate-pulse select-none">
                                ⏳ PENDING REMOVAL
                              </span>
                            </div>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {activeTab === 'create' && !editingDoc && (
        <form onSubmit={handleFormSubmit} className="space-y-6">
          <div className="grid md:grid-cols-12 gap-5">
            {/* Left Side: Metadata Form */}
            <div className="md:col-span-7 bg-white p-5 border border-slate-200 rounded-lg shadow-sm space-y-4">
              <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2">
                Document Identification & System Metadata
              </h3>

              {errorMsg && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded font-medium text-xs">
                  {errorMsg}
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Standard Document Title *</label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => { setTitle(e.target.value); setErrorMsg(''); }}
                  placeholder="e.g., SOP-3011: Laboratory Cleaning and Sterilization Register"
                  className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 rounded p-2 text-xs text-slate-800 outline-none"
                  id="metadata-title-input"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Associate Accepted DCRN Change Registry Number (Optional)
                </label>
                <select
                  value={referencedDcrn}
                  onChange={(e) => setReferencedDcrn(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 rounded p-2 text-xs text-slate-800 cursor-pointer outline-none font-sans"
                  id="metadata-dcrn-select"
                >
                  <option value="">-- No DCRN Association (Independent Draft) --</option>
                  {(dcrnRequests || [])
                    .filter(r => r.status === 'Completed')
                    .map(r => (
                      <option key={r.id} value={r.mrRegistryNumber || r.id}>
                        {r.mrRegistryNumber} - Change Order: "{r.initialDocs[0]?.docNumber || 'Multi-Document Change'}" ({r.initialDocs.length} update(s))
                      </option>
                    ))}
                </select>
                <p className="text-[10px] text-slate-500 mt-1">
                  Connect this SOP draft to an officially closed, inter-departmentally approved DCRN Change Control entry.
                </p>
              </div>
            </div>

            {/* Right Side: Restricted Workflow Info Panel */}
            <div className="md:col-span-5">
              <div className="bg-gradient-to-br from-blue-50 to-indigo-50/40 p-5 border border-blue-200 rounded-lg shadow-sm space-y-4">
                <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                  <UploadCloud className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <h3 className="text-xs font-mono font-bold text-blue-800 uppercase tracking-widest">
                    MR SOFT COPY PROVISIONING FLOW
                  </h3>
                  <h4 className="text-[13px] font-bold text-slate-800 mt-1 leading-tight">
                    Regulatory Authoring Restrictions Active
                  </h4>
                  <p className="text-[11px] text-slate-600 mt-2 leading-relaxed">
                    Under standard compliance directives, Preparers can no longer upload self-authored binary Word files or templates directly.
                  </p>
                  <p className="text-[11px] text-slate-600 mt-2 leading-relaxed">
                    You must request a soft copy directly from the **Management Representative (MR) Department**. 
                  </p>
                  <p className="text-[11px] text-slate-600 mt-2 leading-relaxed">
                    The MR department will review the specifications, attach the designated corporate outline, and return a draft workspace directly to your tracking dashboard.
                  </p>
                </div>

                <div className="p-3 bg-white/80 rounded border border-blue-100 text-[10.5px] text-slate-500 font-mono space-y-1">
                  <div>• Phase 1: Request Soft Copy (Preparer)</div>
                  <div>• Phase 2: Provision & Upload Template (MR)</div>
                  <div>• Phase 3: Text Editing & Submitting (Preparer)</div>
                  <div>• Phase 4: Final Approval & Sign-off (MR)</div>
                </div>
              </div>
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex justify-end gap-3 text-xs font-semibold border-t border-slate-250 pt-4">
            <button
               type="submit"
              className="px-5 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white transition-all flex items-center gap-2 cursor-pointer border border-blue-500"
              id="btn-request-soft-copy-mr"
            >
              <Send className="w-4 h-4" />
              <span>Request Soft Copy from MR</span>
            </button>
          </div>
        </form>
      )}

      {activeTab === 'dcrn_dashboard' && (
        <div className="space-y-4" id="preparer-dcrn-ledger-dashboard">
          <DcrnWorkflow
            currentUser={currentUser}
            dcrnRequests={ownDeptDcrnRequests}
            isPreparerBoard={true}
            onAddDcrnRequest={onAddDcrnRequest || (() => {})}
            onEvaluateDcrnRequest={onEvaluateDcrnRequest || (() => {})}
            onSubmitDepartmentAssessment={onSubmitDepartmentAssessment || (() => {})}
            onAuthorizeDcrnRequest={onAuthorizeDcrnRequest || (() => {})}
            onDeleteDcrnRequest={onDeleteDcrnRequest}
            onRejectDcrnRemoval={onRejectDcrnRemoval}
            onUpdateDcrnRequest={onUpdateDcrnRequest}
            onUpdateDcrnDocumentField={onUpdateDcrnDocumentField}
            onSubmitToQa={onSubmitToQa}
            users={users}
          />
        </div>
      )}

      {downloadPayload && (
        <DownloadVaultModal
          isOpen={downloadModalOpen}
          onClose={() => setDownloadModalOpen(false)}
          fileName={downloadPayload.fileName}
          fileSize={downloadPayload.fileSize}
          fileContent={downloadPayload.fileContent}
          fileType="docx"
          checksum={downloadPayload.checksum}
          filePathUrl={downloadPayload.filePathUrl}
        />
      )}
    </div>
  );
}
