import React, { useState } from 'react';
import { AuditTrailEntry } from '../types';
import { Terminal, Search, ShieldCheck, Filter, RefreshCw, AlertCircle, RefreshCcw, Download } from 'lucide-react';
import { formatToIST } from '../utils/dateUtils';

interface AuditTrailConsoleProps {
  auditLogs: AuditTrailEntry[];
  onExportAuditLogs: () => void;
}

export default function AuditTrailConsole({ auditLogs, onExportAuditLogs }: AuditTrailConsoleProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedAction, setSelectedAction] = useState<string>('ALL');
  const [integrityVerified, setIntegrityVerified] = useState(true);
  const [verifying, setVerifying] = useState(false);

  // Derive unique action types for filter dropdown
  const actionTypes = ['ALL', ...Array.from(new Set(auditLogs.map(log => log.action)))];

  // Filter logs based on inputs
  const filteredLogs = auditLogs.filter(log => {
    const matchesSearch = 
      log.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.userEmail.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.details.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.id.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesAction = selectedAction === 'ALL' || log.action === selectedAction;

    return matchesSearch && matchesAction;
  });

  // Sort logs: descending order (latest first)
  const sortedLogs = [...filteredLogs].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  // Trigger simulated integrity checking sweep
  const handleVerifyIntegrity = () => {
    setVerifying(true);
    setTimeout(() => {
      setIntegrityVerified(true);
      setVerifying(false);
    }, 1200);
  };

  return (
    <div className="space-y-5" id="audit-trail-console">
      {/* Integrity Summary Header Area */}
      <div className="bg-slate-900 text-slate-100 rounded-lg p-5 border border-slate-800 shadow-md flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono text-emerald-400 font-bold bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-900/40">● SYSTEM_INTEGRITY_SAFE</span>
          </div>
          <h2 className="text-lg font-bold font-sans tracking-tight text-white mt-2 flex items-center gap-2">
            <Terminal className="w-5 h-5 text-amber-500" />
            Immutable Quality Ledger & System History Logs
          </h2>
          <p className="text-xs text-slate-450 mt-1">
            Secure, computer-validated index logging of credentials, procedural adjustments, submissions, and signature consents.
          </p>
        </div>

        <div className="flex gap-2">
          <button
            onClick={handleVerifyIntegrity}
            disabled={verifying}
            className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-slate-200 border border-slate-700 text-xs font-semibold rounded flex items-center gap-1.5 cursor-pointer disabled:cursor-not-allowed transition-all"
            id="btn-verify-integrity"
          >
            <ShieldCheck className={`w-3.5 h-3.5 text-emerald-400 ${verifying ? 'animate-spin' : ''}`} />
            <span>{verifying ? 'Verifying Ledger...' : 'Validate Cryptographic Integrity'}</span>
          </button>

          <button
            onClick={onExportAuditLogs}
            className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded flex items-center gap-1.5 cursor-pointer transition-all border border-blue-400/20"
            id="btn-export-audit"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* FILTER CONTROL REGISTRY BAR */}
      <div className="bg-white p-4 border border-slate-200 rounded-lg shadow-sm grid md:grid-cols-12 gap-3 items-center">
        
        {/* Keyword inputs */}
        <div className="md:col-span-6 relative">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search records by employee, email, log ID, or action keywords..."
            className="w-full bg-slate-50 border border-slate-200 focus:bg-white focus:border-blue-500 outline-none rounded p-2 pl-8 text-xs text-slate-800 placeholder-slate-400 transition-all font-medium"
            id="audit-search-input"
          />
          <span className="absolute left-2.5 top-3 text-slate-400">
            <Search className="w-3.5 h-3.5" />
          </span>
        </div>

        {/* Action picker dropdown */}
        <div className="md:col-span-4 flex items-center gap-2">
          <span className="text-slate-400 font-mono text-[11px] uppercase shrink-0">Action:</span>
          <select
            value={selectedAction}
            onChange={(e) => setSelectedAction(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 rounded p-2 text-xs text-slate-700 outline-none"
            id="audit-action-filter-select"
          >
            {actionTypes.map(act => (
              <option key={act} value={act}>{act.replace('_', ' ')}</option>
            ))}
          </select>
        </div>

        {/* Reset button */}
        <div className="md:col-span-2 text-right">
          <button
            onClick={() => { setSearchTerm(''); setSelectedAction('ALL'); }}
            className="px-3 py-2 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-650 text-xs rounded transition-all cursor-pointer flex items-center justify-center gap-1 w-full font-semibold"
          >
            <RefreshCcw className="w-3 h-3" />
            <span>Reset Grid</span>
          </button>
        </div>
      </div>      {/* LEDGER CENTRAL GRID */}
      <div className="bg-white border border-slate-200 rounded-lg shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 text-left text-xs text-slate-700">
            <thead className="bg-gray-50 text-[10px] font-bold text-[#9ca3af] uppercase tracking-widest font-mono border-b border-gray-200">
              <tr>
                <th scope="col" className="px-5 py-3">Log ID</th>
                <th scope="col" className="px-5 py-3">Timestamp (IST)</th>
                <th scope="col" className="px-5 py-3">Accepted Operator</th>
                <th scope="col" className="px-5 py-3">Action Type</th>
                <th scope="col" className="px-5 py-3">System Log Details</th>
                <th scope="col" className="px-5 py-3">IP Address</th>
                <th scope="col" className="px-5 py-3 text-right">Ledger Checksum</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-150 bg-white font-mono text-[11px]">
              {sortedLogs.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-5 py-12 text-center text-slate-450 italic font-sans text-xs">
                    No log markers satisfied your filter inputs. Try another combination.
                  </td>
                </tr>
              ) : (
                sortedLogs.map((log, idx) => {
                  let accentColor = "text-slate-600 bg-slate-100";
                  if (log.action === 'E_SIGNED' || log.action === 'APPROVED') {
                    accentColor = "text-emerald-700 bg-emerald-50 border-emerald-200 border";
                  } else if (log.action === 'LOGIN_SUCCESS') {
                    accentColor = "text-blue-700 bg-blue-50 border-blue-200 border";
                  } else if (log.action === 'ROLE_MODIFIED') {
                    accentColor = "text-amber-700 bg-amber-50 border-amber-200 border";
                  } else if (log.action === 'DOCUMENT_SUBMITTED') {
                    accentColor = "text-indigo-700 bg-indigo-50 border-indigo-200 border";
                  } else if (log.action === 'REVIEW_PASSED') {
                    accentColor = "text-[cadetblue] bg-cyan-50 border-cyan-200 border";
                  }

                  const rowBg = idx % 2 === 0 ? "bg-blue-50/20" : "bg-white";

                  return (
                    <tr key={log.id} className={`${rowBg} hover:bg-slate-50 transition-colors font-mono`}>
                      <td className="px-5 py-3.5 font-bold text-slate-500 whitespace-nowrap">{log.id}</td>
                      <td className="px-5 py-3.5 text-slate-500 whitespace-nowrap">{formatToIST(log.timestamp)}</td>
                      <td className="px-5 py-3.5 font-sans whitespace-nowrap">
                        <div className="font-semibold text-slate-900 leading-tight">{log.userName}</div>
                        <div className="text-[10px] text-slate-400 select-all font-mono mt-0.5">{log.userEmail}</div>
                      </td>
                      <td className="px-5 py-3.5 whitespace-nowrap">
                        <span className={`inline-block px-2 py-0.5 rounded text-[10px] uppercase font-bold tracking-tight ${accentColor}`}>
                          {log.action}
                        </span>
                      </td>
                      <td className="px-5 py-3.5 font-sans font-medium text-slate-750 max-w-[240px] leading-snug break-words">
                        {log.details}
                      </td>
                      <td className="px-5 py-3.5 text-slate-450 whitespace-nowrap">{log.ipAddress}</td>
                      <td className="px-5 py-3.5 text-right font-bold text-blue-600/85 select-all text-[10.5px]">
                        {log.checksum}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Verification Alert confirmation widget */}
        {integrityVerified && !verifying && (
          <div className="bg-[#f0fdf4] border-t border-slate-200 p-3.5 px-5 flex items-center justify-between font-sans text-xs text-emerald-800">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-600 mt-0.5 shrink-0" />
              <span>
                Verified: <span className="font-bold">ALL CHECKSUM COEFFICIENTS BALANCE.</span> System records conform strictly to Part 11 ledger guidelines and ISO traceability rules. No modifications detected.
              </span>
            </div>
            <span className="hidden leading-none md:inline text-[9.5px] font-mono font-bold text-emerald-600 bg-emerald-100 border border-emerald-300 rounded px-2 py-0.5 uppercase select-none">
              ✓ ENVELOPE SAFE
            </span>
          </div>
        )}
      </div>
    </div>
  );
}
