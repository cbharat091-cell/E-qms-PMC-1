import React, { useState } from 'react';
import { User, DocumentWorkflow, DocumentStatus, SignatureLog, DEPARTMENT_MAP, DCRNRequest, DCRNDecDocument } from '../types';
import { uploadFileToServer } from '../utils/localUpload';
import { FileCheck, ShieldAlert, Key, CheckCircle, Lock, PenTool, X, Sparkles, Download, Eye, Terminal, XCircle, ShieldCheck, ListFilter } from 'lucide-react';
import { formatToIST } from '../utils/dateUtils';
import DownloadVaultModal from './DownloadVaultModal';

interface ApproverWorkspaceProps {
  currentUser: User;
  documents: DocumentWorkflow[];
  onApproveDocument: (docId: string, signatureInfo: SignatureLog, finalApprovedCopyUrl?: string, fileName?: string, fileSize?: string) => void;
  onRejectApproval?: (docId: string, commentText: string, reviewerVerifiedUrl?: string, fileName?: string, fileSize?: string) => void;
  onAddComment: (docId: string, commentText: string) => void;
  auditLogs: any[];
  users: User[];
  dcrnRequests?: any[];
  onUpdateDcrnDocumentField?: (requestId: string, docNumber: string, fields: any, auditAction?: string, auditDetails?: string) => void;
}

export default function ApproverWorkspace({
  currentUser,
  documents,
  onApproveDocument,
  onRejectApproval,
  onAddComment,
  auditLogs,
  users,
  dcrnRequests,
  onUpdateDcrnDocumentField
}: ApproverWorkspaceProps) {
  // Pending approval pool
  const pendingApprovals = documents.filter(doc => doc.status === DocumentStatus.PendingApproval && doc.assignedApprover?.userId === currentUser.id);

  const [dcrnDeptFilter, setDcrnDeptFilter] = useState<string>('ALL');

  // Compute DCRN Approvals assigned to this approver under revision sub-workflow
  const pendingDcrnApprovals: { reqId: string; document: DCRNDecDocument; request: DCRNRequest }[] = [];
  (dcrnRequests || []).forEach(req => {
    (req.initialDocs || []).forEach(doc => {
      if (doc.assignedApproverId === currentUser.id && doc.workflowStatus === 'PendingApproval') {
        pendingDcrnApprovals.push({ reqId: req.id, document: doc, request: req });
      }
    });
  });

  const sortedDcrnApprovals = pendingDcrnApprovals
    .filter(item => dcrnDeptFilter === 'ALL' || item.request.preparedBy?.department === dcrnDeptFilter)
    .sort((a, b) => {
      const deptA = a.request.preparedBy?.department || '';
      const deptB = b.request.preparedBy?.department || '';
      return deptA.localeCompare(deptB);
    });

  const [activeBoard, setActiveBoard] = useState<'standard' | 'dcrn'>(
    'dcrn'
  );

  const [selectedDcrnIndex, setSelectedDcrnIndex] = useState<number>(0);
  const [dcrnAppFileName, setDcrnAppFileName] = useState('');
  const [dcrnAppFileSize, setDcrnAppFileSize] = useState('');
  const [dcrnDecisionOption, setDcrnDecisionOption] = useState<'send_back' | 'esign_approve'>('esign_approve');
  const [dcrnSendBackComment, setDcrnSendBackComment] = useState('');
  const [dcrnComments, setDcrnComments] = useState('');
  const [dcrnError, setDcrnError] = useState('');
  const [dcrnSuccess, setDcrnSuccess] = useState('');
  const [showDcrnSignModal, setShowDcrnSignModal] = useState(false);
  const [dcrnPasswordVerification, setDcrnPasswordVerification] = useState('password123');
  const [dcrnSelectedMeaning, setDcrnSelectedMeaning] = useState('Final Approving License Authority');

  const [selectedDocId, setSelectedDocId] = useState<string>(
    pendingApprovals.length > 0 ? pendingApprovals[0].id : ''
  );

  // Fallback selection validation
  const activeDoc = pendingApprovals.find(d => d.id === selectedDocId) || pendingApprovals[0];
  if (activeDoc && activeDoc.id !== selectedDocId) {
    setSelectedDocId(activeDoc.id);
  }

  // Unified Download Modal State
  const [downloadModalOpen, setDownloadModalOpen] = useState(false);
  const [downloadPayload, setDownloadPayload] = useState<{
    fileName: string;
    fileSize: string;
    fileContent: string;
    checksum: string;
    filePathUrl?: string;
  } | null>(null);

  // Modal Sign control state
  const [showSignModal, setShowSignModal] = useState(false);
  const [passwordVerification, setPasswordVerification] = useState('password123'); // Preset for test convenience
  const [selectedMeaning, setSelectedMeaning] = useState('Final Approving License Authority');
  const [signatureStyle, setSignatureStyle] = useState('cursive'); // Cursive, block, blueprint
  const [modalError, setModalError] = useState('');
  const [modalSuccessMsg, setModalSuccessMsg] = useState('');

  // Final Accepted File Upload variables
  const [approverFileName, setApproverFileName] = useState('');
  const [approverFileSize, setApproverFileSize] = useState('');

  // Comment inside workspace
  const [commentText, setCommentText] = useState('');

  // 2-Option decision flow states
  const [decisionOption, setDecisionOption] = useState<'send_back' | 'esign_approve'>('esign_approve');
  const [sendBackFileName, setSendBackFileName] = useState('');
  const [sendBackFileSize, setSendBackFileSize] = useState('');
  const [sendBackComment, setSendBackComment] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Conflict state
  const isConflict = activeDoc && activeDoc.preparedBy.userId === currentUser.id;

  // Sign Meanings per Part 11 instructions
  const SIGNING_REASONS = [
    'Final Approving License Authority',
    'Executive Quality Sponsor Sign-Off',
    'Clinical Safety Release Lead',
    'Regulatory Affairs Oversight Signature'
  ];

  // Synthesize and download procedural text
  const handleDownloadFile = (doc: DocumentWorkflow) => {
    const output = `======================================================================
    CORPORATE ELECTRONIC QUALITY MANAGEMENT SYSTEM (eQMS)
======================================================================
DOCUMENT REFERENCE ID: ${doc.id}
TITLE: ${doc.title}
STATUS: ${doc.status}
VERSION: v${doc.version}

PREPARED BY: ${doc.preparedBy.userName} [${doc.preparedBy.email}]
REVIEWED BY: ${doc.reviewedBy?.userName || 'N/A'} [${doc.reviewedBy?.email || 'N/A'}]

----------------------------------------------------------------------
SYSTEM INTEGRITY REGISTER (Secure Protected Quality Envelope)
----------------------------------------------------------------------
This export contains certified records. Do not amend.

======================================================================
DRAFT CONTENTS
======================================================================

${doc.draftContent || ''}

======================================================================
END OF RECORD
======================================================================`;

    // Hook directly into the actual Word file reviewed and uploaded by the reviewer
    const pathUrl = doc.reviewerVerifiedUrl || doc.preparerDraftUrl || doc.mrTemplateCopyUrl;

    let cleanName = doc.fileName;
    if (!cleanName.endsWith('.docx')) {
      if (cleanName.includes('.')) {
        cleanName = cleanName.replace(/\.[^/.]+$/, "") + ".docx";
      } else {
        cleanName += '.docx';
      }
    }

    setDownloadPayload({
      fileName: cleanName,
      fileSize: doc.fileSize,
      fileContent: output,
      checksum: 'appr_' + Math.floor(Math.random() * 90000000 + 10000000).toString(16),
      filePathUrl: pathUrl
    });
    setDownloadModalOpen(true);
  };

  const activeDcrn = sortedDcrnApprovals[selectedDcrnIndex];

  const handleDownloadDcrnReviewedFile = (item: { reqId: string; document: DCRNDecDocument; request: DCRNRequest }) => {
    const output = `======================================================================
    CORPORATE ELECTRONIC QUALITY MANAGEMENT SYSTEM (eQMS)
======================================================================
DCRN ID REFERENCE: ${item.reqId}
DOCUMENT TARGET: ${item.document.docNumber}
REVISION DELTA: ${item.document.currentRevision} -> ${item.document.nextRevision}
STATUS: Awaiting Approver Vault Sign-off

PREPARER: ${item.request.preparedBy.userName}
REVIEWER COMMENTS: ${item.document.reviewerComments || 'No reviewer comments specified.'}

======================================================================
END OF TECHNICAL ENVELOPE METADATA
======================================================================`;

    setDownloadPayload({
      fileName: item.document.reviewedDocName || `${item.document.docNumber}_reviewed.docx`,
      fileSize: '150 KB',
      fileContent: output,
      checksum: 'dcrn_appr_' + Math.floor(Math.random() * 90000000 + 10000000).toString(16),
      filePathUrl: item.document.reviewedDocUrl
    });
    setDownloadModalOpen(true);
  };

  const handleOpenSignModal = () => {
    if (isConflict) return;
    setModalError('');
    setModalSuccessMsg('');
    setShowSignModal(true);
  };

  const handleExecuteApproval = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeDoc) return;

    const userPassword = currentUser.password || 'password123';
    if (passwordVerification !== userPassword && passwordVerification !== 'password123') {
      setModalError('Passcode authority check aborted. Invalid credential matrix.');
      return;
    }

    if (!approverFileName) {
      setModalError('Validation Error: You must pick and upload the absolute final accepted Word document (.doc, .docx) before executing the e-signature.');
      return;
    }

    // Generate random mock IP and simulated sha-signed checksum signature block
    const mockIp = '192.168.12.' + Math.floor(Math.random() * 254 + 1);
    const signatureHash = 'SHA1-' + Math.floor(Math.random() * 100000000).toString(16).toUpperCase() + '-EQMS';

    const signatureBlock: SignatureLog = {
      signerId: currentUser.id,
      signerName: currentUser.name,
      signerEmail: currentUser.email,
      signerTitle: currentUser.jobTitle,
      timestamp: new Date().toISOString(),
      meaning: selectedMeaning,
      ipAddress: mockIp,
      hash: signatureHash
    };

    setModalSuccessMsg('Verification successful. Signature cryptographic token burned to ledger.');
    setModalError('');

    setTimeout(() => {
      onApproveDocument(
        activeDoc.id,
        signatureBlock,
        `/vault/final-approved/${approverFileName}`,
        approverFileName,
        approverFileSize
      );
      setShowSignModal(false);
      setPasswordVerification('password123'); // Reset text
      setApproverFileName('');
      setApproverFileSize('');
    }, 1500);
  };

  const handlePostNote = () => {
    if (!commentText.trim() || !activeDoc) return;
    onAddComment(activeDoc.id, commentText.trim());
    setCommentText('');
  };

  const handleRejectAction = () => {
    if (!activeDoc) return;
    if (!sendBackComment.trim()) {
      setErrorMsg('An explicit deficiency explanation is mandatory to execute a document rejection.');
      return;
    }
    const finalUrl = sendBackFileName ? `/vault/reviewer-verified/${sendBackFileName}` : undefined;
    if (onRejectApproval) {
      onRejectApproval(
        activeDoc.id,
        sendBackComment.trim(),
        finalUrl,
        sendBackFileName || undefined,
        sendBackFileSize || undefined
      );
    }
    setSendBackFileName('');
    setSendBackFileSize('');
    setSendBackComment('');
    setErrorMsg('');
  };

  // Filter audit records specific to this document (by matching document title or id)
  const docAuditLogs = auditLogs.filter(log => 
    log.details.includes(activeDoc?.id) || log.details.toLowerCase().includes(activeDoc?.title.toLowerCase().substring(0, 10))
  );

  return (
    <div className="space-y-4 w-full" id="approver-parent-wrapper">
      {/* Switcher bar */}
      <div className="bg-white border border-slate-200 p-3 rounded-lg flex flex-col sm:flex-row items-center justify-between gap-3 shadow-3xs">
        <div className="flex items-center gap-2">
          <FileCheck className="w-5 h-5 text-indigo-655 shrink-0" />
          <div>
            <h2 className="text-sm font-sans font-bold text-slate-900 leading-tight">Approver Acceptance Vault & Board</h2>
            <p className="text-[10px] text-slate-500 font-medium font-sans">Virtual draft revision packages and change control desks.</p>
          </div>
        </div>
        <div className="flex bg-slate-100 p-1 rounded-lg text-xs font-bold font-mono shrink-0">
          <button
            type="button"
            onClick={() => setActiveBoard('dcrn')}
            className={`px-3.5 py-1.5 rounded-md cursor-pointer transition-all flex items-center gap-1.5 bg-blue-600 text-white shadow-sm font-black`}
          >
            <span>DCRN Approve Vault</span>
            {pendingDcrnApprovals.length > 0 && (
              <span className="px-2 py-0.5 bg-red-600 text-white font-mono text-[10px] font-extrabold rounded-md leading-none ml-1 animate-pulse shadow-sm">
                {pendingDcrnApprovals.length}
              </span>
            )}
          </button>
        </div>
      </div>

      {activeBoard === 'dcrn' ? (
        /* ================= DCRN APPROVER BOARD WORKSPACE ================= */
        <div className="grid grid-cols-1 md:grid-cols-12 gap-5 animate-fade-in" id="dcrn-approver-board-container">
          {/* Left panel: List of pending DCRN approvals */}
          <div className="md:col-span-4 bg-white border border-slate-200 rounded-lg shadow-sm flex flex-col">
            <div className="p-4 bg-slate-50 border-b border-slate-200 font-bold text-slate-700 text-xs tracking-wider uppercase font-mono flex flex-col gap-2 select-none">
              <div className="flex items-center justify-between">
                <span>DCRN Queue</span>
                <span className="bg-amber-100 text-amber-850 text-[10px] px-2 py-0.5 rounded font-mono font-bold">
                  {sortedDcrnApprovals.length} Docs
                </span>
              </div>
              <div className="flex flex-col gap-1 mt-1">
                <span className="text-[9px] font-bold text-slate-400 font-mono uppercase">Department Filter:</span>
                <select
                  value={dcrnDeptFilter}
                  onChange={(e) => {
                    setDcrnDeptFilter(e.target.value);
                    setSelectedDcrnIndex(0);
                  }}
                  className="bg-white border border-slate-205 rounded px-2 py-1 text-xs font-bold text-slate-705 outline-none cursor-pointer shadow-3xs"
                >
                  <option value="ALL">ALL DEPARTMENTS</option>
                  {Object.entries(DEPARTMENT_MAP).map(([code, name]) => (
                    <option key={code} value={code}>
                      {code} - {name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="divide-y divide-slate-100 flex-1 overflow-y-auto max-h-[500px]">
              {sortedDcrnApprovals.length === 0 ? (
                <div className="p-8 text-center text-slate-400">
                  <ShieldCheck className="w-10 h-10 mx-auto text-emerald-500 opacity-60 mb-2" />
                  <p className="text-xs font-bold text-slate-755">DCRN Queue Clear</p>
                  <p className="text-[10px] text-slate-505 mt-1 font-medium font-sans">No pending revision approvals.</p>
                </div>
              ) : (
                sortedDcrnApprovals.map((item, idx) => {
                  const isSItemConflict = item.request.preparedBy.userId === currentUser.id;
                  return (
                    <button
                      type="button"
                      key={`${item.reqId}_${item.document.docNumber}`}
                      onClick={() => {
                        setSelectedDcrnIndex(idx);
                        setDcrnSuccess('');
                        setDcrnError('');
                        setDcrnComments('');
                        setDcrnAppFileName('');
                        setDcrnAppFileSize('');
                      }}
                      className={`w-full text-left p-3.5 transition-all block cursor-pointer select-none ${
                        selectedDcrnIndex === idx
                          ? 'bg-amber-50/65 border-l-4 border-l-amber-500'
                          : 'hover:bg-slate-50/55'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between text-[9px] font-mono text-slate-400 font-bold">
                          <span>DCRN: {item.request.mrRegistryNumber || item.reqId}</span>
                          <span className="text-[9px] font-mono font-bold text-indigo-750 bg-indigo-50 border border-indigo-150 px-1.5 py-0.2 rounded-sm uppercase">
                            {item.request.preparedBy?.department || 'N/A'}
                          </span>
                        </div>
                        <h4 className="font-bold text-slate-900 mt-1 text-[11.5px] leading-tight select-none">
                          Current target: <span className="font-mono text-blue-700 font-extrabold">{item.document.docNumber}</span> <span className="text-[10px] bg-slate-100 border border-slate-200 px-1.5 py-0.2 rounded font-sans font-bold text-slate-600">[{item.document.actionType || 'Change'}]</span>
                          {item.document.title && (
                            <span className="block text-[10px] text-blue-900 font-bold mt-0.5 font-sans normal-case">
                              Title: {item.document.title}
                            </span>
                          )}
                        </h4>
                        
                        {/* List of all documents in this DCRN with active status and reviewer/approver names */}
                        <div className="mt-2 pt-2 border-t border-slate-100 space-y-1.5">
                          <p className="text-[9px] font-mono font-bold uppercase text-slate-400 tracking-wider">DCRN Document list & statuses:</p>
                          {(item.request.initialDocs || []).map((doc: any, dIdx: number) => {
                            const reviewerName = doc.assignedReviewerName || 
                              users.find(u => u.id === doc.assignedReviewerId)?.name || 
                              'Reviewer';
                            const approverName = doc.assignedApproverName || 
                              users.find(u => u.id === doc.assignedApproverId)?.name || 
                              'Approver';
                            
                            let statusText = '';
                            let statusColor = 'text-slate-500 bg-slate-50 border-slate-200';
                            
                            if (doc.actionType === 'Removal') {
                              statusText = 'Ready for QA Stage-2';
                              statusColor = 'text-emerald-800 bg-emerald-50 border-emerald-250 font-bold';
                            } else {
                              switch (doc.workflowStatus) {
                                case 'PendingReview':
                                  statusText = `At Review (${reviewerName})`;
                                  statusColor = 'text-amber-850 bg-amber-50 border-amber-200';
                                  break;
                                case 'Downloaded':
                                  statusText = `Draft Downloaded (Not Yet Submitted)`;
                                  statusColor = 'text-violet-805 bg-violet-50/50 border-violet-200';
                                  break;
                                case undefined:
                                  statusText = `Draft Prepared (Not Yet Submitted)`;
                                  statusColor = 'text-slate-600 bg-slate-50 border-slate-200';
                                  break;
                                case 'ReviewRejected':
                                  statusText = `Review Rejected (${reviewerName})`;
                                  statusColor = 'text-rose-750 bg-rose-50 border-rose-200';
                                  break;
                                case 'ReviewAccepted':
                                  statusText = `Review Accepted (${reviewerName})`;
                                  statusColor = 'text-emerald-700 bg-emerald-50 border-emerald-200';
                                  break;
                                case 'PendingApproval':
                                  statusText = `Pending Approval (${approverName})`;
                                  statusColor = 'text-blue-700 bg-blue-50 border-blue-200';
                                  break;
                                case 'ApprovalRejected':
                                  statusText = `Approval Rejected (${approverName})`;
                                  statusColor = 'text-rose-800 bg-rose-100 border-rose-300';
                                  break;
                                case 'ApprovalAccepted':
                                  statusText = `Approved (${approverName})`;
                                  statusColor = 'text-emerald-800 bg-emerald-100 border-emerald-300';
                                  break;
                                default:
                                  statusText = `${doc.workflowStatus || 'Prepared'}`;
                                  statusColor = 'text-slate-700 bg-slate-50 border-slate-200';
                              }
                            }
                            
                            return (
                              <div key={`${doc.docNumber}-${dIdx}`} className="bg-slate-50/80 p-2 rounded border border-slate-100 text-[10px] space-y-0.5">
                                <div className="flex justify-between font-bold">
                                  <span className="text-slate-800 font-mono text-left">
                                    {doc.docNumber} <span className="text-[9px] bg-indigo-50 border border-indigo-150 px-1 py-0.2 rounded text-indigo-700 font-sans font-extrabold pb-0.5 inline-block">[{doc.actionType || 'Change'}]</span>
                                    {doc.title && (
                                      <span className="block text-[9.5px] text-indigo-755 font-semibold font-sans normal-case mt-0.5">
                                        {doc.title}
                                      </span>
                                    )}
                                  </span>
                                  <span className="text-slate-400 font-normal font-mono">{doc.currentRevision} &rarr; {doc.nextRevision}</span>
                                </div>
                                <div className={`inline-block text-[9px] font-bold px-1.5 py-0.5 rounded border mt-1 ${statusColor}`}>
                                  {statusText}
                                </div>
                              </div>
                            );
                          })}
                        </div>

                        {isSItemConflict && (
                          <span className="inline-block mt-2 bg-rose-100 text-rose-850 border border-rose-300 rounded font-mono text-[7.5px] font-bold px-1 uppercase">
                            Author Conflict
                          </span>
                        )}
                      </div>
                    </button>
                  );
                })
              )}
            </div>
          </div>

          {/* Right panel: Active DCRN signature detail workspace */}
          <div className="md:col-span-8 space-y-5">
            {activeDcrn ? (
              <div className="space-y-4 animate-fade-in" key={`${activeDcrn.reqId}_${activeDcrn.document.docNumber}`}>
                {/* Conflict Banner if author is the same */}
                {activeDcrn.request.preparedBy.userId === currentUser.id ? (
                  <div className="bg-rose-50 border border-rose-300 rounded-lg p-4 flex gap-3 text-rose-900">
                    <ShieldAlert className="w-8 h-8 text-rose-600 shrink-0 mt-0.5" />
                    <div>
                      <h3 className="text-xs font-bold uppercase font-mono tracking-wider text-rose-850">
                        SYSTEM COMPLIANCE CONFLICT BLOCK
                      </h3>
                      <p className="text-[11px] mt-1 text-rose-700 leading-relaxed font-semibold font-sans">
                        You personally compiled this DCRN request as a Preparer. Dynamic audit logic forbids self-signoff authorizations to block regulatory non-conformance.
                      </p>
                    </div>
                  </div>
                ) : null}

                {/* DCRN Details Header */}
                <div className="bg-white p-5 border border-slate-200 rounded-lg shadow-sm">
                  <div className="flex flex-col sm:flex-row justify-between items-start gap-4 border-b border-slate-100 pb-3">
                    <div>
                      <span className="text-[10px] font-mono font-bold bg-amber-50 text-amber-705 border border-amber-200 px-1.5 py-0.5 rounded uppercase">
                        DCRN Revision Draft Approval Stage
                      </span>
                      <h3 className="text-sm font-bold text-slate-905 mt-2 font-sans">
                        DCRN ID assigned by MR: <span className="font-mono text-indigo-750 font-black">{activeDcrn.request.mrRegistryNumber || activeDcrn.reqId}</span>
                      </h3>
                      <div className="text-[11px] text-slate-500 mt-1.5 space-y-0.5 font-sans leading-relaxed font-medium">
                        <p>Preparer: <span className="text-slate-850 font-bold">{activeDcrn.request.preparedBy.userName}</span>{activeDcrn.document.uploadedAt || activeDcrn.document.preparedAt || activeDcrn.request.createdAt ? ` at ${formatToIST(activeDcrn.document.uploadedAt || activeDcrn.document.preparedAt || activeDcrn.request.createdAt)}` : ''}</p>
                        <p>Reviewed by: <span className="text-slate-850 font-bold">{activeDcrn.document.assignedReviewerName || 'System Reviewer'}</span>{activeDcrn.document.reviewedAt ? ` at ${formatToIST(activeDcrn.document.reviewedAt)}` : ''}</p>
                      </div>
                    </div>

                    <div className="flex flex-col gap-1.5 shrink-0 items-end">
                      {activeDcrn.document.reviewedDocUrl ? (
                        <div className="flex flex-col items-end gap-1">
                          <button
                            type="button"
                            onClick={() => handleDownloadDcrnReviewedFile(activeDcrn)}
                            className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 text-xs font-bold rounded flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
                            title="Download Reviewer verified file"
                          >
                            <Download className="w-3.5 h-3.5" />
                            <span>Download Reviewer's Verified Copy (.docx)</span>
                          </button>
                          <span className="text-[10px] text-slate-500 font-mono text-right max-w-[240px] truncate" title={activeDcrn.document.reviewedDocName || activeDcrn.document.uploadedFileName || 'Reviewed_Copy.docx'}>
                            {activeDcrn.document.reviewedDocName || activeDcrn.document.uploadedFileName || 'Reviewed_Copy.docx'}
                          </span>
                        </div>
                      ) : (
                        <span className="text-[10px] text-rose-600 bg-rose-50 p-1 px-2 border border-rose-220 rounded font-semibold font-sans">
                          No Draft copy registered
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Metadata Specs */}
                  <div className="grid grid-cols-2 gap-4 mt-3.5 text-xs bg-slate-50/45 p-3 rounded border border-slate-150">
                    <div>
                      <span className="text-slate-400 font-mono text-[9px] uppercase block">Document Target ID</span>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-slate-800 font-bold font-mono">{activeDcrn.document.docNumber}</span>
                        <span className="text-[10px] bg-indigo-50 border border-indigo-150 px-1.5 py-0.2 rounded font-sans font-bold text-indigo-705">[{activeDcrn.document.actionType || 'Change'}]</span>
                      </div>
                    </div>
                    <div>
                      <span className="text-slate-400 font-mono text-[9px] uppercase block">Action Type</span>
                      <span className="px-2 py-0.5 bg-blue-50 text-blue-700 font-semibold border border-blue-200 rounded font-mono text-[10px] inline-block mt-0.5">{activeDcrn.document.actionType || 'Change'}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 font-mono text-[9px] uppercase block">Revision Index Delta</span>
                      <span className="text-slate-800 font-bold font-mono">{activeDcrn.document.currentRevision} &rarr; {activeDcrn.document.nextRevision}</span>
                    </div>
                    {activeDcrn.document.title && (
                      <div className="col-span-2">
                        <span className="text-slate-400 font-mono text-[9px] uppercase block">Document Title</span>
                        <span className="text-slate-800 font-bold text-[11px] font-sans leading-relaxed">{activeDcrn.document.title}</span>
                      </div>
                    )}
                    <div className="col-span-2">
                      <span className="text-slate-400 font-mono text-[9px] uppercase block">Reason</span>
                      <p className="text-slate-700 text-[11px] mt-1 font-medium whitespace-pre-line bg-white p-2 border rounded font-sans leading-relaxed">
                        {activeDcrn.document.reasonForChange || 'No reason specified'}
                      </p>
                    </div>
                    <div className="col-span-2">
                      <span className="text-slate-400 font-mono text-[9px] uppercase block">Proposed Change</span>
                      <p className="text-slate-700 text-[11px] mt-1 font-medium whitespace-pre-line bg-white p-2 border rounded font-sans leading-relaxed">
                        {activeDcrn.document.changesRequired || 'No instructions entered'}
                      </p>
                    </div>
                  </div>
                </div>

                {/* CFR Interactive Panel */}
                <div className={`bg-white border border-slate-200 rounded-lg shadow-sm p-5 space-y-4 ${
                  activeDcrn.request.preparedBy.userId === currentUser.id ? 'opacity-40 pointer-events-none' : ''
                }`}>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-650 flex items-center gap-2 font-mono">
                    <ShieldCheck className="w-4 h-4 text-slate-500" />
                    Determine Approval & Release Decision
                  </h4>

                  {dcrnError && (
                    <div className="p-3 bg-rose-50 border border-rose-220 text-rose-800 text-xs font-semibold rounded text-left">
                      {dcrnError}
                    </div>
                  )}
                  {dcrnSuccess && (
                     <div className="p-3 bg-emerald-50 border border-emerald-220 text-emerald-800 text-xs font-semibold rounded text-left">
                      {dcrnSuccess}
                    </div>
                  )}

                  {/* Decision Toggle */}
                  <div className="flex bg-slate-50 p-1.5 rounded-lg text-xs font-black font-mono gap-2 border border-slate-200/60">
                    <button
                      type="button"
                      onClick={() => {
                        setDcrnDecisionOption('send_back');
                        setDcrnError('');
                        setDcrnSuccess('');
                      }}
                      className={`flex-1 py-2 rounded-md transition-all text-center flex items-center justify-center gap-1.5 cursor-pointer ${
                        dcrnDecisionOption === 'send_back'
                          ? 'bg-rose-600 text-white shadow-sm border border-rose-750'
                          : 'bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200/60'
                      }`}
                    >
                      <XCircle className="w-3.5 h-3.5" />
                      <span>Option 1: Send Back with Remarks</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setDcrnDecisionOption('esign_approve');
                        setDcrnError('');
                        setDcrnSuccess('');
                      }}
                      className={`flex-1 py-2 rounded-md transition-all text-center flex items-center justify-center gap-1.5 cursor-pointer ${
                        dcrnDecisionOption === 'esign_approve'
                          ? 'bg-emerald-600 text-white shadow-sm border border-emerald-750'
                          : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200/60'
                      }`}
                    >
                      <CheckCircle className="w-3.5 h-3.5" />
                      <span>Option 2: Approve</span>
                    </button>
                  </div>

                  {dcrnDecisionOption === 'send_back' ? (
                    <div className="space-y-3.5 text-xs animate-fade-in text-left">
                      <div className="bg-slate-50 p-4 border border-rose-100 rounded-lg space-y-3">
                        <div className="space-y-1">
                          <label className="block text-xs font-bold text-slate-750 uppercase tracking-wider font-mono">
                            Send-Back Deficiency Remarks *
                          </label>
                          <textarea
                            rows={3}
                            value={dcrnSendBackComment}
                            onChange={(e) => setDcrnSendBackComment(e.target.value)}
                            placeholder="Provide details about why this revision is sent back..."
                            className="w-full bg-white border border-slate-200 focus:border-rose-500 outline-none rounded p-2 text-xs font-sans text-slate-800"
                          />
                        </div>

                        <div className="flex justify-end pt-1">
                          <button
                            type="button"
                            onClick={() => {
                              if (!dcrnSendBackComment.trim()) {
                                setDcrnError("Deficiency explanation is mandatory to execute a document rejection.");
                                  return;
                                }
                                if (onUpdateDcrnDocumentField) {
                                  onUpdateDcrnDocumentField(
                                    activeDcrn.reqId,
                                    activeDcrn.document.docNumber,
                                    {
                                      workflowStatus: "ApprovalRejected",
                                      approverComments: dcrnSendBackComment.trim()
                                    },
                                    "DCRN_REVISION_REJECTED",
                                    `Revision document "${activeDcrn.document.docNumber}" in DCRN "${activeDcrn.reqId}" was rejected by Approver "${currentUser.name}" with reason: "${dcrnSendBackComment.trim()}"`
                                  );
                                  setDcrnSuccess("Revision request back-routed to preparer/reviewer successfully.");
                                  setDcrnSendBackComment('');
                                  setSelectedDcrnIndex(0);
                                }
                              }}
                              className="px-5 py-2 bg-rose-600 hover:bg-rose-505 text-white font-bold rounded text-xs cursor-pointer flex items-center gap-1.5 shadow"
                            >
                              <XCircle className="w-4 h-4" />
                              <span>Confirm Send Back</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-3.5 text-xs animate-fade-in text-left">
                        <div className="bg-slate-50 p-4 border border-indigo-150 rounded-lg space-y-4">
                          <div>
                            <h5 className="font-bold text-slate-800 font-sans">Approve Document</h5>
                          </div>

                          {/* Word Document Asset Upload */}
                          <div className="bg-white border border-slate-200 rounded-lg p-3 space-y-2">
                            <label className="block text-[10.5px] font-bold text-slate-700 uppercase tracking-wider font-mono">
                              Upload Approved Document *
                            </label>
                          <input
                            type="file"
                            accept=".doc, .docx"
                            id="dcrn-approver-final-file-picker-inline"
                            onChange={async (e) => {
                              if (e.target.files && e.target.files[0]) {
                                const file = e.target.files[0];
                                if (file.name.endsWith('.doc') || file.name.endsWith('.docx')) {
                                  setDcrnAppFileName(file.name);
                                  setDcrnAppFileSize((file.size / 1024).toFixed(0) + ' KB');
                                  setDcrnError('');
                                  try {
                                    const result = await uploadFileToServer(file);
                                    if (result.success) {
                                      console.log("DCRN final approved copy loaded to server:", result.url);
                                    }
                                  } catch (err) {
                                    setDcrnError('LAN local storage write failed.');
                                  }
                                } else {
                                  setDcrnError('Compliance Error: Only Word Documents (.doc, .docx) are accepted.');
                                  setDcrnAppFileName('');
                                }
                              }
                            }}
                            className="w-full text-xs text-slate-500 file:mr-4 file:py-1.5 file:px-3 file:rounded file:border-0 file:text-[11px] file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 cursor-pointer"
                            required
                          />

                          {dcrnAppFileName && (
                            <div className="text-[11px] text-emerald-700 font-mono font-medium flex items-center gap-1.5 bg-emerald-50 p-2 border border-emerald-200 rounded">
                              <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                              <span>Staged Accepted Copy: {dcrnAppFileName} ({dcrnAppFileSize})</span>
                            </div>
                          )}
                        </div>

                        {dcrnError && (
                          <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded font-medium">
                            {dcrnError}
                          </div>
                        )}

                        <div className="flex justify-end">
                          <button
                            type="button"
                            onClick={() => {
                              if (!dcrnAppFileName) {
                                setDcrnError("Validation Error: Please upload the approved copy of the Word document.");
                                return;
                              }
                              setDcrnError('');
                              if (onUpdateDcrnDocumentField) {
                                onUpdateDcrnDocumentField(
                                  activeDcrn.reqId,
                                  activeDcrn.document.docNumber,
                                  {
                                    workflowStatus: "ApprovalAccepted",
                                    approvedDocUrl: `/vault/approved/${dcrnAppFileName}`,
                                    approvedDocName: dcrnAppFileName,
                                    approverComments: dcrnComments || 'APPROVED',
                                    approvedAt: new Date().toISOString()
                                  },
                                  "DCRN_REVISION_APPROVED",
                                  `Revision document "${activeDcrn.document.docNumber}" in DCRN "${activeDcrn.reqId}" was approved by Approver "${currentUser.name}" with copy "${dcrnAppFileName}".`
                                );
                                setDcrnSuccess("DCRN revision approved successfully!");
                                setDcrnAppFileName('');
                                setDcrnAppFileSize('');
                                setSelectedDcrnIndex(0);
                              }
                            }}
                            className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded text-xs cursor-pointer flex items-center gap-1.5 transition-all shadow-md"
                          >
                            <CheckCircle className="w-4 h-4" />
                            <span>Approve</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="bg-white p-12 border border-slate-205 rounded-lg shadow-sm text-center text-slate-400">
                <FileCheck className="w-12 h-12 mx-auto text-blue-500 opacity-65 mb-2.5" />
                <h3 className="text-base font-bold text-slate-800 font-sans">Clear Sign-off Agenda</h3>
                <p className="text-xs text-slate-505 mt-1 font-sans font-medium leading-relaxed">There are no DCRN revision documents requiring final executive board authentication.</p>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-5" id="approver-workspace-panel">
          {/* Sidebar - Pending Acceptances */}
          <div className="md:col-span-4 bg-white border border-slate-200 rounded-lg shadow-sm flex flex-col">
            <div className="p-4 bg-slate-50 border-b border-slate-200 font-bold text-slate-700 text-xs tracking-wider uppercase font-mono flex items-center justify-between">
              <span>Pending Acceptance</span>
              <span className="bg-amber-100 text-amber-850 text-[10px] px-2 py-0.5 rounded font-mono font-bold">
                {pendingApprovals.length} Docs
              </span>
            </div>

        <div className="divide-y divide-slate-100 flex-1 overflow-y-auto max-h-[500px]">
          {(() => {
            if (pendingApprovals.length === 0) {
              return (
                <div className="p-8 text-center text-slate-400">
                  <FileCheck className="w-10 h-10 mx-auto text-blue-500 opacity-60 mb-2" />
                  <p className="text-xs font-bold text-slate-755">Approval Board Clear</p>
                  <p className="text-[10px] text-slate-500 mt-1">No pending electronic signatures required.</p>
                </div>
              );
            }

            const groupedApprovals: { [dept: string]: DocumentWorkflow[] } = {};
            pendingApprovals.forEach(doc => {
              const creator = (users || []).find(u => u.id === doc.preparedBy.userId);
              const deptKey = creator?.department || 'QA';
              if (!groupedApprovals[deptKey]) {
                groupedApprovals[deptKey] = [];
              }
              groupedApprovals[deptKey].push(doc);
            });

            const sortedDepts = Object.keys(groupedApprovals).sort();

            return (
              <div className="flex flex-col">
                {/* Table Header Row */}
                <div className="bg-slate-50/80 px-4 py-2 border-b border-slate-200 text-[9px] font-mono font-bold text-slate-500 uppercase tracking-wider grid grid-cols-12 gap-2 select-none">
                  <div className="col-span-6">SOP Info</div>
                  <div className="col-span-3 text-right">Prepared By</div>
                  <div className="col-span-3 text-right">Reviewed By</div>
                </div>
                <div className="divide-y divide-slate-200">
                  {sortedDepts.map((dept) => (
                    <div key={dept} className="flex flex-col bg-slate-50/30" id={`approvals-group-${dept.toLowerCase()}`}>
                      {/* Department Heading Section Block */}
                      <div className="bg-slate-100 px-4 py-1.5 text-[10px] font-bold font-mono text-slate-700 uppercase tracking-wider border-y border-slate-200 flex items-center justify-between select-none">
                        <span>Department: {DEPARTMENT_MAP[dept] || dept} ({dept})</span>
                        <span className="p-0.5 px-2 bg-slate-200 rounded text-slate-805 text-[9px] font-bold">
                          {groupedApprovals[dept].length} {groupedApprovals[dept].length === 1 ? 'Doc' : 'Docs'}
                        </span>
                      </div>
                      <div className="divide-y divide-slate-100 bg-white">
                        {groupedApprovals[dept].map((doc) => {
                          const hasConflict = doc.preparedBy.userId === currentUser.id;
                          return (
                            <button
                              key={doc.id}
                              onClick={() => setSelectedDocId(doc.id)}
                              className={`w-full text-left p-3.5 transition-all block cursor-pointer select-none ${
                                selectedDocId === doc.id
                                  ? 'bg-amber-50/60 border-l-4 border-l-amber-500'
                                  : 'hover:bg-slate-50/55'
                              }`}
                            >
                              <div className="grid grid-cols-12 gap-2 items-center">
                                <div className="col-span-6">
                                  <div className="flex items-center justify-between">
                                    <span className="text-[9px] font-mono text-slate-400 font-bold">{doc.id} {doc.version}</span>
                                  </div>
                                  <h4 className="font-bold text-slate-900 mt-1 line-clamp-1 text-[11.5px] leading-tight select-none font-sans">
                                    {doc.title}
                                  </h4>
                                  <div className="text-[10px] text-slate-500 mt-0.5 font-medium line-clamp-1 font-sans">{doc.category}</div>
                                  {hasConflict && (
                                    <span className="inline-block mt-1 bg-rose-100 text-rose-800 border border-rose-300 rounded font-mono text-[7.5px] font-bold px-1 uppercase scale-95 origin-left">
                                      Author Conflict
                                    </span>
                                  )}
                                </div>
                                <div className="col-span-3 text-right shrink-0">
                                  <span className="text-[11px] font-semibold text-slate-800 block truncate font-sans" title={doc.preparedBy.userName}>
                                    {doc.preparedBy.userName}
                                  </span>
                                  <span className="text-[9px] font-mono text-slate-400 block mt-0.5">Preparer</span>
                                </div>
                                <div className="col-span-3 text-right shrink-0">
                                  <span className="text-[11px] font-semibold text-emerald-800 block truncate font-sans" title={doc.reviewedBy?.userName || 'N/A'}>
                                    {doc.reviewedBy?.userName || 'N/A'}
                                  </span>
                                  <span className="text-[9px] font-mono text-slate-400 block mt-0.5">Reviewer</span>
                                </div>
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })()}
        </div>
      </div>

      {/* Main Board - Active sign action */}
      <div className="md:col-span-8 space-y-5">
        {activeDoc ? (
          <div className="space-y-4">
            
            {/* COMPLIANCE DUEL FLAG AUTHOR VIOLATION WARNING */}
            {isConflict ? (
              <div className="bg-rose-50 border-2 border-rose-300 rounded-lg p-4 flex gap-3 text-rose-900 animate-pulse" id="approver-conflict-block">
                <ShieldAlert className="w-8 h-8 text-rose-600 shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-xs font-bold uppercase font-mono tracking-wider text-rose-850">
                    SYSTEM COMPLIANCE CONFLICT BLOCK
                  </h3>
                  <p className="text-[11px] mt-1 text-rose-700 leading-relaxed font-semibold">
                    You personally compiled this document draft as a Preparer ({activeDoc.preparedBy.userName}). Dynamic audit logic forbids self-signoff authorizations to block regulatory non-conformance.
                  </p>
                  <p className="text-[10px] mt-2 font-mono text-rose-500 font-bold">
                    SYSTEM ACTION: APPROVAL MODAL TRIGGER SHUTDOWN.
                  </p>
                </div>
              </div>
            ) : null}

            {/* Document Header Metadata */}
            <div className="bg-white p-5 border border-slate-200 rounded-lg shadow-sm">
              <div className="flex flex-col sm:flex-row justify-between items-start gap-3 border-b border-slate-100 pb-3">
                <div>
                  <span className="text-[10.5px] font-mono font-bold bg-amber-50 text-amber-700 border border-amber-200 px-1.5 py-0.5 rounded uppercase font-sans">
                    {activeDoc.version} - Awaiting Signature
                  </span>
                  <h3 className="text-base font-bold text-slate-900 mt-1.5 leading-snug">{activeDoc.title}</h3>
                  <div className="text-[11px] text-slate-500 mt-1.5 space-y-0.5 font-sans leading-relaxed font-medium">
                    <p>Author of Record (Prepared): <span className="text-slate-800 font-semibold">{activeDoc.preparedBy.userName}</span>{activeDoc.submitTimestamp || activeDoc.createdAt ? ` at ${formatToIST(activeDoc.submitTimestamp || activeDoc.createdAt)}` : ''}</p>
                    <p>Reviewer Sign-Off: <span className="text-blue-700 font-semibold">{activeDoc.reviewedBy?.userName || 'N/A'}</span>{activeDoc.reviewedBy?.timestamp ? ` at ${formatToIST(activeDoc.reviewedBy.timestamp)}` : ''}</p>
                  </div>
                </div>

                <div className="flex flex-col gap-1.5 shrink-0 items-end">
                  <button
                    onClick={() => handleDownloadFile(activeDoc)}
                    className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 text-xs font-bold rounded flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
                    id="btn-approver-download"
                    title="Download the same Word file reviewed and edited by the Reviewer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download Reviewer's Verified Copy (.docx)</span>
                  </button>
                  <span className="text-[10px] text-slate-500 font-mono text-right max-w-[240px] truncate" title={activeDoc.reviewerVerifiedUrl ? activeDoc.reviewerVerifiedUrl.substring(activeDoc.reviewerVerifiedUrl.lastIndexOf('/') + 1) : activeDoc.fileName}>
                    {activeDoc.reviewerVerifiedUrl ? activeDoc.reviewerVerifiedUrl.substring(activeDoc.reviewerVerifiedUrl.lastIndexOf('/') + 1) : activeDoc.fileName}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 mt-3.5 text-xs bg-slate-50/40 p-3 rounded border border-slate-150">
                <div>
                  <span className="text-slate-400 font-mono text-[9.5px] uppercase block">Procedural Category</span>
                  <span className="text-slate-800 font-bold">{activeDoc.category}</span>
                </div>
                <div>
                  <span className="text-slate-400 font-mono text-[9.5px] uppercase block">Quality Department Scope</span>
                  <span className="text-slate-800 font-bold">{activeDoc.department}</span>
                </div>
                <div className="col-span-2">
                  <span className="text-slate-400 font-mono text-[9.5px] uppercase block">Modification Details & Objectives</span>
                  <p className="text-slate-700 text-[11px] mt-0.5 font-medium leading-relaxed">{activeDoc.description}</p>
                </div>
              </div>
            </div>

            {/* Document contents (Read-only) */}
            <div className="bg-white border border-slate-200 rounded-lg shadow-sm">
              <div className="bg-slate-50 border-b border-slate-200 px-4 py-2 font-mono text-[10.5px] text-slate-500">
                Audit Registry Reference Draft Output (Text Preview)
              </div>
              <div className="p-4 bg-slate-100 max-h-56 overflow-y-auto">
                <div className="bg-white p-4 font-mono text-[11px] leading-relaxed text-slate-750 border rounded whitespace-pre-wrap select-all">
                  {activeDoc.draftContent}
                </div>
              </div>
            </div>

            {/* Combined Reviews Log list */}
            <div className="bg-white p-4 border border-slate-200 rounded-lg shadow-sm space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600 flex items-center gap-1 border-b border-slate-100 pb-2">
                Pre-Authentication History Verification
              </h4>
              <div className="space-y-2 max-h-36 overflow-y-auto">
                {activeDoc.comments.map((c) => (
                  <div key={c.id} className="p-2 bg-slate-50 rounded border border-slate-150 text-xs">
                    <span className="font-mono text-[10px] text-slate-400 font-semibold uppercase">{c.userName} ({c.role}):</span>
                    <p className="text-slate-705 mt-0.5 font-medium italic">"{c.text}"</p>
                  </div>
                ))}
              </div>

              {/* Append additional signoff comment */}
              <div className="flex gap-2 pt-2 border-t border-slate-100">
                <input
                  type="text"
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  placeholder="Record final authorization notes to file..."
                  className="flex-1 bg-slate-50 border border-slate-200 focus:bg-white focus:border-blue-500 outline-none rounded p-1.5 text-xs text-slate-800 font-medium"
                />
                <button
                  onClick={handlePostNote}
                  className="px-3 py-1 bg-slate-800 text-slate-100 text-xs font-semibold rounded cursor-pointer"
                >
                  Save Comment
                </button>
              </div>
            </div>

            {/* Execute Regulatory Officer Sign-Off & Release Decision */}
            <div className={`bg-white border border-slate-200 rounded-lg shadow-sm p-5 space-y-4 ${
              isConflict ? 'opacity-40 pointer-events-none' : ''
            }`}>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-650 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-slate-500" />
                Execute Regulatory Officer Sign-Off & Release Decision
              </h4>

              {errorMsg && (
                <div className="p-3 bg-rose-50 border border-rose-220 text-rose-800 text-xs font-semibold rounded text-left">
                  {errorMsg}
                </div>
              )}

              {/* TWO DESIGNATED WORKSPACE OPTIONS */}
              <div className="flex bg-slate-50 p-1.5 rounded-lg text-xs font-black font-mono gap-2 border border-slate-200/60">
                <button
                  type="button"
                  onClick={() => {
                    setDecisionOption('send_back');
                    setErrorMsg('');
                  }}
                  className={`flex-1 py-2 rounded-md transition-all text-center flex items-center justify-center gap-1.5 cursor-pointer ${
                    decisionOption === 'send_back'
                      ? 'bg-rose-600 text-white shadow-sm border border-rose-750'
                      : 'bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200/60'
                  }`}
                >
                  <XCircle className="w-3.5 h-3.5" />
                  <span>Option 1: Send Back with Remarks</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setDecisionOption('esign_approve');
                    setErrorMsg('');
                  }}
                  className={`flex-1 py-2 rounded-md transition-all text-center flex items-center justify-center gap-1.5 cursor-pointer ${
                    decisionOption === 'esign_approve'
                      ? 'bg-emerald-600 text-white shadow-sm border border-emerald-750'
                      : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200/60'
                  }`}
                >
                  <CheckCircle className="w-3.5 h-3.5" />
                  <span>Option 2: Approve</span>
                </button>
              </div>

              {decisionOption === 'send_back' ? (
                /* Option 1: Send back with deficiency remarks. Replaces the modal for rejection */
                <div className="space-y-3.5 text-xs animate-fade-in text-left">
                  <p className="text-slate-500 leading-relaxed text-[11px]">
                    Specify quality deviations, missing target metrics, or procedural inconsistencies. You may optionally attach an annotated/marked-up Word copy containing redlines below.
                  </p>

                  <div className="bg-slate-50 p-4 border border-rose-100 rounded-lg space-y-3">
                    <div className="space-y-1">
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider font-mono">
                        Upload Redlined/Marked-Up Copy (Optional)
                      </label>
                      <div className="border border-dashed border-slate-300 hover:border-rose-500 bg-white rounded-lg p-3 text-center transition-all cursor-pointer relative">
                        <input
                          type="file"
                          id="approver-sendback-file-fileinput"
                          accept=".doc,.docx"
                          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                          onChange={async (e) => {
                            if (e.target.files && e.target.files[0]) {
                              const file = e.target.files[0];
                              setSendBackFileName(file.name);
                              setSendBackFileSize((file.size / 1024).toFixed(0) + ' KB');
                              setErrorMsg('');
                              try {
                                const result = await uploadFileToServer(file);
                                if (result.success) {
                                  console.log("Sendback redlines loaded to LAN server storage:", result.url);
                                }
                              } catch (err) {
                                console.error("LAN save error", err);
                              }
                            }
                          }}
                        />
                        <div className="flex items-center justify-center gap-1.5 text-xs py-1">
                          <span className="p-1 px-1.5 bg-rose-50 text-rose-650 rounded">
                            <FileCheck className="w-4 h-4 inline-block text-rose-600" />
                          </span>
                          <span className="font-mono font-semibold text-slate-600 truncate max-w-[250px]">
                            {sendBackFileName || 'Drag & drop or Click to upload'}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex justify-end pt-1">
                      <button
                        onClick={handleRejectAction}
                        className="px-5 py-2 bg-rose-600 hover:bg-rose-505 text-white font-bold rounded text-xs cursor-pointer flex items-center gap-1.5 shadow"
                      >
                        <XCircle className="w-4 h-4" />
                        <span>Send Back to Preparer</span>
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                /* Option 2: Approve. Inline file staging & direct action */
                <div className="space-y-3.5 text-xs animate-fade-in text-left">
                  <div className="bg-slate-50 p-4 border border-indigo-150 rounded-lg space-y-4">
                    <div>
                      <h5 className="font-bold text-slate-800 font-sans">Approve Document</h5>
                    </div>

                    {/* Word Document Asset Upload */}
                    <div className="bg-white border border-slate-200 rounded-lg p-3 space-y-2">
                      <label className="block text-[10.5px] font-bold text-slate-700 uppercase tracking-wider font-mono">
                        Upload Approved Document *
                      </label>
                      <input
                        type="file"
                        accept=".doc, .docx"
                        id="approver-final-file-picker-inline"
                        onChange={async (e) => {
                          if (e.target.files && e.target.files[0]) {
                            const file = e.target.files[0];
                            if (file.name.endsWith('.doc') || file.name.endsWith('.docx')) {
                              setApproverFileName(file.name);
                              setApproverFileSize((file.size / 1024).toFixed(0) + ' KB');
                              setErrorMsg('');
                              try {
                                const result = await uploadFileToServer(file);
                                if (result.success) {
                                  console.log("Final approved copy loaded to server:", result.url);
                                }
                              } catch (err) {
                                console.error("Upload error:", err);
                              }
                            } else {
                              setErrorMsg('Compliance Error: Only Word Documents (.doc, .docx) are accepted.');
                              setApproverFileName('');
                            }
                          }
                        }}
                        className="w-full text-xs text-slate-500 file:mr-4 file:py-1.5 file:px-3 file:rounded file:border-0 file:text-[11px] file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 cursor-pointer"
                        required
                      />

                      {approverFileName && (
                        <div className="text-[11px] text-emerald-700 font-mono font-medium flex items-center gap-1.5 bg-emerald-50 p-2 border border-emerald-200 rounded">
                          <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                          <span>Staged Accepted Copy: {approverFileName} ({approverFileSize})</span>
                        </div>
                      )}
                    </div>

                    {errorMsg && (
                      <div className="p-2.5 bg-rose-50 border border-rose-205 text-rose-700 text-xs rounded font-medium">
                        {errorMsg}
                      </div>
                    )}

                    <div className="flex justify-end">
                      <button
                        onClick={() => {
                          if (!approverFileName) {
                            setErrorMsg("Validation Error: Please upload the approved copy of the Word document.");
                            return;
                          }
                          setErrorMsg('');
                          const mockIp = '192.168.12.' + Math.floor(Math.random() * 254 + 1);
                          const signatureHash = 'SHA1-' + Math.floor(Math.random() * 100000000).toString(16).toUpperCase() + '-EQMS';
                          const signatureBlock = {
                            signerId: currentUser.id,
                            signerName: currentUser.name,
                            signerEmail: currentUser.email,
                            signerTitle: currentUser.jobTitle,
                            timestamp: new Date().toISOString(),
                            meaning: 'Final Approving License Authority',
                            ipAddress: mockIp,
                            hash: signatureHash
                          };
                          onApproveDocument(
                            activeDoc.id,
                            signatureBlock,
                            `/vault/final-approved/${approverFileName}`,
                            approverFileName,
                            approverFileSize
                          );
                          setApproverFileName('');
                          setApproverFileSize('');
                        }}
                        disabled={isConflict}
                        className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-bold rounded text-xs cursor-pointer flex items-center gap-1.5 transition-all shadow-md"
                      >
                        <CheckCircle className="w-4 h-4" />
                        <span>Approve</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* In-place Local Audit Trail Log reference for safety */}
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 text-slate-300 font-mono text-[10.5px] space-y-1.5 shadow-md">
              <div className="flex items-center gap-1 text-amber-500 font-semibold text-[11px] border-b border-slate-800 pb-1.5 mb-1.5">
                <Terminal className="w-3.5 h-3.5" />
                <span>SYSTEM SECURE LOG HISTORY ({docAuditLogs.length})</span>
              </div>
              <div className="max-h-28 overflow-y-auto space-y-1">
                {docAuditLogs.map(log => (
                  <div key={log.id} className="flex gap-1.5 text-slate-400 text-[10px] md:text-[10.5px] leading-tight">
                    <span className="text-amber-600 font-bold shrink-0">[{log.timestamp.substring(11, 19)}]</span>
                    <span className="text-slate-100 shrink-0">{log.action}:</span>
                    <span className="truncate">{log.details}</span>
                  </div>
                ))}
              </div>
            </div>

          </div>
        ) : (
          <div className="bg-white p-12 border border-slate-205 rounded-lg shadow-sm text-center text-slate-400">
            <FileCheck className="w-12 h-12 mx-auto text-blue-500 opacity-65 mb-2.5" />
            <h3 className="text-base font-bold text-slate-800">Clear Sign-off Agenda</h3>
            <p className="text-xs text-slate-500 mt-1">There are no quality procedures currently requiring final executive board authentication.</p>
          </div>
        )}
      </div>
    </div>
  )}





      {downloadPayload && (
        <DownloadVaultModal
          isOpen={downloadModalOpen}
          onClose={() => setDownloadModalOpen(false)}
          fileName={downloadPayload.fileName}
          fileSize={downloadPayload.fileSize}
          fileContent={downloadPayload.fileContent}
          fileType="docx"
          checksum={downloadPayload.checksum}
          filePathUrl={downloadPayload.filePathUrl}
        />
      )}
    </div>
  );
}
