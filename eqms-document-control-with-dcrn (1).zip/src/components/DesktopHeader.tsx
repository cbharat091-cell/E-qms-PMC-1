import React, { useEffect, useState } from 'react';
import { User } from '../types';
import { Shield, UserCircle, LogOut, ChevronDown, Monitor, RefreshCw } from 'lucide-react';

interface DesktopHeaderProps {
  currentUser: User | null;
  activeRole: 'Admin' | 'Preparer' | 'Reviewer' | 'Approver' | 'NoRole';
  setActiveRole: (role: 'Admin' | 'Preparer' | 'Reviewer' | 'Approver' | 'NoRole') => void;
  onLogout: () => void;
  systemConnected: boolean;
}

export default function DesktopHeader({
  currentUser,
  activeRole,
  setActiveRole,
  onLogout,
  systemConnected
}: DesktopHeaderProps) {
  const [time, setTime] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      // Calculate IST manually
      const utc = now.getTime() + (now.getTimezoneOffset() * 60000);
      const istDate = new Date(utc + (3600000 * 5.5));
      
      const yyyy = istDate.getFullYear();
      const mm = String(istDate.getMonth() + 1).padStart(2, '0');
      const dd = String(istDate.getDate()).padStart(2, '0');
      const hh = String(istDate.getHours()).padStart(2, '0');
      const min = String(istDate.getMinutes()).padStart(2, '0');
      const ss = String(istDate.getSeconds()).padStart(2, '0');

      setTime(`${yyyy}/${mm}/${dd} ${hh}:${min}:${ss} IST`);
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  // Determine which roles are available for switching
  const getAvailableRoles = () => {
    if (!currentUser) return [];
    const roles: ('Admin' | 'Preparer' | 'Reviewer' | 'Approver')[] = [];
    if (currentUser.isAdmin) roles.push('Admin');
    if (currentUser.isPreparer) roles.push('Preparer');
    if (currentUser.isReviewer) roles.push('Reviewer');
    if (currentUser.isApprover) roles.push('Approver');
    return roles;
  };

  const availableRoles = getAvailableRoles();

  return (
    <div id="desktop-titlebar" className="bg-[#111827] text-white flex flex-col border-b border-gray-800 select-none">
      {/* simulated electron window title bar ornament */}
      <div className="flex items-center justify-between px-3 py-1.5 bg-[#0b0f19] text-[11px] font-medium text-slate-400 border-b border-slate-800">
        <div className="flex items-center gap-2">
          {/* Windows-style mini controls */}
          <div className="flex items-center gap-1.5 mr-2">
            <span className="w-3 h-3 rounded-full bg-red-500/80 hover:bg-red-500 cursor-pointer transition-colors block"></span>
            <span className="w-3 h-3 rounded-full bg-yellow-500/80 hover:bg-yellow-500 cursor-pointer transition-colors block"></span>
            <span className="w-3 h-3 rounded-full bg-green-500/80 hover:bg-green-500 cursor-pointer transition-colors block"></span>
          </div>
          <span className="font-mono tracking-wider font-semibold text-slate-300">
            eQMS_DESKTOP_CLIENT_v2.4.0
          </span>
          <span className="inline-flex items-center px-1.5 py-0.2 rounded bg-indigo-950/60 text-[9px] text-indigo-300 font-mono border border-indigo-900">
            Part 11 SECURE
          </span>
        </div>
        
        <div className="flex items-center gap-4 font-mono text-slate-400 text-[11px]">
          <div className="flex items-center gap-1.5">
            <span className={`w-2 h-2 rounded-full ${systemConnected ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'}`}></span>
            <span>{systemConnected ? 'NODE_SECURE' : 'OFFLINE_ERR'}</span>
          </div>
          <div className="hidden md:block select-all bg-slate-900/60 px-2 py-0.5 rounded text-amber-500 border border-slate-800">
            TIME_STAMP: {time}
          </div>
        </div>
      </div>

      {/* Primary header controls */}
      <div className="flex items-center justify-between px-4 py-3 bg-[#111827]">
        {/* Logo and system subtitle */}
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 bg-blue-600 rounded text-slate-100">
            <Shield className="w-5 h-5" id="eqms-shield-icon" />
          </div>
          <div>
            <h1 className="text-sm font-bold tracking-tight text-white leading-tight">
              PMC Document Control
            </h1>
            <p className="text-[10px] text-slate-400 font-medium">
              Enterprise Electronic Quality Management (eQMS)
            </p>
          </div>
        </div>

        {currentUser && (
          <div className="flex items-center gap-3">
            {/* Active Workspace badge & Switcher */}
            {availableRoles.length > 1 ? (
              <div className="relative flex items-center bg-white/10 hover:bg-white/15 rounded border border-white/20 px-3 py-1 text-xs text-white transition-all">
                <span className="text-slate-300 font-mono mr-1.5">Active View:</span>
                <span className="text-blue-400 font-bold mr-2 uppercase tracking-wide">
                  {activeRole}
                </span>
                <div className="relative group">
                  <select
                    value={activeRole}
                    onChange={(e) => setActiveRole(e.target.value as any)}
                    className="absolute inset-0 opacity-0 cursor-pointer w-full"
                    id="role-switch-dropdown"
                  >
                    {availableRoles.map((role) => (
                      <option key={role} value={role} className="text-slate-900">
                        {role} Dashboard
                      </option>
                    ))}
                  </select>
                  <div className="flex items-center gap-0.5 pointer-events-none text-slate-300">
                    <span className="text-[10px] bg-slate-950/80 px-1 py-0.2 rounded border border-slate-750 text-slate-300">Switch workspace</span>
                    <ChevronDown className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>
            ) : (
              <div className="hidden sm:flex items-center bg-white/10 border border-white/25 px-3 py-1 rounded text-xs select-none">
                <span className="text-slate-300 font-mono mr-1.5">Active Workspace:</span>
                <span className="text-blue-400 font-bold uppercase tracking-wide">
                  {activeRole}
                </span>
              </div>
            )}

            {/* User Profile info */}
            <div className="flex items-center gap-2 border-l border-slate-805 pl-3">
              <div className="text-right">
                <div className="text-xs font-semibold text-slate-100 leading-none flex items-center gap-1 justify-end">
                  <UserCircle className="w-3.5 h-3.5 text-slate-300" />
                  {currentUser.name}
                </div>
                <div className="text-[9px] text-slate-400 mt-1">
                  {currentUser.jobTitle}
                </div>
              </div>
              <button
                onClick={onLogout}
                className="p-1 px-2.5 ml-1 bg-rose-950/80 hover:bg-rose-900 border border-rose-800 text-rose-200 rounded text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                title="Log out of Secure Session"
                id="btn-logout"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Logout</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
