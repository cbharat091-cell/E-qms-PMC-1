import React, { useState } from 'react';
import { User, DCRNRequest, DCRNDecDocument, DCRNDepartmentAssessment } from '../types';
import { 
  Building2, 
  CheckCircle2, 
  Check, 
  XCircle,
  AlertTriangle,
  Award,
  Layers,
  HelpCircle,
  Clock,
  Briefcase,
  Calendar,
  Download,
  ShieldCheck
} from 'lucide-react';
import { formatToIST, formatEffectiveDate } from '../utils/dateUtils';

interface QaGatewayWorkspaceProps {
  currentUser: User;
  dcrnRequests: DCRNRequest[];
  onEvaluateDcrnRequest: (requestId: string, approved: boolean, remarks: string, registryNumber?: string, effectiveDate?: string) => void;
}

const DEPARTMENT_MAP: { [key: string]: string } = {
  QA: 'Quality Assurance',
  PE: 'Process Engineering',
  QC: 'Quality Control',
  PD: 'Production / Manufacturing',
  PK: 'Packaging / Labeling'
};

export default function QaGatewayWorkspace({
  currentUser,
  dcrnRequests,
  onEvaluateDcrnRequest
}: QaGatewayWorkspaceProps) {
  const [remarksByReq, setRemarksByReq] = useState<{ [reqId: string]: string }>({});
  const [effectiveDateByReq, setEffectiveDateByReq] = useState<{ [reqId: string]: string }>({});
  const [errorMap, setErrorMap] = useState<{ [reqId: string]: string }>({});

  const handleQAAction = (requestId: string, approve: boolean, isSecondStage: boolean) => {
    const rmk = remarksByReq[requestId] || '';
    if (!approve && !rmk.trim()) {
      setErrorMap(prev => ({ ...prev, [requestId]: "Please provide the mandatory 'Deficiency Notes' context explaining this rejection." }));
      return;
    }
    const effDate = effectiveDateByReq[requestId] || '';
    if (approve && isSecondStage && !effDate) {
      setErrorMap(prev => ({ ...prev, [requestId]: "Please provide the mandatory 'Final Effective Date' for Stage 2 approval." }));
      return;
    }
    
    setErrorMap(prev => {
      const next = { ...prev };
      delete next[requestId];
      return next;
    });

    // Call evaluate with effective date instead of catalog registry number
    onEvaluateDcrnRequest(requestId, approve, rmk, undefined, effDate.trim() || undefined);
    
    setRemarksByReq(prev => {
      const next = { ...prev };
      delete next[requestId];
      return next;
    });
    setEffectiveDateByReq(prev => {
      const next = { ...prev };
      delete next[requestId];
      return next;
    });
  };

  const getMasterDocs = (req: DCRNRequest): DCRNDecDocument[] => {
    const map = new Map<string, DCRNDecDocument>();
    if (req.initialDocs) {
      req.initialDocs.forEach((doc) => {
        map.set(doc.docNumber, doc);
      });
    }
    if (req.assessments) {
      Object.entries(req.assessments).forEach(([code, ass]) => {
        if (code !== "PK" && ass.documents) {
          ass.documents.forEach((doc) => {
            if (!map.has(doc.docNumber)) {
              map.set(doc.docNumber, doc);
            }
          });
        }
      });
    }
    return Array.from(map.values());
  };

  const stage1Requests = dcrnRequests.filter(r => r.status === 'Pending_QA_Evaluation');
  const stage2Requests = dcrnRequests.filter(r => r.status === 'Pending_QA_Stage2');

  const [qaTab, setQaTab] = useState<'stage1' | 'stage2'>(() => {
    if (stage1Requests.length === 0 && stage2Requests.length > 0) {
      return 'stage2';
    }
    return 'stage1';
  });

  const activeRequests = qaTab === 'stage1' ? stage1Requests : stage2Requests;

  return (
    <div className="space-y-5" id="qa-gateway-workspace">
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5 space-y-2">
        <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
          <Building2 className="w-4.5 h-4.5 text-blue-600" />
          Quality Assurance Board Gateway
        </h3>
        <p className="text-xs text-slate-500">
          Evaluates initial requests (Stage 1) and assigns effective dates for final master packets (Stage 2) prior to MR closure.
        </p>
      </div>

      {/* Stage separation selector tabs */}
      <div className="flex border border-slate-200 bg-white p-1 rounded-lg shadow-3xs gap-1">
        <button
          onClick={() => setQaTab('stage1')}
          type="button"
          className={`flex-1 py-2 px-3 text-xs font-bold rounded-md flex items-center justify-center gap-2 transition-all cursor-pointer ${
            qaTab === 'stage1'
              ? 'bg-blue-600 text-white shadow-xs font-semibold'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
          id="btn-qa-stage1-tab"
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Stage-1: Initial DCRN Review</span>
          {stage1Requests.length > 0 && (
            <span className="px-2 py-0.5 rounded bg-red-600 text-white font-mono text-[10px] font-extrabold leading-none animate-pulse shadow-sm">
              {stage1Requests.length}
            </span>
          )}
        </button>
        <button
          onClick={() => setQaTab('stage2')}
          type="button"
          className={`flex-1 py-1.5 px-3 text-xs font-bold rounded-md flex items-center justify-center gap-2 transition-all cursor-pointer ${
            qaTab === 'stage2'
              ? 'bg-violet-600 text-white shadow-xs font-semibold'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
          id="btn-qa-stage2-tab"
        >
          <Award className="w-3.5 h-3.5" />
          <span>Stage-2: Final Audit & Effective Date</span>
          {stage2Requests.length > 0 && (
            <span className="px-2 py-0.5 rounded bg-red-600 text-white font-mono text-[10px] font-extrabold leading-none animate-pulse shadow-sm">
              {stage2Requests.length}
            </span>
          )}
        </button>
      </div>

      {activeRequests.length === 0 ? (
        <div className="bg-white p-12 rounded-xl border border-slate-200 text-center text-slate-400">
          <CheckCircle2 className="w-12 h-12 mx-auto text-emerald-500 mb-3 opacity-80" />
          <p className="text-sm font-semibold text-slate-705">Queue Clean</p>
          <p className="text-xs text-slate-500 mt-1">
            {qaTab === 'stage1' 
              ? 'No outstanding initial Document Change Request Numbers represent Stage-1 QA review bottlenecks.' 
              : 'No final master packets represent Stage-2 QA compliance review or effective date assignment bottlenecks.'}
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {activeRequests.map((req) => {
            const isSecondStage = req.status === 'Pending_QA_Stage2';
            const docsToRender = isSecondStage ? getMasterDocs(req) : req.initialDocs;

            return (
              <div key={req.id} className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden" id={`qa-req-${req.id}`}>
                <div className="bg-blue-50/60 p-4 border-b border-blue-100 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                  <div>
                    {isSecondStage ? (
                      <span className="px-2 py-0.5 bg-violet-100 border border-violet-200 text-violet-750 text-[9px] font-mono font-bold rounded animate-pulse">
                        STAGE 2: FINAL MASTER PACKET COMPLIANCE AUDIT
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 bg-blue-100 border border-blue-200 text-blue-750 text-[9px] font-mono font-bold rounded">
                        STAGE 1: INITIAL DCRN REVIEW
                      </span>
                    )}
                    <p className="text-[10px] text-slate-500 mt-0.5">
                      PREPARER: {req.preparedBy?.userName || 'N/A'} (Dept: {req.preparedBy?.department || 'N/A'}) | CREATED: {formatToIST(req.createdAt)} IST
                    </p>
                  </div>
                  <span className="text-[10.5px] font-mono text-slate-505 text-right bg-white p-1 rounded border animate-pulse border-slate-150">
                    {docsToRender.length === req.initialDocs.length 
                      ? `${docsToRender.length} documents registered` 
                      : `${docsToRender.length} accumulated documents (Initial + Dept modifications)`}
                  </span>
                </div>

                <div className="p-4 space-y-4">
                  {/* Departments assessment Sign-offs tracker if we are in Stage 2 */}
                  {isSecondStage && (
                    <div className="space-y-3">
                      {/* MR Assigned DCRN ID Banner */}
                      <div className="bg-gradient-to-r from-violet-50 to-indigo-50/50 border border-violet-200 rounded-lg p-3 space-y-2">
                        <h6 className="text-[10px] uppercase font-bold text-indigo-900 font-mono tracking-wider flex items-center gap-1">
                          🆔 DCRN ID assigned by MR:
                        </h6>
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5 bg-white p-2.5 rounded border border-indigo-100 shadow-3xs">
                          <span className="text-xs font-mono font-black text-indigo-950 bg-indigo-50 border border-indigo-200 px-2.5 py-0.5 rounded shadow-3xs shrink-0">
                            {req.mrRegistryNumber || "Pending input / assignment in MR Workstation"}
                          </span>
                          {req.mrRegistryNumber ? (
                            <div className="text-[10.5px] text-slate-655">
                              Assigned by: <strong className="text-slate-800">{req.mrRegistryAssignedBy?.userName || req.mrAuthorizedBy?.userName || "MR Representative"}</strong> on <span className="font-mono text-slate-700 font-bold">{formatToIST(req.mrRegistryAssignedAt || req.mrAuthorizedAt || req.createdAt)} IST</span>
                            </div>
                          ) : (
                            <div className="text-[10px] text-amber-705 font-medium italic flex items-center gap-1 animate-pulse">
                              <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                              Awaiting catalog identifier assignment in DCRN Authorization workspace
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Clearance signoffs */}
                      <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 space-y-2">
                        <h6 className="text-[9.5px] uppercase font-bold text-slate-600 font-mono tracking-wider flex items-center gap-1">
                          <Briefcase className="w-3.5 h-3.5 text-violet-600" />
                          Departmental Impact Clearance Signoffs:
                        </h6>
                        <div className="grid gap-2 sm:grid-cols-3">
                          {Object.entries(req.assessments)
                            .filter(([code]) => code !== 'PK')
                            .map(([code, ass]) => {
                              const hasSubmitted = ass && ass.impacted !== null;
                              const isImpactValue = ass && ass.impacted === 'Yes';
                              return (
                                <div 
                                  key={code} 
                                  className={`p-2 rounded border text-[11px] ${
                                    hasSubmitted 
                                      ? isImpactValue 
                                          ? 'bg-amber-50 border-amber-200 text-amber-900' 
                                          : 'bg-emerald-50 border-emerald-200 text-emerald-950' 
                                      : 'bg-slate-50 border-slate-200 text-slate-400'
                                  }`}
                                >
                                  <div className="font-bold flex justify-between items-center">
                                    <span>{DEPARTMENT_MAP[code] || code}</span>
                                    <span className="text-[9px] font-mono uppercase bg-white/60 px-1 border rounded-sm">
                                      {ass.impacted || 'PENDING'}
                                    </span>
                                  </div>
                                  {hasSubmitted && (
                                    <p className="text-[9.5px] text-slate-550 mt-1">
                                      Approved by: {ass.assessedBy?.userName}
                                    </p>
                                  )}
                                </div>
                              );
                            })}
                        </div>
                      </div>
                    </div>
                  )}

                  <div>
                    <h5 className="text-[10px] uppercase font-bold text-slate-500 font-mono tracking-wider mb-2">
                      {isSecondStage ? "Accumulated Master Packet Change Objects:" : "Registered Initial Alter Procedures:"}
                    </h5>
                    <div className="grid gap-3 sm:grid-cols-2">
                      {docsToRender.map((doc, idx) => {
                        const isDocAddedByDept = doc.addedByDept && doc.addedByDept !== req.preparedBy?.department;
                        return (
                          <div key={idx} className="bg-slate-50 p-3 rounded-lg border border-slate-150 hover:bg-slate-100/50 transition-colors">
                            <div className="flex justify-between items-start gap-1">
                              <p className="text-xs font-bold text-indigo-900 font-mono">
                                DCRN-DOC#{idx + 1}: {doc.docNumber} (Rev: {doc.currentRevision || '-'} &rarr; {doc.nextRevision || '-'})
                                {doc.title && (
                                  <span className="text-[10px] text-indigo-755 font-bold bg-indigo-50 border border-indigo-150 rounded px-1.5 py-0.2 mx-1 inline-block font-sans normal-case">
                                    Title: {doc.title}
                                  </span>
                                )}
                              </p>
                              <span className="text-[9px] font-bold font-mono px-1 py-0.2 bg-slate-200 text-slate-705 border border-slate-300 rounded uppercase">
                                {doc.actionType || 'Change'}
                              </span>
                            </div>
                            
                            {isDocAddedByDept && (
                              <p className="text-[9.5px] font-semibold text-violet-755 bg-violet-50 px-1.5 py-0.5 rounded border border-violet-100 mt-1 inline-block font-mono">
                                Added by assessment department: {DEPARTMENT_MAP[doc.addedByDept!] || doc.addedByDept!}
                              </p>
                            )}

                            <p className="text-xs text-slate-755 mt-2">
                              <strong className="text-slate-500 text-[10px] uppercase tracking-wide">Reason:</strong> {doc.reasonForChange}
                            </p>
                            <p className="text-xs text-slate-755 mt-1.5">
                              <strong className="text-slate-500 text-[10px] uppercase tracking-wide">Proposed Changes:</strong> {doc.changesRequired}
                            </p>

                            {/* Download Action Section */}
                            {isSecondStage && doc.approvedDocUrl && (
                              <div className="mt-3 pt-2 border-t border-slate-200">
                                {/* Approver's Final Certified copy */}
                                <div className="flex items-center justify-between gap-1.5 bg-indigo-50 border border-indigo-150 p-2.5 rounded-lg">
                                  <span className="text-[10.5px] text-indigo-955 font-bold truncate flex items-center gap-1.5 min-w-0">
                                    <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 animate-pulse" />
                                    <span className="truncate">Final Approved Copy: {doc.approvedDocName || 'Approved_Copy.docx'}</span>
                                  </span>
                                  <a
                                    href={doc.approvedDocUrl}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    download={doc.approvedDocName || `APPROVED_${doc.docNumber}.docx`}
                                    className="inline-flex items-center gap-1.5 px-3 py-1.2 bg-indigo-600 hover:bg-indigo-750 text-white rounded font-extrabold font-sans text-[10.5px] cursor-pointer transition-all shadow-sm shrink-0"
                                  >
                                    <Download className="w-3 h-3 text-white" />
                                    <span>Download Approved Copy</span>
                                  </a>
                                </div>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-250 space-y-3">
                    {/* Final Effective Date selector ONLY if we are in Stage 2 */}
                    {isSecondStage && (
                      <div>
                        <label className="block text-xs font-bold text-slate-750 mb-1 flex items-center justify-between">
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3.5 h-3.5 text-indigo-600" />
                            Assign Final Effective Release Date *
                          </span>
                          <span className="text-[10px] text-slate-400 font-normal font-mono">(yyyy/mm/dd)</span>
                        </label>
                        <div className="relative flex items-center bg-white rounded border border-slate-200 focus-within:border-indigo-505 focus-within:ring-1 focus-within:ring-indigo-500">
                          <input
                            type="text"
                            placeholder="YYYY/MM/DD"
                            value={effectiveDateByReq[req.id] ? formatEffectiveDate(effectiveDateByReq[req.id]) : ''}
                            onChange={(e) => {
                              const val = e.target.value;
                              setEffectiveDateByReq(prev => ({ ...prev, [req.id]: val }));
                            }}
                            pattern="\d{4}/\d{2}/\d{2}"
                            className="w-full bg-white p-2 pr-10 text-xs outline-none text-slate-800 font-mono font-bold rounded"
                            required
                            title="Please enter in YYYY/MM/DD format"
                          />
                          <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center justify-center w-7 h-7 hover:bg-slate-100 rounded-full transition-colors cursor-pointer">
                            <input
                              type="date"
                              onChange={(e) => {
                                const val = e.target.value; // YYYY-MM-DD
                                if (val) {
                                  const formatted = val.replace(/-/g, '/');
                                  setEffectiveDateByReq(prev => ({ ...prev, [req.id]: formatted }));
                                }
                              }}
                              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                              style={{ zIndex: 10 }}
                            />
                            <Calendar className="w-4 h-4 text-slate-400 pointer-events-none" />
                          </div>
                        </div>
                      </div>
                    )}

                    <div>
                      <label className="block text-xs font-bold text-slate-755 mb-1">
                        QA Evaluation Remarks & Deficiency Notes *
                      </label>
                      <textarea
                        rows={2}
                        value={remarksByReq[req.id] || ''}
                        onChange={(e) => {
                          setRemarksByReq(prev => ({ ...prev, [req.id]: e.target.value }));
                          if (errorMap[req.id]) {
                            setErrorMap(prev => {
                              const next = { ...prev };
                              delete next[req.id];
                              return next;
                            });
                          }
                        }}
                        placeholder={isSecondStage ? "Insert compliance / audit notes here. These will be logged & sent to MR." : "Insert compliance notes here. (Required specifically for reject & return)"}
                        className="w-full bg-white border border-slate-200 focus:border-blue-500 rounded p-2 text-xs outline-none text-slate-800 shadow-inner font-sans"
                      />
                    </div>

                    {errorMap[req.id] && (
                      <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-850 rounded text-xs font-medium flex items-center gap-2 animate-fade-in">
                        <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                        <span>{errorMap[req.id]}</span>
                      </div>
                    )}

                    <div className="flex flex-wrap gap-2 justify-end pt-1">
                      {!isSecondStage && (
                        <button
                          onClick={() => handleQAAction(req.id, false, isSecondStage)}
                          className="px-3.5 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-semibold rounded text-xs cursor-pointer flex items-center gap-1.5 transition-all"
                          id={`btn-reject-qa-${req.id}`}
                        >
                          <XCircle className="w-3.5 h-3.5" />
                          <span>Reject & Return to Preparer</span>
                        </button>
                      )}

                      <button
                        onClick={() => handleQAAction(req.id, true, isSecondStage)}
                        className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded text-xs cursor-pointer flex items-center gap-1.5 transition-all shadow-md"
                        id={`btn-approve-qa-${req.id}`}
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>{isSecondStage ? 'Review, Sign & Submit to MR' : 'Accept DCRN'}</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
