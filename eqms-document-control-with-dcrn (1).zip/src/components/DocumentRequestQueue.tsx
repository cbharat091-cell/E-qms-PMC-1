import React, { useState, useEffect } from "react";
import {
  User,
  DocumentWorkflow,
  DocumentStatus,
  DocumentCategory,
  Department,
  DCRNRequest,
  DEPARTMENT_MAP,
} from "../types";
import { uploadFileToServer } from "../utils/localUpload";
import { formatToIST, formatEffectiveDate } from "../utils/dateUtils";
import DownloadVaultModal from "./DownloadVaultModal";
import { jsPDF } from "jspdf";
import {
  UploadCloud,
  FileText,
  Clock,
  Search,
  ShieldCheck,
  Layers,
  Send,
  AlertTriangle,
  BookmarkCheck,
  CheckCircle2,
  FileCode,
  ShieldAlert,
  Download,
  FileCheck2,
  Trash2,
  FileCheck,
  FileSpreadsheet,
  Filter,
  BarChart3,
  Check,
} from "lucide-react";

interface DocumentRequestQueueProps {
  currentUser: User;
  documents: DocumentWorkflow[];
  onProvideSoftCopy: (
    docId: string,
    draftContent: string,
    fileName: string,
    fileSize: string,
    mrTemplateCopyUrl?: string,
  ) => void;
  onDownloadSOP?: (docId: string) => void;
  isWidget?: boolean; // Can be rendered as a dashboard widget or tab
  onApproveRemoval?: (docId: string) => void;
  onRejectRemoval?: (docId: string) => void;
  dcrnRequests?: DCRNRequest[];
  onApproveDcrnRemoval?: (requestId: string) => void;
  onRejectDcrnRemoval?: (requestId: string) => void;
  onAuthorizeDcrnRequest?: (requestId: string, registryNumber: string) => void;
  onAssignDcrnRegistryNumber?: (
    requestId: string,
    registryNumber: string,
  ) => void;
  onRejectDepartmentAssessment?: (requestId: string, deptCode: string) => void;
  onUploadDcrnDocument?: (
    requestId: string,
    docIndex: number,
    url: string,
    fileName: string,
    fileSize: string,
  ) => void;
}

const CORPORATE_TEMPLATES = [
  {
    name: "ISO-13485 Calibration Outlines",
    fileName: "ISO_13485_Equipment_Calibration_Outlines_MR.docx",
    text: "CLINICAL SPECIFICATION DRAFT: ISO-13485 Equipment calibration ledger.\n\n1.0 PURPOSE:\nEstablish routine inspection thresholds for laboratory scales.\n\n2.0 METHOD:\nPerform reference sweep alignments prior to daily assay production.\n\n3.0 ACCEPTABILITY LIMITS:\nAcceptable variance range resides strictly within ±0.015g limits.",
  },
  {
    name: "FDA Dev Sterile Cleanroom SOP",
    fileName: "Cleanroom_Gowning_And_Hygiene_Standards_MR.docx",
    text: "CLINICAL SPECIFICATION DRAFT: Clinical cleanroom sanitization rules.\n\n1.0 GOWNING REGULATIONS:\nEnforce Level-4 sterile coveralls prior to crossing the primary partition.\n\n2.0 AIR DENSITY CONTROLS:\nPerform particulate index sweeps under pressure chamber guidelines.\n\n3.0 SYSTEM LOGS:\nVerify antiseptic wrist wash logs twice daily.",
  },
  {
    name: "SOP-Pharma Raw Material Receipt",
    fileName: "Pharma_Raw_Material_Verification_Form_MR.docx",
    text: "CLINICAL SPECIFICATION DRAFT: SOP Chemical verification receipt registers.\n\n1.0 INGREDIENTS DESIGNATION:\nCapture manufacturer batch indexes, origin tags, and expiration timelines.\n\n2.0 CHEMICAL STABILITY TASKS:\nCross-verify relative concentration volumes using certified infrared scanners.\n\n3.0 SIGNOFF GUIDELINES:\nStore digital ledger certificates immediately on verify completion.",
  },
];

const renderDocSignOffTimeline = (
  doc: any,
  req: DCRNRequest,
  assessedByDeptName?: string,
  assessedByDeptAt?: string,
) => {
  if (doc.actionType === "Removal") {
    return null;
  }
  const prepName =
    doc.addedByDept && doc.addedByDept !== req.preparedBy?.department
      ? `${assessedByDeptName || "Department Representative"} (${doc.addedByDept})`
      : `${req.preparedBy?.userName} (${req.preparedBy?.department})`;
  const prepTime = doc.uploadedAt || doc.preparedAt || req.createdAt;

  const revName = doc.assignedReviewerName;
  const revTime = doc.reviewedAt || req.createdAt;

  const appName = doc.assignedApproverName;
  const appTime = doc.approvedAt || req.createdAt;

  return (
    <div className="mt-2.5 p-2 bg-slate-50 border border-slate-200 rounded-lg text-[10.5px] text-slate-700 space-y-2">
      {req.status !== "Completed" && (
        <div className="text-[9.5px] font-bold text-slate-400 uppercase tracking-wider border-b pb-1 mb-1.5 flex justify-between">
          <span>CFR Part 11 Electronic Signature Log</span>
          <span className="text-emerald-700 font-bold">Compliant</span>
        </div>
      )}

      <div className="grid md:grid-cols-3 gap-3">
        {/* Phase 1: Prepare */}
        <div className="space-y-0.5 border-r border-slate-200 pr-2 last:border-0">
          <span className="font-bold text-slate-500 uppercase text-[9px] block">
            1. Prepared By
          </span>
          <p className="font-semibold text-slate-800 truncate">{prepName}</p>
          <p className="text-slate-500 text-[9.5px] font-mono">
            {formatToIST(prepTime)}
          </p>
        </div>

        {/* Phase 2: Review */}
        <div className="space-y-0.5 border-r border-slate-200 pr-2 last:border-0 w-full min-w-0">
          <span className="font-bold text-slate-500 uppercase text-[9px] block">
            2. Reviewed By
          </span>
          {revName ? (
            <div className="min-w-0">
              <p
                className="font-semibold text-slate-800 truncate"
                title={revName}
              >
                {revName}
              </p>
              <p className="text-slate-500 text-[9.5px] font-mono">
                {formatToIST(revTime)}
              </p>
            </div>
          ) : (
            <p className="text-amber-600 font-semibold italic">
              Awaiting QA Stage Reviewer
            </p>
          )}
        </div>

        {/* Phase 3: Approve */}
        <div className="space-y-0.5 w-full min-w-0">
          <span className="font-bold text-slate-500 uppercase text-[9px] block">
            3. Approved By
          </span>
          {appName ? (
            <div className="min-w-0">
              <p
                className="font-semibold text-slate-800 truncate"
                title={appName}
              >
                {appName}
              </p>
              <p className="text-slate-500 text-[9.5px] font-mono">
                {formatToIST(appTime)}
              </p>
              {req.status !== "Completed" && doc.approverComments && (
                <p
                  className="text-slate-450 italic text-[9.5px] truncate mt-0.5"
                  title={doc.approverComments}
                >
                  "{doc.approverComments}"
                </p>
              )}
            </div>
          ) : (
            <p className="text-amber-600 font-semibold italic">
              Awaiting QA Stage Approver
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

class PDFGenerator {
  doc: jsPDF;
  y: number;
  margin: number;
  usableWidth: number;
  pageHeight: number;

  constructor() {
    this.doc = new jsPDF("p", "mm", "a4");
    this.y = 15;
    this.margin = 15;
    this.usableWidth = 180;
    this.pageHeight = 297;
  }

  ensureSpace(needed: number) {
    if (this.y + needed > this.pageHeight - this.margin) {
      this.doc.addPage();
      this.y = 15;

      this.doc.setFont("helvetica", "normal");
      this.doc.setFontSize(7.5);
      this.doc.setTextColor(148, 163, 184);
      this.doc.text(
        "FM-MR-14: Document Change/Introduction/Removal Request Note (DCRN)",
        this.margin,
        10,
      );
      this.doc.line(this.margin, 11, 210 - this.margin, 11);
      this.y = 16;
    }
  }

  drawMainHeader(dcrnId: string, regNum: string, status: string) {
    this.doc.setFillColor(49, 46, 129);
    this.doc.rect(this.margin, this.y, this.usableWidth, 18, "F");

    this.doc.setFont("helvetica", "bold");
    this.doc.setFontSize(11);
    this.doc.setTextColor(255, 255, 255);
    this.doc.text(
      "Document Change/Introduction/Removal Request Note (DCRN)",
      this.margin + 4,
      this.y + 6,
    );

    this.doc.setFont("helvetica", "normal");
    this.doc.setFontSize(8);
    this.doc.text(`DCRN Number: ${regNum}`, this.margin + 4, this.y + 12);

    this.y += 24;
  }

  drawSectionHeader(title: string) {
    this.ensureSpace(12);
    this.doc.setFillColor(241, 245, 249);
    this.doc.rect(this.margin, this.y, this.usableWidth, 7, "F");

    this.doc.setFont("helvetica", "bold");
    this.doc.setFontSize(9);
    this.doc.setTextColor(30, 41, 59);
    this.doc.text(title, this.margin + 2.5, this.y + 5);

    this.y += 10;
  }

  drawField(label: string, value: string, boldLabel: boolean = true) {
    this.ensureSpace(5.5);

    this.doc.setFont("helvetica", boldLabel ? "bold" : "normal");
    this.doc.setFontSize(8.5);
    this.doc.setTextColor(71, 85, 105);
    this.doc.text(`${label}:`, this.margin + 2, this.y);

    const labelWidth = this.doc.getTextWidth(`${label}:`) + 4;

    this.doc.setFont("helvetica", "normal");
    this.doc.setTextColor(15, 23, 42);

    const maxValWidth = this.usableWidth - labelWidth - 4;
    const lines: string[] = this.doc.splitTextToSize(value || "", maxValWidth);

    let isFirst = true;
    lines.forEach((line) => {
      if (isFirst) {
        this.doc.text(line, this.margin + 2 + labelWidth, this.y);
        isFirst = false;
      } else {
        this.y += 4.5;
        this.ensureSpace(5);
        this.doc.text(line, this.margin + 2 + labelWidth, this.y);
      }
    });

    this.y += 5;
  }

  drawText(
    text: string,
    fontStyle: "normal" | "bold" | "italic" = "normal",
    fontSize: number = 9,
    color: [number, number, number] = [30, 41, 59],
  ) {
    this.ensureSpace(5);
    this.doc.setFont("helvetica", fontStyle);
    this.doc.setFontSize(fontSize);
    this.doc.setTextColor(...color);
    this.doc.text(text, this.margin + 2, this.y);
    this.y += 5;
  }

  drawSignatureLog(
    title: string,
    name: string,
    dateStr: string,
    remarks?: string,
  ) {
    const linesOfRemarks: string[] = remarks
      ? this.doc.splitTextToSize(remarks, this.usableWidth - 10)
      : [];
    const blockHeight = remarks ? 11 + linesOfRemarks.length * 4.5 : 10;

    this.ensureSpace(blockHeight + 3);

    this.doc.setFillColor(250, 250, 250);
    this.doc.setDrawColor(226, 232, 240);
    this.doc.setLineWidth(0.25);
    this.doc.rect(
      this.margin + 2,
      this.y,
      this.usableWidth - 4,
      blockHeight,
      "FD",
    );

    this.doc.setFont("helvetica", "bold");
    this.doc.setFontSize(7.5);
    this.doc.setTextColor(79, 70, 229);
    this.doc.text(title, this.margin + 5, this.y + 4.5);

    this.doc.setFont("helvetica", "bold");
    this.doc.setFontSize(8.5);
    this.doc.setTextColor(15, 23, 42);
    this.doc.text(name, this.margin + 5, this.y + 8.5);

    const nameWidth = this.doc.getTextWidth(name);
    this.doc.setFont("helvetica", "normal");
    this.doc.setFontSize(8);
    this.doc.setTextColor(120, 130, 145);
    this.doc.text(
      `   signed electronic copy at   ${dateStr}`,
      this.margin + 5 + nameWidth,
      this.y + 8.5,
    );

    if (remarks) {
      this.doc.setFont("helvetica", "italic");
      this.doc.setFontSize(8);
      this.doc.setTextColor(71, 85, 105);
      let remarkY = this.y + 13;
      linesOfRemarks.forEach((line) => {
        this.doc.text(`" ${line} "`, this.margin + 5, remarkY);
        remarkY += 4.5;
      });
    }

    this.y += blockHeight + 2;
  }

  drawDivider() {
    this.ensureSpace(4);
    this.doc.setDrawColor(241, 245, 249);
    this.doc.setLineWidth(0.3);
    this.doc.line(this.margin, this.y, 210 - this.margin, this.y);
    this.y += 4;
  }

  drawFooter() {
    const pageCount = (this.doc as any).internal.getNumberOfPages();
    const pageWidth = this.doc.internal.pageSize.getWidth();
    for (let i = 1; i <= pageCount; i++) {
      this.doc.setPage(i);
      this.doc.setFont("helvetica", "normal");
      this.doc.setFontSize(7);
      this.doc.setTextColor(148, 163, 184);

      this.doc.line(this.margin, 282, 210 - this.margin, 282);
      this.doc.text(
        "Premier Medical Corporation Private Limited",
        pageWidth / 2,
        286,
        { align: "center" },
      );
      this.doc.text(`Page ${i} of ${pageCount}`, pageWidth / 2, 290, {
        align: "center",
      });
    }
  }

  save(fileName: string) {
    this.drawFooter();
    this.doc.save(fileName);
  }
}

const exportWholeDcrnDetails = (req: DCRNRequest) => {
  const customId = req.id.includes(req.preparedBy?.department)
    ? req.id
    : `DCRN-${req.preparedBy?.department || "QA"}-${req.id.replace("DCRN-", "")}`;
  const registryNum = req.mrRegistryNumber || "PENDING ASSIGNMENT";

  const pdf = new PDFGenerator();
  pdf.drawMainHeader(
    customId,
    registryNum,
    "Closed & Archived Document Record",
  );

  // Custom deterministic secure authentic seal hash
  const checksumSeal =
    "dcrn_seal_" +
    Math.abs(
      req.id
        .split("")
        .reduce((acc, char) => (acc << 5) - acc + char.charCodeAt(0), 0),
    )
      .toString(16)
      .padEnd(8, "c");

  // Step 1: Preparation
  pdf.drawSectionHeader("1. PREPARATION");
  const deptCode = req.preparedBy?.department || "N/A";
  const deptFull = DEPARTMENT_MAP[deptCode] || deptCode;
  pdf.drawField("Initiating Department", `${deptFull} (${deptCode})`);
  pdf.drawField("Prepared By", `${req.preparedBy?.userName || "N/A"}`);
  pdf.drawField(
    "Initiation Timestamp (ITC)",
    req.createdAt ? formatToIST(req.createdAt) : "N/A",
  );
  pdf.drawDivider();

  // Step 2: QA Stage-1
  pdf.drawSectionHeader("2. QA STAGE-1");
  if (req.qaEvaluatedBy) {
    pdf.drawField("Clearance Gateway", "APPROVED / COMPLIANT GATEWAY VERIFIED");
    pdf.drawField("QA Stage-1 Evaluator", `${req.qaEvaluatedBy.userName}`);
    pdf.drawField(
      "Clearance Timestamp (ITC)",
      req.qaEvaluatedAt ? formatToIST(req.qaEvaluatedAt) : "N/A",
    );
    pdf.drawField(
      "Evaluation Remarks & Notes",
      req.qaEvaluationRemarks ||
        "Verified compliant with Stage-1 regulatory prerequisites.",
    );
  } else {
    pdf.drawField(
      "Clearance Gateway status",
      "Awaiting Phase-1 clearance review.",
    );
  }
  pdf.drawDivider();

  // Step 3: DCRN Assign
  pdf.drawSectionHeader("3. DCRN NUMBER ASSIGN");
  pdf.drawField("DCRN Number", registryNum);
  const assignedByObj =
    req.mrRegistryAssignedBy || req.mrAuthorizedBy || req.qaEvaluatedBy;
  pdf.drawField(
    "Assigned By",
    assignedByObj ? `${assignedByObj.userName}` : "Regulatory Quality Office",
  );
  const assignedAtTime =
    req.mrRegistryAssignedAt || req.qaEvaluatedAt || req.createdAt;
  pdf.drawField(
    "Registry Entry Timestamp (ITC)",
    assignedAtTime ? formatToIST(assignedAtTime) : "N/A",
  );
  pdf.drawDivider();

  // Step 4: Preparer Initial Document Record
  pdf.drawSectionHeader("4. PREPARER INITIAL DOCUMENT RECORD");
  const initialDocs = req.initialDocs.filter(
    (d) =>
      !d.addedByDept || d.addedByDept === (req.preparedBy?.department || ""),
  );
  if (initialDocs.length === 0) {
    pdf.drawField("Initial items logged", "No customized revisions declared.");
  } else {
    initialDocs.forEach((doc, idx) => {
      pdf.ensureSpace(12);
      pdf.drawText(
        `Document Number: ${doc.docNumber}`,
        "bold",
        9,
        [49, 46, 129],
      );
      pdf.drawField("Document Title", doc.title || "Untitled Quality Document");
      pdf.drawField("Target Action Type", doc.actionType || "Change");
      pdf.drawField(
        "Revision Interval",
        `${doc.currentRevision || "0"} -> ${doc.nextRevision || "1"}`,
      );
      pdf.drawField(
        "Reason for Change",
        doc.reasonForChange || "Initial change assessment.",
      );
      pdf.drawField(
        "Proposed Changes",
        doc.changesRequired || "No specific alterations.",
      );

      const prepName = `${req.preparedBy?.userName || "N/A"}`;
      if (doc.actionType !== "Removal") {
        pdf.drawSignatureLog(
          "1. Prepared By:",
          prepName,
          formatToIST(doc.preparedAt || req.createdAt),
        );
        pdf.drawSignatureLog(
          "2. Reviewed By:",
          doc.assignedReviewerName || "QA Stage Reviewer",
          formatToIST(doc.reviewedAt || req.createdAt),
          "",
        );
        pdf.drawSignatureLog(
          "3. Approved By:",
          doc.assignedApproverName || "QA Stage Approver",
          formatToIST(doc.approvedAt || req.createdAt),
          "",
        );
      }
      pdf.drawDivider();
    });
  }

  // Step 5: Department Impact Analysis
  pdf.drawSectionHeader("5. DEPARTMENT IMPACT ANALYSIS");
  const assessments = Object.entries(req.assessments || {}).filter(
    ([code]) => code !== "PK" && code !== (req.preparedBy?.department || ""),
  );
  if (assessments.length === 0) {
    pdf.drawField(
      "External Assessments",
      "No concurrent inter-departmental assessments logged.",
    );
  } else {
    assessments.forEach(([code, ass]) => {
      pdf.ensureSpace(15);
      const isDeptImpacted =
        ass.impacted === "Yes" ||
        req.initialDocs.some((d) => d.addedByDept === code);

      const deptLabel = `${DEPARTMENT_MAP[code] || code} (${code})`;
      const impactStatusText = isDeptImpacted
        ? "IMPACTED & PROCESS REGISTERED"
        : "NOT IMPACTED - CLEAR FROM OUTCOME";
      const statusColor: [number, number, number] = isDeptImpacted
        ? [217, 119, 6]
        : [22, 163, 74];

      pdf.drawText(
        `DEPARTMENT TRACKED: ${deptLabel}`,
        "bold",
        9.5,
        [15, 23, 42],
      );
      pdf.drawText(
        `Assessment Conclusion: ${impactStatusText}`,
        "bold",
        8.5,
        statusColor,
      );

      if (ass.assessedBy) {
        pdf.drawField("Assessed / Evaluated By", `${ass.assessedBy.userName}`);
        pdf.drawField(
          "Assessment Timestamp (ITC)",
          ass.assessedAt ? formatToIST(ass.assessedAt) : "N/A",
        );
      } else {
        pdf.drawField(
          "Assessed By Representative",
          "Awaiting evaluation clearance.",
        );
      }

      if (isDeptImpacted) {
        const deptDocs = req.initialDocs.filter((d) => d.addedByDept === code);
        const docsToRender =
          deptDocs.length > 0 ? deptDocs : ass.documents || [];
        if (docsToRender.length === 0) {
          pdf.drawField(
            "Department documents",
            "Impact recognized, but no customized localized modifications submitted.",
          );
        } else {
          docsToRender.forEach((doc, idx) => {
            pdf.ensureSpace(10);
            pdf.drawText(
              `  - Document Number: ${doc.docNumber}`,
              "bold",
              8.5,
              [30, 41, 59],
            );
            pdf.drawField(
              "    Document Title",
              doc.title || "Untitled Quality Document",
              false,
            );
            pdf.drawField("    Action Type", doc.actionType || "Change", false);
            pdf.drawField(
              "    Revision Span",
              `${doc.currentRevision || "0"} -> ${doc.nextRevision || "1"}`,
              false,
            );
            pdf.drawField(
              "    Reason for change",
              doc.reasonForChange ||
                "Departmental specific modification request.",
              false,
            );
            pdf.drawField(
              "    Description of alters",
              doc.changesRequired || "Impacted revisions.",
              false,
            );

            const deptPrepName = `${req.preparedBy?.userName || "N/A"}`;
            if (doc.actionType !== "Removal") {
              pdf.drawSignatureLog(
                "    1. Prepared By:",
                deptPrepName,
                formatToIST(doc.preparedAt || req.createdAt),
              );
              pdf.drawSignatureLog(
                "    2. Reviewed By:",
                doc.assignedReviewerName || "QA Stage Reviewer",
                formatToIST(doc.reviewedAt || req.createdAt),
                "",
              );
              pdf.drawSignatureLog(
                "    3. Approved By:",
                doc.assignedApproverName || "QA Stage Approver",
                formatToIST(doc.approvedAt || req.createdAt),
                "",
              );
            }
          });
        }
      }
      pdf.drawDivider();
    });
  }

  // Step 6: QA Stage-2
  pdf.drawSectionHeader("6. QA STAGE-2");
  if (req.qaStage2EvaluatedBy || req.status === "Completed") {
    pdf.drawField(
      "Evaluated By",
      `${req.qaStage2EvaluatedBy?.userName || req.qaEvaluatedBy?.userName || "QA Senior Auditor"}`,
    );
    pdf.drawField(
      "Effective Assigned Date",
      req.effectiveDate ? formatEffectiveDate(req.effectiveDate) : "IMMEDIATE",
    );
    pdf.drawField(
      "Evaluation Sign-off Remarks",
      req.qaStage2Remarks ||
        "Verified compliant with ISO & FDA release requirements.",
    );
    pdf.drawField(
      "Verification Timestamp (ITC)",
      req.qaStage2EvaluatedAt
        ? formatToIST(req.qaStage2EvaluatedAt)
        : req.qaEvaluatedAt
          ? formatToIST(req.qaEvaluatedAt)
          : "N/A",
    );
  } else {
    pdf.drawField("Status", "Awaiting official Stage-2 verification.");
  }
  pdf.drawDivider();

  // Step 7: Acceptance and closure
  pdf.drawSectionHeader("7. ACCEPTANCE AND CLOSURE");
  if (req.mrAuthorizedBy) {
    pdf.drawField("Closed By", `${req.mrAuthorizedBy.userName}`);
    pdf.drawField(
      "Final Closure Timestamp (ITC)",
      req.mrAuthorizedAt ? formatToIST(req.mrAuthorizedAt) : "N/A",
    );
  } else {
    pdf.drawField(
      "Closure Release status",
      "Awaiting Management Representative signature and ledger record locking.",
    );
  }

  pdf.save(`DCRN_RECORD_${registryNum || req.id}.pdf`);
};

export default function DocumentRequestQueue({
  currentUser,
  documents,
  onProvideSoftCopy,
  onDownloadSOP,
  isWidget = false,
  onApproveRemoval,
  onRejectRemoval,
  dcrnRequests = [],
  onApproveDcrnRemoval,
  onRejectDcrnRemoval,
  onAuthorizeDcrnRequest,
  onAssignDcrnRegistryNumber,
  onRejectDepartmentAssessment,
  onUploadDcrnDocument,
}: DocumentRequestQueueProps) {
  // Filter pending requests with RequestedMR status
  const pendingRequests = documents.filter(
    (doc) => doc.status === DocumentStatus.RequestedMR,
  );
  const approvedDocs = documents.filter(
    (doc) => doc.status === DocumentStatus.Approved,
  );
  const deletionRequests = documents.filter(
    (doc) => doc.status === DocumentStatus.PendingDeletion,
  );
  const pendingDcrnDeletions = dcrnRequests.filter(
    (req) => req.pendingDeletion === true,
  );

  const [localDownloadedIds, setLocalDownloadedIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem("dcrn_downloaded_ids");
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(
        "dcrn_downloaded_ids",
        JSON.stringify(localDownloadedIds),
      );
    } catch (e) {}
  }, [localDownloadedIds.length, localDownloadedIds.join(",")]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedDocId, setSelectedDocId] = useState<string | null>(null);

  // Sub-tabs for MR
  const [activeMRTab, setActiveMRTab] = useState<
    | "pending"
    | "approved"
    | "sop_removal"
    | "dcrn_removal"
    | "dcrn_authorization"
  >("dcrn_authorization");

  // MR DCRN States
  const [mrSearchQuery, setMrSearchQuery] = useState("");
  const [mrStatusFilter, setMrStatusFilter] = useState<string>("ALL");
  const [mrDeptFilter, setMrDeptFilter] = useState<string>("ALL");
  const [assignedRegistryNum, setAssignedRegistryNum] = useState<{
    [reqId: string]: string;
  }>({});
  const [confirmRejectKey, setConfirmRejectKey] = useState<string | null>(null);
  const [authSubSection, setAuthSubSection] = useState<
    "unauthorized" | "open" | "accepted"
  >("unauthorized");
  const [expandedAuthorizedDcrnId, setExpandedAuthorizedDcrnId] = useState<
    string | null
  >(null);

  const isAssessmentFinished = (req: DCRNRequest): boolean => {
    const assessments = req.assessments || {};
    const codes = Object.keys(assessments).filter((code) => code !== "PK");
    if (codes.length === 0) return false;
    return codes.every((code) => {
      const ass = assessments[code];
      return ass && ass.impacted !== null;
    });
  };

  const handleAuthDCRN = (requestId: string) => {
    const req = dcrnRequests.find((r) => r.id === requestId);
    const regNum =
      req?.mrRegistryNumber || assignedRegistryNum[requestId] || "";
    if (!regNum.trim()) {
      alert(
        "Please enter or assign an official verified DCRN registry number before issuing.",
      );
      return;
    }
    if (onAuthorizeDcrnRequest) {
      onAuthorizeDcrnRequest(requestId, regNum.trim());
    }
    setAssignedRegistryNum((prev) => {
      const next = { ...prev };
      delete next[requestId];
      return next;
    });
  };

  const handleSaveRegistryNum = (requestId: string) => {
    const regNum = assignedRegistryNum[requestId] || "";
    if (!regNum.trim()) {
      alert("Please enter a valid DCRN registry number to assign.");
      return;
    }
    if (onAssignDcrnRegistryNumber) {
      onAssignDcrnRegistryNumber(requestId, regNum.trim());
    }
  };

  const [expandedUnauthorizedDcrnId, setExpandedUnauthorizedDcrnId] = useState<
    string | null
  >(null);
  const [expandedOpenDcrnId, setExpandedOpenDcrnId] = useState<string | null>(
    null,
  );

  const [dcrnDeptFilter, setDcrnDeptFilter] = useState<string>("ALL");

  const sortDcrnsByDept = (a: DCRNRequest, b: DCRNRequest) => {
    const deptA = a.preparedBy?.department || "";
    const deptB = b.preparedBy?.department || "";
    return deptA.localeCompare(deptB);
  };

  const rawUnauthorizedDcrns = dcrnRequests.filter(
    (r) =>
      r.status !== "Completed" &&
      r.status !== "Rejected" &&
      !r.mrRegistryNumber,
  );
  const unauthorizedDcrns = rawUnauthorizedDcrns
    .filter(
      (r) =>
        dcrnDeptFilter === "ALL" || r.preparedBy?.department === dcrnDeptFilter,
    )
    .sort(sortDcrnsByDept);

  const rawOpenDcrns = dcrnRequests.filter(
    (r) =>
      r.status !== "Completed" &&
      r.status !== "Rejected" &&
      !!r.mrRegistryNumber,
  );
  const openDcrns = rawOpenDcrns
    .filter(
      (r) =>
        dcrnDeptFilter === "ALL" || r.preparedBy?.department === dcrnDeptFilter,
    )
    .sort(sortDcrnsByDept);

  const rawAuthorizedDcrns = dcrnRequests.filter(
    (r) => r.status === "Completed",
  );
  const authorizedDcrns = rawAuthorizedDcrns
    .filter(
      (r) =>
        dcrnDeptFilter === "ALL" || r.preparedBy?.department === dcrnDeptFilter,
    )
    .sort(sortDcrnsByDept);

  const areAllDocumentsUploaded = (req: DCRNRequest): boolean => {
    const prepDocs = req.initialDocs.filter(
      (d) =>
        !d.addedByDept || d.addedByDept === (req.preparedBy?.department || ""),
    );
    const prepAllUploaded = prepDocs.every(
      (d) => d.actionType === "Removal" || !!d.uploadedUrl,
    );

    let deptAllUploaded = true;
    if (req.assessments) {
      Object.entries(req.assessments).forEach(([code, ass]) => {
        if (code !== "PK" && code !== (req.preparedBy?.department || "")) {
          const deptDocs = req.initialDocs.filter(
            (d) => d.addedByDept === code,
          );
          const isDeptImpacted = ass.impacted === "Yes" || deptDocs.length > 0;
          if (isDeptImpacted) {
            const docsToRender =
              deptDocs.length > 0 ? deptDocs : ass.documents || [];
            const allDeptDocsUploaded = docsToRender.every(
              (d) => d.actionType === "Removal" || !!d.uploadedUrl,
            );
            if (!allDeptDocsUploaded) {
              deptAllUploaded = false;
            }
          }
        }
      });
    }
    return prepAllUploaded && deptAllUploaded;
  };

  const getProgressPill = (req: DCRNRequest) => {
    const filesUploaded = areAllDocumentsUploaded(req);
    const isStage2Reviewed =
      !!req.qaStage2EvaluatedBy || req.status === "Pending_MR_Closure";

    if (!filesUploaded) {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-amber-50 text-amber-800 border border-amber-250 text-[10px] font-bold rounded-full font-mono uppercase leading-none shadow-3xs shrink-0">
          <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse shrink-0" />
          waiting upload file
        </span>
      );
    } else if (!isStage2Reviewed) {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-blue-50 text-blue-800 border border-blue-250 text-[10px] font-bold rounded-full font-mono uppercase leading-none shadow-3xs shrink-0">
          <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse shrink-0" />
          waiting stage-2
        </span>
      );
    } else {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-indigo-50 text-indigo-900 border border-indigo-250 text-[10px] font-bold rounded-full font-mono uppercase leading-none shadow-3xs animate-pulse shrink-0">
          <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-pulse shrink-0" />
          waiting closing
        </span>
      );
    }
  };

  // Vault/Download Modal states
  const [downloadModalOpen, setDownloadModalOpen] = useState(false);
  const [downloadFileName, setDownloadFileName] = useState("");
  const [downloadFileSize, setDownloadFileSize] = useState("");
  const [downloadFileContent, setDownloadFileContent] = useState("");
  const [downloadChecksum, setDownloadChecksum] = useState("");
  const [downloadFilePathUrl, setDownloadFilePathUrl] = useState("");

  // Fulfillment panel inputs
  const [templateFileName, setTemplateFileName] = useState("");
  const [templateContent, setTemplateContent] = useState("");
  const [templateFileSize, setTemplateFileSize] = useState("128 KB");
  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  const handleDownloadFile = (doc: DocumentWorkflow) => {
    const formattedContent = `======================================================================
     CORPORATE ELECTRONIC QUALITY MANAGEMENT SYSTEM (eQMS)
======================================================================
DOCUMENT REFERENCE ID: ${doc.id}
TITLE: ${doc.title}
CATEGORY: ${doc.category}
DEPARTMENT: ${doc.department}
VERSION: v${doc.version}
STATUS: ${doc.status}
AUTHOR: ${doc.preparedBy.userName} (${doc.preparedBy.email})

AUDITED TIMESTAMP OF ASSEMBLY: ${formatToIST(doc.createdAt)}

----------------------------------------------------------------------
SYSTEM INTEGRITY REGISTER (Secure Protected Quality Envelope)
----------------------------------------------------------------------
This file represents an accepted corporate export from eQMS secure 
nodes. File integrity and tampering states are certified recursively.

======================================================================
DOCUMENT TEXT BODY DATA
======================================================================

${doc.draftContent || "No draft content entered."}

======================================================================
SYSTEM LOG RECORD HISTORICAL AUDIT
======================================================================
* Pre-checks completed by: ${doc.preparedBy.userName}
* Reviewed and Approved by MR Department Representative: ${doc.reviewedBy?.userName || "N/A"}
* Comment history logged:
${doc.comments.map((c) => `  [${c.userName} - ${c.timestamp.substring(11, 19)}]: "${c.text}"`).join("\n")}

======================================================================
SYSTEM DIGITAL SIGNATURE LOGS
======================================================================
Signer Name: ${doc.approvedBy?.signerName || "N/A"}
Signer Title: ${doc.approvedBy?.signerTitle || "N/A"}
Audit Date/Time: ${doc.approvedBy?.timestamp || "N/A"}
E-Certificate Hash: ${doc.approvedBy?.hash || "N/A"}
Signing Meaning: ${doc.approvedBy?.meaning || "N/A"}

======================================================================
END OF CONTROLLED STANDARD COPY QUALITY RECORD
======================================================================
`;

    const pathUrl =
      doc.finalApprovedCopyUrl ||
      doc.reviewerVerifiedUrl ||
      doc.preparerDraftUrl ||
      doc.mrTemplateCopyUrl;

    setDownloadFileName(doc.fileName || `${doc.id}_Approved_Release.docx`);
    setDownloadFileSize(doc.fileSize || "128 KB");
    setDownloadFileContent(formattedContent);
    setDownloadChecksum(
      "docx_" + Math.floor(Math.random() * 90000000 + 10000000).toString(16),
    );
    setDownloadFilePathUrl(pathUrl || "");
    setDownloadModalOpen(true);

    // Call onDownloadSOP triggers
    if (onDownloadSOP) {
      onDownloadSOP(doc.id);
    }
    if (!localDownloadedIds.includes(doc.id)) {
      setLocalDownloadedIds((prev) => [...prev, doc.id]);
    }
  };

  // Find currently open document for fulfillment input modal/drawer
  const activeFulfillmentDoc = pendingRequests.find(
    (d) => d.id === selectedDocId,
  );

  const handleSelectRequestToFulfill = (doc: DocumentWorkflow) => {
    setSelectedDocId(doc.id);
    setTemplateFileName(
      `${doc.id}_Template_${doc.title.replace(/[^a-z0-9]/gi, "_").substring(0, 20)}.docx`,
    );
    setTemplateContent("");
    setErrorMessage("");
    setSuccessMessage("");
  };

  const handleApplyTemplate = (text: string, file: string) => {
    setTemplateContent(text);
    setTemplateFileName(file);
    setTemplateFileSize("128 KB");
  };

  const handleUploadSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDocId) return;

    if (!templateContent.trim()) {
      setErrorMessage(
        "Please provide some initial template body content or apply a corporate standard draft layout.",
      );
      return;
    }

    const finalFile =
      templateFileName.trim() || `${selectedDocId}_Corporate_Template.docx`;
    const finalUrl = `/vault/mr-templates/${finalFile}`;

    // Call parents transition mechanism to SoftCopyProvided state
    onProvideSoftCopy(
      selectedDocId,
      templateContent.trim(),
      finalFile,
      templateFileSize,
      finalUrl,
    );

    // Reset state & show success
    setSuccessMessage(
      `Success! Official soft copy template uploaded for request "${selectedDocId}". Document state transitioned to Soft_Copy_Provided.`,
    );
    setSelectedDocId(null);
    setTemplateContent("");
    setTemplateFileName("");
    setErrorMessage("");

    setTimeout(() => {
      setSuccessMessage("");
    }, 5000);
  };

  // Filter requests based on search
  const filteredRequests = pendingRequests.filter((req) => {
    const searchString =
      `${req.id} ${req.preparedBy.userName} ${req.title} ${req.department}`.toLowerCase();
    return searchString.includes(searchTerm.toLowerCase());
  });

  // Render widget layout (simpler, denser) or full landing tab view
  return (
    <div className="space-y-6" id="mr-document-request-queue-section">
      {/* Dynamic fulfillment system notice */}
      {successMessage && (
        <div
          className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-850 text-xs font-bold rounded-lg flex items-center gap-3 animate-fade-in"
          id="queue-success-toast"
        >
          <CheckCircle2 className="w-5.5 h-5.5 text-emerald-650 shrink-0" />
          <div>
            <p className="font-bold">{successMessage}</p>
            <p className="text-[10px] text-emerald-600 font-normal mt-0.5">
              Real-time update propagated. The record has been safely handed off
              to the Preparer and removed from this queue.
            </p>
          </div>
        </div>
      )}

      {/* MR Main Panel Header with Subtab Switcher */}
      <div className="p-5 bg-white border border-slate-200 rounded-lg shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2 mb-1">
            <Layers className="w-5 h-5 text-indigo-600" />
            MR Executive Dossier Panel
          </h2>
          <p className="text-xs text-slate-500">
            Provide official starting document baselines, or monitor and
            download pristine approved electronic records.
          </p>
        </div>

        {/* Compact Sub-navigation tab inside MR component */}
        <div className="flex flex-wrap items-center bg-slate-100 p-1 rounded-lg border shrink-0 gap-1">
          <button
            type="button"
            onClick={() => setActiveMRTab("dcrn_authorization")}
            className={`px-3 py-1.5 text-xs font-bold leading-none cursor-pointer rounded-md transition-all flex items-center gap-1 ${activeMRTab === "dcrn_authorization" ? "bg-white text-indigo-800 shadow-xs font-extrabold" : "text-slate-550 hover:text-slate-800"}`}
            id="tab-active-dcrn-auth"
          >
            <span>DCRN Acceptance</span>
            {unauthorizedDcrns.length + openDcrns.length > 0 && (
              <span className="px-1.5 py-0.5 rounded-lg bg-pink-700 text-white font-mono text-[10px] font-extrabold leading-none ml-1">
                {unauthorizedDcrns.length + openDcrns.length}
              </span>
            )}
          </button>
          <button
            type="button"
            onClick={() => setActiveMRTab("dcrn_removal")}
            className={`px-3 py-1.5 text-xs font-bold leading-none cursor-pointer rounded-md transition-all flex items-center gap-1 ${activeMRTab === "dcrn_removal" ? "bg-white text-rose-700 shadow-xs font-bold" : "text-slate-550 hover:text-slate-800"}`}
          >
            <span>DCRN Deletion Queue</span>
            {pendingDcrnDeletions.length > 0 && (
              <span className="px-1.5 py-0.5 rounded-lg bg-pink-700 text-white font-mono text-[10px] font-extrabold leading-none ml-1">
                {pendingDcrnDeletions.length}
              </span>
            )}
          </button>
        </div>
      </div>
      {activeMRTab === "dcrn_authorization" ? (
        <div className="space-y-4 animate-fade-in" id="dcrn-auth-view-wrapper">
          {/* Sub-sections tabs */}
          <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-200 gap-4 mb-3">
            <div className="flex gap-4">
              <button
                onClick={() => setAuthSubSection("unauthorized")}
                className={`py-2 px-4 text-xs font-bold border-b-2 transition-all cursor-pointer flex items-center gap-1 ${
                  authSubSection === "unauthorized"
                    ? "border-indigo-650 text-indigo-850"
                    : "border-transparent text-slate-500 hover:text-slate-800"
                }`}
                id="subtab-unauthorized-dcrn"
              >
                <span>Unauthorized</span>
                {unauthorizedDcrns.length > 0 && (
                  <span className="px-1.5 py-0.5 rounded-lg bg-pink-700 text-white font-mono text-[10px] font-extrabold leading-none ml-1">
                    {unauthorizedDcrns.length}
                  </span>
                )}
              </button>
              <button
                onClick={() => setAuthSubSection("open")}
                className={`py-2 px-4 text-xs font-bold border-b-2 transition-all cursor-pointer flex items-center gap-1 ${
                  authSubSection === "open"
                    ? "border-indigo-650 text-indigo-850"
                    : "border-transparent text-slate-500 hover:text-slate-800"
                }`}
                id="subtab-open-dcrn"
              >
                <span>Open DCRN</span>
                {openDcrns.length > 0 && (
                  <span className="px-1.5 py-0.5 rounded-lg bg-pink-700 text-white font-mono text-[10px] font-extrabold leading-none ml-1">
                    {openDcrns.length}
                  </span>
                )}
              </button>
              <button
                onClick={() => setAuthSubSection("accepted")}
                className={`py-2 px-4 text-xs font-bold border-b-2 transition-all cursor-pointer flex items-center gap-1 ${
                  authSubSection === "accepted"
                    ? "border-indigo-650 text-indigo-850"
                    : "border-transparent text-slate-500 hover:text-slate-800"
                }`}
                id="subtab-accepted-dcrn"
              >
                <span>Closed DCRN</span>
                {authorizedDcrns.length > 0 && (
                  <span className="px-1.5 py-0.5 rounded-lg bg-slate-500 text-white font-mono text-[10px] font-bold leading-none ml-1">
                    {authorizedDcrns.length}
                  </span>
                )}
              </button>
            </div>

            {/* Department Selection Dropdown */}
            <div className="flex items-center gap-2 pb-2 md:pb-0">
              <label className="text-[10px] font-extrabold text-slate-500 uppercase font-mono shrink-0">
                Department filter:
              </label>
              <select
                value={dcrnDeptFilter}
                onChange={(e) => setDcrnDeptFilter(e.target.value)}
                className="bg-white border border-slate-250 rounded px-2.5 py-1 text-xs font-bold text-slate-707 outline-none focus:ring-1 focus:ring-indigo-500 cursor-pointer shadow-3xs"
              >
                <option value="ALL">ALL DEPARTMENTS</option>
                {Object.entries(DEPARTMENT_MAP).map(([code, name]) => (
                  <option key={code} value={code}>
                    {code} - {name}
                  </option>
                ))}
              </select>
            </div>
          </div>
          {authSubSection === "unauthorized" ? (
            unauthorizedDcrns.length === 0 ? (
              <div
                className="bg-white p-12 rounded-xl border border-slate-200 text-center text-slate-400 animate-fade-in"
                id="mr-empty-auth-view"
              >
                <Check className="w-12 h-12 mx-auto text-slate-350 opacity-60 mb-2 pointer-events-none animate-pulse" />
                <p className="text-sm font-semibold text-slate-700">
                  No Pending MR Verification Packets
                </p>
                <p className="text-xs text-slate-500 mt-1">
                  DCRNs awaiting official registration or catalog numbering will
                  appear here.
                </p>
              </div>
            ) : (
              <div
                className="space-y-3 animate-fade-in"
                id="mr-unauthorized-requests-container"
              >
                <p className="text-xs text-slate-500 font-medium mb-1.5 bg-slate-50 p-2.5 rounded-lg border">
                  Click on any DCRN Request ID below to expand and view its full
                  audited details, assigned Effective Date, and issue the
                  official catalog number to close the request.
                </p>
                <div className="grid gap-2">
                  {unauthorizedDcrns.map((req) => {
                    const isExpanded = expandedUnauthorizedDcrnId === req.id;
                    const allDocsUploaded = areAllDocumentsUploaded(req);
                    return (
                      <div
                        key={req.id}
                        className="bg-white rounded-lg border border-slate-205 shadow-3xs overflow-hidden"
                        id={`mr-auth-req-${req.id}`}
                      >
                        {/* Header Row - initially shows only the DCRN ID and meta */}
                        <div
                          onClick={() =>
                            setExpandedUnauthorizedDcrnId(
                              isExpanded ? null : req.id,
                            )
                          }
                          className={`p-3 flex justify-between items-center cursor-pointer hover:bg-slate-50 border-l-4 ${isExpanded ? "border-indigo-650 bg-slate-50/50" : "border-indigo-400"} transition-all`}
                          id={`unauthorized-dcrn-row-header-${req.id}`}
                        >
                          <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                            <span className="font-mono font-extrabold text-slate-800 text-[11.5px] bg-slate-100 border-slate-300 border px-2 py-0.5 rounded shadow-3xs">
                              🆔 DCRN ID:{" "}
                              {req.id.includes(req.preparedBy?.department)
                                ? req.id
                                : `DCRN-${req.preparedBy?.department || "QA"}-${req.id.replace("DCRN-", "")}`}
                            </span>
                            <span className="text-[10px] text-slate-500 font-mono">
                              Author:{" "}
                              <strong className="font-sans text-[10.5px] font-semibold text-slate-700">
                                {req.preparedBy?.userName}
                              </strong>{" "}
                              | Dept:{" "}
                              <strong className="font-sans text-[10.5px] font-medium text-slate-700">
                                {req.preparedBy?.department}
                              </strong>{" "}
                              | Submitted:{" "}
                              <strong className="font-sans text-[10.5px] font-semibold text-slate-700">
                                {req.createdAt.substring(0, 10)}
                              </strong>
                            </span>
                          </div>

                          <div className="flex items-center gap-2">
                            {!req.mrRegistryNumber ? (
                              <span className="text-[9px] bg-amber-100 text-amber-800 font-bold px-2 py-0.5 rounded uppercase font-sans animate-pulse">
                                Awaiting Assigning DCRN Number
                              </span>
                            ) : !allDocsUploaded ? (
                              <span className="text-[9px] bg-orange-100 text-orange-850 font-bold px-2 py-0.5 rounded uppercase font-sans animate-pulse">
                                Document Update Pending
                              </span>
                            ) : (
                              <span className="text-[9px] bg-indigo-150 text-indigo-900 border border-indigo-250 font-bold px-2 py-0.5 rounded uppercase font-sans animate-pulse">
                                Awaiting QA Submission
                              </span>
                            )}
                            <span className="text-slate-400 text-[9px] font-mono">
                              {isExpanded ? "Collapse ▲" : "Expand Details ▼"}
                            </span>
                          </div>
                        </div>

                        {/* Collapsible Details */}
                        {isExpanded &&
                          (() => {
                            const assessments = req.assessments || {};
                            const assessmentCodes = Object.keys(
                              assessments,
                            ).filter((code) => code !== "PK");
                            const pendingDepts = assessmentCodes.filter(
                              (code) =>
                                !assessments[code] ||
                                assessments[code].impacted === null,
                            );
                            const allImpactAssessmentsCompleted =
                              assessmentCodes.length > 0 &&
                              assessmentCodes.every(
                                (code) =>
                                  assessments[code] &&
                                  assessments[code].impacted !== null,
                              );

                            if (!allImpactAssessmentsCompleted) {
                              return (
                                <div className="p-4 border-t border-slate-100 bg-slate-50/50 space-y-4 animate-fade-in">
                                  <div className="bg-amber-50 border border-amber-250 p-4 rounded-xl flex items-start gap-3">
                                    <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                                    <div className="space-y-1 text-xs">
                                      <h4 className="font-bold text-amber-900 uppercase tracking-widest text-[11px]">
                                        Audited Details Restricted (Assessments
                                        Pending)
                                      </h4>
                                      <p className="text-amber-800 leading-relaxed font-sans font-medium text-[11px]">
                                        Under strict change control compliance,
                                        full DCRN specifications, file
                                        attachments, and MR verification
                                        controls remain securely locked until
                                        all designated departments complete
                                        their Mandatory Departmental Impact
                                        Assessments.
                                      </p>
                                    </div>
                                  </div>

                                  <div className="bg-white border hover:border-slate-300 rounded-xl p-3.5 space-y-3 transition-colors shadow-2xs">
                                    <div className="flex justify-between items-center border-b pb-1.5 text-[11px]">
                                      <span className="text-[10px] font-mono uppercase text-slate-400 font-bold">
                                        Assessment Status Map
                                      </span>
                                      <span className="text-[10.5px] font-bold text-slate-500 font-sans tracking-wide">
                                        {assessmentCodes.length === 0
                                          ? "Awaiting Stage 1 Review"
                                          : `${assessmentCodes.length - pendingDepts.length} of ${assessmentCodes.length} Completed`}
                                      </span>
                                    </div>

                                    {assessmentCodes.length === 0 ? (
                                      <div className="flex items-center gap-2.5 p-3 bg-slate-50 rounded-lg border text-xs text-slate-600 font-medium">
                                        <Clock className="w-4 h-4 text-slate-400 animate-pulse" />
                                        <span>
                                          Awaiting Stage 1 Quality Assurance
                                          Evaluation & Assignment.
                                        </span>
                                      </div>
                                    ) : (
                                      <div className="grid sm:grid-cols-2 gap-2 text-xs">
                                        {assessmentCodes.map((code) => {
                                          const ass = assessments[code];
                                          const isCompleted =
                                            ass && ass.impacted !== null;
                                          return (
                                            <div
                                              key={code}
                                              className={`p-2.5 rounded-lg border flex items-center justify-between ${isCompleted ? "bg-emerald-50/40 border-emerald-100 text-emerald-900" : "bg-slate-50 border-slate-100 text-slate-500"}`}
                                            >
                                              <span className="font-medium truncate pr-2 text-[11px]">
                                                {DEPARTMENT_MAP[code] || code} (
                                                {code})
                                              </span>
                                              {isCompleted ? (
                                                <span className="text-[9px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.5 rounded flex items-center gap-1 shrink-0">
                                                  <Check className="w-3 h-3" />{" "}
                                                  Signed
                                                </span>
                                              ) : (
                                                <span className="text-[9px] bg-amber-150 text-amber-800 font-bold px-1.5 py-0.5 rounded flex items-center gap-1 shrink-0 animate-pulse">
                                                  <Clock className="w-3 h-3" />{" "}
                                                  Pending
                                                </span>
                                              )}
                                            </div>
                                          );
                                        })}
                                      </div>
                                    )}
                                  </div>
                                </div>
                              );
                            }

                            return (
                              <div className="p-4 border-t border-slate-100 bg-slate-50/10 space-y-4">
                                {/* QA Stage 2 Audit and Assigned Effective Date */}
                                {req.qaStage2EvaluatedBy ||
                                req.status === "Pending_MR_Closure" ? (
                                  <div className="bg-blue-50/50 p-3 rounded-lg border border-blue-200 text-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
                                    <div className="space-y-1">
                                      <span className="font-bold text-indigo-900 uppercase text-[9px] tracking-wider block font-sans">
                                        QA Stage 2 Gateway Verification Sign-off
                                      </span>
                                      <p className="text-slate-755">
                                        <strong>Reviewed & Signed By:</strong>{" "}
                                        {req.qaStage2EvaluatedBy?.userName ||
                                          req.qaEvaluatedBy?.userName ||
                                          "QA Senior Auditor"}
                                      </p>
                                      <p className="text-slate-650 italic bg-white p-1.5 rounded border border-slate-200/50">
                                        "{" "}
                                        {req.qaStage2Remarks ||
                                          req.qaEvaluationRemarks ||
                                          "Verified compliant with ISO & FDA release requirements."}{" "}
                                        "
                                      </p>
                                    </div>
                                    <div className="bg-white p-2.5 rounded-lg border border-indigo-200 shadow-3xs flex flex-col items-center justify-center shrink-0 w-full md:w-auto">
                                      <span className="text-[9px] font-mono uppercase text-slate-400 font-bold">
                                        Assigned Effective Release Date
                                      </span>
                                      <span className="text-sm font-mono font-extrabold text-indigo-900">
                                        {req.effectiveDate
                                          ? formatEffectiveDate(
                                              req.effectiveDate,
                                            )
                                          : "IMMEDIATE"}
                                      </span>
                                    </div>
                                  </div>
                                ) : null}

                                {/* 1. Preparer's initial documents */}
                                <div>
                                  <h5 className="text-[10px] font-mono font-bold uppercase text-slate-400 mb-1">
                                    1. Preparer's Initial Document Records
                                  </h5>
                                  <div className="bg-white border p-3 rounded-lg text-slate-750 divide-y divide-slate-100">
                                    {req.initialDocs
                                      .filter(
                                        (d) =>
                                          !d.addedByDept ||
                                          d.addedByDept ===
                                            (req.preparedBy?.department || ""),
                                      )
                                      .map((doc, idx) => {
                                        const docIdxInInitialDocs =
                                          req.initialDocs.findIndex(
                                            (d) =>
                                              d.docNumber === doc.docNumber &&
                                              d.addedByDept === doc.addedByDept,
                                          );
                                        const hasDcrnNumber = !!(
                                          assignedRegistryNum[req.id]?.trim() ||
                                          req.mrRegistryNumber?.trim()
                                        );
                                        return (
                                          <div
                                            key={idx}
                                            className="py-2.5 first:pt-0 last:pb-0 font-sans"
                                          >
                                            <p className="font-bold text-indigo-900 flex items-center flex-wrap gap-1.5">
                                              <span>📄 {doc.docNumber}</span>
                                              <span className="text-[10px] font-mono text-slate-600 bg-slate-100 p-0.5 rounded px-1.5 font-bold">
                                                Rev:{" "}
                                                {doc.currentRevision || "-"}
                                              </span>
                                              {doc.title && (
                                                <span className="text-[10px] text-indigo-755 font-bold bg-indigo-50 border border-indigo-150 rounded px-1.5 py-0.2 mx-1 inline-block font-sans">
                                                  Title: {doc.title}
                                                </span>
                                              )}
                                              <span className="text-[9px] font-sans font-normal text-slate-500">
                                                [{doc.actionType || "Change"}]
                                              </span>
                                            </p>
                                            <p className="mt-1">
                                              <strong className="text-slate-400 font-normal">
                                                Reason:
                                              </strong>{" "}
                                              {doc.reasonForChange}
                                            </p>
                                            <p>
                                              <strong className="text-slate-400 font-normal">
                                                Proposed Change:
                                              </strong>{" "}
                                              {doc.changesRequired}
                                            </p>

                                            <div className="mt-2 pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 bg-slate-50/55 p-1.5 px-2 rounded-lg text-[10.5px]">
                                              <div className="flex items-center gap-1.5 min-w-0">
                                                {doc.uploadedUrl ? (
                                                  <div className="flex items-center gap-1 text-[10.5px] text-emerald-700 font-medium truncate">
                                                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                                                    <span className="truncate">
                                                      File:{" "}
                                                      <strong>
                                                        {doc.uploadedFileName ||
                                                          "Accepted Doc"}
                                                      </strong>
                                                    </span>
                                                  </div>
                                                ) : (
                                                  <span className="text-[9.5px] text-slate-555 font-mono flex items-center gap-1">
                                                    <AlertTriangle className="w-3.5 h-3.5 text-amber-500 shrink-0 animate-pulse" />
                                                    Awaiting official copy
                                                    upload
                                                  </span>
                                                )}
                                              </div>
                                            </div>
                                          </div>
                                        );
                                      })}
                                  </div>
                                </div>

                                {/* 2. Impact assessment block */}
                                <div>
                                  <h5 className="text-[10px] font-mono font-bold uppercase text-slate-400 mb-1">
                                    2. Departmental Impact Analysis
                                  </h5>
                                  <div className="space-y-3">
                                    {Object.entries(req.assessments || {})
                                      .filter(
                                        ([code]) =>
                                          code !== "PK" &&
                                          code !==
                                            (req.preparedBy?.department || ""),
                                      )
                                      .map(([code, ass]) => {
                                        const deptDocs = req.initialDocs.filter(
                                          (d) => d.addedByDept === code,
                                        );
                                        const isDeptImpacted =
                                          ass.impacted === "Yes" ||
                                          deptDocs.length > 0;
                                        const docsToRender =
                                          deptDocs.length > 0
                                            ? deptDocs
                                            : ass.documents || [];

                                        return (
                                          <div
                                            key={code}
                                            className="bg-white border border-slate-200 rounded-lg p-3 shadow-3xs"
                                          >
                                            <div className="flex justify-between items-center mb-1.5 pb-2 border-b border-slate-100">
                                              <span className="font-bold text-slate-800 font-mono text-[11px]">
                                                {DEPARTMENT_MAP[code] || code} (
                                                {code})
                                              </span>
                                              <span
                                                className={`px-2 py-0.5 rounded text-[10px] font-bold ${isDeptImpacted ? "bg-amber-100 text-amber-850" : "bg-slate-100 text-slate-600"}`}
                                              >
                                                {isDeptImpacted
                                                  ? "Impacted"
                                                  : "Not Impacted"}
                                              </span>
                                            </div>
                                            {isDeptImpacted && (
                                              <div className="text-[10px] space-y-2 mt-2 bg-slate-50/50 p-2 rounded border border-slate-100">
                                                <p className="font-semibold text-slate-500 uppercase mb-1.5 text-[9px] tracking-wider">
                                                  Impacted Documents &
                                                  Parameters:
                                                </p>
                                                {docsToRender.map(
                                                  (doc, dIdx) => {
                                                    const docIdxInInitialDocs =
                                                      req.initialDocs.findIndex(
                                                        (d) =>
                                                          d.docNumber ===
                                                            doc.docNumber &&
                                                          d.addedByDept ===
                                                            doc.addedByDept,
                                                      );
                                                    const hasDcrnNumber = !!(
                                                      assignedRegistryNum[
                                                        req.id
                                                      ]?.trim() ||
                                                      req.mrRegistryNumber?.trim()
                                                    );
                                                    return (
                                                      <div
                                                        key={dIdx}
                                                        className="bg-white p-2.5 rounded border border-slate-150 font-sans text-slate-705 space-y-1.5 shadow-3xs"
                                                      >
                                                        <span className="font-mono text-indigo-900 font-bold flex items-center flex-wrap gap-1.5">
                                                          <span>
                                                            📄 {doc.docNumber}
                                                          </span>
                                                          <span className="text-[9.5px] font-mono text-slate-655 bg-slate-100 px-1 py-0.2 rounded font-bold">
                                                            Rev:{" "}
                                                            {doc.currentRevision ||
                                                              "-"}{" "}
                                                            &rarr;{" "}
                                                            {doc.nextRevision ||
                                                              "-"}
                                                          </span>
                                                          {doc.title && (
                                                            <span className="text-[10px] text-indigo-755 font-bold bg-indigo-50 border border-indigo-150 rounded px-1.5 py-0.2 mx-1 inline-block font-sans">
                                                              Title: {doc.title}
                                                            </span>
                                                          )}
                                                          <span className="text-[9px] font-sans font-normal text-slate-555">
                                                            [
                                                            {doc.actionType ||
                                                              "Change"}
                                                            ]
                                                          </span>
                                                        </span>
                                                        <div className="text-slate-605 text-[10.5px]">
                                                          <strong className="text-slate-400 font-semibold">
                                                            Reason for Change:
                                                          </strong>{" "}
                                                          {doc.reasonForChange ||
                                                            "N/A"}
                                                        </div>
                                                        <div className="text-slate-605 text-[10.5px]">
                                                          <strong className="text-slate-400 font-semibold">
                                                            Proposed Changes:
                                                          </strong>{" "}
                                                          {doc.changesRequired}
                                                        </div>

                                                        {docIdxInInitialDocs !==
                                                          -1 && (
                                                          <div className="pt-2 mt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-[10px] bg-slate-50/55 p-1 rounded-md">
                                                            <div className="flex items-center gap-1 min-w-0">
                                                              {doc.uploadedUrl ? (
                                                                <span className="text-emerald-700 font-medium truncate flex items-center gap-1">
                                                                  <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0" />
                                                                  <span className="truncate">
                                                                    File:{" "}
                                                                    {doc.uploadedFileName ||
                                                                      "Doc Copy"}
                                                                  </span>
                                                                </span>
                                                              ) : (
                                                                <span className="text-[9px] text-slate-500 font-mono flex items-center gap-1">
                                                                  <AlertTriangle className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                                                                  No file
                                                                  uploaded
                                                                </span>
                                                              )}
                                                            </div>
                                                          </div>
                                                        )}
                                                      </div>
                                                    );
                                                  },
                                                )}
                                              </div>
                                            )}
                                            <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center justify-between gap-2 flex-wrap">
                                              <div className="text-[9.5px] text-slate-450 font-mono">
                                                Verified Approved by{" "}
                                                <strong>
                                                  {ass.assessedBy?.userName ||
                                                    "Dept Representative"}
                                                </strong>{" "}
                                                {ass.assessedAt
                                                  ? formatToIST(ass.assessedAt)
                                                  : ""}
                                              </div>

                                              {onRejectDepartmentAssessment && (
                                                <div>
                                                  {confirmRejectKey ===
                                                  `${req.id}-${code}` ? (
                                                    <div className="flex items-center gap-1.5 animate-fade-in">
                                                      <span className="text-[8.5px] text-amber-705 font-bold font-mono">
                                                        Reset?
                                                      </span>
                                                      <button
                                                        onClick={() => {
                                                          onRejectDepartmentAssessment(
                                                            req.id,
                                                            code,
                                                          );
                                                          setConfirmRejectKey(
                                                            null,
                                                          );
                                                        }}
                                                        className="px-1.5 py-0.5 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded text-[8.5px] cursor-pointer"
                                                      >
                                                        Yes
                                                      </button>
                                                      <button
                                                        onClick={() =>
                                                          setConfirmRejectKey(
                                                            null,
                                                          )
                                                        }
                                                        className="px-1.5 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-700 border rounded text-[8.5px] cursor-pointer"
                                                      >
                                                        No
                                                      </button>
                                                    </div>
                                                  ) : (
                                                    <button
                                                      type="button"
                                                      onClick={() =>
                                                        setConfirmRejectKey(
                                                          `${req.id}-${code}`,
                                                        )
                                                      }
                                                      className="px-2 py-0.5 text-[9px] bg-amber-50 hover:bg-amber-100 text-amber-700 border border-amber-200 hover:border-amber-300 rounded font-bold cursor-pointer transition-colors"
                                                    >
                                                      Reject Analysis
                                                    </button>
                                                  )}
                                                </div>
                                              )}
                                            </div>
                                          </div>
                                        );
                                      })}
                                  </div>
                                </div>

                                {/* 3. MR Entry Controls */}
                                <div className="bg-gradient-to-br from-indigo-50/50 to-indigo-150/40 p-4 rounded-xl border-2 border-indigo-200/80 space-y-4 shadow-3xs">
                                  <h5 className="text-[11px] font-mono font-bold text-indigo-900 uppercase tracking-widest flex items-center gap-2">
                                    <span>
                                      Acceptative MR Registry verification &
                                      closure
                                    </span>
                                    {req.mrRegistryNumber ||
                                    assignedRegistryNum[req.id] ? (
                                      <span className="bg-indigo-100 text-indigo-805 text-[9px] font-bold py-0.5 px-2 rounded">
                                        DCRN Registry Number Pre-populated
                                      </span>
                                    ) : (
                                      <span className="bg-amber-100 text-amber-805 text-[9px] font-bold py-0.5 px-2 rounded">
                                        Requires Assigned DCRN Number
                                      </span>
                                    )}
                                  </h5>

                                  <div className="space-y-4">
                                    {/* Assign official number */}
                                    <div className="bg-white p-3.5 rounded-lg border border-slate-200 shadow-3xs space-y-2.5">
                                      <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider block">
                                        Step 1: Assign DCRN number
                                      </span>

                                      {req.mrRegistryNumber ? (
                                        <div className="space-y-2">
                                          <div className="p-2 bg-emerald-50 text-emerald-850 border border-emerald-200 rounded flex items-center justify-between">
                                            <div className="min-w-0">
                                              <span className="text-[10px] block font-sans text-emerald-600 font-medium">
                                                Assigned Catalog Registry:
                                              </span>
                                              <strong className="text-xs font-mono font-bold truncate block">
                                                {req.mrRegistryNumber}
                                              </strong>
                                            </div>
                                            <button
                                              type="button"
                                              onClick={() => {
                                                setAssignedRegistryNum(
                                                  (prev) => ({
                                                    ...prev,
                                                    [req.id]:
                                                      req.mrRegistryNumber ||
                                                      "",
                                                  }),
                                                );
                                                if (
                                                  onAssignDcrnRegistryNumber
                                                ) {
                                                  onAssignDcrnRegistryNumber(
                                                    req.id,
                                                    "",
                                                  );
                                                }
                                              }}
                                              className="px-2 py-1 text-[9px] text-slate-655 hover:bg-slate-200 bg-slate-100 border border-slate-300 rounded font-bold transition-all cursor-pointer"
                                            >
                                              Edit / Change
                                            </button>
                                          </div>
                                        </div>
                                      ) : (
                                        <div className="space-y-2">
                                          <label className="block text-[11px] font-bold text-slate-755 font-sans">
                                            Assign DCRN number *
                                          </label>
                                          <div className="flex gap-1.5">
                                            <input
                                              type="text"
                                              value={
                                                assignedRegistryNum[req.id] ||
                                                ""
                                              }
                                              onChange={(e) =>
                                                setAssignedRegistryNum(
                                                  (prev) => ({
                                                    ...prev,
                                                    [req.id]: e.target.value,
                                                  }),
                                                )
                                              }
                                              placeholder="e.g., DCRN-QA-2026-0044"
                                              className="flex-1 bg-white border border-slate-300 focus:border-indigo-600 rounded p-1.5 text-xs font-mono font-bold outline-none text-slate-800 shadow-3xs"
                                              id={`assign-registry-input-${req.id}`}
                                            />
                                            <button
                                              type="button"
                                              onClick={() =>
                                                handleSaveRegistryNum(req.id)
                                              }
                                              className="px-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded text-xs transition-all cursor-pointer whitespace-nowrap shadow-3xs active:scale-95 font-sans"
                                              id={`btn-save-registry-${req.id}`}
                                            >
                                              Assign & Lock
                                            </button>
                                          </div>
                                          <p className="text-[10px] text-indigo-755 font-medium bg-indigo-50 p-1.5 rounded font-sans border border-indigo-100">
                                            💡 Only MR is accepted to assign
                                            this DCRN number according to
                                            corporate process guidelines.
                                          </p>
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                </div>
                              </div>
                            );
                          })()}
                      </div>
                    );
                  })}
                </div>
              </div>
            )
          ) : authSubSection === "open" ? (
            openDcrns.length === 0 ? (
              <div
                className="bg-white p-12 rounded-xl border border-slate-200 text-center text-slate-400 animate-fade-in"
                id="mr-empty-open-view"
              >
                <Check className="w-12 h-12 mx-auto text-slate-350 opacity-60 mb-2 pointer-events-none animate-pulse" />
                <p className="text-sm font-semibold text-slate-700">
                  No Open DCRNs Active
                </p>
                <p className="text-xs text-slate-500 mt-1 animate-pulse">
                  DCRNs will appear here once they are assigned a DCRN registry
                  number but before final acceptance closure.
                </p>
              </div>
            ) : (
              <div
                className="space-y-3 animate-fade-in"
                id="mr-open-requests-container"
              >
                <p className="text-xs text-slate-505 font-medium mb-1.5 bg-slate-50 p-2.5 rounded-lg border">
                  Click on any DCRN numbering record below to manage
                  attachments/uploads, check QA Stage 2 review progress, and
                  authorize corporate record storage closure.
                </p>
                <div className="grid gap-2">
                  {openDcrns.map((req) => {
                    const isExpanded = expandedOpenDcrnId === req.id;
                    const progressPill = getProgressPill(req);
                    return (
                      <div
                        key={req.id}
                        className="bg-white rounded-lg border border-slate-205 shadow-3xs overflow-hidden"
                        id={`mr-open-req-${req.id}`}
                      >
                        {/* Header Row - initially shows only the DCRN registry number */}
                        <div
                          onClick={() =>
                            setExpandedOpenDcrnId(isExpanded ? null : req.id)
                          }
                          className={`p-3.5 flex justify-between items-center cursor-pointer hover:bg-slate-55 border-l-4 ${isExpanded ? "border-indigo-650 bg-slate-50/55" : "border-indigo-400"} transition-all`}
                          id={`open-dcrn-row-header-${req.id}`}
                        >
                          <div className="flex items-center gap-3">
                            <span className="font-mono font-extrabold text-indigo-900 text-[12px] bg-indigo-50 border-indigo-200 border px-3 py-1 rounded shadow-3xs tracking-wider">
                              🆔 DCRN Number: {req.mrRegistryNumber}
                            </span>
                          </div>

                          <div className="flex items-center gap-3">
                            {progressPill}
                            <span className="text-slate-400 text-[10px] font-mono whitespace-nowrap hidden sm:inline">
                              {isExpanded ? "Hide Details ▲" : "Show Details ▼"}
                            </span>
                          </div>
                        </div>

                        {/* Collapsible Details */}
                        {isExpanded && (
                          <div className="p-4 border-t border-slate-100 bg-slate-50/10 space-y-4">
                            {/* Uploading document option */}
                            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-3xs space-y-4">
                              <h4 className="text-xs font-bold font-sans text-slate-800 uppercase tracking-wide border-b pb-2 flex items-center gap-2">
                                <UploadCloud className="w-4 h-4 text-indigo-600" />
                                <span>1. Document Upload Registry Center</span>
                              </h4>

                              {/* Preparer's initial documents */}
                              <div className="space-y-3">
                                <h5 className="text-[10px] font-mono font-bold uppercase text-slate-400">
                                  Preparer's Initial Document Records
                                </h5>
                                <div className="bg-slate-50/30 border p-3 rounded-lg text-slate-750 divide-y divide-slate-150">
                                  {req.initialDocs
                                    .filter(
                                      (d) =>
                                        !d.addedByDept ||
                                        d.addedByDept ===
                                          (req.preparedBy?.department || ""),
                                    )
                                    .map((doc, idx) => {
                                      const docIdxInInitialDocs =
                                        req.initialDocs.findIndex(
                                          (d) =>
                                            d.docNumber === doc.docNumber &&
                                            d.addedByDept === doc.addedByDept,
                                        );
                                      return (
                                        <div
                                          key={idx}
                                          className="py-2.5 first:pt-0 last:pb-0 font-sans"
                                        >
                                          <div className="flex justify-between items-start gap-3 flex-wrap sm:flex-nowrap">
                                            <div className="min-w-0">
                                              <p className="font-bold text-slate-800 flex items-center flex-wrap gap-1.5">
                                                <span>📄 {doc.docNumber}</span>
                                                <span className="text-[9.5px] font-mono text-slate-655 bg-slate-100 px-1.5 py-0.5 rounded">
                                                  {doc.currentRevision || "-"}
                                                </span>
                                                {doc.title && (
                                                  <span className="text-[10px] text-indigo-755 font-bold bg-indigo-50 border border-indigo-150 rounded px-1.5 py-0.2 mx-1 inline-block font-sans">
                                                    Title: {doc.title}
                                                  </span>
                                                )}
                                                <span className="text-[9px] font-sans font-normal text-slate-500">
                                                  [{doc.actionType || "Change"}]
                                                </span>
                                              </p>
                                              <p className="mt-1 text-xs text-slate-600">
                                                <strong className="text-slate-400 font-normal">
                                                  Proposed Modification:
                                                </strong>{" "}
                                                {doc.changesRequired}
                                              </p>

                                              <div className="mt-1 flex items-center gap-1">
                                                {doc.actionType ===
                                                "Removal" ? (
                                                  <span className="text-[10.5px] text-rose-700 font-medium flex items-center gap-1">
                                                    <Trash2 className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                                                    Document Removal (No upload
                                                    copy required)
                                                  </span>
                                                ) : doc.uploadedUrl ? (
                                                  <span className="text-[10.5px] text-emerald-700 font-medium flex items-center gap-1">
                                                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                                                    Uploaded:{" "}
                                                    <strong className="font-mono">
                                                      {doc.uploadedFileName ||
                                                        "Document"}
                                                    </strong>
                                                  </span>
                                                ) : (
                                                  <span className="text-[10px] text-amber-600 font-medium flex items-center gap-1">
                                                    <AlertTriangle className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                                                    Awaiting physical file copy
                                                    upload
                                                  </span>
                                                )}
                                              </div>
                                            </div>

                                            <div className="flex items-center gap-2 mt-2 sm:mt-0 shrink-0">
                                              {doc.actionType !== "Removal" ? (
                                                <>
                                                  <a
                                                    href={
                                                      doc.uploadedUrl ||
                                                      `data:text/plain;charset=utf-8,${encodeURIComponent(
                                                        `APPROVED DOCUMENT CHANGE CONTROL SPECIFICATION SHEET\n======================================================\n\n` +
                                                          `Document Number: ${doc.docNumber}\n` +
                                                          `Action Type: ${doc.actionType || "Change"}\n` +
                                                          `Current Revision: ${doc.currentRevision || "-"}\n` +
                                                          `Next Revision: ${doc.nextRevision || "-"}\n` +
                                                          `DCRN Request ID: ${req.id}\n` +
                                                          `Assignee Department: ${req.preparedBy?.department}\n` +
                                                          `Approved Effective Date: ${req.effectiveDate ? formatEffectiveDate(req.effectiveDate) : "IMMEDIATE"}\n` +
                                                          `Official Catalog ID: ${req.mrRegistryNumber || "PENDING"}\n\n` +
                                                          `Reason:\n"${doc.reasonForChange}"\n\n` +
                                                          `Proposed Alterations:\n"${doc.changesRequired}"\n`,
                                                      )}`
                                                    }
                                                    target="_blank"
                                                    rel="noopener noreferrer"
                                                    download={
                                                      doc.uploadedFileName ||
                                                      `SOP_${doc.docNumber}.txt`
                                                    }
                                                    className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-50 border border-slate-205 text-slate-705 hover:bg-slate-100 rounded font-bold font-sans text-[10.5px] cursor-pointer"
                                                  >
                                                    <Download className="w-3.5 h-3.5" />
                                                    <span>Download</span>
                                                  </a>

                                                  <label className="inline-flex items-center gap-1 px-2.5 py-1 bg-indigo-600 hover:bg-indigo-700 text-white rounded font-bold font-sans text-[10.5px] cursor-pointer shadow-3xs transition-all active:scale-95">
                                                    <UploadCloud className="w-3.5 h-3.5" />
                                                    <span>
                                                      {doc.uploadedUrl
                                                        ? "Replace"
                                                        : "Upload file"}
                                                    </span>
                                                    <input
                                                      type="file"
                                                      className="hidden"
                                                      onChange={async (e) => {
                                                        if (
                                                          e.target.files &&
                                                          e.target.files[0]
                                                        ) {
                                                          const file =
                                                            e.target.files[0];
                                                          try {
                                                            const result =
                                                              await uploadFileToServer(
                                                                file,
                                                              );
                                                            if (
                                                              result.success &&
                                                              onUploadDcrnDocument
                                                            ) {
                                                              onUploadDcrnDocument(
                                                                req.id,
                                                                docIdxInInitialDocs,
                                                                result.url,
                                                                result.fileName,
                                                                result.fileSize,
                                                              );
                                                            }
                                                          } catch (err) {
                                                            alert(
                                                              "File upload failed.",
                                                            );
                                                          }
                                                        }
                                                      }}
                                                    />
                                                  </label>
                                                </>
                                              ) : (
                                                <span className="text-[10px] text-rose-700 bg-rose-50 px-2.5 py-1 border border-rose-100 rounded font-semibold">
                                                  Ready for QA Stage-2
                                                </span>
                                              )}
                                            </div>
                                          </div>
                                        </div>
                                      );
                                    })}
                                </div>
                              </div>

                              {/* External assessed department documents */}
                              {Object.entries(req.assessments || {}).filter(
                                ([code]) =>
                                  code !== "PK" &&
                                  code !== (req.preparedBy?.department || ""),
                              ).length > 0 && (
                                <div className="space-y-3 pt-2">
                                  <h5 className="text-[10px] font-mono font-bold uppercase text-slate-400">
                                    Departmental Impact Analysis Documents
                                  </h5>
                                  <div className="space-y-3">
                                    {Object.entries(req.assessments || {})
                                      .filter(
                                        ([code]) =>
                                          code !== "PK" &&
                                          code !==
                                            (req.preparedBy?.department || ""),
                                      )
                                      .map(([code, ass]) => {
                                        const deptDocs = req.initialDocs.filter(
                                          (d) => d.addedByDept === code,
                                        );
                                        const isDeptImpacted =
                                          ass.impacted === "Yes" ||
                                          deptDocs.length > 0;
                                        const docsToRender =
                                          deptDocs.length > 0
                                            ? deptDocs
                                            : ass.documents || [];

                                        if (!isDeptImpacted) return null;

                                        return (
                                          <div
                                            key={code}
                                            className="bg-slate-100/50 border border-slate-200 rounded-lg p-3"
                                          >
                                            <div className="font-bold text-slate-755 font-mono text-[10.5px] mb-2 border-b pb-1">
                                              {DEPARTMENT_MAP[code] || code} (
                                              {code}) - Impact Documents
                                            </div>

                                            {docsToRender.length === 0 ? (
                                              <p className="text-[10px] text-slate-400 italic">
                                                No custom modifications declared
                                                for this department.
                                              </p>
                                            ) : (
                                              <div className="space-y-2.5 divide-y divide-slate-100">
                                                {docsToRender.map(
                                                  (doc, dIdx) => {
                                                    const docIdxInInitialDocs =
                                                      req.initialDocs.findIndex(
                                                        (d) =>
                                                          d.docNumber ===
                                                            doc.docNumber &&
                                                          d.addedByDept ===
                                                            doc.addedByDept,
                                                      );
                                                    return (
                                                      <div
                                                        key={dIdx}
                                                        className="pt-2 first:pt-0 font-sans text-xs flex justify-between items-start gap-3 flex-wrap sm:flex-nowrap"
                                                      >
                                                        <div>
                                                          <span className="font-mono text-indigo-900 font-bold flex items-center flex-wrap gap-1.5">
                                                            <span>
                                                              📄 {doc.docNumber}
                                                            </span>
                                                            <span className="text-[9.5px] font-mono text-slate-655 bg-white border px-1.5 py-0.2 rounded font-semibold">
                                                              Rev:{" "}
                                                              {doc.currentRevision ||
                                                                "-"}{" "}
                                                              &rarr;{" "}
                                                              {doc.nextRevision ||
                                                                "-"}
                                                            </span>
                                                            {doc.title && (
                                                              <span className="text-[10px] text-indigo-755 font-bold bg-indigo-50 border border-indigo-150 rounded px-1.5 py-0.2 mx-1 inline-block font-sans">
                                                                Title:{" "}
                                                                {doc.title}
                                                              </span>
                                                            )}
                                                          </span>
                                                          <p className="mt-1 text-slate-605 text-[11px]">
                                                            <strong className="text-slate-400 font-semibold text-[10.5px]">
                                                              Reason for Change:
                                                            </strong>{" "}
                                                            {doc.reasonForChange ||
                                                              "N/A"}
                                                          </p>
                                                          <p className="mt-1 text-slate-605 text-[11px]">
                                                            <strong className="text-slate-400 font-semibold text-[10.5px]">
                                                              Proposed Changes:
                                                            </strong>{" "}
                                                            {
                                                              doc.changesRequired
                                                            }
                                                          </p>
                                                          <div className="mt-1.5">
                                                            {doc.actionType ===
                                                            "Removal" ? (
                                                              <span className="text-[10px] text-rose-700 font-medium flex items-center gap-1">
                                                                <Trash2 className="w-3 h-3 text-rose-600 shrink-0" />
                                                                Document Removal
                                                                (No upload copy
                                                                required)
                                                              </span>
                                                            ) : doc.uploadedUrl ? (
                                                              <span className="text-[10px] text-emerald-755 font-medium flex items-center gap-1">
                                                                <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0" />
                                                                Uploaded:{" "}
                                                                {doc.uploadedFileName ||
                                                                  "Doc Copy"}
                                                              </span>
                                                            ) : (
                                                              <span className="text-[10px] text-amber-606 font-medium flex items-center gap-1">
                                                                <AlertTriangle className="w-3 h-3 text-amber-500 shrink-0" />
                                                                Awaiting file
                                                                upload
                                                              </span>
                                                            )}
                                                          </div>
                                                        </div>

                                                        <div className="flex items-center gap-2 mt-1 sm:mt-0 shrink-0">
                                                          {doc.actionType !==
                                                          "Removal" ? (
                                                            <>
                                                              <a
                                                                href={
                                                                  doc.uploadedUrl ||
                                                                  `data:text/plain;charset=utf-8,${encodeURIComponent(
                                                                    `APPROVED DEPARTMENTAL CHANGE CONTROL SPECIFICATION SHEET\n==========================================================\n\n` +
                                                                      `Document Number: ${doc.docNumber}\n` +
                                                                      `Action Type: ${doc.actionType || "Change"}\n` +
                                                                      `Current Revision: ${doc.currentRevision || "-"}\n` +
                                                                      `Next Revision: ${doc.nextRevision || "-"}\n` +
                                                                      `DCRN Request ID: ${req.id}\n` +
                                                                      `Department: ${code}\n` +
                                                                      `Approved Effective Date: ${req.effectiveDate ? formatEffectiveDate(req.effectiveDate) : "IMMEDIATE"}\n` +
                                                                      `Official Catalog ID: ${req.mrRegistryNumber || "PENDING"}\n\n` +
                                                                      `Reason:\n"${doc.reasonForChange}"\n\n` +
                                                                      `Proposed Alterations:\n"${doc.changesRequired}"\n`,
                                                                  )}`
                                                                }
                                                                target="_blank"
                                                                rel="noopener noreferrer"
                                                                download={
                                                                  doc.uploadedFileName ||
                                                                  `DEPT_${doc.docNumber}.txt`
                                                                }
                                                                className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-50 border border-slate-200 text-slate-700 hover:bg-slate-100 rounded font-bold font-sans text-[10px] cursor-pointer"
                                                              >
                                                                <Download className="w-3 h-3" />
                                                                <span>
                                                                  Download
                                                                </span>
                                                              </a>

                                                              {docIdxInInitialDocs !==
                                                                -1 && (
                                                                <label className="inline-flex items-center gap-1 px-2.5 py-1 bg-indigo-600 hover:bg-indigo-700 text-white rounded font-bold font-sans text-[10px] cursor-pointer shadow-3xs active:scale-95">
                                                                  <UploadCloud className="w-3 h-3" />
                                                                  <span>
                                                                    Upload
                                                                  </span>
                                                                  <input
                                                                    type="file"
                                                                    className="hidden"
                                                                    onChange={async (
                                                                      e,
                                                                    ) => {
                                                                      if (
                                                                        e.target
                                                                          .files &&
                                                                        e.target
                                                                          .files[0]
                                                                      ) {
                                                                        const file =
                                                                          e
                                                                            .target
                                                                            .files[0];
                                                                        try {
                                                                          const result =
                                                                            await uploadFileToServer(
                                                                              file,
                                                                            );
                                                                          if (
                                                                            result.success &&
                                                                            onUploadDcrnDocument
                                                                          ) {
                                                                            onUploadDcrnDocument(
                                                                              req.id,
                                                                              docIdxInInitialDocs,
                                                                              result.url,
                                                                              result.fileName,
                                                                              result.fileSize,
                                                                            );
                                                                          }
                                                                        } catch (err) {
                                                                          alert(
                                                                            "File upload failed.",
                                                                          );
                                                                        }
                                                                      }
                                                                    }}
                                                                  />
                                                                </label>
                                                              )}
                                                            </>
                                                          ) : (
                                                            <span className="text-[10px] text-rose-700 bg-rose-50 px-2 py-1 border border-rose-100 rounded font-semibold">
                                                              Ready for QA
                                                              Stage-2
                                                            </span>
                                                          )}
                                                        </div>
                                                      </div>
                                                    );
                                                  },
                                                )}
                                              </div>
                                            )}
                                          </div>
                                        );
                                      })}
                                  </div>
                                </div>
                              )}
                            </div>

                            {/* Stage 2 QA details */}
                            <div className="bg-white p-4 rounded-xl border border-slate-205 shadow-3xs space-y-3">
                              <h4 className="text-xs font-bold font-sans text-slate-800 uppercase tracking-wide border-b pb-2 flex items-center gap-1.5">
                                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                                <span>2. QA Stage 2 Verification Status</span>
                              </h4>

                              {req.qaStage2EvaluatedBy ||
                              req.status === "Pending_MR_Closure" ? (
                                <div className="bg-emerald-50/50 p-3 rounded-lg border border-emerald-250 text-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
                                  <div className="space-y-1">
                                    <span className="font-extrabold text-emerald-850 uppercase text-[9px] tracking-wider block">
                                      QA Stage 2 Approved
                                    </span>
                                    <p className="text-slate-750 font-sans">
                                      <strong>Reviewed & Signed By:</strong>{" "}
                                      {req.qaStage2EvaluatedBy?.userName ||
                                        req.qaEvaluatedBy?.userName ||
                                        "QA Senior Auditor"}
                                    </p>
                                    <p className="text-slate-600 italic bg-white p-2 rounded border border-slate-200 mt-1">
                                      "
                                      {req.qaStage2Remarks ||
                                        req.qaEvaluationRemarks ||
                                        "Verified compliant with ISO & FDA release requirements."}
                                      "
                                    </p>
                                  </div>
                                  <div className="bg-white p-2.5 rounded-lg border border-emerald-250 shadow-3xs flex flex-col items-center justify-center shrink-0 w-full md:w-auto">
                                    <span className="text-[9.5px] font-mono uppercase text-slate-400 font-bold leading-none mb-1">
                                      Assigned Effective Release Date
                                    </span>
                                    <span className="text-sm font-mono font-extrabold text-emerald-800">
                                      {req.effectiveDate
                                        ? formatEffectiveDate(req.effectiveDate)
                                        : "IMMEDIATE"}
                                    </span>
                                  </div>
                                </div>
                              ) : (
                                <div className="bg-amber-50/50 p-3.5 rounded-lg border border-amber-200 text-xs text-slate-750 space-y-1">
                                  <span className="font-bold text-amber-800 uppercase text-[9px] tracking-wider block font-sans">
                                    Awaiting QA Stage 2 Verification Signature
                                  </span>
                                  <p className="leading-relaxed font-sans">
                                    The package has not yet received QA Stage 2
                                    verification clearance. QA must log into the
                                    QA Gateway Workspace, review this registry,
                                    assign the Effective Date, and submit final
                                    clearance first.
                                  </p>
                                </div>
                              )}
                            </div>

                            {/* Step 2 of close request & store */}
                            <div className="bg-gradient-to-br from-indigo-50/40 to-indigo-150/20 p-4 rounded-xl border border-indigo-200 space-y-3 shadow-3xs">
                              <h4 className="text-xs font-bold font-mono text-indigo-950 uppercase tracking-widest flex items-center gap-1.5 pb-2 border-b border-indigo-250/50">
                                <FileCheck className="w-4 h-4 text-indigo-700" />
                                <span>
                                  3. Step 2: Close Request & Store in Vault
                                </span>
                              </h4>

                              <div className="grid md:grid-cols-3 gap-3 items-center">
                                <div className="md:col-span-2">
                                  <p className="text-xs text-slate-655 leading-relaxed font-sans">
                                    Kindly verify the closure of post activity
                                    for DCRN(FM-MR-43) before closing DCRN.
                                  </p>
                                </div>

                                <div className="shrink-0">
                                  {req.status === "Pending_MR_Closure" ? (
                                    <button
                                      type="button"
                                      onClick={() => handleAuthDCRN(req.id)}
                                      className="w-full py-2.5 font-bold rounded-lg text-xs cursor-pointer flex items-center justify-center gap-2 shadow-md hover:shadow-lg transition-all active:scale-99 bg-indigo-900 hover:bg-indigo-955 text-white font-sans border-t border-indigo-400"
                                    >
                                      <FileCheck className="w-4 h-4" />
                                      <span>Close DCRN</span>
                                    </button>
                                  ) : (
                                    <button
                                      type="button"
                                      disabled
                                      className="w-full py-2.5 bg-slate-150 text-slate-450 border border-slate-200 font-bold rounded-lg text-xs cursor-not-allowed flex items-center justify-center gap-2 shadow-sm"
                                      title="Please complete uploads and wait for QA Stage 2 to sign-off and unlock final closure."
                                    >
                                      <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                                      <span>
                                        Awaiting QA Auditor Release Sign-off
                                      </span>
                                    </button>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )
          ) : // ================== ACCEPTED SECTION ==================
          authorizedDcrns.length === 0 ? (
            <div
              className="bg-white p-12 rounded-xl border border-slate-200 text-center text-slate-400 animate-fade-in"
              id="mr-empty-accepted-view"
            >
              <Check className="w-12 h-12 mx-auto text-slate-350 opacity-60 mb-2 pointer-events-none" />
              <p className="text-sm font-semibold text-slate-700">
                No CLOSED DCRNs Yet
              </p>
              <p className="text-xs text-slate-500 mt-1">
                CLOSED DCRNs will be displayed here once their registries are
                issued and locked.
              </p>
            </div>
          ) : (
            <div
              className="space-y-3 animate-fade-in"
              id="mr-accepted-requests-container"
            >
              <p className="text-xs text-slate-500 font-medium mb-1.5 bg-slate-50 p-2.5 rounded-lg border">
                Click on any DCRN catalog number below to expand and view its
                full audit history, Preparer's Initial records, Departmental
                Impact Analysis records, QA verification, and official
                Acceptance & Closure details.
              </p>
              <div className="grid gap-2">
                {authorizedDcrns.map((req) => {
                  const isExpanded = expandedAuthorizedDcrnId === req.id;

                  const userDept = currentUser?.department;

                  const allDocsInDcrn = [
                    ...req.initialDocs,
                    ...Object.values(req.assessments || {}).flatMap(
                      (ass) => ass.documents || [],
                    ),
                  ];
                  const approvedDocsInDcrn = allDocsInDcrn.filter(
                    (d) => !!d.approvedDocUrl,
                  );
                  const isDownloadPendingForDept =
                    approvedDocsInDcrn.length > 0 &&
                    approvedDocsInDcrn.some((doc) => {
                      const targetId = req.id + "_" + doc.docNumber;
                      const isDownloaded =
                        doc.workflowStatus === "Downloaded" ||
                        localDownloadedIds.includes(targetId) ||
                        localDownloadedIds.includes(
                          targetId + (doc.addedByDept || ""),
                        );
                      return !isDownloaded;
                    });

                  return (
                    <div
                      key={req.id}
                      className="bg-white rounded-lg border border-slate-200 shadow-3xs overflow-hidden"
                    >
                      {/* Header Row */}
                      <div
                        onClick={() =>
                          setExpandedAuthorizedDcrnId(
                            isExpanded ? null : req.id,
                          )
                        }
                        className="p-3 flex justify-between items-center cursor-pointer hover:bg-slate-50 border-l-4 border-emerald-500 transition-colors"
                        id={`accepted-dcrn-row-${req.id}`}
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                          <span className="font-mono font-extrabold text-indigo-900 text-[11.5px] bg-indigo-50 border-indigo-200 border px-2 py-0.5 rounded shadow-3xs">
                            📄 {req.mrRegistryNumber}
                          </span>
                          <span className="text-[10px] text-slate-50a font-mono">
                            Preparer:{" "}
                            <strong className="font-sans text-[10.5px] font-semibold text-slate-700">
                              {req.preparedBy?.userName}
                            </strong>{" "}
                            | Issued:{" "}
                            <strong className="font-sans text-[10.5px] font-semibold text-slate-700">
                              {req.mrAuthorizedAt
                                ? req.mrAuthorizedAt.substring(0, 10)
                                : "N/A"}
                            </strong>
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          {isDownloadPendingForDept && (
                            <span className="inline-flex items-center gap-1.5 px-2 py-0.5 bg-red-100 text-red-800 border border-red-200 rounded text-[9px] font-bold font-sans uppercase tracking-tight animate-pulse shrink-0">
                              <span className="w-1 h-1 rounded-full bg-red-600 block shrink-0" />
                              Download Pending
                            </span>
                          )}
                          <span className="text-[9px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded uppercase">
                            Accepted & Locked
                          </span>
                          <span className="text-slate-400 text-[9px] font-bold">
                            {isExpanded ? "▲" : "▼"}
                          </span>
                        </div>
                      </div>
                      {/* Expanded details */}
                      {isExpanded && (
                        <div className="p-4 border-t bg-slate-50/20 space-y-4 text-xs">
                          {/* Actions and Export utility on top of detail */}
                          <div className="flex items-center justify-between border-b pb-2 mb-2">
                            <span className="text-[10px] font-mono text-slate-400 font-bold">
                              DCRN CLOSED CONTROL ARCHIVE
                            </span>
                            <button
                              onClick={() => exportWholeDcrnDetails(req)}
                              className="inline-flex items-center gap-1 px-3 py-1.5 bg-indigo-600 hover:bg-slate-800 text-white font-bold rounded text-[10px] cursor-pointer transition-all shadow-3xs hover:shadow-xs"
                            >
                              <Download className="w-3.5 h-3.5" />
                              <span>Export Whole DCRN Record (.pdf)</span>
                            </button>
                          </div>

                          {/* Metadata */}
                          <div className="bg-white p-3.5 rounded-lg border text-xs text-slate-700 space-y-1">
                            <p className="font-bold text-slate-405 uppercase text-[9px] mb-1">
                              General Registry Info
                            </p>
                            <p className="leading-relaxed">
                              <strong>Preparer Name:</strong>{" "}
                              {req.preparedBy?.userName} (
                              {req.preparedBy?.department || "QA"})
                            </p>
                            <p className="leading-relaxed font-mono">
                              <strong>Initiated Date & Time (ITC):</strong>{" "}
                              {req.createdAt
                                ? formatToIST(req.createdAt)
                                : "N/A"}
                            </p>
                            <p className="leading-relaxed">
                              <strong>Status:</strong>{" "}
                              <span className="text-emerald-700 font-bold">
                                Closed & Cataloged
                              </span>
                            </p>
                          </div>

                          {/* QA Stage 1 and DCRN catalog assignment details */}
                          {req.qaEvaluatedBy && (
                            <div className="bg-emerald-50/40 p-3 rounded-lg border border-emerald-150 text-xs space-y-1">
                              <span className="font-bold text-emerald-800 uppercase text-[9px] tracking-wider block font-sans">
                                QA Stage-1 Review & Evaluation Sign-off
                              </span>
                              <p className="text-slate-755">
                                <strong>Evaluated & Approved By:</strong>{" "}
                                {req.qaEvaluatedBy.userName}
                              </p>
                              <p className="text-slate-755 font-mono">
                                <strong>Evaluation Date & Time:</strong>{" "}
                                {req.qaEvaluatedAt
                                  ? formatToIST(req.qaEvaluatedAt)
                                  : "N/A"}
                              </p>
                              {req.qaEvaluationRemarks && (
                                <p className="text-slate-650 italic bg-white/60 p-1.5 rounded border border-emerald-100/50">
                                  " {req.qaEvaluationRemarks} "
                                </p>
                              )}
                            </div>
                          )}

                          {req.qaEvaluatedBy && req.mrRegistryNumber && (
                            <div className="bg-indigo-50/40 p-3 rounded-lg border border-indigo-150 text-xs space-y-1 text-slate-755">
                              <span className="font-bold text-indigo-805 uppercase text-[9px] tracking-wider block font-sans">
                                DCRN Assign Catalog Number Detail
                              </span>
                              <p>
                                <strong>Assigned DCRN Number:</strong>{" "}
                                <span className="font-mono font-bold text-slate-900 bg-white border px-1 rounded">
                                  {req.mrRegistryNumber}
                                </span>
                              </p>
                              <p>
                                <strong>Assigned By Name (MR):</strong>{" "}
                                {req.mrRegistryAssignedBy?.userName ||
                                  req.mrAuthorizedBy?.userName ||
                                  "Management Representative Office"}
                              </p>
                              <p className="font-mono">
                                <strong>Assigned Date & Time:</strong>{" "}
                                {req.mrRegistryAssignedAt || req.mrAuthorizedAt
                                  ? formatToIST(
                                      req.mrRegistryAssignedAt ||
                                        req.mrAuthorizedAt ||
                                        "",
                                    )
                                  : "N/A"}
                              </p>
                            </div>
                          )}

                          {/* 1. Preparer's records */}
                          <div className="bg-white p-3 rounded-lg border shadow-3xs">
                            <h5 className="text-[10px] font-mono font-bold uppercase text-slate-400 mb-2">
                              1. Preparer's Initial Document Records
                            </h5>
                            <div className="divide-y divide-slate-150">
                              {req.initialDocs
                                .filter(
                                  (d) =>
                                    !d.addedByDept ||
                                    d.addedByDept ===
                                      (req.preparedBy?.department || ""),
                                )
                                .map((doc, idx) => (
                                  <div
                                    key={idx}
                                    className="py-2.5 first:pt-0 last:pb-0"
                                  >
                                    <p className="font-bold text-indigo-900 flex flex-wrap items-center gap-1.5">
                                      <span>📄 {doc.docNumber}</span>
                                      <span className="text-[10px] font-mono text-slate-600 bg-slate-100 p-0.5 rounded px-1.5 font-bold">
                                        Rev: {doc.currentRevision || "-"}
                                      </span>
                                      {doc.title && (
                                        <span className="text-[10px] text-indigo-755 font-bold bg-indigo-50 border border-indigo-150 rounded px-1.5 py-0.2 mx-1 inline-block font-sans">
                                          Title: {doc.title}
                                        </span>
                                      )}
                                      <span className="text-[9px] font-sans font-normal text-slate-500">
                                        [{doc.actionType || "Change"}]
                                      </span>
                                    </p>
                                    <p className="mt-1 font-sans text-slate-700">
                                      <strong>Reason:</strong>{" "}
                                      {doc.reasonForChange}
                                    </p>
                                    <p className="font-sans text-slate-700">
                                      <strong>Proposed Change:</strong>{" "}
                                      {doc.changesRequired}
                                    </p>

                                    {/* Document signatures audit timeline */}
                                    {renderDocSignOffTimeline(doc, req)}
                                    {doc.approvedDocUrl && (
                                      <div className="mt-2 text-[10.5px] bg-indigo-50 border border-indigo-150 p-2 rounded-lg flex items-center justify-between">
                                        <div className="text-[10.5px] font-bold truncate flex items-center gap-1.5 text-indigo-955">
                                          <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 animate-pulse" />
                                          <span className="truncate">
                                            Final Approved Copy:{" "}
                                            {doc.approvedDocName ||
                                              "Approved_Copy.docx"}
                                          </span>
                                        </div>
                                        {(() => {
                                          const targetId =
                                            req.id + "_" + doc.docNumber;
                                          const isDownloaded =
                                            doc.workflowStatus ===
                                              "Downloaded" ||
                                            localDownloadedIds.includes(
                                              targetId,
                                            ) ||
                                            localDownloadedIds.includes(
                                              targetId +
                                                (doc.addedByDept || ""),
                                            );
                                          return (
                                            <a
                                              href={doc.approvedDocUrl}
                                              target="_blank"
                                              rel="noopener noreferrer"
                                              download={
                                                doc.approvedDocName ||
                                                `APPROVED_${doc.docNumber}.docx`
                                              }
                                              onClick={() => {
                                                if (onDownloadSOP) {
                                                  onDownloadSOP(doc.docNumber);
                                                }
                                                if (
                                                  !localDownloadedIds.includes(
                                                    targetId,
                                                  )
                                                ) {
                                                  setLocalDownloadedIds(
                                                    (prev) => [
                                                      ...prev,
                                                      targetId,
                                                    ],
                                                  );
                                                }
                                              }}
                                              className={`${isDownloaded ? "bg-indigo-600 hover:bg-indigo-700" : "bg-emerald-600 hover:bg-emerald-700"} text-white rounded px-2.5 py-0.8 text-[10px] font-bold inline-flex items-center gap-1 cursor-pointer shadow-3xs transition-all`}
                                            >
                                              <Download className="w-3 h-3 text-white" />
                                              <span>
                                                {isDownloaded
                                                  ? "Download Approved Copy Again"
                                                  : "Download Approved Copy"}
                                              </span>
                                            </a>
                                          );
                                        })()}
                                      </div>
                                    )}
                                  </div>
                                ))}
                            </div>
                          </div>

                          {/* 2. Departmental Impact Analysis */}
                          <div className="bg-white p-3 rounded-lg border shadow-3xs">
                            <h5 className="text-[10px] font-mono font-bold uppercase text-slate-400 mb-2">
                              2. Departmental Impact Analysis
                            </h5>
                            <div className="space-y-3">
                              {Object.entries(req.assessments || {})
                                .filter(
                                  ([code]) =>
                                    code !== "PK" &&
                                    code !== (req.preparedBy?.department || ""),
                                )
                                .map(([code, ass]) => {
                                  const deptDocs = req.initialDocs.filter(
                                    (d) => d.addedByDept === code,
                                  );
                                  const isDeptImpacted =
                                    ass.impacted === "Yes" ||
                                    deptDocs.length > 0;
                                  const docsToRender =
                                    deptDocs.length > 0
                                      ? deptDocs
                                      : ass.documents || [];

                                  return (
                                    <div
                                      key={code}
                                      className="bg-slate-50/50 border border-slate-150 rounded-lg p-3"
                                    >
                                      <div className="flex justify-between items-center mb-1.5 flex-wrap gap-2">
                                        <span className="font-bold text-slate-805 font-mono text-[10.5px]">
                                          {DEPARTMENT_MAP[code] || code} ({code}
                                          )
                                        </span>
                                        <div className="flex items-center gap-2 flex-wrap">
                                          {!isDeptImpacted &&
                                            ass.assessedBy && (
                                              <span className="text-[10px] text-slate-550 font-sans">
                                                Assessed By:{" "}
                                                <strong>
                                                  {ass.assessedBy.userName}
                                                </strong>{" "}
                                                on{" "}
                                                {ass.assessedAt
                                                  ? formatToIST(ass.assessedAt)
                                                  : "N/A"}
                                              </span>
                                            )}
                                          <span
                                            className={`px-2 py-0.5 rounded text-[9.5px] font-bold ${isDeptImpacted ? "bg-amber-100 text-amber-800" : "bg-slate-100 text-slate-600"}`}
                                          >
                                            {isDeptImpacted
                                              ? "Impacted"
                                              : "Not Impacted"}
                                          </span>
                                        </div>
                                      </div>

                                      {isDeptImpacted && (
                                        <div className="text-[10px] space-y-2 bg-white p-2 border rounded mt-1.5">
                                          <p className="font-semibold text-slate-500 uppercase text-[9px] mb-1">
                                            Impacted Documents:
                                          </p>
                                          {docsToRender.map((doc, dIdx) => (
                                            <div
                                              key={dIdx}
                                              className="border-b last:border-0 pb-2.5 mb-2.5 last:mb-0 last:pb-0"
                                            >
                                              <p className="font-mono text-indigo-900 font-bold flex flex-wrap items-center gap-1.5">
                                                <span>📄 {doc.docNumber}</span>
                                                <span className="text-[10px] font-mono text-slate-600 bg-slate-100 p-0.5 rounded px-1.5 font-bold">
                                                  Rev:{" "}
                                                  {doc.currentRevision || "-"}
                                                </span>
                                                {doc.title && (
                                                  <span className="text-[10px] text-indigo-755 font-bold bg-indigo-50 border border-indigo-150 rounded px-1.5 py-0.2 mx-1 inline-block font-sans">
                                                    Title: {doc.title}
                                                  </span>
                                                )}
                                                <span className="text-[9px] font-sans font-normal text-slate-550">
                                                  [{doc.actionType || "Change"}]
                                                </span>
                                              </p>
                                              <p className="text-slate-650 mt-0.5">
                                                <strong>Reason:</strong>{" "}
                                                {doc.reasonForChange}
                                              </p>
                                              <p className="text-slate-650">
                                                <strong>
                                                  Proposed Change:
                                                </strong>{" "}
                                                {doc.changesRequired}
                                              </p>

                                              {/* Document signatures audit timeline */}
                                              {renderDocSignOffTimeline(
                                                doc,
                                                req,
                                                ass.assessedBy?.userName,
                                                ass.assessedAt,
                                              )}

                                              {doc.approvedDocUrl && (
                                                <div className="text-[10px] bg-indigo-50 border border-indigo-120 p-2 rounded-lg flex items-center justify-between mt-1.5">
                                                  <div className="text-[10px] font-bold truncate flex items-center gap-1.5 text-indigo-955">
                                                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0 animate-pulse" />
                                                    <span className="truncate">
                                                      Approved Copy:{" "}
                                                      {doc.approvedDocName ||
                                                        "Approved_Copy.docx"}
                                                    </span>
                                                  </div>
                                                  {(() => {
                                                    const targetId =
                                                      req.id + "_" + doc.docNumber;
                                                    const isDownloaded =
                                                      doc.workflowStatus ===
                                                        "Downloaded" ||
                                                      localDownloadedIds.includes(
                                                        targetId,
                                                      ) ||
                                                      localDownloadedIds.includes(
                                                        targetId +
                                                          (doc.addedByDept ||
                                                            ""),
                                                      );
                                                    return (
                                                      <a
                                                        href={
                                                          doc.approvedDocUrl
                                                        }
                                                        target="_blank"
                                                        rel="noopener noreferrer"
                                                        download={
                                                          doc.approvedDocName ||
                                                          `APPROVED_${doc.docNumber}.docx`
                                                        }
                                                        onClick={() => {
                                                          if (onDownloadSOP) {
                                                            onDownloadSOP(
                                                              doc.docNumber,
                                                            );
                                                          }
                                                          if (
                                                            !localDownloadedIds.includes(
                                                              targetId,
                                                            )
                                                          ) {
                                                            setLocalDownloadedIds(
                                                              (prev) => [
                                                                ...prev,
                                                                targetId,
                                                              ],
                                                            );
                                                          }
                                                        }}
                                                        className={`${isDownloaded ? "bg-indigo-600 hover:bg-indigo-700" : "bg-emerald-600 hover:bg-emerald-700"} text-white rounded px-2.5 py-0.8 text-[10px] font-bold inline-flex items-center gap-1 cursor-pointer shadow-3xs transition-all`}
                                                      >
                                                        <Download className="w-2.5 h-2.5 text-white" />
                                                        <span>
                                                          {isDownloaded
                                                            ? "Download Approved Copy Again"
                                                            : "Download Approved Copy"}
                                                        </span>
                                                      </a>
                                                    );
                                                  })()}
                                                </div>
                                              )}
                                            </div>
                                          ))}
                                        </div>
                                      )}

                                      {isDeptImpacted && ass.assessedBy && (
                                        <div className="mt-2 text-[9.5px] text-slate-500 font-mono italic">
                                          Assessed by:{" "}
                                          <strong>
                                            {ass.assessedBy.userName}
                                          </strong>{" "}
                                          on{" "}
                                          {ass.assessedAt
                                            ? formatToIST(ass.assessedAt)
                                            : "N/A"}
                                        </div>
                                      )}
                                    </div>
                                  );
                                })}
                            </div>
                          </div>

                          {/* BEFORE Acceptance Detail: QA Stage 2 review details with Effective Date */}
                          <div className="bg-blue-50/50 p-3.5 rounded-lg border border-blue-200 text-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
                            <div className="space-y-1">
                              <span className="font-bold text-indigo-900 uppercase text-[9px] tracking-wider block font-sans">
                                QA Stage-2 Gateway Verification Sign-off
                              </span>
                              <p className="text-slate-755">
                                <strong>Reviewed & Verified By:</strong>{" "}
                                {req.qaStage2EvaluatedBy?.userName ||
                                  req.qaEvaluatedBy?.userName ||
                                  "QA Senior Auditor"}
                              </p>
                              <p className="text-slate-755 font-mono">
                                <strong>Review Signed At:</strong>{" "}
                                {req.qaStage2EvaluatedAt
                                  ? formatToIST(req.qaStage2EvaluatedAt)
                                  : req.qaEvaluatedAt
                                    ? formatToIST(req.qaEvaluatedAt)
                                    : "N/A"}
                              </p>
                              <p className="text-slate-650 italic bg-white p-1.5 rounded border border-slate-200/50">
                                "{" "}
                                {req.qaStage2Remarks ||
                                  req.qaEvaluationRemarks ||
                                  "Verified compliant with ISO & FDA release guidelines."}{" "}
                                "
                              </p>
                            </div>
                            <div className="bg-white p-2.5 rounded-lg border border-indigo-200 shadow-3xs flex flex-col items-center justify-center shrink-0 w-full md:w-auto">
                              <span className="text-[9px] font-mono uppercase text-slate-400 font-bold">
                                Assigned Effective Release Date
                              </span>
                              <span className="text-sm font-mono font-extrabold text-indigo-900">
                                {req.effectiveDate
                                  ? formatEffectiveDate(req.effectiveDate)
                                  : "IMMEDIATE"}
                              </span>
                            </div>
                          </div>

                          {/* ACCEPTANCE DETAIL: At the bottom after department impact analysis */}
                          <div className="bg-indigo-50/80 p-4 rounded-xl border border-indigo-200 text-xs space-y-2 shadow-3xs">
                            <span className="font-extrabold text-indigo-900 uppercase text-[10px] tracking-widest block font-sans border-b border-indigo-150 pb-1.5 mb-2 flex items-center gap-1.5">
                              <ShieldCheck className="w-4 h-4 text-indigo-600 shrink-0" />
                              Acceptance & Closure Detail (Official MR Sign-off)
                            </span>
                            <div className="grid md:grid-cols-2 gap-4">
                              <div className="space-y-1">
                                <p className="text-slate-755">
                                  <strong>Accepted By MR:</strong>{" "}
                                  {req.mrAuthorizedBy?.userName ||
                                    req.mrRegistryAssignedBy?.userName ||
                                    "Management Representative"}
                                </p>
                                <p className="text-slate-755 font-mono text-[10.5px]">
                                  <strong>Closure Date & Time:</strong>{" "}
                                  {req.mrAuthorizedAt
                                    ? formatToIST(req.mrAuthorizedAt)
                                    : req.mrRegistryAssignedAt
                                      ? formatToIST(req.mrRegistryAssignedAt)
                                      : "N/A"}
                                </p>
                              </div>
                              <div className="bg-white p-2.5 rounded-lg border border-indigo-150 flex flex-col justify-center">
                                <span className="text-[9px] text-slate-400 font-mono uppercase font-bold block">
                                  Issued Catalog Registry Number
                                </span>
                                <span className="text-xs font-mono font-black text-indigo-900">
                                  {req.mrRegistryNumber}
                                </span>
                                <span className="text-[8.5px] text-emerald-700 font-bold mt-1">
                                  ✓ Electronically Signed & Locked
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      ) : activeMRTab === "dcrn_ledger" ? (
        <div
          className="space-y-5 animate-fade-in"
          id="mr-complete-dcrn-ledger-dashboard"
        >
          {/* Bento Statistics Grid */}
          <div
            className="grid grid-cols-2 md:grid-cols-5 gap-3"
            id="mr-ledger-stats-grid"
          >
            <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs flex flex-col justify-between">
              <span className="text-[10px] uppercase tracking-wider text-slate-400 font-bold font-mono">
                Total Logged
              </span>
              <span className="text-2xl font-extrabold text-indigo-950 mt-1 font-sans">
                {dcrnRequests.length}
              </span>
            </div>
            <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs flex flex-col justify-between">
              <span className="text-[10px] uppercase tracking-wider text-emerald-600 font-bold font-mono">
                Issued DCRNs
              </span>
              <span className="text-2xl font-extrabold text-emerald-700 mt-1 font-sans">
                {dcrnRequests.filter((r) => r.status === "Completed").length}
              </span>
            </div>
            <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs flex flex-col justify-between">
              <span className="text-[10px] uppercase tracking-wider text-amber-600 font-bold font-mono">
                In Progress
              </span>
              <span className="text-2xl font-extrabold text-amber-700 mt-1 font-sans">
                {
                  dcrnRequests.filter(
                    (r) => r.status === "Pending_Impact_Assessment",
                  ).length
                }
              </span>
            </div>
            <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs flex flex-col justify-between">
              <span className="text-[10px] uppercase tracking-wider text-red-600 font-bold font-mono">
                QA Rejections
              </span>
              <span className="text-2xl font-extrabold text-red-700 mt-1 font-sans">
                {dcrnRequests.filter((r) => r.status === "Rejected").length}
              </span>
            </div>
            <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs flex flex-col justify-between col-span-2 md:col-span-1">
              <span className="text-[10px] uppercase tracking-wider text-purple-650 font-bold font-mono">
                Deletion Queue
              </span>
              <span className="text-2xl font-extrabold text-purple-700 mt-1 font-sans">
                {dcrnRequests.filter((r) => r.pendingDeletion).length}
              </span>
            </div>
          </div>

          {/* Ledger Search & Filtration Panel */}
          <div
            className="bg-white p-4 rounded-xl border border-slate-200 shadow-3xs flex flex-col md:flex-row gap-3.5 items-center justify-between"
            id="mr-ledger-filters-bar"
          >
            {/* Search label */}
            <div className="relative w-full md:w-80">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-slate-400">
                <Search className="w-4 h-4" />
              </span>
              <input
                type="text"
                placeholder="Search DCRN Track, document, or author..."
                value={mrSearchQuery}
                onChange={(e) => setMrSearchQuery(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-9 pr-3 py-2 text-xs outline-none focus:border-indigo-800 transition-colors text-slate-800 font-medium"
                id="mr-search-ledger-input"
              />
            </div>

            {/* Quick dropdown selectors */}
            <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
              <div className="flex items-center gap-1.5 text-xs text-slate-500 w-full sm:w-auto">
                <Filter className="w-3.5 h-3.5 text-slate-400" />
                <span className="font-medium whitespace-nowrap">Status:</span>
                <select
                  value={mrStatusFilter}
                  onChange={(e) => setMrStatusFilter(e.target.value)}
                  className="bg-slate-50 border p-1 rounded font-semibold text-slate-700 text-xs cursor-pointer outline-none grow"
                  id="mr-status-filter-select"
                >
                  <option value="ALL">All Status Pipeline</option>
                  <option value="Pending_QA_Evaluation">
                    Pending QA Evaluation
                  </option>
                  <option value="Pending_Impact_Assessment">
                    Pending Impact Assessment
                  </option>
                  <option value="Completed">Completed & Issued</option>
                  <option value="Rejected">Rejected</option>
                  <option value="PENDING_DELETION">
                    Pending Deletion Request
                  </option>
                </select>
              </div>

              <div className="flex items-center gap-1.5 text-xs text-slate-500 w-full sm:w-auto">
                <BarChart3 className="w-3.5 h-3.5 text-slate-400" />
                <span className="font-medium whitespace-nowrap">
                  Originator Dept:
                </span>
                <select
                  value={mrDeptFilter}
                  onChange={(e) => setMrDeptFilter(e.target.value)}
                  className="bg-slate-50 border p-1 rounded font-semibold text-slate-700 text-xs cursor-pointer outline-none grow"
                  id="mr-dept-filter-select"
                >
                  <option value="ALL">All Origin Departments</option>
                  <option value="QA">Quality Assurance (QA)</option>
                  <option value="PD">Production & Design (PD)</option>
                  <option value="QC">Quality Control (QC)</option>
                  <option value="MN">Maintenance (MN)</option>
                  <option value="ST">Warehouse / Store (ST)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Dynamic list rendering */}
          <div id="mr-ledger-dynamic-list">
            {dcrnRequests.filter((req) => {
              const matchSearch =
                req.id.toLowerCase().includes(mrSearchQuery.toLowerCase()) ||
                (req.preparedBy?.userName || "")
                  .toLowerCase()
                  .includes(mrSearchQuery.toLowerCase()) ||
                (req.mrRegistryNumber || "")
                  .toLowerCase()
                  .includes(mrSearchQuery.toLowerCase()) ||
                req.initialDocs.some((d) =>
                  d.docNumber
                    .toLowerCase()
                    .includes(mrSearchQuery.toLowerCase()),
                );

              const matchStatus =
                mrStatusFilter === "ALL" ||
                req.status === mrStatusFilter ||
                (mrStatusFilter === "PENDING_DELETION" && req.pendingDeletion);
              const matchDept =
                mrDeptFilter === "ALL" ||
                req.preparedBy?.department === mrDeptFilter;

              return matchSearch && matchStatus && matchDept;
            }).length === 0 ? (
              <div
                className="bg-white p-12 rounded-xl border border-slate-200 text-center text-slate-400"
                id="mr-ledger-empty-results"
              >
                <FileText className="w-12 h-12 mx-auto text-slate-350 opacity-60 mb-2 pointer-events-none" />
                <p className="text-sm font-semibold text-slate-700">
                  No Ledger Records Match Your Criteria
                </p>
                <p className="text-xs text-slate-500 mt-1">
                  Refine your search term, select different statuses, or choose
                  another originating department.
                </p>
              </div>
            ) : (
              <div className="space-y-4 font-sans" id="mr-ledger-cards-list">
                {dcrnRequests
                  .filter((req) => {
                    const matchSearch =
                      req.id
                        .toLowerCase()
                        .includes(mrSearchQuery.toLowerCase()) ||
                      (req.preparedBy?.userName || "")
                        .toLowerCase()
                        .includes(mrSearchQuery.toLowerCase()) ||
                      (req.mrRegistryNumber || "")
                        .toLowerCase()
                        .includes(mrSearchQuery.toLowerCase()) ||
                      req.initialDocs.some((d) =>
                        d.docNumber
                          .toLowerCase()
                          .includes(mrSearchQuery.toLowerCase()),
                      );

                    const matchStatus =
                      mrStatusFilter === "ALL" ||
                      req.status === mrStatusFilter ||
                      (mrStatusFilter === "PENDING_DELETION" &&
                        req.pendingDeletion);
                    const matchDept =
                      mrDeptFilter === "ALL" ||
                      req.preparedBy?.department === mrDeptFilter;

                    return matchSearch && matchStatus && matchDept;
                  })
                  .map((req) => {
                    let statusBadge =
                      "bg-slate-100 text-slate-700 border-slate-205";
                    if (req.status === "Pending_QA_Evaluation") {
                      statusBadge = "bg-blue-50 text-blue-700 border-blue-200";
                    } else if (req.status === "Pending_Impact_Assessment") {
                      if (isAssessmentFinished(req)) {
                        statusBadge =
                          "bg-indigo-100 text-indigo-800 border-indigo-200 font-bold animate-pulse";
                      } else {
                        statusBadge =
                          "bg-emerald-50 text-emerald-700 border-emerald-200";
                      }
                    } else if (req.status === "Rejected") {
                      statusBadge = "bg-rose-50 text-rose-700 border-rose-250";
                    } else if (req.status === "Completed") {
                      statusBadge =
                        "bg-indigo-50 text-indigo-700 border-indigo-200 font-bold";
                    }

                    const trackingDepts = Object.keys(
                      req.assessments || {},
                    ).filter((code) => code !== "PK");

                    return (
                      <div
                        key={req.id}
                        className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden"
                        id={`ledger-card-${req.id}`}
                      >
                        {/* Card Heading */}
                        <div className="bg-slate-50/85 p-3.5 border-b border-gray-150 flex flex-wrap justify-between items-center gap-2 text-xs">
                          <div className="flex items-center gap-2.5">
                            <span className="font-bold text-slate-800 font-mono">
                              DCRN Track: {req.id}
                            </span>
                            <span className="text-[10px] text-slate-450 font-mono font-medium">
                              Originator Dept:{" "}
                              <strong className="text-indigo-900">
                                {req.preparedBy?.department || "N/A"}
                              </strong>
                            </span>
                            <span className="text-[10px] text-slate-450 font-mono font-medium">
                              • {formatToIST(req.createdAt)} IST
                            </span>
                          </div>

                          <div className="flex items-center gap-2">
                            {req.pendingDeletion && (
                              <span className="inline-flex px-1.5 py-0.5 bg-rose-100 text-rose-800 border border-rose-200 rounded text-[9.5px] font-mono font-bold uppercase tracking-tight animate-pulse">
                                Pending Deletion
                              </span>
                            )}
                            <span
                              className={`inline-flex px-1.5 py-0.5 rounded text-[9.5px] border font-semibold ${statusBadge}`}
                            >
                              {req.status === "Pending_Impact_Assessment" &&
                              isAssessmentFinished(req)
                                ? "Forwarded for MR Approval"
                                : req.status}
                            </span>
                            {req.status === "Completed" &&
                              req.mrRegistryNumber && (
                                <span className="bg-amber-100 text-amber-800 border border-amber-200 px-1.5 py-0.5 rounded text-[9.5px] font-mono font-bold uppercase tracking-tight">
                                  Issued DCRN: {req.mrRegistryNumber}
                                </span>
                              )}
                          </div>
                        </div>

                        {/* Detail body */}
                        <div className="p-4 space-y-4 text-xs">
                          {/* Preparer Banner Summary */}
                          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-slate-50/30 p-2.5 rounded-lg border border-slate-150/80 gap-1">
                            <div>
                              <span className="text-slate-400 font-semibold uppercase text-[9.5px] tracking-wide font-mono block">
                                Preparer Credentials
                              </span>
                              <span className="text-slate-805 font-bold">
                                {req.preparedBy?.userName}
                              </span>
                            </div>
                            <div className="text-right sm:text-right">
                              <span className="text-slate-400 font-semibold uppercase text-[9.5px] tracking-wide font-mono block">
                                Action Status
                              </span>
                              <span className="text-slate-705 font-semibold">
                                {req.status === "Pending_Impact_Assessment" &&
                                isAssessmentFinished(req)
                                  ? "Forwarded for MR Approval"
                                  : req.status.replace(/_/g, " ")}
                              </span>
                            </div>
                          </div>

                          {/* Initial Docs Block */}
                          <div>
                            <h5 className="text-[10px] font-mono font-bold uppercase text-slate-400 tracking-wider mb-1.5">
                              Originating Requested Document Changes
                            </h5>
                            <div className="space-y-1.5">
                              {req.initialDocs
                                .filter(
                                  (d) =>
                                    !d.addedByDept ||
                                    d.addedByDept ===
                                      (req.preparedBy?.department || ""),
                                )
                                .map((doc, dIdx) => (
                                  <div
                                    key={dIdx}
                                    className="p-2 border border-slate-205 bg-white rounded-lg shadow-3xs"
                                  >
                                    <span className="font-bold text-indigo-900 font-mono text-[11px]">
                                      📄 {doc.docNumber || "N/A"}{" "}
                                      {doc.title && (
                                        <span className="text-[10px] text-indigo-755 font-bold bg-indigo-50 border border-indigo-150 rounded px-1.5 py-0.2 mx-1 inline-block font-sans normal-case">
                                          Title: {doc.title}
                                        </span>
                                      )}
                                      <span className="text-[9px] font-sans font-normal text-slate-555">
                                        [{doc.actionType || "Change"}]
                                      </span>
                                    </span>
                                    <p className="mt-1">
                                      <strong className="text-slate-400 font-semibold text-[10.5px]">
                                        Reason:
                                      </strong>{" "}
                                      {doc.reasonForChange || "None declared"}
                                    </p>
                                    <p className="mt-0.5">
                                      <strong className="text-slate-400 font-semibold text-[10.5px]">
                                        Proposed Change:
                                      </strong>{" "}
                                      {doc.changesRequired || "None declared"}
                                    </p>

                                    {req.mrRegistryNumber &&
                                      (() => {
                                        const docIdxInInitialDocs =
                                          req.initialDocs.findIndex(
                                            (d) =>
                                              d.docNumber === doc.docNumber &&
                                              d.addedByDept === doc.addedByDept,
                                          );
                                        if (docIdxInInitialDocs === -1)
                                          return null;
                                        return (
                                          <div className="space-y-1.5">
                                            <div className="mt-2 pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 bg-slate-50/55 p-1.5 px-2 rounded-lg text-[10.5px]">
                                              <div className="flex items-center gap-1.5 min-w-0">
                                                {doc.uploadedUrl ? (
                                                  <div className="flex items-center gap-1 text-[11px] text-emerald-700 font-medium truncate">
                                                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 animate-fade-in" />
                                                    <span className="truncate">
                                                      File Spec:{" "}
                                                      <strong>
                                                        {doc.uploadedFileName ||
                                                          "Accepted Doc"}
                                                      </strong>
                                                    </span>
                                                  </div>
                                                ) : (
                                                  <span className="text-[10px] text-slate-500 font-mono flex items-center gap-1">
                                                    <AlertTriangle className="w-3.5 h-3.5 text-amber-500 shrink-0 animate-pulse" />
                                                    Awaiting official copy
                                                    upload
                                                  </span>
                                                )}
                                              </div>

                                              <div className="flex items-center gap-1.5 shrink-0">
                                                {doc.uploadedUrl ? (
                                                  <a
                                                    href={doc.uploadedUrl}
                                                    target="_blank"
                                                    rel="noopener noreferrer"
                                                    download={
                                                      doc.uploadedFileName ||
                                                      doc.docNumber
                                                    }
                                                    className="inline-flex items-center gap-1 px-2 py-0.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded font-bold font-sans text-[10px] cursor-pointer transition-colors"
                                                  >
                                                    <Download className="w-3 h-3" />
                                                    <span>Download Spec</span>
                                                  </a>
                                                ) : (
                                                  <span className="text-[9px] text-slate-400 italic">
                                                    No file uploaded
                                                  </span>
                                                )}
                                              </div>
                                            </div>

                                            {doc.approvedDocUrl && (
                                              <div className="text-[11px] bg-indigo-50 border border-indigo-150 p-2.5 rounded-lg flex items-center justify-between">
                                                <div className="text-[11px] font-bold truncate flex items-center gap-1.5 text-indigo-955">
                                                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 animate-pulse" />
                                                  <span className="truncate">
                                                    Final Approved Copy:{" "}
                                                    {doc.approvedDocName ||
                                                      "Approved_Copy.docx"}
                                                  </span>
                                                </div>
                                                {(() => {
                                                  const targetId =
                                                    req.id + "_" + doc.docNumber;
                                                  const isDownloaded =
                                                    doc.workflowStatus ===
                                                      "Downloaded" ||
                                                    localDownloadedIds.includes(
                                                      targetId,
                                                    ) ||
                                                    localDownloadedIds.includes(
                                                      targetId +
                                                        (doc.addedByDept || ""),
                                                    );
                                                  return (
                                                    <a
                                                      href={doc.approvedDocUrl}
                                                      target="_blank"
                                                      rel="noopener noreferrer"
                                                      download={
                                                        doc.approvedDocName ||
                                                        `APPROVED_${doc.docNumber}.docx`
                                                      }
                                                      onClick={() => {
                                                        if (onDownloadSOP) {
                                                          onDownloadSOP(
                                                            doc.docNumber,
                                                          );
                                                        }
                                                        if (
                                                          !localDownloadedIds.includes(
                                                            targetId,
                                                          )
                                                        ) {
                                                          setLocalDownloadedIds(
                                                            (prev) => [
                                                              ...prev,
                                                              targetId,
                                                            ],
                                                          );
                                                        }
                                                      }}
                                                      className={`inline-flex items-center gap-1.5 px-3 py-1 ${isDownloaded ? "bg-indigo-600 hover:bg-indigo-700" : "bg-emerald-600 hover:bg-emerald-700"} text-white rounded font-extrabold font-sans text-[10.5px] cursor-pointer shadow-3xs transition-colors`}
                                                    >
                                                      <Download className="w-3 h-3 text-white" />
                                                      <span>
                                                        {isDownloaded
                                                          ? "Download Approved Copy Again"
                                                          : "Download Approved Copy"}
                                                      </span>
                                                    </a>
                                                  );
                                                })()}
                                              </div>
                                            )}
                                          </div>
                                        );
                                      })()}
                                  </div>
                                ))}
                            </div>
                          </div>

                          {/* 2. Departmental Impact Analysis Section */}
                          {req.assessments && (
                            <div className="space-y-3 pt-2 border-t border-slate-200">
                              <h6 className="text-[10px] font-mono font-bold uppercase text-slate-400">
                                Departmental Impact Analysis
                              </h6>
                              <div className="space-y-3">
                                {Object.entries(req.assessments)
                                  .filter(
                                    ([code]) =>
                                      code !== "PK" &&
                                      code !==
                                        (req.preparedBy?.department || ""),
                                  )
                                  .map(([code, ass]) => {
                                    const deptDocs = req.initialDocs.filter(
                                      (d) => d.addedByDept === code,
                                    );
                                    const isDeptImpacted =
                                      ass.impacted === "Yes" ||
                                      deptDocs.length > 0;
                                    const docsToRender =
                                      deptDocs.length > 0
                                        ? deptDocs
                                        : ass.documents || [];

                                    return (
                                      <div
                                        key={code}
                                        className="bg-slate-50/50 border border-slate-150 rounded-lg p-3"
                                      >
                                        <div className="flex justify-between items-center mb-1.5 flex-wrap gap-2">
                                          <span className="font-bold text-slate-805 font-mono text-[10.5px]">
                                            {DEPARTMENT_MAP[code] || code} (
                                            {code})
                                          </span>
                                          <div className="flex items-center gap-2 flex-wrap">
                                            {ass.assessedBy && (
                                              <span className="text-[10px] text-slate-550 font-sans">
                                                Assessed By:{" "}
                                                <strong>
                                                  {ass.assessedBy.userName}
                                                </strong>{" "}
                                                ({ass.assessedBy.email}) on{" "}
                                                {ass.assessedAt
                                                  ? formatToIST(ass.assessedAt)
                                                  : "N/A"}
                                              </span>
                                            )}
                                            <span
                                              className={`px-2 py-0.5 rounded text-[9.5px] font-bold ${isDeptImpacted ? "bg-amber-100 text-amber-800" : "bg-slate-100 text-slate-600"}`}
                                            >
                                              {isDeptImpacted
                                                ? "Impacted"
                                                : "Not Impacted"}
                                            </span>
                                          </div>
                                        </div>

                                        {isDeptImpacted && (
                                          <div className="space-y-1.5 mt-2 divide-y divide-slate-150">
                                            {docsToRender &&
                                            docsToRender.length > 0 ? (
                                              docsToRender.map(
                                                (doc, docIdx) => {
                                                  const docIdxInInitialDocs =
                                                    req.initialDocs.findIndex(
                                                      (d) =>
                                                        d.docNumber ===
                                                          doc.docNumber &&
                                                        d.addedByDept ===
                                                          doc.addedByDept,
                                                    );
                                                  return (
                                                    <div
                                                      key={docIdx}
                                                      className="first:pt-0 pt-2 font-sans flex flex-col gap-1.5 pb-2.5 last:pb-0"
                                                    >
                                                      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-1">
                                                        <span className="font-bold text-amber-850 font-mono w-full sm:w-1/4">
                                                          📄 {doc.docNumber}{" "}
                                                          {doc.title && (
                                                            <span className="text-[10px] text-amber-900 font-bold bg-amber-100 border border-amber-200 rounded px-1.5 py-0.2 mx-1 inline-block font-sans normal-case">
                                                              Title: {doc.title}
                                                            </span>
                                                          )}
                                                          <span className="text-[9px] font-sans font-normal text-slate-500">
                                                            [
                                                            {doc.actionType ||
                                                              "Change"}
                                                            ]
                                                          </span>
                                                        </span>
                                                        <span className="text-slate-650 w-full sm:w-3/8">
                                                          <strong className="text-slate-400 font-normal font-sans">
                                                            Reason:
                                                          </strong>{" "}
                                                          {doc.reasonForChange}
                                                        </span>
                                                        <span className="text-slate-650 w-full sm:w-3/8">
                                                          <strong className="text-slate-400 font-normal font-sans">
                                                            Proposed Change:
                                                          </strong>{" "}
                                                          {doc.changesRequired}
                                                        </span>
                                                      </div>

                                                      {req.status ===
                                                        "Completed" &&
                                                        docIdxInInitialDocs !==
                                                          -1 && (
                                                          <div className="space-y-1.5 w-full">
                                                            <div className="mt-1 flex flex-wrap items-center justify-between gap-2 bg-amber-50/40 border border-amber-100 p-1.5 px-2 rounded-lg">
                                                              <div className="flex items-center gap-1.5 min-w-0">
                                                                {doc.uploadedUrl ? (
                                                                  <div className="flex items-center gap-1 text-[11px] text-emerald-700 font-medium truncate font-sans">
                                                                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                                                                    <span className="truncate">
                                                                      File Spec:{" "}
                                                                      <strong>
                                                                        {doc.uploadedFileName ||
                                                                          "Accepted Doc"}
                                                                      </strong>
                                                                    </span>
                                                                  </div>
                                                                ) : (
                                                                  <span className="text-[10px] text-amber-700 font-mono flex items-center gap-1">
                                                                    <AlertTriangle className="w-3.5 h-3.5 text-amber-500 shrink-0 animate-pulse" />
                                                                    Awaiting
                                                                    official
                                                                    copy upload
                                                                  </span>
                                                                )}
                                                              </div>

                                                              <div className="flex items-center gap-1.5 shrink-0">
                                                                {doc.uploadedUrl ? (
                                                                  <a
                                                                    href={
                                                                      doc.uploadedUrl
                                                                    }
                                                                    target="_blank"
                                                                    rel="noopener noreferrer"
                                                                    download={
                                                                      doc.uploadedFileName ||
                                                                      doc.docNumber
                                                                    }
                                                                    className="inline-flex items-center gap-1 px-2 py-0.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded font-bold font-sans text-[10px] cursor-pointer transition-colors"
                                                                  >
                                                                    <Download className="w-3 h-3" />
                                                                    <span>
                                                                      Download
                                                                      Spec
                                                                    </span>
                                                                  </a>
                                                                ) : (
                                                                  <span className="text-[9px] text-slate-400 italic">
                                                                    No file
                                                                    uploaded
                                                                  </span>
                                                                )}
                                                              </div>
                                                            </div>

                                                            {doc.approvedDocUrl && (
                                                              <div className="text-[10.5px] bg-indigo-50 border border-indigo-155 p-2 rounded-lg flex items-center justify-between">
                                                                <div className="text-[10.5px] font-bold truncate flex items-center gap-1.5 text-indigo-950">
                                                                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                                                                  <span className="truncate">
                                                                    Final
                                                                    Approved
                                                                    Copy:{" "}
                                                                    {doc.approvedDocName ||
                                                                      "Approved_Copy.docx"}
                                                                  </span>
                                                                </div>
                                                                {(() => {
                                                                  const targetId =
                                                                    req.id + "_" + doc.docNumber;
                                                                  const isDownloaded =
                                                                    doc.workflowStatus ===
                                                                      "Downloaded" ||
                                                                    localDownloadedIds.includes(
                                                                      targetId,
                                                                    ) ||
                                                                    localDownloadedIds.includes(
                                                                      targetId +
                                                                        (doc.addedByDept ||
                                                                          ""),
                                                                    );
                                                                  return (
                                                                    <a
                                                                      href={
                                                                        doc.approvedDocUrl
                                                                      }
                                                                      target="_blank"
                                                                      rel="noopener noreferrer"
                                                                      download={
                                                                        doc.approvedDocName ||
                                                                        `APPROVED_${doc.docNumber}.docx`
                                                                      }
                                                                      onClick={() => {
                                                                        if (
                                                                          onDownloadSOP
                                                                        ) {
                                                                          onDownloadSOP(
                                                                            doc.docNumber,
                                                                          );
                                                                        }
                                                                        if (
                                                                          !localDownloadedIds.includes(
                                                                            targetId,
                                                                          )
                                                                        ) {
                                                                          setLocalDownloadedIds(
                                                                            (
                                                                              prev,
                                                                            ) => [
                                                                              ...prev,
                                                                              targetId,
                                                                            ],
                                                                          );
                                                                        }
                                                                      }}
                                                                      className={`inline-flex items-center gap-1.5 px-2.5 py-1 ${isDownloaded ? "bg-indigo-600 hover:bg-indigo-700" : "bg-emerald-600 hover:bg-emerald-700"} text-white rounded font-extrabold font-sans text-[10px] cursor-pointer shadow-3xs transition-colors`}
                                                                    >
                                                                      <Download className="w-2.5 h-2.5 text-white" />
                                                                      <span>
                                                                        {isDownloaded
                                                                          ? "Download Approved Copy Again"
                                                                          : "Download Approved Copy"}
                                                                      </span>
                                                                    </a>
                                                                  );
                                                                })()}
                                                              </div>
                                                            )}
                                                          </div>
                                                        )}
                                                    </div>
                                                  );
                                                },
                                              )
                                            ) : (
                                              <p className="text-amber-805 font-medium italic text-[10px] py-1 font-sans">
                                                Impact recognized (No localized
                                                document modifications
                                                submitted)
                                              </p>
                                            )}
                                          </div>
                                        )}
                                      </div>
                                    );
                                  })}
                              </div>
                            </div>
                          )}

                          {/* Clearance Evaluation details */}
                          <div className="grid md:grid-cols-2 gap-3.5">
                            {/* QA Gateway column */}
                            <div className="bg-slate-50/50 p-3 rounded-lg border border-slate-200">
                              <h6 className="text-[9.5px] font-mono font-bold uppercase text-slate-400 tracking-wider mb-2">
                                1. QA Gateway Clearance Check
                              </h6>
                              {req.qaEvaluatedBy ? (
                                <div className="space-y-1">
                                  <div className="flex items-center gap-1.5">
                                    <span className="font-semibold text-slate-700">
                                      Clearance Assessment:
                                    </span>
                                    {req.status === "Rejected" &&
                                    !req.qaEvaluationRemarks?.includes(
                                      "Approved",
                                    ) ? (
                                      <span className="text-rose-700 font-bold">
                                        QA Rejected / Blocked
                                      </span>
                                    ) : (
                                      <span className="text-blue-700 font-bold flex items-center gap-1">
                                        ✓ Accepted Gateway
                                      </span>
                                    )}
                                  </div>
                                  <p className="text-[10px] text-slate-450 font-mono">
                                    Evaluator: {req.qaEvaluatedBy.userName}
                                  </p>
                                  <p className="italic text-slate-600 mt-1 bg-white p-1.5 border border-slate-205 rounded">
                                    "{req.qaEvaluationRemarks}"
                                  </p>
                                </div>
                              ) : (
                                <div className="text-slate-400 italic py-1.5">
                                  Awaiting QA Evaluation clearance. DCRN process
                                  not validated.
                                </div>
                              )}
                            </div>

                            {/* 4-Dept assessments matrix column */}
                            <div className="bg-slate-50/50 p-3 rounded-lg border border-slate-200">
                              <h6 className="text-[9.5px] font-mono font-bold uppercase text-slate-400 tracking-wider mb-2">
                                2. Inter-Departmental Trackers Matrix
                              </h6>
                              <div className="grid grid-cols-2 gap-2 text-[10px]">
                                {trackingDepts.map((code) => {
                                  const rep = req.assessments?.[code];
                                  const deptLabel =
                                    DEPARTMENT_MAP[code] || code;
                                  const hasAddedDocs = req.initialDocs.some(
                                    (doc) => doc.addedByDept === code,
                                  );
                                  const isImpacted =
                                    rep?.impacted === "Yes" || hasAddedDocs;
                                  const isAwaiting =
                                    !hasAddedDocs &&
                                    (!rep || rep.impacted === null);

                                  return (
                                    <div
                                      key={code}
                                      className="p-1.5 rounded border bg-white border-slate-205 flex items-center justify-between"
                                    >
                                      <div className="flex flex-col">
                                        <span className="font-bold text-slate-800 font-mono">
                                          {code}
                                        </span>
                                        <span className="text-[8px] text-slate-400 leading-none">
                                          {deptLabel.substring(0, 11)}..
                                        </span>
                                      </div>

                                      {isAwaiting ? (
                                        <span className="bg-slate-100 text-slate-450 px-1.5 py-0.2 rounded text-[9px] font-mono font-semibold animate-pulse">
                                          AWAITING
                                        </span>
                                      ) : (
                                        <div className="text-right">
                                          <span
                                            className={`px-1.5 py-0.2 rounded text-[9px] font-mono font-bold ${
                                              isImpacted
                                                ? "bg-amber-100 text-amber-800"
                                                : "bg-emerald-100 text-emerald-800"
                                            }`}
                                            title={
                                              isImpacted
                                                ? "IMPACTED DEPARTMENT"
                                                : "CLEAR FROM IMPACT"
                                            }
                                          >
                                            {isImpacted ? "IMPACT" : "CLEAR"}
                                          </span>
                                        </div>
                                      )}
                                    </div>
                                  );
                                })}
                              </div>
                            </div>
                          </div>

                          {/* Administrative Deletion Options directly within ledger dashboard */}
                          {req.pendingDeletion &&
                            (onApproveDcrnRemoval || onRejectDcrnRemoval) && (
                              <div className="mt-3 bg-rose-50 border border-rose-200 rounded-lg p-3 flex flex-wrap justify-between items-center gap-3 font-sans">
                                <div className="flex items-center gap-2 text-xs text-rose-850 font-semibold font-sans">
                                  <AlertTriangle className="w-4 h-4 text-rose-600 animate-pulse pointer-events-none" />
                                  <span>
                                    Original author requested deletion disposal
                                    under management representative clearance
                                    controls.
                                  </span>
                                </div>

                                <div className="flex items-center gap-2 font-sans font-medium">
                                  {onApproveDcrnRemoval && (
                                    <button
                                      type="button"
                                      onClick={() =>
                                        onApproveDcrnRemoval(req.id)
                                      }
                                      className="bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs p-1.5 px-3 rounded-lg cursor-pointer flex items-center gap-1 shadow-sm transition-colors"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                      <span>Accept Permanent Deletion</span>
                                    </button>
                                  )}
                                  {onRejectDcrnRemoval && (
                                    <button
                                      type="button"
                                      onClick={() =>
                                        onRejectDcrnRemoval(req.id)
                                      }
                                      className="bg-slate-100 hover:bg-slate-200 border border-slate-350 text-slate-700 font-semibold text-xs p-1.5 px-3 rounded-lg cursor-pointer transition-all"
                                    >
                                      Reject & Restore Request
                                    </button>
                                  )}
                                </div>
                              </div>
                            )}
                        </div>
                      </div>
                    );
                  })}
              </div>
            )}
          </div>
        </div>
      ) : activeMRTab === "approved" ? (
        <div className="bg-white border border-slate-200 rounded-lg shadow-sm overflow-hidden p-5 space-y-6">
          <div className="flex justify-between items-center pb-1.5 border-b border-slate-150">
            <span className="text-[10px] uppercase font-bold tracking-wider font-mono text-slate-400 block">
              Accepted Release Outputs:
            </span>
            <span className="text-xs text-blue-600 font-bold block">
              Accepted SOPs: {approvedDocs.length}
            </span>
          </div>

          {approvedDocs.length === 0 ? (
            <div className="p-10 text-center border-2 border-dashed border-slate-200 rounded-lg bg-white space-y-2 select-none">
              <ShieldAlert className="w-10 h-10 text-slate-400 mx-auto" />
              <h4 className="text-sm font-bold text-slate-850">
                No Accepted Records Found
              </h4>
              <p className="text-xs text-slate-450 mt-1">
                Once an approver signs off on any active standard draft, the
                final accepted copy will appear here for regulatory downloading.
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Category A: Pending Download */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 pb-1.5 border-b border-amber-100">
                  <span className="p-1.5 bg-amber-50 text-amber-600 rounded-md">
                    <Clock className="w-4 h-4 text-amber-500 animate-pulse" />
                  </span>
                  <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-800">
                    Category A: Pending Download (
                    {
                      approvedDocs.filter(
                        (d) =>
                          !d.mrDownloaded && !localDownloadedIds.includes(d.id),
                      ).length
                    }
                    )
                  </h3>
                  <span className="text-[9px] bg-red-100 text-red-800 px-1.5 py-0.5 rounded-full font-bold font-mono ml-auto">
                    To Be Downloaded
                  </span>
                </div>

                {approvedDocs.filter(
                  (d) => !d.mrDownloaded && !localDownloadedIds.includes(d.id),
                ).length === 0 ? (
                  <div className="p-5 text-center border border-dashed border-slate-200 bg-emerald-50/20 text-[#047857] font-semibold text-xs rounded-lg flex items-center justify-center gap-1">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>
                      All approved SOP templates have been successfully
                      downloaded.
                    </span>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {approvedDocs
                      .filter(
                        (d) =>
                          !d.mrDownloaded && !localDownloadedIds.includes(d.id),
                      )
                      .map((doc) => (
                        <div
                          key={doc.id}
                          className="bg-amber-50/10 border-2 border-amber-100/70 hover:border-amber-300 rounded-lg p-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 transition-all hover:bg-amber-50/30 shadow-xs"
                        >
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="font-mono text-[9px] px-2 py-0.5 bg-slate-900 text-emerald-300 rounded font-bold">
                                {doc.id}
                              </span>
                              <h4 className="text-sm font-bold text-slate-900">
                                {doc.title}
                              </h4>
                              <span className="text-[9px] bg-amber-100 text-amber-800 font-mono font-bold px-1.5 py-0.5 rounded leading-none">
                                Pending Download
                              </span>
                            </div>
                            <p className="text-xs text-slate-500">
                              Classification:{" "}
                              <strong className="text-slate-700">
                                {doc.category}
                              </strong>{" "}
                              | Department:{" "}
                              <strong class="text-slate-700">
                                {doc.department}
                              </strong>
                            </p>

                            {doc.approvedBy && (
                              <div className="text-[10px] text-slate-500 font-mono mt-1">
                                Signed Off by:{" "}
                                <strong className="text-slate-700">
                                  {doc.approvedBy.signerName}
                                </strong>{" "}
                                ({doc.approvedBy.signerTitle}) on{" "}
                                <span className="text-slate-450 font-semibold">
                                  {formatToIST(doc.approvedBy.timestamp)}
                                </span>
                              </div>
                            )}

                            {doc.fileName && (
                              <div className="text-[10.5px] text-[#2563EB] font-mono mt-1 flex items-center gap-1.5 font-semibold">
                                <FileCheck2 className="w-3.5 h-3.5 text-blue-600" />
                                <span>
                                  Physical Copy:{" "}
                                  <strong className="text-blue-700 underline">
                                    {doc.fileName} ({doc.fileSize || "128 KB"})
                                  </strong>
                                </span>
                              </div>
                            )}
                          </div>

                          <div className="self-stretch md:self-auto flex items-center md:justify-end">
                            <button
                              type="button"
                              onClick={() => handleDownloadFile(doc)}
                              className="px-3.5 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded text-xs cursor-pointer flex items-center gap-1.5 shadow transition-all whitespace-nowrap"
                            >
                              <Download className="w-3.5 h-3.5" />
                              <span>Download Final Signoff Copy</span>
                            </button>
                          </div>
                        </div>
                      ))}
                  </div>
                )}
              </div>

              {/* Category B: Already Downloaded */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 pb-1.5 border-b border-slate-200">
                  <span className="p-1.5 bg-slate-100 text-slate-600 rounded-md">
                    <CheckCircle2 className="w-4 h-4 text-slate-500" />
                  </span>
                  <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-800">
                    Category B: Already Downloaded (
                    {
                      approvedDocs.filter(
                        (d) =>
                          d.mrDownloaded || localDownloadedIds.includes(d.id),
                      ).length
                    }
                    )
                  </h3>
                  <span className="text-[9px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded-full font-bold font-mono ml-auto">
                    Archive
                  </span>
                </div>

                {approvedDocs.filter(
                  (d) => d.mrDownloaded || localDownloadedIds.includes(d.id),
                ).length === 0 ? (
                  <div className="p-5 text-center border border-dashed border-slate-200 bg-slate-50/50 text-slate-450 text-xs rounded-lg">
                    No records have been downloaded yet.
                  </div>
                ) : (
                  <div className="space-y-3">
                    {approvedDocs
                      .filter(
                        (d) =>
                          d.mrDownloaded || localDownloadedIds.includes(d.id),
                      )
                      .map((doc) => (
                        <div
                          key={doc.id}
                          className="bg-slate-50/50 border border-slate-200 rounded-lg p-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 transition-all opacity-85 hover:opacity-100 hover:bg-slate-50 shadow-xs"
                        >
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="font-mono text-[9px] px-2 py-0.5 bg-slate-400 text-white rounded font-bold">
                                {doc.id}
                              </span>
                              <h4 className="text-sm font-bold text-slate-700">
                                {doc.title}
                              </h4>
                              <span className="text-[9px] bg-indigo-50 text-indigo-700 font-mono font-bold px-1.5 py-0.5 rounded leading-none border border-indigo-100 flex items-center gap-1">
                                <CheckCircle2 className="w-3 h-3 text-indigo-500" />
                                <span>Downloaded</span>
                              </span>
                            </div>
                            <p className="text-xs text-slate-500">
                              Classification:{" "}
                              <strong className="text-slate-600">
                                {doc.category}
                              </strong>{" "}
                              | Department:{" "}
                              <strong class="text-slate-600">
                                {doc.department}
                              </strong>
                            </p>

                            {doc.approvedBy && (
                              <div className="text-[10px] text-slate-500 font-mono mt-1">
                                Signed Off by:{" "}
                                <strong className="text-slate-600">
                                  {doc.approvedBy.signerName}
                                </strong>{" "}
                                ({doc.approvedBy.signerTitle}) on{" "}
                                <span className="text-slate-450 font-semibold">
                                  {formatToIST(doc.approvedBy.timestamp)}
                                </span>
                              </div>
                            )}

                            {doc.fileName && (
                              <div className="text-[10.5px] text-slate-500 font-mono mt-1 flex items-center gap-1.5">
                                <FileCheck2 className="w-3.5 h-3.5 text-slate-400" />
                                <span>
                                  Physical Copy:{" "}
                                  <strong className="text-slate-600 underline">
                                    {doc.fileName} ({doc.fileSize || "128 KB"})
                                  </strong>
                                </span>
                              </div>
                            )}
                          </div>

                          <div className="self-stretch md:self-auto flex items-center md:justify-end">
                            <button
                              type="button"
                              onClick={() => handleDownloadFile(doc)}
                              className="px-3.5 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold rounded text-xs cursor-pointer flex items-center gap-1.5 shadow-xs transition-all whitespace-nowrap"
                            >
                              <Download className="w-3.5 h-3.5 text-slate-500" />
                              <span>Download Again</span>
                            </button>
                          </div>
                        </div>
                      ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      ) : activeMRTab === "sop_removal" ? (
        <div className="space-y-6" id="mr-sop-removal-queue-dashboard">
          {/* Section A: SOP Document Deletions */}
          <div className="bg-white border border-slate-200 rounded-lg shadow-sm overflow-hidden p-5 space-y-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center pb-3 border-b border-rose-100 gap-2">
              <div>
                <h3 className="text-sm font-bold text-slate-800 flex items-center gap-1.5 font-sans">
                  <Trash2 className="w-4 h-4 text-rose-500 animate-pulse" />
                  SOP Document Deletion & Archiving Queue
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Authoritatively approve or reject standard operating procedure
                  removal proposals.
                </p>
              </div>
              <span className="text-[10px] text-rose-600 font-mono font-bold bg-rose-50 border border-rose-100 px-2 py-0.5 rounded">
                SOP QUEUE: {deletionRequests.length}
              </span>
            </div>

            {deletionRequests.length === 0 ? (
              <div className="p-8 text-center text-slate-400 border border-dashed border-slate-200 rounded-xl bg-slate-50/20">
                <Trash2 className="w-8 h-8 mx-auto text-slate-350 opacity-60 mb-2" />
                <p className="text-xs font-bold text-slate-700">
                  No Pending Document Removal Requests
                </p>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  All operating procedures are currently aligned with active
                  development stages.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {deletionRequests.map((doc) => (
                  <div
                    key={doc.id}
                    className="bg-rose-50/10 border border-rose-100 hover:border-rose-200 rounded-lg p-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 transition-all shadow-2xs"
                    id={`mr-removal-card-${doc.id}`}
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-[9px] px-2 py-0.5 bg-slate-900 text-rose-300 rounded font-bold">
                          {doc.id}
                        </span>
                        <h4 className="text-sm font-bold text-slate-900">
                          {doc.title}
                        </h4>
                        <span className="text-[9px] bg-rose-100 text-rose-850 font-mono font-bold px-1.5 py-0.2 rounded leading-none">
                          Pending Removal
                        </span>
                      </div>
                      <p className="text-xs text-slate-500">
                        Classification-Category:{" "}
                        <strong className="text-slate-705">
                          {doc.category}
                        </strong>{" "}
                        | Department:{" "}
                        <strong className="text-slate-705">
                          {doc.department}
                        </strong>
                      </p>
                      <div className="text-[10px] text-slate-500 font-mono mt-1">
                        Submitted by:{" "}
                        <strong className="text-slate-700">
                          {doc.preparedBy.userName}
                        </strong>
                        on{" "}
                        <span className="text-slate-450 font-semibold">
                          {doc.submitTimestamp
                            ? formatToIST(doc.submitTimestamp)
                            : "N/A"}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 self-stretch md:self-auto justify-end">
                      <button
                        type="button"
                        onClick={() =>
                          onApproveRemoval && onApproveRemoval(doc.id)
                        }
                        className="px-3.5 py-1.5 bg-rose-650 hover:bg-rose-700 text-white text-xs font-bold rounded-lg cursor-pointer transition-all border border-rose-700 shadow-sm flex items-center gap-1.5 select-none"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Approve & Archive</span>
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          onRejectRemoval && onRejectRemoval(doc.id)
                        }
                        className="px-3 py-1.5 bg-slate-100 hover:bg-slate-205 text-slate-700 text-xs font-bold rounded-lg cursor-pointer transition-all border border-slate-350 shadow-2xs select-none"
                      >
                        Reject & Restore
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      ) : activeMRTab === "dcrn_removal" ? (
        <div className="space-y-6" id="mr-dcrn-removal-queue-dashboard">
          {/* Section B: DCRN Registry Deletions */}
          <div className="bg-white border border-slate-200 rounded-lg shadow-sm overflow-hidden p-5 space-y-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center pb-3 border-b border-rose-100 gap-2">
              <div>
                <h3 className="text-sm font-bold text-slate-800 flex items-center gap-1.5 font-sans">
                  <Trash2 className="w-4 h-4 text-rose-500 animate-pulse" />
                  DCRN Ledger Change Request Deletion Queue
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Approve or reject deletion requests for ongoing or registered
                  Document Change Request Numbers.
                </p>
              </div>
              <span className="text-[10px] text-rose-600 font-mono font-bold bg-rose-50 border border-rose-100 px-2 py-0.5 rounded">
                DCRN QUEUE: {pendingDcrnDeletions.length}
              </span>
            </div>

            {pendingDcrnDeletions.length === 0 ? (
              <div className="p-8 text-center text-slate-400 border border-dashed border-slate-200 rounded-xl bg-slate-50/20">
                <Trash2 className="w-8 h-8 mx-auto text-slate-355 opacity-60 mb-2" />
                <p className="text-xs font-bold text-slate-700">
                  No Pending DCRN Deletion Requests
                </p>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  All DCRN processes are currently locked in secure active
                  operating state.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {pendingDcrnDeletions.map((req) => (
                  <div
                    key={req.id}
                    className="bg-rose-50/10 border border-rose-105 hover:border-rose-200 rounded-lg p-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 transition-all shadow-2xs"
                    id={`mr-dcrn-removal-card-${req.id}`}
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-[9px] px-2 py-0.5 bg-indigo-950 text-indigo-300 rounded font-bold">
                          {req.id}
                        </span>
                        <h4 className="text-sm font-bold text-slate-900">
                          DCRN Request Deletion Proposing
                        </h4>
                        <span className="text-[9px] bg-rose-100 text-rose-850 font-mono font-bold px-1.5 py-0.2 rounded leading-none">
                          Awaiting Deletion Approval
                        </span>
                      </div>
                      <p className="text-xs text-slate-500">
                        Status:{" "}
                        <strong className="text-slate-700 font-mono">
                          {req.status === "Pending_Impact_Assessment" &&
                          isAssessmentFinished(req)
                            ? "Forwarded for MR Approval"
                            : req.status}
                        </strong>{" "}
                        | Department:{" "}
                        <strong className="text-slate-700">
                          {req.preparedBy.department}
                        </strong>
                      </p>
                      <div className="text-[10px] text-slate-500 font-mono mt-1">
                        Prepared by:{" "}
                        <strong className="text-slate-700">
                          {req.preparedBy.userName}
                        </strong>
                        on{" "}
                        <span className="text-slate-450 font-semibold">
                          {formatToIST(req.createdAt)} IST
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 self-stretch md:self-auto justify-end">
                      <button
                        type="button"
                        onClick={() =>
                          onApproveDcrnRemoval && onApproveDcrnRemoval(req.id)
                        }
                        className="px-3.5 py-1.5 bg-red-600 text-white text-xs font-bold rounded-lg cursor-pointer transition-all border border-red-700 shadow-sm flex items-center gap-1.5 select-none"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Approve & Delete DCRN</span>
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          onRejectDcrnRemoval && onRejectDcrnRemoval(req.id)
                        }
                        className="px-3 py-1.5 bg-slate-100 hover:bg-slate-205 text-slate-700 text-xs font-bold rounded-lg cursor-pointer transition-all border border-slate-350 shadow-2xs select-none"
                      >
                        Reject & Reinstate
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      ) : (
        /* Primary table element for fulfillment queue */
        <div
          className={`bg-white border border-slate-200 rounded-lg shadow-sm overflow-hidden ${isWidget ? "max-h-[480px]" : ""}`}
        >
          <div className="p-5 border-b border-slate-150 bg-slate-50 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Layers className="w-5 h-5 text-indigo-600 animate-pulse" />
                Document Request Queue
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                {pendingRequests.length === 0
                  ? "Excellent work! No templates or soft copy forms require MR attention."
                  : `Active queue: ${pendingRequests.length} incoming compliance standard copy requests require template provisions.`}
              </p>
            </div>

            <div className="relative w-full sm:w-64">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                <Search className="h-4.5 w-4.5 text-slate-400" />
              </span>
              <input
                type="text"
                placeholder="Filter request directory..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-white border border-slate-250 focus:border-indigo-500 rounded-md pl-9.5 pr-4 py-1.5 text-xs text-slate-800 outline-none transition-all"
                id="search-req-queue"
              />
            </div>
          </div>

          {filteredRequests.length === 0 ? (
            <div className="p-10 text-center text-slate-400">
              <ShieldCheck className="w-12 h-12 mx-auto text-emerald-500 opacity-60 mb-2.5" />
              <h4 className="text-xs font-bold text-slate-700">
                MR Queue Clear
              </h4>
              <p className="text-[10.5px] text-slate-500 mt-1">
                All standard copies are provisioned or there are no pending
                requests matching search filters.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table
                className="min-w-full divide-y divide-slate-150 text-left text-xs"
                id="table-document-request-queue"
              >
                <thead className="bg-[#f9fafb] text-[10px] font-bold text-[#6b7280] uppercase tracking-wider font-mono">
                  <tr>
                    <th className="px-5 py-3">Document ID</th>
                    <th className="px-5 py-3">Requested By</th>
                    <th className="px-5 py-3">Date & Time</th>
                    <th className="px-5 py-3">Priority / Dept</th>
                    <th className="px-5 py-3 text-right">Action Button</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white">
                  {filteredRequests.map((req, idx) => {
                    const isEven = idx % 2 === 0;
                    const rowBg = isEven ? "bg-indigo-50/10" : "bg-white";

                    // Format nicely to yyyy/mm/dd
                    let formattedDate = "N/A";
                    if (req.createdAt) {
                      formattedDate = formatEffectiveDate(req.createdAt);
                    }

                    return (
                      <tr
                        key={req.id}
                        className={`${rowBg} hover:bg-indigo-50/20 transition-all`}
                        id={`row-request-${req.id}`}
                      >
                        <td className="px-5 py-4 whitespace-nowrap">
                          <span className="font-mono text-xs font-bold text-slate-900 bg-slate-100 px-2.5 py-1 rounded-md border border-slate-200">
                            {req.id}
                          </span>
                        </td>

                        <td className="px-5 py-4">
                          <div className="font-bold text-slate-850 text-xs flex items-center gap-1.5">
                            <span>{req.preparedBy.userName}</span>
                            <span className="text-[10px] text-slate-400 font-normal">
                              (Preparer)
                            </span>
                          </div>
                        </td>

                        <td className="px-5 py-4 whitespace-nowrap">
                          <div className="flex items-center gap-1.5 text-slate-700 font-medium">
                            <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                            <span>{formattedDate}</span>
                          </div>
                        </td>

                        <td className="px-5 py-4">
                          <div className="font-semibold text-slate-800">
                            {req.department}
                          </div>
                          <div className="text-[9.5px] text-indigo-600 font-mono font-bold uppercase tracking-wider mt-0.5">
                            {req.id.startsWith("DOC-")
                              ? "HIGH_PRIORITY"
                              : "REGULAR"}
                          </div>
                        </td>

                        <td className="px-5 py-4 text-right whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => handleSelectRequestToFulfill(req)}
                            className={`inline-flex items-center gap-1.5 text-[11.5px] font-bold px-3 py-1.5 bg-red-50 text-red-700 hover:bg-red-100 border border-red-200 rounded transition-all cursor-pointer shadow-xs ${
                              selectedDocId === req.id
                                ? "ring-2 ring-red-400 bg-red-100"
                                : ""
                            }`}
                            id={`btn-fulfill-${req.id}`}
                          >
                            <UploadCloud className="w-4 h-4 text-red-600 animate-bounce" />
                            <span>[ 📤 Upload Soft Copy ]</span>
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* 📥 FULFILLMENT DIALOG DRAWER PANEL */}
      {selectedDocId && activeFulfillmentDoc && (
        <div
          className="bg-slate-900 text-slate-100 p-5 rounded-lg border border-slate-750 shadow-xl animate-fade-in space-y-4"
          id="upload-fulfillment-panel"
        >
          <div className="flex justify-between items-start border-b border-slate-800 pb-3">
            <div className="space-y-1">
              <span className="text-[9px] font-mono font-bold bg-amber-500 text-slate-950 px-2 py-0.5 rounded-sm uppercase tracking-wide">
                Fulfilling Document Request: {activeFulfillmentDoc.id}
              </span>
              <h4 className="text-sm font-bold text-white mt-2">
                Provisioning Standard Template for "{activeFulfillmentDoc.title}
                "
              </h4>
              <p className="text-[10.5px] text-slate-400">
                Requested by:{" "}
                <span className="font-semibold text-slate-250 underline">
                  {activeFulfillmentDoc.preparedBy.userName}
                </span>
              </p>
            </div>
            <button
              type="button"
              onClick={() => setSelectedDocId(null)}
              className="text-slate-400 hover:text-white px-2 py-1 bg-slate-800 hover:bg-slate-700 rounded text-xs transition-colors cursor-pointer"
            >
              Cancel
            </button>
          </div>

          <form onSubmit={handleUploadSubmit} className="space-y-4">
            {/* Quick-Apply Quality Catalog Templates */}
            <div className="bg-slate-950/60 p-3 rounded-md border border-slate-800 space-y-2">
              <span className="block text-[10px] font-bold font-mono tracking-wider text-slate-400 uppercase">
                ⚡ ISO Compliance Accelerator presets:
              </span>
              <div className="flex flex-wrap gap-2">
                {CORPORATE_TEMPLATES.map((tmpl, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() =>
                      handleApplyTemplate(tmpl.text, tmpl.fileName)
                    }
                    className="px-2.5 py-1 bg-slate-850 hover:bg-slate-750 text-[10px] text-slate-300 font-semibold rounded border border-slate-800 hover:border-slate-650 transition-colors cursor-pointer flex items-center gap-1"
                  >
                    <FileCode className="w-3 h-3 text-indigo-400" />
                    <span>Apply {tmpl.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {errorMessage && (
              <div className="p-3 bg-red-950 border border-red-750 text-red-200 text-xs font-semibold rounded-md">
                {errorMessage}
              </div>
            )}

            <div className="bg-slate-950 p-4 border border-slate-800 rounded-md space-y-2">
              <label className="block text-xs font-bold text-slate-350 uppercase tracking-widest font-mono">
                Upload Actual Word Copy (.doc, .docx) *
              </label>
              <input
                type="file"
                accept=".doc, .docx"
                id="mr-upload-file-picker"
                name="mr-upload-file-picker"
                onChange={async (e) => {
                  if (e.target.files && e.target.files[0]) {
                    const file = e.target.files[0];
                    if (
                      file.name.endsWith(".doc") ||
                      file.name.endsWith(".docx")
                    ) {
                      setTemplateFileName(file.name);
                      setTemplateFileSize(
                        (file.size / 1024).toFixed(0) + " KB",
                      );
                      setErrorMessage("");
                      try {
                        const result = await uploadFileToServer(file);
                        if (result.success) {
                          console.log(
                            "Template saved in LAN office storage:",
                            result.url,
                          );
                        }
                      } catch (err) {
                        setErrorMessage(
                          "LAN storage is temporarily offline. Local parameters accepted.",
                        );
                      }
                    } else {
                      setErrorMessage(
                        "Compliance Error: Only Word Documents (.doc, .docx) are accepted.",
                      );
                      setTemplateFileName("");
                    }
                  }
                }}
                className="w-full text-xs text-slate-400 file:mr-4 file:py-1.5 file:px-3.5 file:rounded file:border-0 file:text-[11px] file:font-semibold file:bg-indigo-900 file:text-indigo-200 hover:file:bg-indigo-850 cursor-pointer"
                required
              />
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-widest font-mono">
                  Corporate File Name Asset (*.docx):
                </label>
                <input
                  type="text"
                  value={templateFileName}
                  onChange={(e) => setTemplateFileName(e.target.value)}
                  placeholder="SOP_Compliance_Template.docx"
                  className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded p-2.5 text-xs font-mono text-white outline-none"
                  required
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-widest font-mono">
                  Assigned File Size Allocation:
                </label>
                <input
                  type="text"
                  value={templateFileSize}
                  onChange={(e) => setTemplateFileSize(e.target.value)}
                  placeholder="e.g., 240 KB"
                  className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded p-2.5 text-xs font-mono text-white outline-none"
                  required
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-widest font-mono">
                Initial Template Material / Instructions body:
              </label>
              <textarea
                rows={6}
                value={templateContent}
                onChange={(e) => setTemplateContent(e.target.value)}
                placeholder="Write, paste, or apply standard quality drafts here. In line with FDA guidelines represent procedural sections clearly..."
                className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded p-2.5 text-xs text-white placeholder-slate-500 outline-none font-mono"
                required
              />
            </div>

            <div className="flex gap-2.5 justify-end">
              <button
                type="button"
                onClick={() => setSelectedDocId(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-750 text-slate-300 text-xs font-semibold rounded cursor-pointer transition-colors"
              >
                Cancel Fulfilling
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-505 text-white text-xs font-bold rounded cursor-pointer transition-all flex items-center gap-1.5"
                id="btn-upload-submit-fulfill"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Upload & Transition copy</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Vault modal trigger overlay */}
      <DownloadVaultModal
        isOpen={downloadModalOpen}
        onClose={() => setDownloadModalOpen(false)}
        fileName={downloadFileName}
        fileSize={downloadFileSize}
        fileContent={downloadFileContent}
        fileType="docx"
        checksum={downloadChecksum}
        filePathUrl={downloadFilePathUrl}
      />
    </div>
  );
}
