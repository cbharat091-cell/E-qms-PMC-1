import React, { useState, useEffect } from "react";
import {
  User,
  DCRNRequest,
  DCRNDecDocument,
  DCRNDepartmentAssessment,
  DEPARTMENT_MAP,
} from "../types";
import { uploadFileToServer } from "../utils/localUpload";
import {
  FileText,
  Plus,
  Trash2,
  Send,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Building2,
  Check,
  FileCheck,
  HelpCircle,
  FileSpreadsheet,
  Layers,
  ArrowRight,
  Search,
  Filter,
  BarChart3,
  Download,
  Clock,
  CheckCircle,
  ShieldCheck,
  MessageSquare,
} from "lucide-react";
import { formatToIST, formatTimeToIST } from "../utils/dateUtils";

const getDifferentiatedDocs = (req: DCRNRequest, deptCode: string) => {
  const ass = req.assessments?.[deptCode];
  const previousDocs = ass?.previouslyAnalyzedDocs || [];

  if (previousDocs.length > 0) {
    const previouslyAnalyzed = previousDocs.map((pDoc) => {
      const latest = req.initialDocs.find((d) => d.docNumber === pDoc.docNumber);
      return latest || pDoc;
    });
    const newlyAdded = req.initialDocs.filter(
      (d) => !previousDocs.some((p) => p.docNumber === d.docNumber),
    );
    return { previouslyAnalyzed, newlyAdded, hasPrevious: true };
  } else {
    const prepDept = req.preparedBy?.department || "";
    const previouslyAnalyzed = req.initialDocs.filter(
      (d) => !d.addedByDept || d.addedByDept === prepDept,
    );
    const newlyAdded = req.initialDocs.filter(
      (d) => d.addedByDept && d.addedByDept !== prepDept,
    );
    return { previouslyAnalyzed, newlyAdded, hasPrevious: false };
  }
};

const renderDocWorkflowStatusBadge = (doc: DCRNDecDocument | undefined) => {
  if (!doc) return null;
  if (doc.actionType === "Removal") {
    return (
      <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[9px] font-mono font-bold uppercase bg-emerald-100 text-emerald-800 border border-emerald-250 font-bold">
        Ready for QA Stage-2
      </span>
    );
  }
  const status = doc.workflowStatus;
  if (status === "ApprovalAccepted") {
    return (
      <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[9px] font-mono font-bold uppercase bg-emerald-100 text-emerald-800 border border-emerald-250 animate-pulse">
        ✓ Accepted & Released
      </span>
    );
  }
  if (status === "PendingApproval") {
    return (
      <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[9px] font-mono font-bold uppercase bg-amber-100 text-amber-805 border border-amber-250">
        ⌛ Pending Acceptance
      </span>
    );
  }
  if (status === "ReviewAccepted") {
    return (
      <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[9px] font-mono font-bold uppercase bg-sky-100 text-sky-850 border border-sky-200">
        ✓ Reviewed
      </span>
    );
  }
  if (status === "PendingReview") {
    return (
      <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[9px] font-mono font-bold uppercase bg-indigo-100 text-indigo-750 border border-indigo-150">
        ⌛ Pending Review
      </span>
    );
  }
  if (status === "Downloaded") {
    return (
      <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[9px] font-mono font-bold uppercase bg-violet-105 text-violet-800 border border-violet-200">
        ✍ Draft Downloaded
      </span>
    );
  }
  if (status === "ReviewRejected") {
    return (
      <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[9px] font-mono font-bold uppercase bg-rose-100 text-rose-800 border border-rose-200">
        ✖ Review Rejected
      </span>
    );
  }
  if (status === "ApprovalRejected") {
    return (
      <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[9px] font-mono font-bold uppercase bg-red-100 text-red-800 border border-red-200">
        ✖ Approval Rejected
      </span>
    );
  }

  return (
    <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[9px] font-mono font-bold uppercase bg-slate-100 text-slate-500 border border-slate-200">
      ⌛ Ready / Draft Stage
    </span>
  );
};

interface DcrnWorkflowProps {
  currentUser: User;
  dcrnRequests: DCRNRequest[];
  isPreparerBoard?: boolean;
  onAddDcrnRequest: (initialDocs: DCRNDecDocument[]) => void;
  onEvaluateDcrnRequest: (
    requestId: string,
    approved: boolean,
    remarks: string,
  ) => void;
  onSubmitDepartmentAssessment: (
    requestId: string,
    deptCode: string,
    impacted: "Yes" | "No",
    addedDocs: DCRNDecDocument[],
  ) => void;
  onAuthorizeDcrnRequest: (requestId: string, registryNumber: string) => void;
  onDeleteDcrnRequest?: (requestId: string) => void;
  onRejectDcrnRemoval?: (requestId: string) => void;
  onUpdateDcrnRequest?: (
    requestId: string,
    docNumber: string,
    reviewerId: string,
    updatedDocUrl: string,
    fileName: string,
  ) => void;
  onUpdateDcrnDocumentField?: (
    requestId: string,
    docNumber: string,
    fields: Partial<DCRNDecDocument>,
    auditAction?: string,
    auditDetails?: string,
  ) => void;
  onSubmitToQa?: (requestId: string) => void;
  users: User[];
}

export default function DcrnWorkflow({
  currentUser,
  dcrnRequests,
  isPreparerBoard = false,
  onAddDcrnRequest,
  onEvaluateDcrnRequest,
  onSubmitDepartmentAssessment,
  onAuthorizeDcrnRequest,
  onDeleteDcrnRequest,
  onRejectDcrnRemoval,
  onUpdateDcrnRequest,
  onUpdateDcrnDocumentField,
  onSubmitToQa,
  users,
}: DcrnWorkflowProps) {
  // Tabs: 'initiate' | 'qa' | 'history'
  const [activeTab, setActiveTab] = useState<"initiate" | "qa" | "history">(
    "initiate",
  );
  const [mrSubTab, setMrSubTab] = useState<"authorization" | "ledger">(
    "authorization",
  );
  const [mrSearchQuery, setMrSearchQuery] = useState("");
  const [mrStatusFilter, setMrStatusFilter] = useState<string>("ALL");
  const [mrDeptFilter, setMrDeptFilter] = useState<string>("ALL");

  // Filter DCRN requests to only show ones from own department or involvement
  const filteredDcrnRequests = dcrnRequests.filter((req) => {
    // Once DCRN closed by MR (Completed) it shall not be visible to preparer logfile
    if (isPreparerBoard && req.status === "Completed") {
      return false;
    }
    if (!currentUser.department) return true;
    const isPreparerDept =
      req.preparedBy?.department === currentUser.department;
    const isInAssessment =
      req.assessments && currentUser.department in req.assessments;
    return isPreparerDept || isInAssessment;
  });

  // Dynamic Popup controls for inter-departmental assessments
  const [dismissedPopupRequests, setDismissedPopupRequests] = useState<{
    [reqId: string]: boolean;
  }>({});
  const [confirmDcrnDeleteId, setConfirmDcrnDeleteId] = useState<string | null>(
    null,
  );
  const [localDownloadedIds, setLocalDownloadedIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem("dcrn_downloaded_ids");
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem("dcrn_downloaded_ids", JSON.stringify(localDownloadedIds));
    } catch (e) {}
  }, [localDownloadedIds.length, localDownloadedIds.join(",")]);

  // Revision upload states
  const [revisionReviewerIds, setRevisionReviewerIds] = useState<{
    [docId: string]: string;
  }>({});
  const [revisionFileNames, setRevisionFileNames] = useState<{
    [docId: string]: string;
  }>({});
  const [revisionFileUrls, setRevisionFileUrls] = useState<{
    [docId: string]: string;
  }>({});

  // ----------------------------------------------------
  // Preparer State: New DCRN Form
  // ----------------------------------------------------
  const [preparerDocs, setPreparerDocs] = useState<DCRNDecDocument[]>([
    {
      docNumber: "",
      title: "",
      currentRevision: "",
      nextRevision: "",
      reasonForChange: "",
      changesRequired: "",
      actionType: "Change",
    },
  ]);
  const [isSubmitPrepSuccess, setIsSubmitPrepSuccess] = useState(false);
  const [prepError, setPrepError] = useState("");

  // Popup Text Editor State for Long Inputs
  const [textEditorOpen, setTextEditorOpen] = useState(false);
  const [textEditorField, setTextEditorField] = useState<'reason' | 'changes' | null>(null);
  const [textEditorIndex, setTextEditorIndex] = useState<number | null>(null);
  const [textEditorValue, setTextEditorValue] = useState("");
  const [textEditorTitle, setTextEditorTitle] = useState("");
  const [textEditorReqId, setTextEditorReqId] = useState<string | null>(null);
  const [textEditorDocNumber, setTextEditorDocNumber] = useState<string | null>(null);

  const openTextEditor = (field: 'reason' | 'changes', index: number, initialValue: string, title: string) => {
    setTextEditorField(field);
    setTextEditorIndex(index);
    setTextEditorValue(initialValue);
    setTextEditorTitle(title);
    setTextEditorReqId(null);
    setTextEditorDocNumber(null);
    setTextEditorOpen(true);
  };

  const openHistoryTextEditor = (reqId: string, docNumber: string, field: 'reason' | 'changes', initialValue: string, title: string) => {
    setTextEditorReqId(reqId);
    setTextEditorDocNumber(docNumber);
    setTextEditorField(field);
    setTextEditorIndex(null);
    setTextEditorValue(initialValue);
    setTextEditorTitle(title);
    setTextEditorOpen(true);
  };

  const handleSaveTextEditor = () => {
    if (textEditorReqId && textEditorDocNumber && textEditorField) {
      const updates: Partial<DCRNDecDocument> = {};
      if (textEditorField === 'reason') {
        updates.reasonForChange = textEditorValue;
      } else if (textEditorField === 'changes') {
        updates.changesRequired = textEditorValue;
      }
      onUpdateDcrnDocumentField?.(textEditorReqId, textEditorDocNumber, updates);
    } else if (textEditorIndex !== null && textEditorField) {
      if (textEditorField === 'reason') {
        handleUpdatePrepDoc(textEditorIndex, 'reasonForChange', textEditorValue);
      } else if (textEditorField === 'changes') {
        handleUpdatePrepDoc(textEditorIndex, 'changesRequired', textEditorValue);
      }
    }
    setTextEditorOpen(false);
    setTextEditorField(null);
    setTextEditorIndex(null);
    setTextEditorReqId(null);
    setTextEditorDocNumber(null);
  };

  const handleAddPrepDoc = () => {
    setPreparerDocs((prev) => [
      ...prev,
      {
        docNumber: "",
        title: "",
        currentRevision: "",
        nextRevision: "",
        reasonForChange: "",
        changesRequired: "",
        actionType: "Change",
      },
    ]);
  };

  const handleRemovePrepDoc = (index: number) => {
    if (preparerDocs.length <= 1) return;
    setPreparerDocs((prev) => prev.filter((_, idx) => idx !== index));
  };

  const handleUpdatePrepDoc = (
    index: number,
    field: keyof DCRNDecDocument,
    value: string,
  ) => {
    setPreparerDocs((prev) =>
      prev.map((doc, idx) => {
        if (idx === index) {
          return { ...doc, [field]: value };
        }
        return doc;
      }),
    );
  };

  const handlePrepSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPrepError("");

    // Field validations
    for (let i = 0; i < preparerDocs.length; i++) {
      const doc = preparerDocs[i];
      if (
        !doc.docNumber.trim() ||
        !doc.reasonForChange.trim() ||
        !doc.changesRequired.trim()
      ) {
        setPrepError(
          `Validation Error: Document #${i + 1} has empty mandatory text fields.`,
        );
        return;
      }
    }

    onAddDcrnRequest(preparerDocs);
    setIsSubmitPrepSuccess(true);
    setPreparerDocs([
      { docNumber: "", reasonForChange: "", changesRequired: "" },
    ]);

    setTimeout(() => {
      setIsSubmitPrepSuccess(false);
      setActiveTab("history");
    }, 2000);
  };

  // ----------------------------------------------------
  // QA step State
  // ----------------------------------------------------
  const [remarksByReq, setRemarksByReq] = useState<{ [reqId: string]: string }>(
    {},
  );

  const handleQAAction = (requestId: string, approve: boolean) => {
    const rmk = remarksByReq[requestId] || "";
    if (!approve && !rmk.trim()) {
      alert(
        "Please provide the mandatory 'Deficiency Notes' context explaining this rejection.",
      );
      return;
    }
    onEvaluateDcrnRequest(requestId, approve, rmk);
    // Clear state
    setRemarksByReq((prev) => {
      const next = { ...prev };
      delete next[requestId];
      return next;
    });
  };

  // ----------------------------------------------------
  // Department step State
  // ----------------------------------------------------
  const [selectedImpact, setSelectedImpact] = useState<{
    [reqId: string]: "Yes" | "No" | "";
  }>({});
  const [departmentDocs, setDepartmentDocs] = useState<{
    [reqId: string]: DCRNDecDocument[];
  }>({});

  const handleAddDeptDoc = (reqId: string) => {
    setDepartmentDocs((prev) => ({
      ...prev,
      [reqId]: [
        ...(prev[reqId] || []),
        { docNumber: "", reasonForChange: "", changesRequired: "" },
      ],
    }));
  };

  const handleRemoveDeptDoc = (reqId: string, docIndex: number) => {
    setDepartmentDocs((prev) => ({
      ...prev,
      [reqId]: (prev[reqId] || []).filter((_, idx) => idx !== docIndex),
    }));
  };

  const handleUpdateDeptDoc = (
    reqId: string,
    docIndex: number,
    field: keyof DCRNDecDocument,
    val: string,
  ) => {
    setDepartmentDocs((prev) => ({
      ...prev,
      [reqId]: (prev[reqId] || []).map((doc, idx) => {
        if (idx === docIndex) {
          return { ...doc, [field]: val };
        }
        return doc;
      }),
    }));
  };

  const handleDeptChoice = (reqId: string, choice: "Yes" | "No") => {
    setSelectedImpact((prev) => ({ ...prev, [reqId]: choice }));
    if (choice === "Yes") {
      setDepartmentDocs((prev) => ({
        ...prev,
        [reqId]: [{ docNumber: "", reasonForChange: "", changesRequired: "" }],
      }));
    } else {
      setDepartmentDocs((prev) => {
        const next = { ...prev };
        delete next[reqId];
        return next;
      });
    }
  };

  const handleDeptSubmit = (requestId: string, deptCode: string) => {
    const choice = selectedImpact[requestId];
    if (!choice) {
      alert("Please select whether this change impacts your department.");
      return;
    }

    const addedDocs = departmentDocs[requestId] || [];
    if (choice === "Yes") {
      // Validate inputs
      for (let i = 0; i < addedDocs.length; i++) {
        const doc = addedDocs[i];
        if (
          !doc.docNumber.trim() ||
          !doc.reasonForChange.trim() ||
          !doc.changesRequired.trim()
        ) {
          alert(`Document #${i + 1} has outstanding empty parameters.`);
          return;
        }
      }
    }

    onSubmitDepartmentAssessment(requestId, deptCode, choice, addedDocs);

    // Clear selection state
    setSelectedImpact((prev) => {
      const next = { ...prev };
      delete next[requestId];
      return next;
    });
    setDepartmentDocs((prev) => {
      const next = { ...prev };
      delete next[requestId];
      return next;
    });
  };

  // ----------------------------------------------------
  // MR step State
  // ----------------------------------------------------
  const [assignedRegistryNum, setAssignedRegistryNum] = useState<{
    [reqId: string]: string;
  }>({});

  const handleAuthDCRN = (requestId: string) => {
    const regNum = assignedRegistryNum[requestId] || "";
    if (!regNum.trim()) {
      alert(
        "Please enter an official verified DCRN registry number before issuing.",
      );
      return;
    }
    onAuthorizeDcrnRequest(requestId, regNum.trim());
    setAssignedRegistryNum((prev) => {
      const next = { ...prev };
      delete next[requestId];
      return next;
    });
  };

  // Helper: check if a request has signed off from all dynamic tracking departmental slots
  const isAssessmentFinished = (req: DCRNRequest): boolean => {
    const assessments = req.assessments || {};
    const codes = Object.keys(assessments).filter((code) => code !== "PK");
    if (codes.length === 0) return false;
    return codes.every((code) => {
      const ass = assessments[code];
      return ass && ass.impacted !== null;
    });
  };

  // Compile full Master DCRN Packet dynamically (preparer + any department's added docs)
  const getMasterDocs = (req: DCRNRequest): DCRNDecDocument[] => {
    const map = new Map<string, DCRNDecDocument>();
    if (req.initialDocs) {
      req.initialDocs.forEach((doc) => {
        map.set(doc.docNumber, doc);
      });
    }
    if (req.assessments) {
      Object.values(req.assessments).forEach((ass: DCRNDepartmentAssessment) => {
        if (ass.documents) {
          ass.documents.forEach((doc) => {
            if (!map.has(doc.docNumber)) {
              map.set(doc.docNumber, doc);
            }
          });
        }
      });
    }
    return Array.from(map.values());
  };

  // Notification Counts
  const qaPendingCount = dcrnRequests.filter(
    (r) => r.status === "Pending_QA_Evaluation",
  ).length;

  // Department pending task count for current user
  const userDeptCode = currentUser.department || "";
  const deptPendingCount = dcrnRequests.filter((r) => {
    if (r.status !== "Pending_Impact_Assessment") return false;
    const ass = r.assessments && r.assessments[userDeptCode];
    return ass && ass.impacted === null;
  }).length;

  // MR pending count
  const mrPendingCount = currentUser.isMR
    ? dcrnRequests.filter((r) => {
        // Escalate specifically when Pendings are fully reviewed by the departments
        return (
          r.status === "Pending_Impact_Assessment" && isAssessmentFinished(r)
        );
      }).length
    : 0;

  // Find a pending request requiring our department that hasn't been completed-signed or dismissed yet
  const pendingPopupRequest = dcrnRequests.find(
    (r) =>
      r.status === "Pending_Impact_Assessment" &&
      userDeptCode &&
      r.assessments &&
      r.assessments[userDeptCode] &&
      r.assessments[userDeptCode].impacted === null &&
      !dismissedPopupRequests[r.id],
  );

  // Calculate DCRN Log File Pending Count for originator departments
  const dcrnLogFilePendingCount = (() => {
    let count = 0;
    dcrnRequests.forEach((req) => {
      const isUserPreparerOrSameDept =
        currentUser.id === req.preparedBy?.userId ||
        (currentUser.department &&
          currentUser.department === req.preparedBy?.department);

      if (isUserPreparerOrSameDept) {
        (req.initialDocs || []).forEach((doc) => {
          const isMRDownloadPending =
            doc.uploadedUrl &&
            (!doc.workflowStatus || (doc.workflowStatus as string) === "None") &&
            !localDownloadedIds.includes(doc.docNumber + (doc.addedByDept || ""));
          const isApprovedDownloadPending =
            doc.approvedDocUrl &&
            doc.workflowStatus === "ApprovalAccepted" &&
            !localDownloadedIds.includes(doc.docNumber + (doc.addedByDept || ""));
          if (isMRDownloadPending || isApprovedDownloadPending) {
            count++;
          }
        });

        const masterDocs = req.initialDocs || [];
        const allApproved =
          masterDocs.length > 0 &&
          masterDocs.every((d) => d.actionType === "Removal" || d.workflowStatus === "ApprovalAccepted");
        const isNotYetSubmitted =
          req.status !== "Pending_QA_Evaluation" &&
          req.status !== "Pending_QA_Stage2" &&
          req.status !== "Pending_MR_Closure" &&
          req.status !== "Completed" &&
          req.status !== "Rejected";
        const canSubmit =
          req.preparedBy?.userId === currentUser.id ||
          req.preparedBy?.email === currentUser.email;
        if (allApproved && isNotYetSubmitted && canSubmit) {
          count++;
        }
      }
    });
    return count;
  })();

  return (
    <div className="space-y-6" id="dcrn-inter-department-workspace">
      {/* Dynamic Selector Header */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-indigo-600" />
            <h2 className="text-base font-bold text-slate-900 font-sans tracking-tight">
              DCRN Change Control Center
            </h2>
          </div>
          <p className="text-xs text-slate-500"></p>
        </div>

        {/* Tab Selection Row */}
        <div className="flex flex-wrap gap-1.5 self-start md:self-center">
          <button
            onClick={() => setActiveTab("initiate")}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all border ${
              activeTab === "initiate"
                ? "bg-indigo-600 border-indigo-700 text-white"
                : "bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-650"
            }`}
          >
            Initiate DCRN Request
          </button>

          <button
            onClick={() => setActiveTab("history")}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all border flex items-center gap-1.5 ${
              activeTab === "history"
                ? "bg-slate-800 border-slate-900 text-white"
                : "bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-650"
            }`}
          >
            <span>DCRN Log File</span>
            {filteredDcrnRequests.length > 0 && (
              <span className="px-2 py-0.5 rounded bg-red-600 text-white font-mono text-[10px] font-extrabold leading-none animate-pulse">
                {filteredDcrnRequests.length}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Main Content Areas */}
      <div id="dcrn-active-panel">
        {/* --------------------------------------------------------------------------
            TAB 1: INITIALIZE DCRN REQUEST (PREPARER VIEW)
            -------------------------------------------------------------------------- */}
        {activeTab === "initiate" && (
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-6">
            <div className="border-b border-slate-100 pb-3">
              <h3 className="text-sm font-bold text-slate-900">
                Initiate DCRN Request
              </h3>
              <p className="text-xs text-slate-500 mt-1"></p>
            </div>

            {isSubmitPrepSuccess && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-850 rounded text-xs font-medium flex items-center gap-2">
                <CheckCircle2 className="w-4.5 h-4.5 text-emerald-600" />
                <span>
                  Success: Multi-document payload logged and dispatched to QA
                  Evaluation Gateway.
                </span>
              </div>
            )}

            {prepError && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-850 rounded text-xs font-medium flex items-center gap-2">
                <AlertTriangle className="w-4.5 h-4.5 text-rose-600 animate-bounce" />
                <span>{prepError}</span>
              </div>
            )}

            <form onSubmit={handlePrepSubmit} className="space-y-6">
              <div className="space-y-4">
                <div className="flex justify-between items-center bg-slate-50 p-2.5 rounded-lg border border-slate-150">
                  <span className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider">
                    CURRENT PREPARER: {currentUser.name} (
                    {currentUser.department || "QA"})
                  </span>
                  <button
                    type="button"
                    onClick={handleAddPrepDoc}
                    className="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-indigo-700 rounded text-[10.5px] font-bold flex items-center gap-1 cursor-pointer transition-all hover:scale-102"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>+ Add Document</span>
                  </button>
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  {preparerDocs.map((doc, idx) => (
                    <div
                      key={idx}
                      className="bg-white border-2 border-dashed border-slate-200 rounded-xl p-4 space-y-3 relative hover:border-slate-350 transition-all shadow-xs"
                      id={`prep-card-${idx}`}
                    >
                      <div className="flex justify-between items-center text-xs font-bold border-b border-slate-100 pb-1.5 mb-1 text-slate-700">
                        <span className="flex items-center gap-1">
                          <FileText className="w-3.5 h-3.5 text-slate-500" />
                          Document Entry #{idx + 1}
                        </span>
                        {preparerDocs.length > 1 && (
                          <button
                            type="button"
                            onClick={() => handleRemovePrepDoc(idx)}
                            className="p-1 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded cursor-pointer transition-colors"
                            title="Remove Document sub-form"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>

                      <div className="space-y-2.5 text-xs">
                        <div>
                          <label className="block text-[10px] font-bold text-slate-600 mb-1">
                            Action Type *
                          </label>
                          <div className="flex gap-3">
                            {["Change", "Introduction", "Removal"].map(
                              (type) => (
                                <label
                                  key={type}
                                  className="inline-flex items-center gap-1 cursor-pointer"
                                >
                                  <input
                                    type="radio"
                                    value={type}
                                    checked={doc.actionType === type}
                                    onChange={(e) => {
                                      const newType = e.target.value as
                                        | "Change"
                                        | "Introduction"
                                        | "Removal";
                                      handleUpdatePrepDoc(
                                        idx,
                                        "actionType",
                                        newType,
                                      );
                                      if (newType === "Introduction") {
                                        handleUpdatePrepDoc(
                                          idx,
                                          "currentRevision",
                                          "-",
                                        );
                                      } else if (doc.currentRevision === "-") {
                                        handleUpdatePrepDoc(
                                          idx,
                                          "currentRevision",
                                          "",
                                        );
                                      }
                                      if (newType === "Removal") {
                                        handleUpdatePrepDoc(
                                          idx,
                                          "nextRevision",
                                          "-",
                                        );
                                      } else if (doc.nextRevision === "-") {
                                        handleUpdatePrepDoc(
                                          idx,
                                          "nextRevision",
                                          "",
                                        );
                                      }
                                    }}
                                    className="accent-indigo-600 cursor-pointer"
                                  />
                                  <span className="text-[10px] text-slate-700">
                                    {type}
                                  </span>
                                </label>
                              ),
                            )}
                          </div>
                        </div>
                        {/* Document Number */}
                        <div>
                          <label className="block text-[10px] font-bold text-slate-600 mb-1">
                            Document Number *
                          </label>
                          <input
                            type="text"
                            value={doc.docNumber || ""}
                            onChange={(e) =>
                              handleUpdatePrepDoc(
                                idx,
                                "docNumber",
                                e.target.value,
                              )
                            }
                            placeholder="e.g., SOP-2041-v2.0"
                            className="w-full bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded p-1.5 outline-none text-slate-800"
                            required
                          />
                        </div>

                        {/* Preparer Added */}
                        {/* Removed */}

                        {/* Revision Fields */}
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="block text-[10px] font-bold text-slate-600 mb-1">
                              Current Revision *
                            </label>
                            <input
                              type="text"
                              value={
                                doc.actionType === "Introduction"
                                  ? "-"
                                  : doc.currentRevision || ""
                              }
                              onChange={(e) =>
                                handleUpdatePrepDoc(
                                  idx,
                                  "currentRevision",
                                  e.target.value.toUpperCase(),
                                )
                              }
                              placeholder="e.g., AA"
                              pattern="[A-Za-z]{2}"
                              maxLength={2}
                              disabled={doc.actionType === "Introduction"}
                              className="w-full bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded p-1.5 outline-none text-slate-800 disabled:opacity-50 font-mono font-bold disabled:bg-slate-200"
                              required
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] font-bold text-slate-600 mb-1">
                              Next Revision *
                            </label>
                            <input
                              type="text"
                              value={
                                doc.actionType === "Removal"
                                  ? "-"
                                  : doc.nextRevision || ""
                              }
                              onChange={(e) =>
                                handleUpdatePrepDoc(
                                  idx,
                                  "nextRevision",
                                  e.target.value.toUpperCase(),
                                )
                              }
                              placeholder="e.g., AB"
                              pattern="[A-Za-z]{2}"
                              maxLength={2}
                              disabled={doc.actionType === "Removal"}
                              className="w-full bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded p-1.5 outline-none text-slate-800 disabled:opacity-50 font-mono font-bold disabled:bg-slate-200"
                              required
                            />
                          </div>
                        </div>

                        {/* Document Title */}
                        <div>
                          <label className="block text-[10px] font-bold text-slate-600 mb-1">
                            Document Title *
                          </label>
                          <input
                            type="text"
                            value={doc.title || ""}
                            onChange={(e) =>
                              handleUpdatePrepDoc(
                                idx,
                                "title",
                                e.target.value,
                              )
                            }
                            placeholder="e.g., SOP for Calibrator Operation"
                            className="w-full bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded p-1.5 outline-none text-slate-800"
                            required
                          />
                        </div>

                        {/* Reason */}
                        <div>
                          <label className="block text-[10px] font-bold text-slate-600 mb-1 flex justify-between items-center">
                            <span>Reason *</span>
                            <span className="text-[9px] text-indigo-650 font-normal">Click chat box to expand</span>
                          </label>
                          <div className="relative flex items-center bg-slate-50 border border-slate-200 focus-within:border-indigo-500 rounded">
                            <input
                              type="text"
                              value={doc.reasonForChange || ""}
                              onChange={(e) =>
                                handleUpdatePrepDoc(
                                  idx,
                                  "reasonForChange",
                                  e.target.value,
                                )
                              }
                              placeholder="e.g., Calibrator limit updates from QA audit"
                              className="w-full bg-transparent p-1.5 pr-8 outline-none text-slate-800 text-xs"
                              required
                            />
                            <button
                              type="button"
                              onClick={() => openTextEditor('reason', idx, doc.reasonForChange || "", "Reason")}
                              title="Open rich text editor window"
                              className="absolute right-1.5 p-1 text-slate-400 hover:text-indigo-600 hover:bg-slate-100 rounded transition-all cursor-pointer flex items-center justify-center"
                            >
                              <MessageSquare className="w-3.5 h-3.5 animate-pulse" />
                            </button>
                          </div>
                        </div>

                        {/* Proposed Changes */}
                        <div>
                          <label className="block text-[10px] font-bold text-slate-600 mb-1 flex justify-between items-center">
                            <span>Proposed Change *</span>
                            <span className="text-[9px] text-indigo-650 font-normal">Click chat box to expand</span>
                          </label>
                          <div className="relative flex items-start bg-slate-50 border border-slate-200 focus-within:border-indigo-500 rounded">
                            <textarea
                              rows={2}
                              value={doc.changesRequired || ""}
                              onChange={(e) =>
                                handleUpdatePrepDoc(
                                  idx,
                                  "changesRequired",
                                  e.target.value,
                                )
                              }
                              placeholder="Identify precise edits or lines to exchange..."
                              className="w-full bg-transparent p-1.5 pr-8 outline-none text-slate-800 text-xs resize-none"
                              required
                            />
                            <button
                              type="button"
                              onClick={() => openTextEditor('changes', idx, doc.changesRequired || "", "Proposed Change")}
                              title="Open rich text editor window"
                              className="absolute right-1.5 top-1.5 p-1 text-slate-400 hover:text-indigo-600 hover:bg-slate-100 rounded transition-all cursor-pointer flex items-center justify-center"
                            >
                              <MessageSquare className="w-3.5 h-3.5 animate-pulse" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex justify-end gap-3.5 pt-4 border-t border-slate-100">
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg text-xs flex items-center gap-2 cursor-pointer transition-all shadow-md hover:scale-101"
                >
                  <Send className="w-4 h-4" />
                  <span>Submit to QA</span>
                </button>
              </div>
            </form>
          </div>
        )}

        {/* --------------------------------------------------------------------------
            TAB 3: INTER-DEPARTMENTAL REVIEWS & AUTOMATIC IMPACT TRACKING
            -------------------------------------------------------------------------- */}
        {false && (
          <div className="space-y-5">
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4.5 space-y-1">
              <h3 className="text-sm font-bold text-slate-900">
                Departmental Review Pool
              </h3>
              <p className="text-xs text-slate-550">
                Any member of{" "}
                {currentUser.department
                  ? `Department "${currentUser.department}"`
                  : "assigned department"}{" "}
                can open active tasks to assess localized impact.
              </p>
              <div className="text-[10px] font-mono text-indigo-700 bg-indigo-50 p-1.5 rounded mt-2 border border-indigo-100 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>
                  CROSS-COMMUNICATION RULE ACTIVE: Adding a new document to any
                  task automatically syncs to the master database.
                </span>
              </div>
            </div>

            {dcrnRequests.filter(
              (r) => r.status === "Pending_Impact_Assessment",
            ).length === 0 ? (
              <div className="bg-white p-12 rounded-xl border border-slate-200 text-center text-slate-400">
                <FileSpreadsheet className="w-12 h-12 mx-auto text-slate-300 opacity-60 mb-2" />
                <p className="text-sm font-semibold text-slate-700">
                  No Pending Impact Assessments
                </p>
                <p className="text-xs text-slate-500 mt-1">
                  There are currently no Change Requests awaiting
                  inter-departmental evaluations.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {dcrnRequests
                  .filter((r) => r.status === "Pending_Impact_Assessment")
                  .map((req) => {
                    const masterDocs = getMasterDocs(req);
                    // Check if this user's department has already signed off on this request
                    const currentDeptSignoff =
                      req.assessments && req.assessments[userDeptCode];
                    const hasUserDeptSignedOff =
                      currentDeptSignoff &&
                      currentDeptSignoff.impacted !== null;

                    return (
                      <div
                        key={req.id}
                        className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden"
                        id={`dept-req-${req.id}`}
                      >
                        {/* Card Header info */}
                        <div className="bg-emerald-50/60 p-4 border-b border-emerald-100 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                          <div>
                            <div className="flex items-center gap-1.5">
                              <span className="px-2 py-0.5 bg-emerald-100 border border-emerald-200 text-emerald-700 text-[9px] font-mono font-bold rounded">
                                STATUS: PENDING IMPACT ASSESSMENT
                              </span>
                              {hasUserDeptSignedOff ? (
                                <span className="px-2 py-0.5 bg-slate-100 border text-slate-600 text-[9px] font-mono font-bold rounded">
                                  YOUR DEPT SIGNED CLOSE
                                </span>
                              ) : null}
                            </div>
                            <p className="text-[10px] text-slate-500">
                              QA EVALUATOR:{" "}
                              {req.qaEvaluatedBy?.userName || "N/A"} | QA
                              REMARKS: "{req.qaEvaluationRemarks}"
                            </p>
                          </div>

                          {/* Signoff Tracker grid */}
                          <div className="bg-white p-2 rounded border border-slate-200 text-[10.5px]">
                            <strong className="block text-[9.5px] font-mono text-slate-400 font-bold mb-1 uppercase text-center border-b pb-0.5">
                              Tracking Signoffs:
                            </strong>
                            <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-1 font-mono text-center">
                              {Object.keys(req.assessments || {})
                                .filter((code) => code !== "PK")
                                .map((code) => {
                                  const ass = req.assessments[code];
                                  const signed = ass && ass.impacted !== null;
                                  const hasAddedImpactedDoc =
                                    req.initialDocs.some(
                                      (doc) => doc.addedByDept === code,
                                    );
                                  const isImpact =
                                    ass?.impacted === "Yes" ||
                                    (signed && hasAddedImpactedDoc);
                                  return (
                                    <div
                                      key={code}
                                      className={`px-1 py-0.5 rounded text-[9px] border ${
                                        isImpact
                                          ? "bg-amber-100 text-amber-800 border-amber-200 font-bold"
                                          : signed
                                            ? "bg-emerald-100 text-emerald-800 border-emerald-200"
                                            : "bg-slate-50 text-slate-400 border-slate-200"
                                      }`}
                                    >
                                      {code}:{" "}
                                      {isImpact
                                        ? "IMPACT"
                                        : signed
                                          ? "NO IMPACT"
                                          : "PEND"}
                                    </div>
                                  );
                                })}
                            </div>
                          </div>
                        </div>

                        {/* Card Body */}
                        <div className="p-4 space-y-4">
                          {/* Dynamic compiled master packet view with separate tables */}
                          <div className="bg-[#fcfcff] border border-slate-150 rounded-xl p-3.5 space-y-4">
                            <div className="flex flex-wrap items-center justify-between gap-2 border-b pb-1.5 border-slate-100">
                              <h5 className="text-[10px] font-mono font-bold uppercase text-slate-500 tracking-wider">
                                Accumulated Master Document Packet
                              </h5>
                              {(() => {
                                const masterDocs = getMasterDocs(req);
                                const allApproved = masterDocs.length > 0 && masterDocs.every(d => d.actionType === "Removal" || d.workflowStatus === "ApprovalAccepted");
                                return allApproved ? (
                                  <div className="flex items-center gap-2">
                                    <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[9px] font-mono font-bold rounded-sm border border-emerald-250 uppercase shadow-3xs animate-pulse">
                                      ✓ All Documents Accepted
                                    </span>
                                    {req.status === "Pending_QA_Evaluation" || req.status === "Pending_QA_Stage2" ? (
                                      <button
                                        disabled
                                        className="px-2.5 py-1 bg-slate-150 text-slate-450 border border-slate-200 font-bold rounded text-[10px] cursor-not-allowed flex items-center gap-1 shadow-sm"
                                        id={`btn-submit-to-qa-final-${req.id}`}
                                      >
                                        <Check className="w-3" />
                                        <span>Submitted to QA</span>
                                      </button>
                                    ) : req.status === "Pending_MR_Closure" ? (
                                      <button
                                        disabled
                                        className="px-2.5 py-1 bg-amber-50 text-amber-650 border border-amber-200 font-bold rounded text-[10px] cursor-not-allowed flex items-center gap-1 shadow-sm"
                                        id={`btn-submit-to-qa-final-${req.id}`}
                                      >
                                        <Clock className="w-3 h-3 text-amber-500" />
                                        <span>Awaiting MR Closure</span>
                                      </button>
                                    ) : req.status === "Completed" ? (
                                      <button
                                        disabled
                                        className="px-2.5 py-1 bg-emerald-50 text-emerald-650 border border-emerald-200 font-bold rounded text-[10px] cursor-not-allowed flex items-center gap-1 shadow-sm"
                                        id={`btn-submit-to-qa-final-${req.id}`}
                                      >
                                        <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                                        <span>Accepted & Archived</span>
                                      </button>
                                    ) : (
                                      <button

                                       disabled={req.preparedBy?.userId !== currentUser.id && req.preparedBy?.email !== currentUser.email}
                                       onClick={() => onSubmitToQa?.(req.id)}
                                        className={`px-2.5 py-1 font-bold rounded text-[10px] flex items-center gap-1 shadow-sm transition-all ${req.preparedBy?.userId === currentUser.id || req.preparedBy?.email === currentUser.email ? "bg-indigo-600 hover:bg-indigo-750 text-white cursor-pointer active:scale-98" : "bg-slate-100 text-slate-400 border border-slate-200 cursor-not-allowed"}`}
                                        id={`btn-submit-to-qa-final-${req.id}`}
                                      >
                                        <Send className="w-3 h-3 text-indigo-200" />
                                        <span>Submit to QA</span>
                                      </button>
                                    )}
                                  </div>
                                ) : req.status === "Pending_Impact_Assessment" ? (
                                  <div className="flex flex-col items-end gap-1">
                                    <span className="inline-flex items-center gap-1 px-1.5 py-0.5 bg-amber-50 text-amber-800 text-[8.5px] font-mono font-bold rounded border border-amber-200 uppercase">
                                      Awaiting Document Approvals
                                    </span>
                                    <span className="text-[8.5px] text-slate-450 italic mt-0.5 font-semibold text-right">
                                      Submit to QA happens as a whole packet once all Introduction/Change approvals are complete.
                                    </span>
                                  </div>
                                ) : null;
                              })()}
                            </div>

                            {(() => {
                              const {
                                previouslyAnalyzed,
                                newlyAdded,
                                hasPrevious,
                              } = getDifferentiatedDocs(req, userDeptCode);

                              return (
                                <div className="space-y-4">
                                  {/* Table 1: Previously Analyzed / Baseline */}
                                  <div className="border border-slate-205 rounded-lg overflow-hidden bg-slate-50/50">
                                    <div className="bg-slate-100 flex justify-between items-center px-3 py-1.5 border-b border-slate-200 text-[10px] font-mono font-bold text-slate-650 uppercase tracking-wider">
                                      <span>
                                        {hasPrevious
                                          ? "1. Previously Analyzed Documents"
                                          : "1. Baseline Original Documents"}
                                      </span>
                                      <span className="bg-slate-200/80 text-slate-700 px-1.5 py-0.2 rounded font-sans text-[9px]">
                                        {previouslyAnalyzed.length} files
                                      </span>
                                    </div>
                                    {previouslyAnalyzed.length === 0 ? (
                                      <p className="p-3 text-[11px] italic text-slate-400 text-center">
                                        No baseline documents under assessment.
                                      </p>
                                    ) : (
                                      <div className="divide-y divide-slate-100 max-h-40 overflow-y-auto bg-white p-2 text-xs space-y-2">
                                        {previouslyAnalyzed.map((doc, idx) => (
                                          <div
                                            key={idx}
                                            className="p-2 border border-slate-100 bg-slate-50/50 rounded-lg"
                                          >
                                            <div className="flex flex-wrap items-center justify-between gap-2 border-b pb-1.5 mb-1.5 border-slate-100">
                                              <span className="font-bold font-mono text-slate-805">
                                                📄 {doc.docNumber} (Rev:{" "}
                                                {doc.currentRevision || "-"}){" "}
                                                {doc.title && (
                                                  <span className="text-[10px] text-indigo-755 font-bold bg-indigo-50 border border-indigo-150 rounded px-1.5 py-0.2 mx-1 inline-block font-sans">
                                                    Title: {doc.title}
                                                  </span>
                                                )}
                                                <span className="text-[9px] font-sans font-normal text-slate-500">
                                                  [{doc.actionType || "Change"}]
                                                </span>
                                              </span>
                                              {renderDocWorkflowStatusBadge(doc)}
                                            </div>
                                            <div className="text-[10px] text-slate-500 font-mono mt-1 space-y-0.5">
                                              {/* Removed */}
                                              <p>
                                                Revision:{" "}
                                                <span className="font-bold text-slate-700">
                                                  {doc.currentRevision} →{" "}
                                                  {doc.nextRevision}
                                                </span>
                                              </p>
                                            </div>
                                            <div className="grid grid-cols-2 gap-2 mt-1 text-[11px] text-slate-600">
                                              <div>
                                                <strong className="text-slate-400 font-medium text-[9.5px] block uppercase font-mono">
                                                  "Reason":
                                                </strong>{" "}
                                                {doc.reasonForChange}
                                              </div>
                                              <div>
                                                <strong className="text-slate-400 font-medium text-[9.5px] block uppercase font-mono">
                                                  Proposed Change:
                                                </strong>{" "}
                                                {doc.changesRequired}
                                              </div>
                                            </div>
                                          </div>
                                        ))}
                                      </div>
                                    )}
                                  </div>

                                  {/* Table 2: Newly Added */}
                                  {newlyAdded.length > 0 && (
                                    <div className="border border-amber-250 rounded-lg overflow-hidden bg-amber-50">
                                      <div className="bg-amber-100 flex justify-between items-center px-3 py-1.5 border-b border-amber-200 text-[10px] font-mono font-bold text-amber-900 uppercase tracking-wider">
                                        <span className="flex items-center gap-1">
                                          <AlertTriangle className="w-3.5 h-3.5 text-amber-700 animate-pulse shrink-0" />
                                          <span>
                                            2. Newly Added Impacted Documents
                                          </span>
                                        </span>
                                        <span className="bg-amber-200 text-amber-805 px-1.5 py-0.2 rounded font-sans text-[9px] font-bold">
                                          New: {newlyAdded.length} files
                                        </span>
                                      </div>
                                      <div className="divide-y divide-amber-100 max-h-40 overflow-y-auto bg-white p-2 text-xs space-y-2">
                                        {newlyAdded.map((doc, idx) => (
                                          <div
                                            key={idx}
                                            className="p-2 border border-amber-100 bg-amber-50/30 rounded-lg"
                                          >
                                            <div className="flex flex-wrap items-center justify-between gap-2 border-b pb-1.5 mb-1.5 border-slate-100">
                                              <span className="font-bold font-mono text-indigo-900">
                                                📄 {doc.docNumber} (Rev:{" "}
                                                {doc.currentRevision || "-"}){" "}
                                                {doc.title && (
                                                  <span className="text-[10px] text-indigo-755 font-bold bg-indigo-50 border border-indigo-150 rounded px-1.5 py-0.2 mx-1 inline-block font-sans">
                                                    Title: {doc.title}
                                                  </span>
                                                )}
                                                <span className="text-[9px] font-sans font-normal text-slate-500">
                                                  [{doc.actionType || "Change"}]
                                                </span>
                                              </span>
                                              <div className="flex items-center gap-2">
                                                {renderDocWorkflowStatusBadge(doc)}
                                                <span className="bg-indigo-50 border border-indigo-100 text-indigo-700 px-1.5 py-0.5 rounded text-[8.5px] font-mono uppercase font-bold">
                                                  Added by:{" "}
                                                  {DEPARTMENT_MAP[
                                                    doc.addedByDept || ""
                                                  ] ||
                                                    doc.addedByDept ||
                                                    "Unknown"}
                                                </span>
                                              </div>
                                            </div>
                                            <div className="grid grid-cols-2 gap-2 mt-1 text-[11px] text-slate-600">
                                              <div>
                                                <strong className="text-slate-400 font-medium text-[9.5px] block uppercase font-mono">
                                                  "Reason":
                                                </strong>{" "}
                                                {doc.reasonForChange}
                                              </div>
                                              <div>
                                                <strong className="text-slate-400 font-medium text-[9.5px] block uppercase font-mono">
                                                  Proposed Change:
                                                </strong>{" "}
                                                {doc.changesRequired}
                                              </div>
                                            </div>
                                          </div>
                                        ))}
                                      </div>
                                    </div>
                                  )}
                                </div>
                              );
                            })()}

                            {/* Impacted section */}
                            {req.assessments &&
                              Object.entries(req.assessments).some(
                                ([code, ass]) =>
                                  code !== "PK" &&
                                  code !== (req.preparedBy?.department || "") &&
                                  (ass.impacted === "Yes" ||
                                    req.initialDocs.some(
                                      (d) => d.addedByDept === code,
                                    )),
                              ) && (
                                <div className="space-y-3 pt-2 border-t border-slate-200">
                                  <h6 className="text-[9px] font-mono text-amber-800 uppercase font-bold">
                                    Impacted Departments
                                  </h6>
                                  {Object.entries(req.assessments).map(
                                    ([code, ass]) => {
                                      if (
                                        code === "PK" ||
                                        code ===
                                          (req.preparedBy?.department || "")
                                      )
                                        return null;
                                      const deptDocs = req.initialDocs.filter(
                                        (d) => d.addedByDept === code,
                                      );
                                      const isDeptImpacted =
                                        ass.impacted === "Yes" ||
                                        deptDocs.length > 0;
                                      const docsToRender =
                                        deptDocs.length > 0
                                          ? deptDocs
                                          : ass.documents || [];

                                      if (isDeptImpacted) {
                                        return (
                                          <div key={code} className="space-y-1">
                                            <p className="text-[9px] font-medium text-slate-500 bg-slate-100 p-0.5 rounded px-1.5">
                                              {DEPARTMENT_MAP[code] || code}
                                            </p>
                                            <div className="divide-y divide-slate-100 pl-2">
                                              {docsToRender.length > 0 ? (
                                                docsToRender.map(
                                                  (doc, docIdx) => (
                                                    <div
                                                      key={docIdx}
                                                      className="py-2 first:pt-0 last:pb-0 flex flex-col md:flex-row md:justify-between gap-1 text-xs"
                                                    >
                                                      <span className="font-bold font-mono text-amber-800 md:w-1/4 select-all">
                                                        📄 {doc.docNumber} (Rev:{" "}
                                                        {doc.currentRevision ||
                                                          "-"}{" "}
                                                        →{" "}
                                                        {doc.nextRevision ||
                                                          "-"}
                                                        ){" "}
                                                        {doc.title && (
                                                          <span className="text-[10px] text-amber-900 font-bold bg-amber-100 border border-amber-200 rounded px-1.5 py-0.2 mx-1 inline-block font-sans">
                                                            Title: {doc.title}
                                                          </span>
                                                        )}
                                                        <span className="text-[9px] font-sans font-normal text-slate-500">
                                                          [
                                                          {doc.actionType ||
                                                            "Change"}
                                                          ]
                                                        </span>
                                                      </span>
                                                      <span className="text-slate-650 md:w-3/8">
                                                        <strong className="text-slate-400 font-normal">
                                                          Reason:
                                                        </strong>{" "}
                                                        {doc.reasonForChange}
                                                      </span>
                                                      <span className="text-slate-650 md:w-3/8">
                                                        <strong className="text-slate-400 font-normal">
                                                          Proposed Change:
                                                        </strong>{" "}
                                                        {doc.changesRequired}
                                                      </span>
                                                    </div>
                                                  ),
                                                )
                                              ) : (
                                                <p className="text-amber-800 font-medium italic text-[10px] py-1">
                                                  Impact recognized (No
                                                  localized document
                                                  modifications submitted)
                                                </p>
                                              )}
                                            </div>
                                          </div>
                                        );
                                      }
                                      return null;
                                    },
                                  )}
                                </div>
                              )}
                          </div>

                          {/* Interactive sign off form if current user department has not signed off */}
                          {!(
                            req.assessments && userDeptCode in req.assessments
                          ) ? (
                            <div className="bg-yellow-50 border border-yellow-200 p-3.5 rounded text-xs text-yellow-805 flex items-center gap-2">
                              <HelpCircle className="w-5 h-5 text-yellow-600 shrink-0" />
                              <span>
                                Your department{" "}
                                <strong>
                                  {currentUser.department || "None"}
                                </strong>{" "}
                                is not listed as active tracking controller for
                                this specific DCRN request. Under safety
                                compliance rules, you cannot submit evaluations
                                for this DCRN.
                              </span>
                            </div>
                          ) : hasUserDeptSignedOff ? (
                            <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-lg text-xs space-y-1 text-slate-600">
                              <div className="flex items-center gap-1.5 font-bold text-emerald-805 text-xs">
                                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                                <span>
                                  Department Sign-Off Confirmed for: "
                                  {userDeptCode}"
                                </span>
                              </div>
                              <p className="text-[11px] text-slate-500 mt-1 ml-5">
                                Assessed By:{" "}
                                {currentDeptSignoff.assessedBy?.userName} at{" "}
                                {formatTimeToIST(
                                  currentDeptSignoff.assessedAt || "",
                                )}{" "}
                                IST. Localized Impact stated: "
                                {currentDeptSignoff.impacted}".
                              </p>
                            </div>
                          ) : (
                            <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl space-y-4">
                              <h5 className="text-xs font-bold text-slate-800 border-b pb-1.5 flex items-center gap-1.5 uppercase font-mono text-slate-600">
                                <Building2 className="w-4.5 h-4.5 text-emerald-600" />
                                Evaluate Localized Alterations for Department:{" "}
                                {userDeptCode}
                              </h5>

                              {/* Impact selector */}
                              <div className="space-y-2">
                                <p className="text-[11px] font-bold text-slate-700">
                                  Does this change impact your department? *
                                </p>
                                <div className="flex gap-4">
                                  <label className="inline-flex items-center gap-1.5 text-xs font-sans text-slate-700 cursor-pointer">
                                    <input
                                      type="radio"
                                      name={`impact-choice-${req.id}`}
                                      checked={selectedImpact[req.id] === "No"}
                                      onChange={() =>
                                        handleDeptChoice(req.id, "No")
                                      }
                                      className="accent-emerald-600 cursor-pointer w-4 h-4"
                                    />
                                    <span>
                                      <strong>No</strong> - No impact
                                    </span>
                                  </label>

                                  <label className="inline-flex items-center gap-1.5 text-xs font-sans text-slate-700 cursor-pointer">
                                    <input
                                      type="radio"
                                      name={`impact-choice-${req.id}`}
                                      checked={selectedImpact[req.id] === "Yes"}
                                      onChange={() =>
                                        handleDeptChoice(req.id, "Yes")
                                      }
                                      className="accent-indigo-600 cursor-pointer w-4 h-4"
                                    />
                                    <span>
                                      <strong>Yes</strong> - Impacted (Requires
                                      3-box entries)
                                    </span>
                                  </label>
                                </div>
                              </div>

                              {/* If Impact is YES, show identical 3-box form cards and '+ Add Document' */}
                              {selectedImpact[req.id] === "Yes" && (
                                <div className="space-y-4 border-t border-slate-200 pt-3">
                                  <div className="flex justify-between items-center bg-white p-2 rounded border">
                                    <span className="text-[10px] font-mono font-bold text-slate-500 uppercase">
                                      Capture Impacted Records for:{" "}
                                      {userDeptCode}
                                    </span>
                                    <button
                                      type="button"
                                      onClick={() => handleAddDeptDoc(req.id)}
                                      className="px-2 py-0.5 bg-indigo-50 hover:bg-indigo-150 text-indigo-700 border text-[10.5px] rounded font-bold cursor-pointer transition-all flex items-center gap-1"
                                    >
                                      <Plus className="w-3.5 h-3.5" />
                                      <span>+ Add Document</span>
                                    </button>
                                  </div>

                                  <div className="grid gap-3 sm:grid-cols-2">
                                    {(departmentDocs[req.id] || []).map(
                                      (dDoc, idx) => (
                                        <div
                                          key={idx}
                                          className="bg-white border p-3 rounded-lg space-y-2 relative shadow-xs"
                                        >
                                          <div className="flex justify-between items-center text-[10.5px] font-bold border-b pb-1 text-slate-650">
                                            <span>
                                              Alteration Record #{idx + 1}
                                            </span>
                                            {(departmentDocs[req.id] || [])
                                              .length > 1 && (
                                              <button
                                                type="button"
                                                onClick={() =>
                                                  handleRemoveDeptDoc(
                                                    req.id,
                                                    idx,
                                                  )
                                                }
                                                className="text-rose-500 hover:text-rose-700 cursor-pointer"
                                                title="Delete Entry"
                                              >
                                                <Trash2 className="w-3 h-3" />
                                              </button>
                                            )}
                                          </div>

                                          <div className="space-y-2 text-xs">
                                            <div>
                                              <label className="block text-[9px] font-bold text-slate-500">
                                                Action Type *
                                              </label>
                                              <select
                                                value={
                                                  dDoc.actionType || "Change"
                                                }
                                                onChange={(e) => {
                                                  const newAction = e.target
                                                    .value as
                                                    | "Change"
                                                    | "Introduction"
                                                    | "Removal";
                                                  handleUpdateDeptDoc(
                                                    req.id,
                                                    idx,
                                                    "actionType",
                                                    newAction,
                                                  );
                                                  if (
                                                    newAction === "Introduction"
                                                  ) {
                                                    handleUpdateDeptDoc(
                                                      req.id,
                                                      idx,
                                                      "currentRevision",
                                                      "-",
                                                    );
                                                  } else if (
                                                    dDoc.currentRevision === "-"
                                                  ) {
                                                    handleUpdateDeptDoc(
                                                      req.id,
                                                      idx,
                                                      "currentRevision",
                                                      "",
                                                    );
                                                  }
                                                  if (newAction === "Removal") {
                                                    handleUpdateDeptDoc(
                                                      req.id,
                                                      idx,
                                                      "nextRevision",
                                                      "-",
                                                    );
                                                  } else if (
                                                    dDoc.nextRevision === "-"
                                                  ) {
                                                    handleUpdateDeptDoc(
                                                      req.id,
                                                      idx,
                                                      "nextRevision",
                                                      "",
                                                    );
                                                  }
                                                }}
                                                className="w-full bg-slate-50 border rounded p-1 outline-none text-[11px]"
                                                required
                                              >
                                                <option value="Change">
                                                  Change
                                                </option>
                                                <option value="Introduction">
                                                  Introduction
                                                </option>
                                                <option value="Removal">
                                                  Removal
                                                </option>
                                              </select>
                                            </div>
                                            <div>
                                              <label className="block text-[9px] font-bold text-slate-500">
                                                Document Number *
                                              </label>
                                              <input
                                                type="text"
                                                value={dDoc.docNumber}
                                                onChange={(e) =>
                                                  handleUpdateDeptDoc(
                                                    req.id,
                                                    idx,
                                                    "docNumber",
                                                    e.target.value,
                                                  )
                                                }
                                                placeholder="e.g., WI-PD-101"
                                                className="w-full bg-slate-50 border rounded p-1 outline-none text-[11px]"
                                                required
                                              />
                                            </div>

                                            <div>
                                              <label className="block text-[9px] font-bold text-slate-500">
                                                Current Rev *
                                              </label>
                                              <input
                                                type="text"
                                                value={
                                                  dDoc.actionType ===
                                                  "Introduction"
                                                    ? "-"
                                                    : dDoc.currentRevision || ""
                                                }
                                                disabled={
                                                  dDoc.actionType ===
                                                  "Introduction"
                                                }
                                                onChange={(e) =>
                                                  handleUpdateDeptDoc(
                                                    req.id,
                                                    idx,
                                                    "currentRevision",
                                                    e.target.value.toUpperCase(),
                                                  )
                                                }
                                                placeholder="e.g., AA"
                                                pattern="[A-Za-z]{2}"
                                                title="Must be exactly 2 letters"
                                                maxLength={2}
                                                className="w-full bg-slate-50 border rounded p-1 outline-none text-[11px] font-mono font-bold disabled:bg-slate-200"
                                                required
                                              />
                                            </div>

                                            <div>
                                              <label className="block text-[9px] font-bold text-slate-500">
                                                Next Rev *
                                              </label>
                                              <input
                                                type="text"
                                                value={
                                                  dDoc.actionType === "Removal"
                                                    ? "-"
                                                    : dDoc.nextRevision || ""
                                                }
                                                disabled={
                                                  dDoc.actionType === "Removal"
                                                }
                                                onChange={(e) =>
                                                  handleUpdateDeptDoc(
                                                    req.id,
                                                    idx,
                                                    "nextRevision",
                                                    e.target.value.toUpperCase(),
                                                  )
                                                }
                                                placeholder="e.g., AB"
                                                pattern="[A-Za-z]{2}"
                                                title="Must be exactly 2 letters"
                                                maxLength={2}
                                                className="w-full bg-slate-50 border rounded p-1 outline-none text-[11px] font-mono font-bold disabled:bg-slate-200"
                                                required
                                              />
                                            </div>

                                            <div>
                                              <label className="block text-[9px] font-bold text-slate-500">
                                                Document Title *
                                              </label>
                                              <input
                                                type="text"
                                                value={dDoc.title || ""}
                                                onChange={(e) =>
                                                  handleUpdateDeptDoc(
                                                    req.id,
                                                    idx,
                                                    "title",
                                                    e.target.value,
                                                  )
                                                }
                                                placeholder="e.g., Localized Production WI Title"
                                                className="w-full bg-slate-50 border rounded p-1 outline-none text-[11px]"
                                                required
                                              />
                                            </div>

                                            <div>
                                              <label className="block text-[9px] font-bold text-slate-500">
                                                Reason *
                                              </label>
                                              <input
                                                type="text"
                                                value={dDoc.reasonForChange}
                                                onChange={(e) =>
                                                  handleUpdateDeptDoc(
                                                    req.id,
                                                    idx,
                                                    "reasonForChange",
                                                    e.target.value,
                                                  )
                                                }
                                                placeholder="Indicate department specific impactReason"
                                                className="w-full bg-slate-50 border rounded p-1 outline-none text-[11px]"
                                                required
                                              />
                                            </div>

                                            <div>
                                              <label className="block text-[9px] font-bold text-slate-500">
                                                Proposed Change *
                                              </label>
                                              <textarea
                                                rows={2}
                                                value={dDoc.changesRequired}
                                                onChange={(e) =>
                                                  handleUpdateDeptDoc(
                                                    req.id,
                                                    idx,
                                                    "changesRequired",
                                                    e.target.value,
                                                  )
                                                }
                                                placeholder="Define technical localized procedures changes..."
                                                className="w-full bg-slate-50 border rounded p-1 outline-none text-[11px]"
                                                required
                                              />
                                            </div>
                                          </div>
                                        </div>
                                      ),
                                    )}
                                  </div>
                                </div>
                              )}

                              {/* Submit Department Signoff */}
                              <div className="flex justify-end pt-2 border-t border-slate-150">
                                <button
                                  onClick={() =>
                                    handleDeptSubmit(req.id, userDeptCode)
                                  }
                                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded text-xs cursor-pointer flex items-center gap-1 shadow-md transition-all"
                                  id={`btn-submit-dept-${req.id}`}
                                >
                                  <Send className="w-3.5 h-3.5" />
                                  <span>Sign & Log Department Signoff</span>
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
              </div>
            )}
          </div>
        )}

        {/* MR Dashboard is now transferred to the main workspace control center */}
        {(() => {
          // Deactivated legacy MR command center view
          return null;
        })()}

        {false && (
          <div>
            {/* Sub Tabs Selection */}
            <div className="flex border-b border-indigo-100 pb-px">
              <button
                type="button"
                onClick={() => setMrSubTab("authorization")}
                className={`px-4 py-2.5 text-xs font-bold border-b-2 transition-all cursor-pointer flex items-center gap-1.5 ${
                  mrSubTab === "authorization"
                    ? "border-indigo-900 text-indigo-900 font-extrabold"
                    : "border-transparent text-slate-500 hover:text-slate-800"
                }`}
              >
                <Layers className="w-3.5 h-3.5 text-indigo-900" />
                <span>
                  Acceptance Queue (
                  {
                    dcrnRequests.filter(
                      (r) =>
                        r.status === "Pending_Impact_Assessment" &&
                        isAssessmentFinished(r),
                    ).length
                  }
                  )
                </span>
              </button>
              <button
                type="button"
                onClick={() => setMrSubTab("ledger")}
                className={`px-4 py-2.5 text-xs font-bold border-b-2 transition-all cursor-pointer flex items-center gap-1.5 ${
                  mrSubTab === "ledger"
                    ? "border-indigo-900 text-indigo-900 font-extrabold"
                    : "border-transparent text-slate-500 hover:text-slate-800"
                }`}
                id="mr-ledger-dashboard-tab-btn"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-indigo-900" />
                <span>
                  Complete DCRN Ledger Dashboard ({dcrnRequests.length})
                </span>
              </button>
            </div>

            {mrSubTab === "authorization" ? (
              dcrnRequests.filter(
                (r) =>
                  r.status === "Pending_Impact_Assessment" &&
                  isAssessmentFinished(r),
              ).length === 0 ? (
                <div className="bg-white p-12 rounded-xl border border-slate-200 text-center text-slate-400">
                  <Check className="w-12 h-12 mx-auto text-slate-350 opacity-60 mb-2 pointer-events-none" />
                  <p className="text-sm font-semibold text-slate-700">
                    No Escalated Master Packets Available
                  </p>
                  <p className="text-xs text-slate-500 mt-1">
                    DCRNs only escalate here once all required tracking
                    departments submit impact assessments.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {dcrnRequests
                    .filter(
                      (r) =>
                        r.status === "Pending_Impact_Assessment" &&
                        isAssessmentFinished(r),
                    )
                    .map((req) => {
                      const masterDocs = getMasterDocs(req);

                      return (
                        <div
                          key={req.id}
                          className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden"
                          id={`mr-auth-req-${req.id}`}
                        >
                          {/* Sub header */}
                          <div className="bg-indigo-950 text-white p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                            <div>
                              <span className="p-0.5 px-2 bg-indigo-900 border border-indigo-750 rounded text-[9px] font-mono font-bold tracking-wider">
                                MR ACCEPTANCE: REQUISITE COMPLETED
                              </span>
                              <p className="text-[10px] text-slate-300">
                                Preparer: {req.preparedBy?.userName} | Date
                                Requested: {req.createdAt.substring(0, 10)} | QA
                                Gateway Remark: "{req.qaEvaluationRemarks}"
                              </p>
                            </div>
                            <span className="text-[10px] bg-indigo-900/60 p-1 px-2.5 rounded font-mono font-bold">
                              All 4 Signoffs Certified
                            </span>
                          </div>

                          {/* Content Aggregation */}
                          <div className="p-4 space-y-4 text-xs">
                            {/* 1. Preparer block */}
                            <div>
                              <h5 className="text-[10px] font-mono font-bold uppercase text-slate-400 mb-1">
                                1. Preparer's Initial Document Records
                              </h5>
                              <div className="bg-slate-50 border p-3 rounded-lg text-slate-705 divide-y divide-slate-200/60">
                                {req.initialDocs
                                  .filter(
                                    (doc) =>
                                      !doc.addedByDept ||
                                      doc.addedByDept ===
                                        (req.preparedBy?.department || ""),
                                  )
                                  .map((doc, idx) => (
                                    <div
                                      key={idx}
                                      className="py-2 first:pt-0 last:pb-0 font-sans"
                                    >
                                      <p className="font-bold text-indigo-900">
                                        📄 {doc.docNumber}
                                      </p>
                                      <p className="mt-1">
                                        <strong className="text-slate-400 font-normal">
                                          "Reason:"
                                        </strong>{" "}
                                        {doc.reasonForChange}
                                      </p>
                                      <p>
                                        <strong className="text-slate-400 font-normal">
                                          Proposed Change:
                                        </strong>{" "}
                                        {doc.changesRequired}
                                      </p>
                                    </div>
                                  ))}
                              </div>
                            </div>

                            {/* 3. Organized List of all Impacted Departments alongside their respective 3-box entries */}
                            <div>
                              <h5 className="text-[10px] font-mono font-bold uppercase text-slate-400 mb-1">
                                3. Inter-Departmental Impact Review History
                                Matrix
                              </h5>
                              <div className="space-y-2.5">
                                {Object.keys(req.assessments || {})
                                  .filter((code) => code !== "PK")
                                  .map((code) => {
                                    if (
                                      code ===
                                      (req.preparedBy?.department || "")
                                    )
                                      return null;
                                    const ass = req.assessments[code];
                                    if (!ass) return null;
                                    const deptName =
                                      DEPARTMENT_MAP[code] || code;
                                    const signed = ass && ass.impacted !== null;
                                    const hasAddedImpactedDoc =
                                      req.initialDocs.some(
                                        (doc) => doc.addedByDept === code,
                                      );
                                    const isImpact =
                                      ass.impacted === "Yes" ||
                                      (signed && hasAddedImpactedDoc);

                                    return (
                                      <div
                                        key={code}
                                        className="bg-white border rounded-lg overflow-hidden border-slate-200 shadow-2xs"
                                      >
                                        <div className="bg-slate-100/80 p-2 border-b flex justify-between items-center text-[10.5px]">
                                          <span className="font-bold font-mono text-slate-700">
                                            🏢 {deptName} ({code})
                                          </span>
                                          <span
                                            className={`px-2 py-0.2 rounded text-[9.5px] font-mono font-bold ${
                                              isImpact
                                                ? "bg-amber-100 text-amber-800"
                                                : "bg-emerald-100 text-emerald-800"
                                            }`}
                                          >
                                            IMPACTED: {isImpact ? "YES" : "NO"}
                                          </span>
                                        </div>

                                        <div className="p-2.5 text-[11px] text-slate-600">
                                          <div className="flex justify-between text-[10px] text-slate-400 font-mono italic mb-1.5 border-b pb-0.5">
                                            <span>
                                              Accepted Evaluator:{" "}
                                              {ass.assessedBy?.userName ||
                                                "N/A"}
                                            </span>
                                            <span>
                                              Timestamp:{" "}
                                              {formatToIST(
                                                ass.assessedAt || "",
                                              )}{" "}
                                              IST
                                            </span>
                                          </div>

                                          {!isImpact ? (
                                            <p className="text-emerald-700 italic font-medium">
                                              ✓ Checked clearance provided.
                                              Confirmed NO departments
                                              procedural records impacted.
                                            </p>
                                          ) : (
                                            <div className="space-y-2 divide-y divide-slate-100">
                                              {(() => {
                                                const deptDocs =
                                                  req.initialDocs.filter(
                                                    (d) =>
                                                      d.addedByDept === code,
                                                  );
                                                const docsToRender =
                                                  deptDocs.length > 0
                                                    ? deptDocs
                                                    : ass.documents;

                                                if (docsToRender.length === 0) {
                                                  return (
                                                    <p className="text-amber-800 font-medium">
                                                      Labeled Impacted via
                                                      previous dynamic changes.
                                                    </p>
                                                  );
                                                }

                                                return docsToRender.map(
                                                  (dDoc, dIdx) => (
                                                    <div
                                                      key={dIdx}
                                                      className="pt-2 first:pt-0 font-sans"
                                                    >
                                                      <p className="font-bold text-indigo-900">
                                                        {dDoc.docNumber}
                                                      </p>
                                                      <p className="mt-0.5">
                                                        <strong className="text-slate-400 font-normal">
                                                          "Reason:"
                                                        </strong>{" "}
                                                        {dDoc.reasonForChange}
                                                      </p>
                                                      <p>
                                                        <strong className="text-slate-400 font-normal">
                                                          Proposed Change:
                                                        </strong>{" "}
                                                        {dDoc.changesRequired}
                                                      </p>
                                                    </div>
                                                  ),
                                                );
                                              })()}
                                            </div>
                                          )}
                                        </div>
                                      </div>
                                    );
                                  })}
                              </div>
                            </div>

                            {/* 4. AUTHORITATIVE SUBMISSION ACTION BOX */}
                            <div className="bg-gradient-to-br from-indigo-50/50 to-indigo-100/50 p-4 rounded-xl border-2 border-indigo-200/80 space-y-3 shadow-xs">
                              <h5 className="text-[11px] font-mono font-bold text-indigo-900 uppercase tracking-widest">
                                Acceptative MR Registry Lock
                              </h5>

                              <div className="grid sm:grid-cols-2 gap-4">
                                <div>
                                  <label className="block text-xs font-bold text-slate-800 mb-1">
                                    Assign Official DCRN Registry Number *
                                  </label>
                                  <input
                                    type="text"
                                    value={assignedRegistryNum[req.id] || ""}
                                    onChange={(e) =>
                                      setAssignedRegistryNum((prev) => ({
                                        ...prev,
                                        [req.id]: e.target.value,
                                      }))
                                    }
                                    placeholder="e.g., PMC-DCR-2026-0881"
                                    className="w-full bg-white border border-slate-350 focus:border-indigo-600 rounded p-2 text-xs font-mono font-bold outline-none text-slate-800 shadow-sm"
                                    id={`assign-registry-input-${req.id}`}
                                  />
                                </div>

                                <div className="flex items-end">
                                  <button
                                    onClick={() => handleAuthDCRN(req.id)}
                                    className="w-full py-2.5 bg-indigo-900 hover:bg-slate-900 text-white font-bold rounded text-xs cursor-pointer flex items-center justify-center gap-2 shadow-md transition-all active:scale-99"
                                    id={`btn-authorize-dcrn-${req.id}`}
                                  >
                                    <FileCheck className="w-4 h-4 text-indigo-300" />
                                    <span>Authorize & Issue DCRN</span>
                                  </button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                </div>
              )
            ) : (
              /* DCRN LEDGER DASHBOARD VIEW */
              <div className="space-y-5" id="mr-complete-dcrn-ledger-dashboard">
                {/* Bento Statistics Grid */}
                <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                  <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs flex flex-col justify-between">
                    <span className="text-[10px] uppercase tracking-wider text-slate-400 font-bold font-mono">
                      Total Logged
                    </span>
                    <span className="text-2xl font-extrabold text-indigo-950 mt-1 font-sans">
                      {dcrnRequests.length}
                    </span>
                  </div>
                  <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs flex flex-col justify-between">
                    <span className="text-[10px] uppercase tracking-wider text-emerald-600 font-bold font-mono">
                      Issued DCRNs
                    </span>
                    <span className="text-2xl font-extrabold text-emerald-700 mt-1 font-sans">
                      {
                        dcrnRequests.filter((r) => r.status === "Completed")
                          .length
                      }
                    </span>
                  </div>
                  <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs flex flex-col justify-between">
                    <span className="text-[10px] uppercase tracking-wider text-blue-500 font-bold font-mono">
                      Pending QA
                    </span>
                    <span className="text-2xl font-extrabold text-blue-600 mt-1 font-sans">
                      {
                        dcrnRequests.filter(
                          (r) => r.status === "Pending_QA_Evaluation",
                        ).length
                      }
                    </span>
                  </div>
                  <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs flex flex-col justify-between">
                    <span className="text-[10px] uppercase tracking-wider text-indigo-650 font-bold font-mono">
                      Department Review
                    </span>
                    <span className="text-2xl font-extrabold text-indigo-700 mt-1 font-sans">
                      {
                        dcrnRequests.filter(
                          (r) => r.status === "Pending_Impact_Assessment",
                        ).length
                      }
                    </span>
                  </div>
                  <div className="bg-white p-3.5 rounded-xl border border-rose-150 shadow-2xs col-span-2 md:col-span-1 flex flex-col justify-between bg-rose-50/20">
                    <span className="text-[10px] uppercase tracking-wider text-rose-600 font-bold font-mono">
                      Pending Deletion
                    </span>
                    <span className="text-2xl font-extrabold text-rose-700 mt-1 font-sans">
                      {dcrnRequests.filter((r) => r.pendingDeletion).length}
                    </span>
                  </div>
                </div>

                {/* Filter and Controls Toolbar */}
                <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm space-y-3">
                  <div className="flex flex-col md:flex-row gap-3">
                    {/* Live Search input */}
                    <div className="relative flex-1">
                      <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
                      <input
                        type="text"
                        value={mrSearchQuery}
                        onChange={(e) => setMrSearchQuery(e.target.value)}
                        placeholder="Search by ID, preparer, doc number or registry mapping..."
                        className="w-full bg-slate-50 hover:bg-slate-100/50 focus:bg-white border focus:border-indigo-600 outline-none rounded-lg p-2 pl-9 text-xs transition-colors text-slate-800 font-medium"
                      />
                    </div>

                    {/* Status selection filter */}
                    <div className="w-full md:w-52 flex items-center gap-2">
                      <Filter className="w-3.5 h-3.5 text-slate-455 shrink-0 pointer-events-none" />
                      <select
                        value={mrStatusFilter}
                        onChange={(e) => setMrStatusFilter(e.target.value)}
                        className="w-full bg-slate-50 border outline-none rounded-lg p-2 text-xs font-semibold text-slate-700 cursor-pointer"
                      >
                        <option value="ALL">All Statuses</option>
                        <option value="Pending_QA_Evaluation">
                          Pending QA Evaluator
                        </option>
                        <option value="Pending_Impact_Assessment">
                          Pending Dept Review
                        </option>
                        <option value="Completed">Completed / Issued</option>
                        <option value="Rejected">Rejected</option>
                        <option value="PENDING_DELETION">
                          Pending Deletion Approval
                        </option>
                      </select>
                    </div>

                    {/* Department selection filter */}
                    <div className="w-full md:w-52 flex items-center gap-2">
                      <Building2 className="w-3.5 h-3.5 text-slate-455 shrink-0 pointer-events-none" />
                      <select
                        value={mrDeptFilter}
                        onChange={(e) => setMrDeptFilter(e.target.value)}
                        className="w-full bg-slate-50 border outline-none rounded-lg p-2 text-xs font-semibold text-slate-705 cursor-pointer"
                      >
                        <option value="ALL">All Departments</option>
                        <option value="PD">Production (PD)</option>
                        <option value="QC">Quality Control (QC)</option>
                        <option value="MN">Maintenance (MN)</option>
                        <option value="ST">Store / Warehouse (ST)</option>
                        <option value="QA">Quality Assurance (QA)</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Ledger Listing */}
                {dcrnRequests.filter((req) => {
                  const matchSearch =
                    req.id
                      .toLowerCase()
                      .includes(mrSearchQuery.toLowerCase()) ||
                    (req.preparedBy?.userName || "")
                      .toLowerCase()
                      .includes(mrSearchQuery.toLowerCase()) ||
                    (req.mrRegistryNumber || "")
                      .toLowerCase()
                      .includes(mrSearchQuery.toLowerCase()) ||
                    req.initialDocs.some((d) =>
                      d.docNumber
                        .toLowerCase()
                        .includes(mrSearchQuery.toLowerCase()),
                    );

                  const matchStatus =
                    mrStatusFilter === "ALL" ||
                    req.status === mrStatusFilter ||
                    (mrStatusFilter === "PENDING_DELETION" &&
                      req.pendingDeletion);
                  const matchDept =
                    mrDeptFilter === "ALL" ||
                    req.preparedBy?.department === mrDeptFilter;

                  return matchSearch && matchStatus && matchDept;
                }).length === 0 ? (
                  <div className="bg-white p-12 rounded-xl border border-slate-200 text-center text-slate-400">
                    <FileText className="w-12 h-12 mx-auto text-slate-350 opacity-60 mb-2 pointer-events-none" />
                    <p className="text-sm font-semibold text-slate-700">
                      No Ledger Records Match Your Criteria
                    </p>
                    <p className="text-xs text-slate-500 mt-1">
                      Refine your search term, select different statuses, or
                      choose another originating department.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4 font-sans">
                    {dcrnRequests
                      .filter((req) => {
                        const matchSearch =
                          req.id
                            .toLowerCase()
                            .includes(mrSearchQuery.toLowerCase()) ||
                          (req.preparedBy?.userName || "")
                            .toLowerCase()
                            .includes(mrSearchQuery.toLowerCase()) ||
                          (req.mrRegistryNumber || "")
                            .toLowerCase()
                            .includes(mrSearchQuery.toLowerCase()) ||
                          req.initialDocs.some((d) =>
                            d.docNumber
                              .toLowerCase()
                              .includes(mrSearchQuery.toLowerCase()),
                          );

                        const matchStatus =
                          mrStatusFilter === "ALL" ||
                          req.status === mrStatusFilter ||
                          (mrStatusFilter === "PENDING_DELETION" &&
                            req.pendingDeletion);
                        const matchDept =
                          mrDeptFilter === "ALL" ||
                          req.preparedBy?.department === mrDeptFilter;

                        return matchSearch && matchStatus && matchDept;
                      })
                      .map((req) => {
                        let statusBadge =
                          "bg-slate-100 text-slate-700 border-slate-205";
                        if (req.status === "Pending_QA_Evaluation") {
                          statusBadge =
                            "bg-blue-50 text-blue-700 border-blue-200";
                        } else if (req.status === "Pending_Impact_Assessment") {
                          if (isAssessmentFinished(req)) {
                            statusBadge =
                              "bg-indigo-100 text-indigo-800 border-indigo-200 font-bold animate-pulse";
                          } else {
                            statusBadge =
                              "bg-emerald-50 text-emerald-700 border-emerald-200";
                          }
                        } else if (req.status === "Rejected") {
                          statusBadge =
                            "bg-rose-50 text-rose-700 border-rose-250";
                        } else if (req.status === "Completed") {
                          statusBadge =
                            "bg-indigo-50 text-indigo-700 border-indigo-200 font-bold";
                        }

                        const trackingDepts = (
                          Object.keys(req.assessments || {}).length > 0
                            ? Object.keys(req.assessments)
                            : Object.keys(DEPARTMENT_MAP).filter(
                                (code) =>
                                  code !== (req.preparedBy?.department || ""),
                              )
                        ).filter((code) => code !== "PK");

                        const userDept = currentUser?.department;
                        let isDownloadPendingForDept = false;

                        if (req.status === "Completed") {
                          const allDocsInDcrn = [
                            ...req.initialDocs,
                            ...Object.values(req.assessments || {}).flatMap(ass => ass.documents || [])
                          ];
                          const approvedDocsInDcrn = allDocsInDcrn.filter(d => !!d.approvedDocUrl);
                          isDownloadPendingForDept = approvedDocsInDcrn.length > 0 && approvedDocsInDcrn.some((doc) => {
                            const isDownloaded = doc.workflowStatus === "Downloaded" || 
                              localDownloadedIds.includes(doc.docNumber) ||
                              localDownloadedIds.includes(doc.docNumber + (doc.addedByDept || ""));
                            return !isDownloaded;
                          });
                        }

                        return (
                          <div
                            key={req.id}
                            className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden"
                            id={`ledger-card-${req.id}`}
                          >
                            {/* Card Heading */}
                            <div className="bg-slate-50/85 p-3.5 border-b border-gray-150 flex flex-wrap justify-between items-center gap-2 text-xs">
                              <div className="flex items-center gap-2.5">
                                <span className="font-bold text-slate-800 font-mono">
                                  DCRN Track: {req.id}
                                </span>
                                <span className="text-[10px] text-slate-400 font-mono font-medium">
                                  Originator Dept:{" "}
                                  <strong className="text-indigo-900">
                                    {req.preparedBy?.department || "N/A"}
                                  </strong>
                                </span>
                                <span className="text-[10px] text-slate-455 font-mono font-medium">
                                  • {formatToIST(req.createdAt)} IST
                                </span>
                              </div>

                              <div className="flex items-center gap-2">
                                {req.pendingDeletion && (
                                  <span className="inline-flex px-1.5 py-0.5 bg-rose-100 text-rose-800 border border-rose-200 rounded text-[9.5px] font-mono font-bold uppercase tracking-tight animate-pulse">
                                    Pending Deletion
                                  </span>
                                )}
                                <span
                                  className={`inline-flex px-1.5 py-0.5 rounded text-[9.5px] border font-semibold ${statusBadge}`}
                                >
                                  {req.status === "Pending_Impact_Assessment" &&
                                  isAssessmentFinished(req)
                                    ? "Forwarded for MR Approval"
                                    : req.status}
                                </span>
                                {req.status === "Completed" &&
                                  req.mrRegistryNumber && (
                                    <mark className="bg-amber-100 text-amber-800 border border-amber-200 px-1.5 py-0.5 rounded text-[9.5px] font-mono font-bold uppercase tracking-tight font-sans">
                                      Issued DCRN: {req.mrRegistryNumber}
                                    </mark>
                                  )}
                                {isDownloadPendingForDept && (
                                  <span className="inline-flex items-center gap-1.5 px-2 py-0.5 bg-red-100 text-red-800 border border-red-200 rounded text-[9.5px] font-bold font-sans uppercase tracking-tight animate-pulse shrink-0">
                                    <span className="w-1.5 h-1.5 rounded-full bg-red-600 block shrink-0" />
                                    Download Pending
                                  </span>
                                )}
                              </div>
                            </div>

                            {/* Detail body */}
                            <div className="p-4 space-y-4 text-xs">
                              {/* Preparer Banner Summary */}
                              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-slate-50/30 p-2.5 rounded-lg border border-slate-150/80 gap-1">
                                <div>
                                  <span className="text-slate-400 font-semibold uppercase text-[9.5px] tracking-wide font-mono block">
                                    Preparer Credentials
                                  </span>
                                  <span className="text-slate-850 font-bold">
                                    {req.preparedBy?.userName}
                                  </span>
                                </div>
                                <div className="text-right sm:text-right">
                                  <span className="text-slate-400 font-semibold uppercase text-[9.5px] tracking-wide font-mono block">
                                    Action Status
                                  </span>
                                  <span className="text-slate-705 font-semibold">
                                    {req.status ===
                                      "Pending_Impact_Assessment" &&
                                    isAssessmentFinished(req)
                                      ? "Forwarded for MR Approval"
                                      : req.status.replace(/_/g, " ")}
                                  </span>
                                </div>
                              </div>

                              {/* Initial Docs Block */}
                              <div>
                                <h5 className="text-[10px] font-mono font-bold uppercase text-slate-400 tracking-wider mb-1.5">
                                  Originating Requested Document Changes
                                </h5>
                                <div className="space-y-1.5">
                                  {req.initialDocs
                                    .filter(
                                      (doc) =>
                                        !doc.addedByDept ||
                                        doc.addedByDept ===
                                          (req.preparedBy?.department || ""),
                                    )
                                    .map((doc, dIdx) => {
                                      const isEditable = isPreparerBoard && req.status === "Rejected";
                                      return (
                                        <div
                                          key={dIdx}
                                          className="p-3 border border-slate-205 bg-white rounded-lg shadow-3xs space-y-2.5"
                                        >
                                          {isEditable ? (
                                            <div className="space-y-2 bg-slate-50/50 p-2 rounded border border-slate-200">
                                              <div className="grid grid-cols-4 gap-2">
                                                 <div>
                                                   <label className="block text-[9px] font-bold text-slate-500 uppercase font-mono mb-0.5">Action Type</label>
                                                   <select
                                                     value={doc.actionType || "Change"}
                                                     onChange={(e) => {
                                                       const val = e.target.value as "Change" | "Introduction" | "Removal";
                                                       const updates: Partial<DCRNDecDocument> = { actionType: val };
                                                       if (val === "Introduction") {
                                                         updates.currentRevision = "-";
                                                       } else if (doc.currentRevision === "-") {
                                                         updates.currentRevision = "";
                                                       }
                                                       if (val === "Removal") {
                                                         updates.nextRevision = "-";
                                                       } else if (doc.nextRevision === "-") {
                                                         updates.nextRevision = "";
                                                       }
                                                       onUpdateDcrnDocumentField?.(req.id, doc.docNumber, updates);
                                                     }}
                                                     className="w-full bg-white border border-slate-200 rounded px-1 py-0.5 text-xs outline-none text-slate-800 font-sans"
                                                   >
                                                     <option value="Change">Change</option>
                                                     <option value="Introduction">Introduction</option>
                                                     <option value="Removal">Removal</option>
                                                   </select>
                                                 </div>
                                                <div>
                                                  <label className="block text-[9px] font-bold text-slate-500 uppercase font-mono mb-0.5">Doc Ref *</label>
                                                  <input
                                                    type="text"
                                                    value={doc.docNumber || ""}
                                                    onChange={(e) => onUpdateDcrnDocumentField?.(req.id, doc.docNumber, { docNumber: e.target.value })}
                                                    className="w-full bg-white border border-slate-200 rounded px-1.5 py-0.5 text-xs font-mono font-bold outline-none text-slate-800"
                                                    required
                                                  />
                                                </div>
                                                <div>
                                                  <label className="block text-[9px] font-bold text-slate-500 uppercase font-mono mb-0.5">Current Rev</label>
                                                  <input
                                                    type="text"
                                                    value={doc.actionType === "Introduction" ? "-" : doc.currentRevision || ""}
                                                    disabled={doc.actionType === "Introduction"}
                                                    onChange={(e) => onUpdateDcrnDocumentField?.(req.id, doc.docNumber, { currentRevision: e.target.value.toUpperCase() })}
                                                    className="w-full bg-white border border-slate-200 rounded px-1.5 py-0.5 text-xs font-mono font-bold outline-none text-slate-800"
                                                  />
                                                </div>
                                                <div>
                                                  <label className="block text-[9px] font-bold text-slate-500 uppercase font-mono mb-0.5">Next Rev</label>
                                                  <input
                                                    type="text"
                                                    value={doc.actionType === "Removal" ? "-" : doc.nextRevision || ""}
                                                    disabled={doc.actionType === "Removal"}
                                                    onChange={(e) => onUpdateDcrnDocumentField?.(req.id, doc.docNumber, { nextRevision: e.target.value.toUpperCase() })}
                                                    className="w-full bg-white border border-slate-200 rounded px-1.5 py-0.5 text-xs font-mono font-bold outline-none text-slate-800"
                                                  />
                                                </div>
                                              </div>
                                              <div>
                                                <label className="block text-[9px] font-bold text-slate-500 uppercase font-mono mb-0.5">Reason *</label>
                                                <textarea
                                                  rows={1}
                                                  value={doc.reasonForChange || ""}
                                                  onChange={(e) => onUpdateDcrnDocumentField?.(req.id, doc.docNumber, { reasonForChange: e.target.value })}
                                                  className="w-full bg-white border border-slate-200 rounded px-1.5 py-0.5 text-xs outline-none text-slate-800 font-sans"
                                                  required
                                                />
                                              </div>
                                              <div>
                                                <label className="block text-[9px] font-bold text-slate-500 uppercase font-mono mb-0.5">Proposed Changes *</label>
                                                <textarea
                                                  rows={1}
                                                  value={doc.changesRequired || ""}
                                                  onChange={(e) => onUpdateDcrnDocumentField?.(req.id, doc.docNumber, { changesRequired: e.target.value })}
                                                  className="w-full bg-white border border-slate-200 rounded px-1.5 py-0.5 text-xs outline-none text-slate-800 font-sans"
                                                  required
                                                />
                                              </div>
                                            </div>
                                          ) : (
                                            <>
                                              <span className="font-bold text-indigo-900 font-mono text-[11px]">
                                                📄 {doc.docNumber || "N/A"}
                                              </span>
                                              <div className="text-[10px] text-slate-500 font-mono mt-1 space-y-0.5">
                                                <p>
                                                  Revision:{" "}
                                                  <span className="font-bold text-slate-700">
                                                    {doc.currentRevision} →{" "}
                                                    {doc.nextRevision}
                                                  </span>
                                                </p>
                                              </div>
                                              <p className="mt-1.5">
                                                <strong className="text-slate-400 font-semibold text-[10.5px]">
                                                  Reason:
                                                </strong>{" "}
                                                {doc.reasonForChange ||
                                                  "None declared"}
                                              </p>
                                              <p className="mt-0.5">
                                                <strong className="text-slate-400 font-semibold text-[10.5px]">
                                                  Proposed Changes:
                                                </strong>{" "}
                                                {doc.changesRequired ||
                                                  "None declared"}
                                              </p>
                                            </>
                                          )}
                                        </div>
                                      );
                                    })}
                                </div>
                              </div>

                              {/* Clearance Evaluation details */}
                              <div className="grid md:grid-cols-2 gap-3.5">
                                {/* QA Gateway column */}
                                <div className="bg-slate-50/50 p-3 rounded-lg border border-slate-200">
                                  <h6 className="text-[9.5px] font-mono font-bold uppercase text-slate-400 tracking-wider mb-2">
                                    1. QA Gateway Clearance Check
                                  </h6>
                                  {req.qaEvaluatedBy ? (
                                    <div className="space-y-1">
                                      <div className="flex items-center gap-1.5">
                                        <span className="font-semibold text-slate-703">
                                          Clearance Assessment:
                                        </span>
                                        {req.status === "Rejected" &&
                                        !req.qaEvaluationRemarks?.includes(
                                          "Approved",
                                        ) ? (
                                          <span className="text-rose-700 font-bold">
                                            QA Rejected / Blocked
                                          </span>
                                        ) : (
                                          <span className="text-blue-700 font-bold flex items-center gap-1">
                                            ✓ Accepted Gateway
                                          </span>
                                        )}
                                      </div>
                                      <p className="text-[10px] text-slate-450 font-mono">
                                        Evaluator: {req.qaEvaluatedBy.userName}
                                      </p>
                                      <p className="italic text-slate-600 mt-1 bg-white p-1.5 border border-slate-205 rounded">
                                        "{req.qaEvaluationRemarks}"
                                      </p>
                                    </div>
                                  ) : (
                                    <div className="text-slate-400 italic py-1.5">
                                      Awaiting QA Evaluation clearance. DCRN
                                      process not validated.
                                    </div>
                                  )}
                                </div>

                                {/* 4-Dept assessments matrix column */}
                                <div className="bg-slate-50/50 p-3 rounded-lg border border-slate-200">
                                  <h6 className="text-[9.5px] font-mono font-bold uppercase text-slate-400 tracking-wider mb-2">
                                    2. Inter-Departmental Trackers Matrix
                                  </h6>
                                  <div className="grid grid-cols-2 gap-2 text-[10px]">
                                    {trackingDepts.map((code) => {
                                      const rep = req.assessments?.[code];
                                      const deptLabel =
                                        DEPARTMENT_MAP[code] || code;
                                      const signed =
                                        rep && rep.impacted !== null;
                                      const hasAddedImpactedDoc =
                                        req.initialDocs.some(
                                          (doc) => doc.addedByDept === code,
                                        );
                                      const isImpact =
                                        rep?.impacted === "Yes" ||
                                        (signed && hasAddedImpactedDoc);

                                      return (
                                        <div
                                          key={code}
                                          className="p-1.5 rounded border bg-white border-slate-205 flex items-center justify-between"
                                        >
                                          <div className="flex flex-col">
                                            <span className="font-bold text-slate-805">
                                              {code}
                                            </span>
                                            <span className="text-[8px] text-slate-400 leading-none">
                                              {deptLabel.substring(0, 11)}..
                                            </span>
                                          </div>

                                          {isImpact ? (
                                            <div className="text-right">
                                              <span
                                                className="px-1.5 py-0.2 rounded text-[9px] font-mono font-bold bg-amber-100 text-amber-800"
                                                title="IMPACTED DEPARTMENT"
                                              >
                                                IMPACT
                                              </span>
                                            </div>
                                          ) : signed ? (
                                            <div className="text-right">
                                              <span
                                                className="px-1.5 py-0.2 rounded text-[9px] font-mono font-bold bg-emerald-100 text-emerald-800"
                                                title="CLEAR FROM IMPACT"
                                              >
                                                CLEAR
                                              </span>
                                            </div>
                                          ) : (
                                            <span className="bg-slate-100 text-slate-450 px-1 py-0.2 rounded text-[9px] font-mono font-semibold animate-pulse">
                                              AWAITING
                                            </span>
                                          )}
                                        </div>
                                      );
                                    })}
                                  </div>
                                </div>
                              </div>

                              {/* Administrative Deletion Options directly within ledger dashboard */}
                              {req.pendingDeletion &&
                                (onDeleteDcrnRequest ||
                                  onRejectDcrnRemoval) && (
                                  <div className="mt-3 bg-rose-50 border border-rose-200 rounded-lg p-3 flex flex-wrap justify-between items-center gap-3">
                                    <div className="flex items-center gap-2 text-xs text-rose-800 font-medium font-sans">
                                      <AlertTriangle className="w-4 h-4 text-rose-600 animate-pulse pointer-events-none" />
                                      <span>
                                        Original author requested deletion
                                        disposal under management representative
                                        clearance controls.
                                      </span>
                                    </div>

                                    <div className="flex items-center gap-2 font-sans font-medium">
                                      {onDeleteDcrnRequest && (
                                        <button
                                          type="button"
                                          onClick={() =>
                                            onDeleteDcrnRequest(req.id)
                                          }
                                          className="bg-rose-650 hover:bg-rose-700 text-white font-bold text-xs p-1.5 px-3 rounded-lg cursor-pointer flex items-center gap-1 shadow-sm transition-colors"
                                        >
                                          <Trash2 className="w-3.5 h-3.5" />
                                          <span>
                                            Accept Permanent Deletion
                                          </span>
                                        </button>
                                      )}
                                      {onRejectDcrnRemoval && (
                                        <button
                                          type="button"
                                          onClick={() =>
                                            onRejectDcrnRemoval(req.id)
                                          }
                                          className="bg-slate-105 hover:bg-slate-205 border border-slate-350 text-slate-700 font-semibold text-xs p-1.5 px-3 rounded-lg cursor-pointer transition-colors"
                                        >
                                          Reject & Restore Request
                                        </button>
                                      )}
                                    </div>
                                  </div>
                                )}
                            </div>
                          </div>
                        );
                      })}
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* --------------------------------------------------------------------------
            TAB 5: DCRN LOG FILE / HISTORY LIST
            -------------------------------------------------------------------------- */}
        {activeTab === "history" && (
          <div className="space-y-4">
            <div className="bg-white p-4.5 rounded-xl border border-slate-200 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
              <div>
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                  <FileSpreadsheet className="w-4.5 h-4.5 text-slate-650" />
                  Official DCRN Register Ledger
                </h3>
                <p className="text-xs text-slate-500">
                  Total of {filteredDcrnRequests.length} Document Change Request
                  Number processes logged securely on system storage.
                </p>
              </div>
            </div>

            {filteredDcrnRequests.length === 0 ? (
              <div className="bg-white p-12 rounded-xl border border-slate-200 text-center text-slate-400">
                <FileText className="w-12 h-12 mx-auto text-slate-300 opacity-60 mb-2" />
                <p className="text-sm font-bold text-slate-700">
                  Register Empty
                </p>
                <p className="text-xs text-slate-500 mt-1">
                  No Document Change Request Numbers mapped to your department
                  have been registered on system storage.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredDcrnRequests.map((req) => {
                  const masterDocs = getMasterDocs(req);
                  let statusBadge =
                    "bg-slate-100 text-slate-705 border-slate-300";
                  if (req.status === "Pending_QA_Evaluation") {
                    statusBadge = "bg-blue-50 text-blue-700 border-blue-200";
                  } else if (req.status === "Pending_Impact_Assessment") {
                    if (isAssessmentFinished(req)) {
                      statusBadge =
                        "bg-indigo-100 text-indigo-800 border-indigo-200 font-bold animate-pulse";
                    } else {
                      statusBadge =
                        "bg-emerald-50 text-emerald-700 border-emerald-200";
                    }
                  } else if (req.status === "Rejected") {
                    statusBadge = "bg-rose-50 text-rose-700 border-rose-250";
                  } else if (req.status === "Completed") {
                    statusBadge =
                      "bg-indigo-50 text-indigo-700 border-indigo-200 font-bold";
                  }

                  return (
                    <div
                      key={req.id}
                      className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden"
                      id={`log-card-${req.id}`}
                    >
                      {/* Card standard list header */}
                      <div className="bg-slate-50 p-3.5 border-b border-gray-150 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 text-xs">
                        <div>
                          <div className="flex flex-wrap items-center gap-2">
                            {!isPreparerBoard && (
                              <span className="font-bold text-slate-800">
                                Request: {req.id}
                              </span>
                            )}
                            <span
                              className={`inline-flex px-1.5 py-0.2 rounded text-[9.5px] border font-semibold ${statusBadge}`}
                            >
                              {req.status === "Pending_Impact_Assessment" &&
                              isAssessmentFinished(req)
                                ? "Forwarded for MR Approval"
                                : req.status}
                            </span>
                            {req.pendingDeletion && (
                              <span className="inline-flex px-1.5 py-0.2 bg-rose-100 text-rose-800 border border-rose-200 rounded text-[9.5px] font-mono font-bold uppercase tracking-tight animate-pulse">
                                Pending Deletion Approval
                              </span>
                            )}
                            {req.status === "Completed" &&
                              req.mrRegistryNumber && (
                                <mark className="bg-amber-100 text-amber-800 border border-amber-200 px-1.5 py-0.2 rounded text-[9.5px] font-mono font-bold uppercase tracking-tight font-sans">
                                  Issued DCRN: {req.mrRegistryNumber}
                                </mark>
                              )}
                            {req.preparedBy?.userId === currentUser.id &&
                              onDeleteDcrnRequest && (
                                <div className="inline-flex items-center">
                                  {req.pendingDeletion ? (
                                    <div className="bg-amber-50 text-amber-700 border border-amber-200 rounded px-2 py-0.5 font-sans text-[10px] font-semibold flex items-center gap-1 select-none">
                                      <AlertTriangle className="w-3 h-3 text-amber-600 animate-pulse" />
                                      <span>Awaiting MR Deletion Approval</span>
                                    </div>
                                  ) : confirmDcrnDeleteId === req.id ? (
                                    <div className="flex items-center gap-1.5 bg-rose-50 border border-rose-200 p-1 px-2 rounded animate-fade-in shrink-0">
                                      <span className="text-[9px] font-bold text-rose-700">
                                        Request Removal?
                                      </span>
                                      <button
                                        type="button"
                                        onClick={() => {
                                          onDeleteDcrnRequest(req.id);
                                          setConfirmDcrnDeleteId(null);
                                        }}
                                        className="px-1.5 py-0.5 bg-rose-600 hover:bg-rose-700 text-white rounded font-bold text-[9px] cursor-pointer"
                                      >
                                        Yes
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() =>
                                          setConfirmDcrnDeleteId(null)
                                        }
                                        className="px-1.5 py-0.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded font-bold text-[9px] cursor-pointer"
                                      >
                                        No
                                      </button>
                                    </div>
                                  ) : (
                                    <button
                                      type="button"
                                      onClick={() =>
                                        setConfirmDcrnDeleteId(req.id)
                                      }
                                      className="bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 hover:border-rose-300 rounded px-2 py-0.5 font-sans text-[10px] font-bold cursor-pointer transition-all shrink-0 flex items-center gap-1"
                                      title="Submit removal request of this DCRN to MR department"
                                    >
                                      <Trash2 className="w-3 h-3" />
                                      <span>Request Removal</span>
                                    </button>
                                  )}
                                </div>
                              )}
                          </div>
                          <p className="text-[10px] text-slate-450 mt-0.5">
                            Prepared By: {req.preparedBy?.userName} (
                            {req.preparedBy?.department}) | Created:{" "}
                            {formatToIST(req.createdAt)} IST
                          </p>

                          {req.qaEvaluationRemarks && (
                            <div className="mt-1 space-y-1.5">
                              <p className="text-[10px] text-slate-450">
                                QA Evaluation/Deficiency Notes: <span className="font-semibold text-rose-700 bg-rose-50 px-1 py-0.5 rounded border border-rose-100 italic">"{req.qaEvaluationRemarks}"</span> |
                                Evaluated By: {req.qaEvaluatedBy?.userName} |
                                Date: {formatToIST(req.qaEvaluatedAt || "")} IST
                              </p>
                              {isPreparerBoard && req.status === "Rejected" && (
                                <div className="pt-1 flex items-center gap-2">
                                  <button
                                    type="button"
                                    onClick={() => {
                                      onSubmitToQa?.(req.id);
                                    }}
                                    className="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-750 text-white font-bold rounded text-[10px] cursor-pointer flex items-center gap-1 shadow-sm transition-all active:scale-98 animate-fade-in"
                                    title="Resubmit this corrected DCRN to Stage-1 QA Gateway"
                                  >
                                    <Send className="w-3 h-3 text-indigo-300" />
                                    <span>Correct & Resubmit to QA Gateway</span>
                                  </button>
                                  <span className="text-[9.5px] italic text-indigo-700 font-medium font-sans">
                                    * Edit document inputs above first before resubmitting.
                                  </span>
                                </div>
                              )}
                            </div>
                          )}
                        </div>

                        {/* Signoff Tracker in log summary */}
                        <div className="flex flex-wrap gap-1 items-center font-mono text-[9px]">
                          {Object.keys(req.assessments || {})
                            .filter((code) => code !== "PK")
                            .map((code) => {
                              const ass = req.assessments[code];
                              const answered = ass && ass.impacted !== null;
                              const deptName = DEPARTMENT_MAP[code] || code;
                              const hasAddedImpactedDoc = req.initialDocs.some(
                                (doc) => doc.addedByDept === code,
                              );
                              const isImpact =
                                ass?.impacted === "Yes" ||
                                (answered && hasAddedImpactedDoc);
                              return (
                                <span
                                  key={code}
                                  className={`px-1.5 py-0.5 border rounded ${
                                    isImpact
                                      ? "bg-amber-50 text-amber-700 border-amber-200 font-bold"
                                      : answered
                                        ? "bg-emerald-50 text-emerald-700 border-emerald-250"
                                        : "bg-slate-100 text-slate-400 border-slate-200"
                                  }`}
                                  title={
                                    isImpact
                                      ? `${deptName} has dynamic impacted records`
                                      : answered
                                        ? `${deptName} signed: ${ass.impacted}`
                                        : `${deptName} signoff pending`
                                  }
                                >
                                  {code}:{" "}
                                  {isImpact
                                    ? "IMPACT"
                                    : answered
                                      ? "NO IMPACT"
                                      : "PEND"}
                                </span>
                              );
                            })}
                        </div>
                      </div>

                      {/* Card Details body */}
                      <div className="p-4 space-y-3.5 text-xs">
                        {/* Compiled dynamic entries packet details */}
                        <div className="space-y-4">
                          <div className="flex flex-wrap items-center justify-between gap-2 border-b pb-1.5 border-slate-100">
                            <h5 className="font-bold text-[10px] uppercase font-mono text-slate-450 tracking-wider">
                              Accumulated Master Document Change Packet
                            </h5>
                             {(() => {
                              const masterDocs = getMasterDocs(req);
                              const allApproved = masterDocs.length > 0 && masterDocs.every(d => d.actionType === "Removal" || d.workflowStatus === "ApprovalAccepted");
                              return allApproved ? (
                                <div className="flex items-center gap-2">
                                  <span className="inline-flex items-center gap-1.5 px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[9px] font-mono font-bold rounded-sm border border-emerald-250 uppercase shadow-3xs animate-pulse">
                                    ✓ All Documents Accepted
                                  </span>
                                  {req.status === "Pending_QA_Evaluation" || req.status === "Pending_QA_Stage2" ? (
                                    <button
                                      disabled
                                      className="px-2.5 py-1 bg-slate-100 text-slate-400 border border-slate-200 font-bold rounded text-[10px] cursor-not-allowed flex items-center gap-1 shadow-sm"
                                      id={`btn-submit-to-qa-history-${req.id}`}
                                    >
                                      <Check className="w-3 h-3 text-slate-450" />
                                      <span>Submitted to QA</span>
                                    </button>
                                  ) : req.status === "Completed" ? (
                                    <button
                                      disabled
                                      className="px-2.5 py-1 bg-slate-100 text-slate-400 border border-slate-200 font-bold rounded text-[10px] cursor-not-allowed flex items-center gap-1 shadow-sm"
                                      id={`btn-submit-to-qa-history-${req.id}`}
                                    >
                                      <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                                      <span>Accepted & Archived</span>
                                    </button>
                                  ) : (
                                    <button
                                      disabled={req.preparedBy?.userId !== currentUser.id && req.preparedBy?.email !== currentUser.email}
                                      onClick={() => onSubmitToQa?.(req.id)}
                                      className={`px-2.5 py-1 font-bold rounded text-[10px] flex items-center gap-1 shadow-sm transition-all ${req.preparedBy?.userId === currentUser.id || req.preparedBy?.email === currentUser.email ? "bg-indigo-600 hover:bg-indigo-750 text-white cursor-pointer active:scale-98" : "bg-slate-100 text-slate-400 border border-slate-200 cursor-not-allowed"}`}
                                      id={`btn-submit-to-qa-history-${req.id}`}
                                    >
                                      <Send className="w-3 h-3 text-indigo-200" />
                                      <span>Submit to QA</span>
                                    </button>
                                  )}
                                </div>
                              ) : req.status === "Pending_Impact_Assessment" ? (
                                <div className="flex items-center gap-2">
                                  <span className="inline-flex items-center gap-1.5 px-2 py-0.5 bg-amber-50 text-amber-800 text-[8.5px] font-mono font-bold rounded border border-amber-200 uppercase select-none">
                                    Awaiting Document Approvals
                                  </span>
                                </div>
                              ) : null;
                            })()}
                          </div>

                          {/* Preparer section */}
                          <div className="space-y-1">
                            <h6 className="text-[9px] font-mono text-indigo-800 uppercase font-bold">
                              Preparer: {req.preparedBy?.userName}
                            </h6>
                            <div className="bg-slate-50 border rounded-lg p-3 space-y-2.5 divide-y divide-slate-150">
                              {req.initialDocs
                                .filter(
                                  (doc) =>
                                    !doc.addedByDept ||
                                    doc.addedByDept ===
                                      (req.preparedBy?.department || ""),
                                )
                                .map((doc, docIdx) => {
                                  const isUserPreparerOfDcrn = currentUser.id === req.preparedBy?.userId || currentUser.department === req.preparedBy?.department;
                                  const isEditable = isPreparerBoard && req.status === "Rejected";
                                  const isAssignedAuditor = currentUser.id === doc.assignedReviewerId || currentUser.id === doc.assignedApproverId;
                                  const isImpactedDoc = !!doc.addedByDept && doc.addedByDept !== req.preparedBy?.department;

                                  let canDownloadThisDoc = false;
                                  if (isAssignedAuditor) {
                                    canDownloadThisDoc = true;
                                  } else if (isImpactedDoc) {
                                    if (isUserPreparerOfDcrn) {
                                      canDownloadThisDoc = false;
                                    } else if (currentUser.department === doc.addedByDept) {
                                      canDownloadThisDoc = true;
                                    } else {
                                      canDownloadThisDoc = false;
                                    }
                                  } else {
                                    if (isUserPreparerOfDcrn) {
                                      canDownloadThisDoc = true;
                                    } else {
                                      canDownloadThisDoc = false;
                                    }
                                  }
                                  return (
                                    <div
                                      key={docIdx}
                                      className="first:pt-0 pt-2 font-sans flex flex-col gap-2"
                                    >
                                      {isEditable ? (
                                        <div className="space-y-2 bg-white p-2.5 rounded border border-slate-200">
                                          <div className="grid grid-cols-4 gap-2">
                                            <div>
                                              <label className="block text-[9px] font-bold text-slate-500 uppercase font-mono mb-0.5">Action Type</label>
                                              <select
                                                value={doc.actionType || "Change"}
                                                onChange={(e) => {
                                                  const val = e.target.value as "Change" | "Introduction" | "Removal";
                                                  const updates: Partial<DCRNDecDocument> = { actionType: val };
                                                  if (val === "Introduction") {
                                                    updates.currentRevision = "-";
                                                  } else if (doc.currentRevision === "-") {
                                                    updates.currentRevision = "";
                                                  }
                                                  if (val === "Removal") {
                                                    updates.nextRevision = "-";
                                                  } else if (doc.nextRevision === "-") {
                                                    updates.nextRevision = "";
                                                  }
                                                  onUpdateDcrnDocumentField?.(req.id, doc.docNumber, updates);
                                                }}
                                                className="w-full bg-white border border-slate-200 rounded px-1 py-0.5 text-xs outline-none text-slate-800 font-sans"
                                              >
                                                <option value="Change">Change</option>
                                                <option value="Introduction">Introduction</option>
                                                <option value="Removal">Removal</option>
                                              </select>
                                            </div>
                                            <div>
                                              <label className="block text-[9px] font-bold text-slate-500 uppercase font-mono mb-0.5">Doc Ref *</label>
                                              <input
                                                type="text"
                                                value={doc.docNumber || ""}
                                                onChange={(e) => onUpdateDcrnDocumentField?.(req.id, doc.docNumber, { docNumber: e.target.value })}
                                                className="w-full bg-white border border-slate-200 rounded px-1.5 py-0.5 text-xs font-mono font-bold outline-none text-slate-800"
                                                required
                                              />
                                            </div>
                                            <div>
                                              <label className="block text-[9px] font-bold text-slate-500 uppercase font-mono mb-0.5">Current Rev</label>
                                              <input
                                                type="text"
                                                value={doc.actionType === "Introduction" ? "-" : doc.currentRevision || ""}
                                                disabled={doc.actionType === "Introduction"}
                                                onChange={(e) => onUpdateDcrnDocumentField?.(req.id, doc.docNumber, { currentRevision: e.target.value.toUpperCase() })}
                                                className="w-full bg-white border border-slate-200 rounded px-1.5 py-0.5 text-xs font-mono font-bold outline-none text-slate-800"
                                              />
                                            </div>
                                            <div>
                                              <label className="block text-[9px] font-bold text-slate-500 uppercase font-mono mb-0.5">Next Rev</label>
                                              <input
                                                type="text"
                                                value={doc.actionType === "Removal" ? "-" : doc.nextRevision || ""}
                                                disabled={doc.actionType === "Removal"}
                                                onChange={(e) => onUpdateDcrnDocumentField?.(req.id, doc.docNumber, { nextRevision: e.target.value.toUpperCase() })}
                                                className="w-full bg-white border border-slate-200 rounded px-1.5 py-0.5 text-xs font-mono font-bold outline-none text-slate-800"
                                              />
                                            </div>
                                          </div>
                                          <div>
                                            <label className="block text-[9px] font-bold text-slate-500 uppercase font-mono mb-0.5 flex justify-between items-center">
                                              <span>Reason *</span>
                                              <span className="text-[8px] text-indigo-650 font-normal normal-case font-sans">Click chat box to expand</span>
                                            </label>
                                            <div className="relative flex items-center bg-white border border-slate-200 focus-within:border-indigo-500 rounded">
                                              <input
                                                type="text"
                                                value={doc.reasonForChange || ""}
                                                onChange={(e) => onUpdateDcrnDocumentField?.(req.id, doc.docNumber, { reasonForChange: e.target.value })}
                                                className="w-full bg-transparent p-1.5 pr-8 outline-none text-slate-800 text-xs"
                                                required
                                              />
                                              <button
                                                type="button"
                                                onClick={() => openHistoryTextEditor(req.id, doc.docNumber, 'reason', doc.reasonForChange || "", "Reason")}
                                                title="Open rich text editor window"
                                                className="absolute right-1.5 p-1 text-slate-400 hover:text-indigo-600 hover:bg-slate-100 rounded transition-all cursor-pointer flex items-center justify-center"
                                              >
                                                <MessageSquare className="w-3.5 h-3.5 animate-pulse" />
                                              </button>
                                            </div>
                                          </div>
                                          <div>
                                            <label className="block text-[9px] font-bold text-slate-500 uppercase font-mono mb-0.5 flex justify-between items-center">
                                              <span>Proposed Changes *</span>
                                              <span className="text-[8px] text-indigo-650 font-normal normal-case font-sans">Click chat box to expand</span>
                                            </label>
                                            <div className="relative flex items-start bg-white border border-slate-200 focus-within:border-indigo-500 rounded">
                                              <textarea
                                                rows={2}
                                                value={doc.changesRequired || ""}
                                                onChange={(e) => onUpdateDcrnDocumentField?.(req.id, doc.docNumber, { changesRequired: e.target.value })}
                                                className="w-full bg-transparent p-1.5 pr-8 outline-none text-slate-800 text-xs resize-none"
                                                required
                                              />
                                              <button
                                                type="button"
                                                onClick={() => openHistoryTextEditor(req.id, doc.docNumber, 'changes', doc.changesRequired || "", "Proposed Change")}
                                                title="Open rich text editor window"
                                                className="absolute right-1.5 top-1.5 p-1 text-slate-400 hover:text-indigo-600 hover:bg-slate-100 rounded transition-all cursor-pointer flex items-center justify-center"
                                              >
                                                <MessageSquare className="w-3.5 h-3.5 animate-pulse" />
                                              </button>
                                            </div>
                                          </div>
                                        </div>
                                      ) : (
                                        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-1">
                                          <div className="font-bold text-slate-800 font-mono w-full sm:w-1/4 flex flex-col gap-1 items-start">
                                            <span>
                                              📄 {doc.docNumber} (Rev:{" "}
                                              {doc.currentRevision || "-"} →{" "}
                                              {doc.nextRevision || "-"}){" "}
                                              {doc.title && (
                                                <span className="text-[10px] text-indigo-755 font-bold bg-indigo-50 border border-indigo-150 rounded px-1.5 py-0.2 mx-1 inline-block font-sans">
                                                  Title: {doc.title}
                                                </span>
                                              )}
                                              <span className="text-[9px] font-sans font-normal text-slate-500">
                                                [{doc.actionType || "Change"}]
                                              </span>
                                            </span>
                                            {renderDocWorkflowStatusBadge(doc)}
                                          </div>
                                          <span className="text-slate-600 w-full sm:w-3/8">
                                            <strong className="text-slate-400 font-normal">
                                              "Reason:"
                                            </strong>{" "}
                                            {doc.reasonForChange}
                                          </span>
                                          <span className="text-slate-600 w-full sm:w-3/8">
                                            <strong className="text-slate-400 font-normal">
                                              Proposed Change:
                                            </strong>{" "}
                                            {doc.changesRequired}
                                          </span>
                                        </div>
                                      )}
                                      {doc.actionType === "Removal" ? (
                                        <div className="mt-2 p-2.5 bg-rose-50/70 border border-rose-150 rounded-lg text-rose-905 text-[10.5px] font-medium flex items-center gap-1.5">
                                          <Trash2 className="w-4 h-4 text-rose-605 shrink-0" />
                                          <span><strong>Document Removal authorized.</strong> No download/upload preparation file is required. Direct submit to QA Stage-2 is enabled.</span>
                                        </div>
                                      ) : doc.uploadedUrl &&
                                        (canDownloadThisDoc ? (
                                          <div className="flex flex-col gap-1">
                                            <div className="mt-1 pt-1.5 border-t border-slate-100 flex items-center justify-between gap-1">
                                              <div className="flex items-center gap-1.5 text-emerald-700 font-medium font-sans animate-fade-in">
                                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                                                <span className="text-[10.5px]">
                                                  Accepted Template Copy
                                                  Available
                                                </span>
                                                {doc.uploadedFileName && (
                                                  <span
                                                    className="block text-[10px] font-mono text-indigo-700 font-semibold truncate max-w-[200px]"
                                                    title={doc.uploadedFileName}
                                                  >
                                                    File: {doc.uploadedFileName}
                                                  </span>
                                                )}
                                              </div>
                                              <a
                                                href={doc.uploadedUrl}
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                download={
                                                  doc.uploadedFileName ||
                                                  doc.docNumber
                                                }
                                                onClick={() =>
                                                  setLocalDownloadedIds(
                                                    (prev) =>
                                                      Array.from(
                                                        new Set([
                                                          ...prev,
                                                          doc.docNumber +
                                                            (doc.addedByDept ||
                                                              ""),
                                                        ]),
                                                      ),
                                                  )
                                                }
                                                className={`inline-flex items-center gap-1.5 px-2.5 py-1 ${localDownloadedIds.includes(doc.docNumber + (doc.addedByDept || "")) ? "bg-indigo-50 border-indigo-200 text-indigo-700" : "bg-emerald-50 border-emerald-200 text-emerald-700"} hover:bg-emerald-100 rounded font-bold transition-all text-[10px] cursor-pointer`}
                                              >
                                                <Download className="w-3.5 h-3.5" />
                                                <span>Download</span>
                                              </a>
                                            </div>
                                            {/* Sub-workflow Stage Wizard Card */}
                                            <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 mt-1 space-y-2 text-[11px]">
                                              {(!doc.workflowStatus || doc.workflowStatus === "Downloaded" || doc.workflowStatus === "ReviewRejected" || doc.workflowStatus === "ApprovalRejected") ? (
                                                <div className="space-y-2">
                                                  <div className="flex items-center justify-between border-b pb-1.5 mb-1.5">
                                                    <span className="text-[10px] font-sans font-bold text-indigo-900 uppercase tracking-widest flex items-center gap-1">
                                                      📂 {doc.workflowStatus === "ReviewRejected" ? "Review Rejected (Feedback Received)" : doc.workflowStatus === "ApprovalRejected" ? "Approval Rejected" : "Submit Updated Revision Draft"}
                                                    </span>
                                                    <span className="px-2 py-0.2 bg-amber-100 text-amber-800 font-bold font-mono text-[9px] border border-amber-200 rounded-sm">
                                                      Action Required
                                                    </span>
                                                  </div>

                                                  {doc.workflowStatus === "ReviewRejected" && doc.reviewerComments && (
                                                    <div className="p-2 bg-rose-50 border border-rose-100 rounded text-rose-900 italic text-[10px]">
                                                      <strong>Reviewer Rejection Comments:</strong> "{doc.reviewerComments}"
                                                    </div>
                                                  )}

                                                  {doc.workflowStatus === "ApprovalRejected" && doc.approverComments && (
                                                    <div className="p-2 bg-rose-50 border border-rose-100 rounded text-rose-900 italic text-[10px]">
                                                      <strong>Approver Rejection Comments:</strong> "{doc.approverComments}"
                                                    </div>
                                                  )}

                                                  <div>
                                                    <label className="block text-[9px] font-mono font-bold text-slate-550 uppercase mb-1">1. Choose Designated Reviewer</label>
                                                    <select
                                                      className="w-full text-[10.5px] border border-slate-250 rounded p-1.5 bg-white font-sans text-slate-800"
                                                      value={revisionReviewerIds[req.id + "_" + doc.docNumber] || ""}
                                                      onChange={(e) => setRevisionReviewerIds((prev) => ({ ...prev, [req.id + "_" + doc.docNumber]: e.target.value }))}
                                                    >
                                                      <option value="">-- Click to Select Reviewer --</option>
                                                      {users.filter((u) => u.isReviewer).map((u) => (
                                                        <option key={u.id} value={u.id}>
                                                          {u.name} ({u.department || "QA"} Dept)
                                                        </option>
                                                      ))}
                                                    </select>
                                                  </div>

                                                  <div>
                                                    <label className="block text-[9px] font-mono font-bold text-slate-550 uppercase mb-1">2. Upload Updated Document Copy</label>
                                                    <input
                                                      type="file"
                                                      className="w-full text-[10.5px] p-1 border border-dashed border-slate-350 rounded bg-white font-mono cursor-pointer text-slate-650"
                                                      onChange={async (e) => {
                                                        if (e.target.files && e.target.files[0]) {
                                                          const file = e.target.files[0];
                                                          setRevisionFileNames((prev) => ({ ...prev, [req.id + "_" + doc.docNumber]: file.name }));
                                                          try {
                                                            const res = await uploadFileToServer(file);
                                                            if (res.success) {
                                                              setRevisionFileUrls((prev) => ({ ...prev, [req.id + "_" + doc.docNumber]: res.url }));
                                                            }
                                                          } catch (err) {
                                                            console.error("DCRN upload failed:", err);
                                                          }
                                                        }
                                                      }}
                                                    />
                                                  </div>

                                                  <button
                                                    onClick={() => {
                                                      const revId = revisionReviewerIds[req.id + "_" + doc.docNumber];
                                                      const fileName = revisionFileNames[req.id + "_" + doc.docNumber] || `${doc.docNumber}_Revised_Draft.docx`;
                                                      const fileUrl = revisionFileUrls[req.id + "_" + doc.docNumber] || `/vault/revision/${fileName}`;
                                                      if (!revId) {
                                                        alert("Validation: Please select a reviewer to submit your revised document under FDA CFR rules.");
                                                        return;
                                                      }
                                                      const reviewerUser = users.find((u) => u.id === revId);
                                                      const revName = reviewerUser ? reviewerUser.name : revId;

                                                      if (onUpdateDcrnDocumentField) {
                                                        onUpdateDcrnDocumentField(
                                                          req.id,
                                                          doc.docNumber,
                                                          {
                                                            workflowStatus: "PendingReview",
                                                            assignedReviewerId: revId,
                                                            assignedReviewerName: revName,
                                                            updatedDocUrl: fileUrl,
                                                            updatedDocName: fileName,
                                                            uploadedAt: new Date().toISOString(),
                                                            preparedAt: new Date().toISOString()
                                                          },
                                                          "DCRN_REVISION_SUBMITTED",
                                                          `Revision document "${fileName}" submitted to Reviewer "${revName}" for evaluation under DCRN "${req.id}".`
                                                        );
                                                        setRevisionReviewerIds((prev) => ({ ...prev, [req.id + "_" + doc.docNumber]: "" }));
                                                        setRevisionFileNames((prev) => ({ ...prev, [req.id + "_" + doc.docNumber]: "" }));
                                                        setRevisionFileUrls((prev) => ({ ...prev, [req.id + "_" + doc.docNumber]: "" }));
                                                      }

                                                    }}
                                                    className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-[11px] rounded-md font-bold transition-all shadow-2xs hover:shadow-xs cursor-pointer text-center"
                                                  >
                                                    Submit Revision to Reviewer Workspace
                                                  </button>
                                                </div>
                                              ) : (
                                                <div className="space-y-2 bg-white p-2.5 rounded-lg border border-slate-200">
                                                  {doc.workflowStatus === "PendingReview" && (
                                                    <div className="space-y-1.5">
                                                      <div className="flex items-center gap-1.5 text-amber-700 font-bold">
                                                        <Clock className="w-3.5 h-3.5 animate-spin text-amber-500 shrink-0" />
                                                        <span>Awaiting Reviewer Board Evaluation</span>
                                                      </div>
                                                      <div className="text-[10px] text-slate-600 bg-slate-50 p-2 rounded leading-relaxed">
                                                        <strong>Current Reviewer:</strong> {doc.assignedReviewerName} <br />
                                                        <strong>Draft file:</strong> <span className="font-mono text-indigo-700 font-bold">{doc.updatedDocName}</span>
                                                      </div>
                                                      <a
                                                        href={doc.updatedDocUrl}
                                                        target="_blank"
                                                        rel="noreferrer"
                                                        className="inline-flex items-center gap-1 text-[9.5px] font-bold text-indigo-600 hover:underline"
                                                      >
                                                        <Download className="w-3 h-3" />
                                                        Download Submitted Draft
                                                      </a>
                                                    </div>
                                                  )}

                                                  {doc.workflowStatus === "ReviewAccepted" && (
                                                    <div className="space-y-1.5">
                                                      <div className="flex items-center gap-1.5 text-emerald-700 font-bold">
                                                        <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                                                        <span>Review Passed & Verified!</span>
                                                      </div>
                                                      <p className="text-[10px] text-slate-600 leading-relaxed">
                                                        Your draft revision has been accepted by Reviewer <strong>{doc.assignedReviewerName}</strong>. 
                                                        He/she can now upload a verified copy and forward it to an Approver for final sign-off.
                                                      </p>
                                                    </div>
                                                  )}

                                                  {doc.workflowStatus === "PendingApproval" && (
                                                    <div className="space-y-1.5">
                                                      <div className="flex items-center gap-1.5 text-blue-700 font-bold">
                                                        <Clock className="w-3.5 h-3.5 animate-pulse text-blue-500 shrink-0" />
                                                        <span>Awaiting Approver Vault Sign-off</span>
                                                      </div>
                                                      <div className="text-[10px] text-slate-600 bg-slate-50 p-2 rounded leading-relaxed">
                                                        <strong>Current Approver:</strong> {doc.assignedApproverName} <br />
                                                        <strong>Verified file:</strong> <span className="font-mono text-blue-700 font-bold">{doc.reviewedDocName}</span>
                                                      </div>
                                                      <a
                                                        href={doc.reviewedDocUrl}
                                                        target="_blank"
                                                        rel="noreferrer"
                                                        className="inline-flex items-center gap-1 text-[9.5px] font-bold text-blue-600 hover:underline"
                                                      >
                                                        <Download className="w-3 h-3" />
                                                        Download Verified Draft
                                                      </a>
                                                    </div>
                                                  )}

                                                  {doc.workflowStatus === "ApprovalAccepted" && (
                                                    <div className="bg-emerald-50 border border-emerald-250 p-2.5 rounded-lg space-y-1.5 text-emerald-950">
                                                      <div className="flex items-center gap-1.5 font-bold">
                                                        <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 shadow-3xs animate-bounce" />
                                                        <div className="flex flex-col">
                                                          <span className="font-bold text-[11px]">🎉 Final Approve</span>
                                                          <span className="text-[9px] font-mono text-emerald-750 font-bold">Approved By {doc.assignedApproverName}</span>
                                                        </div>
                                                      </div>
                                                      <p className="text-[10px] leading-relaxed">
                                                        This document is fully authorized with secure electronic signatures and is now operational.
                                                      </p>
                                                      <div className="pt-2 border-t border-emerald-150 flex items-center justify-between gap-1.5">
                                                        <span className="font-mono font-bold text-[9px] truncate max-w-[160px]">{doc.approvedDocName}</span>
                                                        {(() => {
                                                          const isDownloaded = localDownloadedIds.includes(doc.docNumber) || 
                                                            localDownloadedIds.includes(doc.docNumber + (doc.addedByDept || ""));
                                                          return (
                                                            <a
                                                              href={doc.approvedDocUrl}
                                                              target="_blank"
                                                              rel="noopener noreferrer"
                                                              download={doc.approvedDocName || doc.docNumber}
                                                              onClick={() => {
                                                                setLocalDownloadedIds((prev) => Array.from(new Set([...prev, doc.docNumber + (doc.addedByDept || "")])));
                                                              }}
                                                              className={`inline-flex items-center gap-1 px-2.5 py-1 ${isDownloaded ? 'bg-indigo-600 hover:bg-indigo-700' : 'bg-emerald-750 hover:bg-emerald-850'} text-white text-[9px] font-bold rounded shadow-3xs transition-all cursor-pointer shrink-0`}
                                                            >
                                                              <Download className="w-3 h-3" />
                                                              <span>{isDownloaded ? 'Download Approved Copy Again' : 'Download Approved Copy'}</span>
                                                            </a>
                                                          );
                                                        })()}
                                                      </div>
                                                    </div>
                                                  )}
                                                </div>
                                              )}
                                            </div>
                                          </div>
                                        ) : (
                                          <div className="mt-1 pt-1.5 border-t border-slate-100 flex items-center justify-between gap-1 text-[10.5px]">
                                            <div className="flex items-center gap-1.5 text-slate-450 font-medium font-sans">
                                              <XCircle className="w-3.5 h-3.5 text-slate-350 shrink-0" />
                                              <span>
                                                Accepted Copy Uploaded
                                                (Restricted)
                                              </span>
                                            </div>
                                            <span className="bg-slate-100 text-slate-400 px-1.5 py-0.2 rounded font-bold text-[9px] cursor-not-allowed">
                                              RESTRICTED
                                            </span>
                                          </div>
                                        ))}
                                    </div>
                                  );
                                })}
                            </div>
                          </div>

                          {/* Impacted section */}
                          {req.assessments &&
                            Object.entries(req.assessments).some(
                              ([code, ass]) =>
                                code !== "PK" &&
                                code !== (req.preparedBy?.department || "") &&
                                (ass.impacted === "Yes" ||
                                  req.initialDocs.some(
                                    (d) => d.addedByDept === code,
                                  )),
                            ) && (
                              <div className="space-y-3 pt-2 border-t border-slate-200">
                                <h6 className="text-[9px] font-mono text-amber-800 uppercase font-bold">
                                  Impacted Departments
                                </h6>
                                {Object.entries(req.assessments).map(
                                  ([code, ass]) => {
                                    if (
                                      code === "PK" ||
                                      code ===
                                        (req.preparedBy?.department || "")
                                    )
                                      return null;
                                    const deptDocs = req.initialDocs.filter(
                                      (d) => d.addedByDept === code,
                                    );
                                    const isDeptImpacted =
                                      ass.impacted === "Yes" ||
                                      deptDocs.length > 0;
                                    const docsToRenderRaw =
                                      deptDocs.length > 0
                                        ? deptDocs
                                        : (ass.documents || []);
                                    const docsToRender = docsToRenderRaw.map((pDoc) => {
                                      const latest = req.initialDocs.find((d) => d.docNumber === pDoc.docNumber);
                                      return latest || pDoc;
                                    });

                                    if (
                                      isDeptImpacted &&
                                      docsToRender.length > 0
                                    ) {
                                      return (
                                        <div key={code} className="space-y-1">
                                          <p className="text-[9px] font-medium text-slate-500 bg-slate-100 p-0.5 rounded px-1.5">
                                            {DEPARTMENT_MAP[code] || code}
                                          </p>
                                          <div className="bg-slate-50 border rounded-lg p-3 space-y-2.5 divide-y divide-slate-150 pl-2">
                                            {docsToRender.map((doc, docIdx) => {
                                              const isUserPreparerOfDcrn = currentUser.id === req.preparedBy?.userId || currentUser.department === req.preparedBy?.department;
                                              const isAssignedAuditor = currentUser.id === doc.assignedReviewerId || currentUser.id === doc.assignedApproverId;
                                              const targetDept = doc.addedByDept || code;
                                              const isImpactedDoc = targetDept !== req.preparedBy?.department;

                                              let canDownloadThisDoc = false;
                                              if (isAssignedAuditor) {
                                                canDownloadThisDoc = true;
                                              } else if (isImpactedDoc) {
                                                if (isUserPreparerOfDcrn) {
                                                  canDownloadThisDoc = false;
                                                } else if (currentUser.department === targetDept) {
                                                  canDownloadThisDoc = true;
                                                } else {
                                                  canDownloadThisDoc = false;
                                                }
                                              } else {
                                                if (isUserPreparerOfDcrn) {
                                                  canDownloadThisDoc = true;
                                                } else {
                                                  canDownloadThisDoc = false;
                                                }
                                              }
                                              return (
                                                <div
                                                  key={docIdx}
                                                  className="first:pt-0 pt-2 font-sans flex flex-col gap-2"
                                                >
                                                  <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-1">
                                                    <span className="font-bold text-amber-850 font-mono w-full sm:w-1/4 flex flex-col gap-1 items-start">
                                                      {renderDocWorkflowStatusBadge(doc)}
                                                      <span>
                                                        📄 {doc.docNumber} (Rev:{" "}
                                                        {doc.currentRevision ||
                                                          "-"}{" "}
                                                        →{" "}
                                                        {doc.nextRevision || "-"}){" "}
                                                        {doc.title && (
                                                          <span className="text-[10px] text-amber-900 font-bold bg-amber-100 border border-amber-200 rounded px-1.5 py-0.2 mx-1 inline-block font-sans">
                                                            Title: {doc.title}
                                                          </span>
                                                        )}
                                                        <span className="text-[9px] font-sans font-normal text-slate-500">
                                                          [
                                                          {doc.actionType ||
                                                            "Change"}
                                                          ]
                                                        </span>
                                                      </span>
                                                    </span>
                                                    <span className="text-slate-650 w-full sm:w-3/8">
                                                      <strong className="text-slate-400 font-normal">
                                                        "Reason:"
                                                      </strong>{" "}
                                                      {doc.reasonForChange}
                                                    </span>
                                                    <span className="text-slate-650 w-full sm:w-3/8">
                                                      <strong className="text-slate-400 font-normal">
                                                        Proposed Change:
                                                      </strong>{" "}
                                                      {doc.changesRequired}
                                                    </span>
                                                  </div>
                                                  {doc.actionType === "Removal" ? (
                                                    <div className="mt-2 p-2.5 bg-rose-50/70 border border-rose-150 rounded-lg text-rose-905 text-[10.5px] font-medium flex items-center gap-1.5">
                                                      <Trash2 className="w-4 h-4 text-rose-605 shrink-0" />
                                                      <span><strong>Document Removal authorized.</strong> No download/upload preparation file is required. Direct submit to QA Stage-2 is enabled.</span>
                                                    </div>
                                                  ) : doc.uploadedUrl && (
                                                    canDownloadThisDoc ? (
                                                      <div className="flex flex-col gap-2 mt-1 pt-2 border-t border-slate-100">
                                                        {/* Name of document is visible before the download button for both preparer and impacted departments */}
                                                        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 bg-emerald-50/40 p-2.5 rounded-lg border border-emerald-100 shadow-3xs">
                                                          <div className="flex flex-col gap-0.5">
                                                            <span className="text-[9.5px] font-mono font-bold text-emerald-850 uppercase tracking-wider flex items-center gap-1">
                                                              <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0" />
                                                              Accepted Template Available
                                                            </span>
                                                            <span className="text-[11px] font-mono font-bold text-indigo-750 truncate max-w-[260px]" title={doc.uploadedFileName || doc.docNumber}>
                                                              Document Name: {doc.uploadedFileName || doc.docNumber}
                                                            </span>
                                                          </div>
                                                          <a
                                                            href={doc.uploadedUrl}
                                                            target="_blank"
                                                            rel="noopener noreferrer"
                                                            download={doc.uploadedFileName || doc.docNumber}
                                                            onClick={() => {
                                                              setLocalDownloadedIds((prev) => Array.from(new Set([...prev, doc.docNumber + (doc.addedByDept || "")])));
                                                              if (onUpdateDcrnDocumentField && (!doc.workflowStatus || (doc.workflowStatus as string) === "None")) {
                                                                onUpdateDcrnDocumentField(
                                                                  req.id,
                                                                  doc.docNumber,
                                                                  { workflowStatus: "Downloaded" },
                                                                  "DCRN_DOCUMENT_DOWNLOADED",
                                                                  `Downloaded MR approved template for document "${doc.docNumber}" in DCRN ID "${req.id}".`
                                                                );
                                                              }
                                                            }}
                                                            className={`inline-flex items-center gap-1 px-3 py-1 text-[10px] font-bold rounded shadow-3xs cursor-pointer transition-all shrink-0 ${
                                                              localDownloadedIds.includes(doc.docNumber + (doc.addedByDept || "")) || doc.workflowStatus
                                                                ? "bg-slate-100 border border-slate-300 text-slate-700" 
                                                                : "bg-emerald-600 hover:bg-emerald-700 text-white"
                                                            }`}
                                                          >
                                                            <Download className="w-3.5 h-3.5" />
                                                            <span>Download Document</span>
                                                          </a>
                                                        </div>

                                                        {/* Sub-workflow Stage Wizard Card */}
                                                        <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 mt-1 space-y-2 text-[11px]">
                                                          {(!doc.workflowStatus || doc.workflowStatus === "Downloaded" || doc.workflowStatus === "ReviewRejected" || doc.workflowStatus === "ApprovalRejected") ? (
                                                            <div className="space-y-2">
                                                              <div className="flex items-center justify-between border-b pb-1.5 mb-1.5">
                                                                <span className="text-[10px] font-sans font-bold text-indigo-900 uppercase tracking-widest flex items-center gap-1">
                                                                  📂 {doc.workflowStatus === "ReviewRejected" ? "Review Rejected (Feedback Received)" : doc.workflowStatus === "ApprovalRejected" ? "Approval Rejected" : "Submit Updated Revision Draft"}
                                                                </span>
                                                                <span className="px-2 py-0.2 bg-amber-100 text-amber-800 font-bold font-mono text-[9px] border border-amber-200 rounded-sm">
                                                                  Action Required
                                                                </span>
                                                              </div>

                                                              {doc.workflowStatus === "ReviewRejected" && doc.reviewerComments && (
                                                                <div className="p-2 bg-rose-50 border border-rose-100 rounded text-rose-900 italic text-[10px]">
                                                                  <strong>Reviewer Rejection Comments:</strong> "{doc.reviewerComments}"
                                                                </div>
                                                              )}

                                                              {doc.workflowStatus === "ApprovalRejected" && doc.approverComments && (
                                                                <div className="p-2 bg-rose-50 border border-rose-100 rounded text-rose-900 italic text-[10px]">
                                                                  <strong>Approver Rejection Comments:</strong> "{doc.approverComments}"
                                                                </div>
                                                              )}

                                                              <div>
                                                                <label className="block text-[9px] font-mono font-bold text-slate-550 uppercase mb-1">1. Choose Designated Reviewer</label>
                                                                <select
                                                                  className="w-full text-[10.5px] border border-slate-250 rounded p-1.5 bg-white font-sans text-slate-800 font-medium"
                                                                  value={revisionReviewerIds[req.id + "_" + doc.docNumber] || ""}
                                                                  onChange={(e) => setRevisionReviewerIds((prev) => ({ ...prev, [req.id + "_" + doc.docNumber]: e.target.value }))}
                                                                >
                                                                  <option value="">-- Click to Select Reviewer --</option>
                                                                  {users.filter((u) => u.isReviewer).map((u) => (
                                                                    <option key={u.id} value={u.id}>
                                                                      {u.name} ({u.department || "QA"} Dept)
                                                                    </option>
                                                                  ))}
                                                                </select>
                                                              </div>

                                                              <div>
                                                                <label className="block text-[9px] font-mono font-bold text-slate-550 uppercase mb-1">2. Upload Updated Document Copy</label>
                                                                <input
                                                                  type="file"
                                                                  className="w-full text-[10.5px] p-1 border border-dashed border-slate-350 rounded bg-white font-mono cursor-pointer text-slate-650"
                                                                  onChange={async (e) => {
                                                                    if (e.target.files && e.target.files[0]) {
                                                                      const file = e.target.files[0];
                                                                      setRevisionFileNames((prev) => ({ ...prev, [req.id + "_" + doc.docNumber]: file.name }));
                                                                      try {
                                                                        const res = await uploadFileToServer(file);
                                                                        if (res.success) {
                                                                          setRevisionFileUrls((prev) => ({ ...prev, [req.id + "_" + doc.docNumber]: res.url }));
                                                                        }
                                                                      } catch (err) {
                                                                        console.error("DCRN upload failed:", err);
                                                                      }
                                                                    }
                                                                  }}
                                                                />
                                                              </div>

                                                              <button
                                                                onClick={() => {
                                                                  const revId = revisionReviewerIds[req.id + "_" + doc.docNumber];
                                                                  const fileName = revisionFileNames[req.id + "_" + doc.docNumber] || `${doc.docNumber}_Revised_Draft.docx`;
                                                                  const fileUrl = revisionFileUrls[req.id + "_" + doc.docNumber] || `/vault/revision/${fileName}`;
                                                                  if (!revId) {
                                                                    alert("Validation: Please select a reviewer to submit your revised document under FDA CFR rules.");
                                                                    return;
                                                                  }
                                                                  const reviewerUser = users.find((u) => u.id === revId);
                                                                  const revName = reviewerUser ? reviewerUser.name : revId;

                                                                  if (onUpdateDcrnDocumentField) {
                                                                    onUpdateDcrnDocumentField(
                                                                      req.id,
                                                                      doc.docNumber,
                                                                      {
                                                                        workflowStatus: "PendingReview",
                                                                        assignedReviewerId: revId,
                                                                        assignedReviewerName: revName,
                                                                        updatedDocUrl: fileUrl,
                                                                        updatedDocName: fileName,
                                                                        uploadedAt: new Date().toISOString(),
                                                                        preparedAt: new Date().toISOString()
                                                                      },
                                                                      "DCRN_REVISION_SUBMITTED",
                                                                      `Revision document "${fileName}" submitted to Reviewer "${revName}" for evaluation under DCRN "${req.id}".`
                                                                    );
                                                                    setRevisionReviewerIds((prev) => ({ ...prev, [req.id + "_" + doc.docNumber]: "" }));
                                                                    setRevisionFileNames((prev) => ({ ...prev, [req.id + "_" + doc.docNumber]: "" }));
                                                                    setRevisionFileUrls((prev) => ({ ...prev, [req.id + "_" + doc.docNumber]: "" }));
                                                                  }
                                                                }}
                                                                className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-[11px] rounded-md font-bold transition-all shadow-2xs hover:shadow-xs cursor-pointer text-center"
                                                              >
                                                                Submit Revision to Reviewer Workspace
                                                              </button>
                                                            </div>
                                                          ) : (
                                                            <div className="space-y-2 bg-white p-2.5 rounded-lg border border-slate-200">
                                                              {doc.workflowStatus === "PendingReview" && (
                                                                <div className="space-y-1.5 flex flex-col">
                                                                  <div className="flex items-center gap-1.5 text-amber-700 font-bold">
                                                                    <Clock className="w-3.5 h-3.5 animate-spin text-amber-500 shrink-0" />
                                                                    <span>Awaiting Reviewer Board Evaluation</span>
                                                                  </div>
                                                                  <div className="text-[10px] text-slate-600 bg-slate-50 p-2 rounded leading-relaxed">
                                                                    <strong>Current Reviewer:</strong> {doc.assignedReviewerName} <br />
                                                                    <strong>Draft file:</strong> <span className="font-mono text-indigo-700 font-bold">{doc.updatedDocName}</span>
                                                                  </div>
                                                                  {isUserPreparerOfDcrn && isImpactedDoc ? (
                                                                    <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-slate-100 text-slate-400 border border-slate-200 text-[9.5px] font-bold rounded cursor-not-allowed select-none w-fit">
                                                                      <XCircle className="w-3 h-3 text-slate-350 shrink-0" />
                                                                      <span>Download Submitted Draft (Restricted)</span>
                                                                    </span>
                                                                  ) : (
                                                                    <a
                                                                      href={doc.updatedDocUrl}
                                                                      target="_blank"
                                                                      rel="noreferrer"
                                                                      className="inline-flex items-center gap-1 text-[9.5px] font-bold text-indigo-600 hover:underline w-fit"
                                                                    >
                                                                      <Download className="w-3" />
                                                                      Download Submitted Draft
                                                                    </a>
                                                                  )}
                                                                </div>
                                                              )}

                                                              {doc.workflowStatus === "ReviewAccepted" && (
                                                                <div className="space-y-1.5">
                                                                  <div className="flex items-center gap-1.5 text-emerald-700 font-bold">
                                                                    <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                                                                    <span>Review Passed & Verified!</span>
                                                                  </div>
                                                                  <p className="text-[10px] text-slate-600 leading-relaxed">
                                                                    Your draft revision has been accepted by Reviewer <strong>{doc.assignedReviewerName}</strong>. 
                                                                    He/she can now upload a verified copy and forward it to an Approver for final sign-off.
                                                                  </p>
                                                                </div>
                                                              )}

                                                              {doc.workflowStatus === "PendingApproval" && (
                                                                <div className="space-y-1.5 flex flex-col">
                                                                  <div className="flex items-center gap-1.5 text-blue-700 font-bold">
                                                                    <Clock className="w-3.5 h-3.5 animate-pulse text-blue-500 shrink-0" />
                                                                    <span>Awaiting Approver Vault Sign-off</span>
                                                                  </div>
                                                                  <div className="text-[10px] text-slate-600 bg-slate-50 p-2 rounded leading-relaxed">
                                                                    <strong>Current Approver:</strong> {doc.assignedApproverName} <br />
                                                                    <strong>Verified file:</strong> <span className="font-mono text-blue-700 font-bold">{doc.reviewedDocName}</span>
                                                                  </div>
                                                                  {isUserPreparerOfDcrn && isImpactedDoc ? (
                                                                    <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-slate-100 text-slate-400 border border-slate-200 text-[9.5px] font-bold rounded cursor-not-allowed select-none w-fit">
                                                                      <XCircle className="w-3.5 h-3.5 text-slate-350 shrink-0" />
                                                                      <span>Download Verified Draft (Restricted)</span>
                                                                    </span>
                                                                  ) : (
                                                                    <a
                                                                      href={doc.reviewedDocUrl}
                                                                      target="_blank"
                                                                      rel="noreferrer"
                                                                      className="inline-flex items-center gap-1 text-[9.5px] font-bold text-blue-600 hover:underline w-fit"
                                                                    >
                                                                      <Download className="w-3 h-3" />
                                                                      Download Verified Draft
                                                                    </a>
                                                                  )}
                                                                </div>
                                                              )}

                                                              {doc.workflowStatus === "ApprovalAccepted" && (
                                                                <div className="bg-emerald-50 border border-emerald-250 p-2.5 rounded-lg space-y-1.5 text-emerald-950">
                                                                  <div className="flex items-center gap-1.5 font-bold">
                                                                    <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 shadow-3xs animate-bounce" />
                                                                    <div className="flex flex-col">
                                                                      <span className="font-bold text-[11px]">🎉 Final Approve</span>
                                                                      <span className="text-[9px] font-mono text-emerald-750 font-bold">Approved By {doc.assignedApproverName}</span>
                                                                    </div>
                                                                  </div>
                                                                  <p className="text-[10px] leading-relaxed">
                                                                    This document is fully authorized with secure electronic signatures and is now operational.
                                                                  </p>
                                                                  <div className="pt-2 border-t border-emerald-150 flex items-center justify-between gap-1.5">
                                                                    <span className="font-mono font-bold text-[9px] truncate max-w-[160px]">{doc.approvedDocName}</span>
                                                                    {isUserPreparerOfDcrn && isImpactedDoc ? (
                                                                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-slate-100 text-slate-400 border border-slate-200 text-[9px] font-bold rounded cursor-not-allowed select-none shrink-0 shadow-3xs">
                                                                        <XCircle className="w-3.5 h-3.5 text-slate-350 shrink-0" />
                                                                        <span>Download Official Copy (Restricted)</span>
                                                                      </span>
                                                                    ) : (
                                                                      (() => {
                                                                        const isDownloaded = localDownloadedIds.includes(doc.docNumber) || 
                                                                          localDownloadedIds.includes(doc.docNumber + (doc.addedByDept || ""));
                                                                        return (
                                                                          <a
                                                                            href={doc.approvedDocUrl}
                                                                            target="_blank"
                                                                            rel="noopener noreferrer"
                                                                            download={doc.approvedDocName || doc.docNumber}
                                                                            onClick={() => {
                                                                              setLocalDownloadedIds((prev) => Array.from(new Set([...prev, doc.docNumber + (doc.addedByDept || "")])));
                                                                            }}
                                                                            className={`inline-flex items-center gap-1 px-2.5 py-1 ${isDownloaded ? 'bg-indigo-600 hover:bg-indigo-700' : 'bg-emerald-750 hover:bg-emerald-850'} text-white text-[9px] font-bold rounded shadow-3xs transition-all cursor-pointer shrink-0`}
                                                                          >
                                                                            <Download className="w-3 h-3" />
                                                                            <span>{isDownloaded ? 'Download Approved Copy Again' : 'Download Approved Copy'}</span>
                                                                          </a>
                                                                        );
                                                                      })()
                                                                    )}
                                                                  </div>
                                                                </div>
                                                              )}
                                                            </div>
                                                          )}
                                                        </div>
                                                      </div>
                                                    ) : (
                                                      <div className="mt-1 pt-1.5 border-t border-slate-100 flex items-center justify-between gap-1 text-[10.5px]">
                                                        <div className="flex items-center gap-1.5 text-slate-450 font-medium font-sans">
                                                          <XCircle className="w-3.5 h-3.5 text-slate-350 shrink-0" />
                                                          <span>
                                                            Accepted Copy Uploaded
                                                            (Restricted)
                                                          </span>
                                                        </div>
                                                        <span className="bg-slate-100 text-slate-400 px-1.5 py-0.2 rounded font-bold text-[9px] cursor-not-allowed">
                                                          RESTRICTED
                                                        </span>
                                                      </div>
                                                    )
                                                  )}
                                                </div>
                                               );
                                             })}
                                            </div>
                                          </div>
                                      );
                                    }
                                    return null;
                                  },
                                )}
                              </div>
                            )}
                        </div>

                        {/* Audit Details */}
                        {req.status === "Completed" && req.mrAuthorizedBy && (
                          <div className="border border-indigo-150/80 p-2 text-[11px] rounded bg-indigo-50/40 text-slate-700 font-sans">
                            <strong className="text-[10px] text-indigo-700 uppercase font-mono block mb-0.5">
                              Acceptative MR Ledger Lock:
                            </strong>
                            {!isPreparerBoard && "Validated under corporate document control standards. "}
                            {isPreparerBoard ? "DCRN number" : "Issued registry number"}:{" "}
                            <strong>{req.mrRegistryNumber}</strong>. {isPreparerBoard ? "Issued By" : "Accepted by"}{" "}
                            {req.mrAuthorizedBy.userName} at{" "}
                            {formatToIST(req.mrAuthorizedAt || "")} IST.
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Rich Text Editor Modal */}
      {textEditorOpen && (
        <div className="fixed inset-0 bg-slate-900/65 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white border border-slate-200 rounded-xl max-w-lg w-full shadow-2xl overflow-hidden flex flex-col">
            {/* Header */}
            <div className="bg-indigo-50 border-b border-indigo-100 p-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-indigo-600 animate-bounce" />
                <span className="font-bold text-slate-800 text-sm">
                  Detailed Input: {textEditorTitle}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setTextEditorOpen(false)}
                className="text-slate-400 hover:text-slate-600 hover:bg-slate-100 w-6 h-6 flex items-center justify-center rounded-full transition-colors font-mono font-bold text-xs"
              >
                ✕
              </button>
            </div>

            {/* Body */}
            <div className="p-4 flex-1">
              <p className="text-[11px] text-slate-500 mb-2">
                Type or paste your detailed specifications, reason for modification, or proposed guidelines below. Press "Save & Apply" when finished.
              </p>
              <textarea
                rows={8}
                value={textEditorValue}
                onChange={(e) => setTextEditorValue(e.target.value)}
                placeholder={`Provide precise detailed context for ${textEditorTitle.toLowerCase()}...`}
                className="w-full bg-slate-50 border border-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 rounded-lg p-3 text-xs outline-none text-slate-800 leading-relaxed"
                autoFocus
              />
            </div>

            {/* Footer */}
            <div className="bg-slate-50 border-t p-3 flex justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setTextEditorOpen(false)}
                className="px-3.5 py-1.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-605 font-bold rounded-md text-xs cursor-pointer transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveTextEditor}
                className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-md text-xs cursor-pointer shadow-sm hover:scale-101 transition-all"
              >
                Save & Apply
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
