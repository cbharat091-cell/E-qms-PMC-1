import React, { useState } from 'react';
import { User } from '../types';
import { Shield, ShieldAlert, Lock, UserCheck, Key } from 'lucide-react';

interface LoginScreenProps {
  onLoginSuccess: (user: User) => void;
  users: User[];
  addAuditLog: (user: User, action: string, details: string) => void;
}

export default function LoginScreen({ onLoginSuccess, users, addAuditLog }: LoginScreenProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) {
      setError('Please enter your email address.');
      return;
    }

    const matchedUser = users.find(u => u.email.toLowerCase() === email.trim().toLowerCase());
    
    // 1. Admin Assignment Verification: Ensure the user's registry record exists
    if (!matchedUser) {
      setError('Unauthorized access: Employee record not found. Account must be officially provisioned by the Administrator.');
      return;
    }

    // 2. Registry Status Verification: Ensure the account is active
    if (matchedUser.isActive === false) {
      setError('Access Blocked: This corporate credential has been deactivated or is currently pending activation.');
      return;
    }

    // 3. Enforce Strict Password/Passcode Authentication
    // The password entered must exactly match the password registered in the user record.
    const expectedPassword = matchedUser.password || 'password123';
    if (password !== expectedPassword) {
      setError('Security Clearance Refused: Incorrect Access Key Signature Passcode.');
      return;
    }

    // 4. Client IP Security Policy: No geographic/IP lock filter is active.
    // The incoming network IP is recorded strictly for secure electronic logging in system ledger.
    const clientIpAddress = '192.168.1.18'; // Mock value depicting the client's current location-independent context
    addAuditLog(matchedUser, 'LOGIN_SUCCESS', `User session initiated from location-independent network Node (Audited IP: ${clientIpAddress})`);
    onLoginSuccess(matchedUser);
  };

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-4 selection:bg-blue-900 selection:text-blue-100 font-sans">
      <div className="w-full max-w-4xl grid md:grid-cols-12 gap-6 bg-slate-950 border border-slate-800 rounded-xl shadow-2xl overflow-hidden self-center my-auto transition-all">
        
        {/* Left Side: SECURE COMPLIANCE INFO PANEL (CFR Part 11 details) */}
        <div className="md:col-span-5 bg-gradient-to-br from-slate-950 to-slate-900 p-6 flex flex-col justify-between border-r border-slate-800 relative">
          <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
            <Lock className="w-48 h-48 text-white" />
          </div>

          <div className="relative">
            <div className="flex items-center gap-2 mb-6">
              <span className="p-1.5 bg-blue-600 rounded text-slate-100">
                <Shield className="w-5 h-5 text-white" />
              </span>
              <span className="font-mono tracking-wider font-bold text-white text-xs">PMC eQMS</span>
            </div>

            <h2 className="text-xl font-bold tracking-tight text-white mb-2">
              Controlled Access Environment
            </h2>
            <p className="text-xs text-slate-400 leading-relaxed mb-6">
              This terminal enforces access control standards outlined in corporate security policies and standard ISO 13485 computer system validations.
            </p>

            <div className="space-y-4">
              <div className="flex gap-3 items-start">
                <div className="p-1 px-1.5 bg-slate-800 rounded font-bold text-[10px] text-blue-400 font-mono mt-0.5 border border-slate-700">11.10</div>
                <div>
                  <h4 className="text-xs font-semibold text-slate-200">Electronic Signatures</h4>
                  <p className="text-[10.5px] text-slate-400 mt-0.5 leading-snug">Signatures are legally binding with written password authentication for all document Approvals.</p>
                </div>
              </div>

              <div className="flex gap-3 items-start">
                <div className="p-1 px-1.5 bg-slate-800 rounded font-bold text-[10px] text-blue-400 font-mono mt-0.5 border border-slate-700">11.10b</div>
                <div>
                  <h4 className="text-xs font-semibold text-slate-200">Immutable Audit Logs</h4>
                  <p className="text-[10.5px] text-slate-400 mt-0.5 leading-snug">All actions (role toggles, reviews, uploads, and signature consents) write permanent timestamped records.</p>
                </div>
              </div>

              <div className="flex gap-3 items-start">
                <div className="p-1 px-1.5 bg-slate-800 rounded font-bold text-[10px] text-blue-400 font-mono mt-0.5 border border-slate-700">11.10g</div>
                <div>
                  <h4 className="text-xs font-semibold text-slate-200">Authority Checks</h4>
                  <p className="text-[10.5px] text-slate-400 mt-0.5 leading-snug">Enforced segregation of duties prevents preparers from reviewing/approving their own uploaded documents.</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-amber-950/40 border border-amber-900/40 rounded p-3 mt-6 text-[10.5px] text-amber-400/95 flex gap-2 items-start">
            <ShieldAlert className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">SYSTEM WARNING:</span> Unauthorized entry attempts are logged. Continuous audit tracking is active.
            </div>
          </div>
        </div>

        {/* Right Side: LOGIN CONTROLS AND DEMO ACCELERATION */}
        <div className="md:col-span-7 p-6 md:p-8 flex flex-col justify-between bg-slate-950">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
              <div>
                <h1 className="text-lg font-bold text-slate-100 flex items-center gap-1.5">
                  Secure Desktop Node Login
                </h1>
                <p className="text-xs text-slate-400 mt-0.5">Please sign in with your corporate credential card.</p>
              </div>
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/40 border border-emerald-900/60 rounded px-2 py-0.5">
                ● ACTIVE
              </span>
            </div>

            {error && (
              <div className="p-3 bg-rose-950/50 border border-rose-900/80 rounded text-rose-300 text-xs mb-4 font-medium flex gap-2" id="login-error-alert">
                <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Corporate Email Address</label>
                <div className="relative">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => { setEmail(e.target.value); setError(''); }}
                    className="w-full bg-slate-900 border border-slate-800 focus:border-blue-500 rounded px-3 py-2 text-sm text-slate-100 placeholder-slate-500 outline-none transition-all pl-9"
                    placeholder="name@company.com"
                    id="login-email-input"
                  />
                  <span className="absolute left-3 top-2.5 text-slate-500">
                    <UserCheck className="w-4 h-4" />
                  </span>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-medium text-slate-300">Access Key Signature Passcode</label>
                  <span className="text-[10px] text-slate-500 pr-1">Required</span>
                </div>
                <div className="relative">
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => { setPassword(e.target.value); setError(''); }}
                    className="w-full bg-slate-900 border border-slate-800 focus:border-blue-500 rounded px-3 py-2 text-sm text-slate-100 placeholder-slate-500 outline-none transition-all pl-9"
                    placeholder="••••••••••••"
                    id="login-password-input"
                  />
                  <span className="absolute left-3 top-2.5 text-slate-500">
                    <Key className="w-4 h-4" />
                  </span>
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold py-2.5 px-4 rounded transition-all cursor-pointer flex items-center justify-center gap-2 border border-blue-400/20"
                id="btn-submit-login"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Verify Credential & Initialize Session</span>
              </button>
            </form>

            {/* Sandbox Quick Access Panel */}
            <div className="mt-8 pt-6 border-t border-slate-800">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-xs font-bold text-slate-350 flex items-center gap-1.5 uppercase tracking-wider font-mono">
                  <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></span>
                  Sandbox Quick Access Accounts
                </h3>
                <span className="text-[10px] text-slate-500 font-mono">Instant Simulation Login</span>
              </div>
              <p className="text-[11px] text-slate-400 mb-3.5 leading-relaxed">
                Click any pre-configured employee card to simulate multi-role workflows instantly without typing passwords.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-[280px] overflow-y-auto pr-1">
                {users.filter(u => u.isActive !== false).map((u) => {
                  return (
                    <button
                      key={u.id}
                      type="button"
                      onClick={() => {
                        setEmail(u.email);
                        setPassword(u.password || 'password123');
                        const clientIpAddress = '192.168.1.18';
                        addAuditLog(u, 'LOGIN_SUCCESS', `User session initiated via Sandbox Quick Access credential (Audited IP: ${clientIpAddress})`);
                        onLoginSuccess(u);
                      }}
                      className="text-left bg-slate-900 hover:bg-slate-850/80 border border-slate-800 hover:border-blue-800 rounded-lg p-2.5 transition-all flex flex-col justify-between group cursor-pointer active:scale-[0.98]"
                      id={`sandbox-login-${u.id}`}
                    >
                      <div className="flex items-center justify-between w-full gap-2">
                        <span className="text-xs font-bold text-slate-200 group-hover:text-blue-400 transition-colors truncate">
                          {u.name}
                        </span>
                        <span className="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded bg-slate-850 text-slate-400 uppercase border border-slate-750">
                          {u.department || 'QA'}
                        </span>
                      </div>
                      
                      <div className="text-[10.5px] text-slate-400 mt-1 truncate">
                        {u.jobTitle}
                      </div>

                      <div className="flex flex-wrap gap-1 mt-2">
                        {u.isAdmin && (
                          <span className="text-[8px] px-1 bg-red-950 text-red-300 border border-red-900/40 rounded font-mono font-bold">
                            Admin
                          </span>
                        )}
                        {u.isPreparer && (
                          <span className="text-[8px] px-1 bg-blue-950 text-blue-300 border border-blue-900/40 rounded font-mono font-bold">
                            Prep
                          </span>
                        )}
                        {u.isReviewer && (
                          <span className="text-[8px] px-1 bg-purple-950 text-purple-300 border border-purple-900/40 rounded font-mono font-bold">
                            Rev
                          </span>
                        )}
                        {u.isApprover && (
                          <span className="text-[8px] px-1 bg-emerald-950 text-emerald-300 border border-emerald-900/40 rounded font-mono font-bold">
                            App
                          </span>
                        )}
                        {u.isMR && (
                          <span className="text-[8px] px-1 bg-amber-950 text-amber-300 border border-amber-900/40 rounded font-mono font-bold">
                            MR
                          </span>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
