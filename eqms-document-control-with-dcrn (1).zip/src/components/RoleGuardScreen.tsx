import React from 'react';
import { User } from '../types';
import { ShieldAlert, Users, LogOut, ArrowRight, UserCheck } from 'lucide-react';

interface RoleGuardScreenProps {
  currentUser: User;
  onLogout: () => void;
}

export default function RoleGuardScreen({ currentUser, onLogout }: RoleGuardScreenProps) {
  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4 selection:bg-rose-950">
      <div className="max-w-md w-full bg-[#1e293b] rounded-lg border border-slate-700 shadow-xl p-6 md:p-8 text-center">
        <div className="mx-auto w-12 h-12 bg-amber-950/50 border border-amber-800 rounded-full flex items-center justify-center text-amber-500 mb-4 animate-bounce">
          <ShieldAlert className="w-6 h-6" />
        </div>
        
        <h2 className="text-lg font-bold text-white mb-2">
          Security Access Flag: NO_ROLE
        </h2>
        
        <div className="bg-slate-900 border border-slate-800 rounded-md p-3.5 mb-6 text-left">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-300 border-b border-slate-800 pb-2 mb-2">
            <UserCheck className="w-3.5 h-3.5 text-blue-400" />
            <span>Profile Identity Confirmed</span>
          </div>
          <div className="text-xs text-slate-400 font-mono space-y-1">
            <p><span className="text-slate-500">USER:</span> {currentUser.name}</p>
            <p><span className="text-slate-500">EMAIL:</span> {currentUser.email}</p>
            <p><span className="text-slate-500">ASSIGNED DEPT:</span> Operations Control</p>
          </div>
        </div>

        <p className="text-sm text-slate-200 font-medium mb-1">
          Account Active.
        </p>
        <p className="text-xs text-slate-400 leading-relaxed mb-6">
          Please contact your administrator to assign your eQMS roles.
        </p>

        <div className="space-y-2">
          <div className="p-3 bg-slate-900 rounded-lg text-left border border-slate-800 text-[11px] text-slate-400">
            <span className="font-bold text-amber-500 block mb-1">SYSTEM WORKSPACE POLICY:</span>
            Only authorized personnel assigned distinct procedural quality workflows (Prepare, Review, or Approve) are permitted to mount active workspaces.
          </div>

          <button
            onClick={onLogout}
            className="w-full bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold py-2 px-4 rounded transition-all cursor-pointer flex items-center justify-center gap-1.5"
            id="role-guard-back-to-login"
          >
            <LogOut className="w-4 h-4" />
            <span>Back to Login Window</span>
          </button>
        </div>
      </div>
    </div>
  );
}
