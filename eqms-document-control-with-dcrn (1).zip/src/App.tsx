/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  User, 
  DocumentWorkflow, 
  DocumentStatus, 
  DocumentCategory, 
  Department, 
  AuditTrailEntry, 
  SignatureLog,
  DocumentComment,
  DCRNRequest,
  DCRNDecDocument,
  DCRNDepartmentAssessment,
  DEPARTMENT_MAP
} from './types';
import { 
  generateChecksum, 
  INITIAL_USERS, 
  INITIAL_DOCUMENTS, 
  INITIAL_AUDIT_LOGS,
  PRE_ASSIGNED_EMPLOYEES_SEED
} from './data';

// Component imports
import DesktopHeader from './components/DesktopHeader';
import LoginScreen from './components/LoginScreen';
import RoleGuardScreen from './components/RoleGuardScreen';
import AdminPanel from './components/AdminPanel';
import PreparerWorkspace from './components/PreparerWorkspace';
import ReviewerWorkspace from './components/ReviewerWorkspace';
import ApproverWorkspace from './components/ApproverWorkspace';
import AuditTrailConsole from './components/AuditTrailConsole';
import DownloadVaultModal from './components/DownloadVaultModal';
import DocumentRequestQueue from './components/DocumentRequestQueue';
import DcrnWorkflow from './components/DcrnWorkflow';
import QaGatewayWorkspace from './components/QaGatewayWorkspace';
import { saveTextAsFileToServer } from './utils/localUpload';

// Icon imports
import { 
  ShieldAlert, 
  Users, 
  Lock, 
  FileStack, 
  Terminal, 
  RefreshCw, 
  LayoutDashboard, 
  BookmarkCheck,
  Building2,
  LockKeyholeOpen,
  Layers,
  Plus,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  MessageSquare,
  FileText
} from 'lucide-react';

// Helper to safely bootstrap user list with PRE_ASSIGNED_EMPLOYEES_SEED, ensuring database integrity and non-overwriting validation
function bootstrapUserList(rawList: User[]): User[] {
  const updatedUsers = [...rawList];

  // Boot Routine: Bulk profile initialization matching PRE_ASSIGNED_EMPLOYEES_SEED list
  PRE_ASSIGNED_EMPLOYEES_SEED.forEach((seedUser) => {
    const emailExists = updatedUsers.some(
      u => u.email.toLowerCase() === seedUser.email.toLowerCase()
    );
    if (!emailExists) {
      // Automatically default parameters during boot insertion
      const newUser: User = {
        ...seedUser,
        id: seedUser.id || 'usr_' + Math.floor(Math.random() * 900000 + 100000),
        createdAt: seedUser.createdAt || new Date().toISOString(),
        lastActive: seedUser.lastActive || new Date().toISOString(),
        isActive: seedUser.isActive !== false,
        assignedRoles: seedUser.assignedRoles || (
          [
            seedUser.isAdmin ? 'Admin' : null,
            seedUser.isPreparer ? 'Preparer' : null,
            seedUser.isReviewer ? 'Reviewer' : null,
            seedUser.isApprover ? 'Approver' : null,
          ].filter(Boolean) as ('Admin' | 'Preparer' | 'Reviewer' | 'Approver')[]
        )
      };
      updatedUsers.push(newUser);
    } else {
      // If the email already exists in storage, protect the existing password and details from overwrites,
      // but ensure vital attributes (like a baseline passcode if there isn't one already) exist.
      const index = updatedUsers.findIndex(u => u.email.toLowerCase() === seedUser.email.toLowerCase());
      if (index !== -1) {
        const existing = updatedUsers[index];
        updatedUsers[index] = {
          ...seedUser,                  // Default fields from seed
          ...existing,                  // Retain newer fields edited during system active sessions
          password: existing.password || seedUser.password || 'password123' // Keep existing password or fall back to seed
        };
      }
    }
  });

  // Enforce that Lead Executive Admin is always present
  const hasRbarot = updatedUsers.some(u => u.email.toLowerCase() === 'rbarot@premiermedcorp.com');
  if (!hasRbarot) {
    const rbarotUser: User = {
      id: 'usr_rbarot',
      email: 'rbarot@premiermedcorp.com',
      name: 'Ronak Barot',
      jobTitle: 'Lead Executive Admin',
      isAdmin: true,
      isPreparer: true,
      isReviewer: true,
      isApprover: true,
      assignedRoles: ['Admin', 'Preparer', 'Reviewer', 'Approver'],
      isMR: true,
      createdAt: '2026-06-06T05:42:00Z',
      lastActive: '2026-06-06T05:42:16Z',
      password: 'Boski@01',
      department: 'QA',
      owningQualityDepartment: 'QA',
      isActive: true
    };
    updatedUsers.unshift(rbarotUser);
  } else {
    const rIdx = updatedUsers.findIndex(u => u.email.toLowerCase() === 'rbarot@premiermedcorp.com');
    if (rIdx !== -1) {
      updatedUsers[rIdx] = {
        ...updatedUsers[rIdx],
        password: updatedUsers[rIdx].password || 'Boski@01',
        isActive: true
      };
    }
  }

  // Strict cleanup: Ensure absolute uniqueness of records by ID and email to prevent key collisions
  const seenIds = new Set<string>();
  const seenEmails = new Set<string>();
  const uniqueUsers: User[] = [];
  
  updatedUsers.forEach(u => {
    if (!u) return;
    const emailNorm = u.email.toLowerCase();
    if (!seenIds.has(u.id) && !seenEmails.has(emailNorm)) {
      seenIds.add(u.id);
      seenEmails.add(emailNorm);
      uniqueUsers.push(u);
    }
  });

  return uniqueUsers;
}

export const getDifferentiatedDocs = (req: DCRNRequest, deptCode: string) => {
  const ass = req.assessments?.[deptCode];
  const previousDocs = ass?.previouslyAnalyzedDocs || [];

  if (previousDocs.length > 0) {
    const previouslyAnalyzed = previousDocs.map(pDoc => {
      const latest = req.initialDocs.find(d => d.docNumber === pDoc.docNumber);
      return latest || pDoc;
    });
    const newlyAdded = req.initialDocs.filter(
      d => !previousDocs.some(p => p.docNumber === d.docNumber)
    );
    return { previouslyAnalyzed, newlyAdded, hasPrevious: true };
  } else {
    const prepDept = req.preparedBy?.department || '';
    const previouslyAnalyzed = req.initialDocs.filter(
      d => !d.addedByDept || d.addedByDept === prepDept
    );
    const newlyAdded = req.initialDocs.filter(
      d => d.addedByDept && d.addedByDept !== prepDept
    );
    return { previouslyAnalyzed, newlyAdded, hasPrevious: false };
  }
};

const isAuthorizedForQaGateway = (user: User): boolean => {
  if (user.department !== 'QA') return false;
  const title = user.jobTitle.toLowerCase();
  return (
    title.includes('manager') ||
    title.includes('gm')
  );
};

export default function App() {
  // ----------------------------------------------------
  // Persistent Storage Synchronization Setup
  // ----------------------------------------------------
  // ----------------------------------------------------
  // LAN Server Persistent Storage Integration Setup
  // ----------------------------------------------------
  const [dbLoading, setDbLoading] = useState(true);

  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem('eqms_users_v2');
    const parsed: User[] = saved ? JSON.parse(saved) : [...INITIAL_USERS];
    return bootstrapUserList(parsed);
  });

  const [documents, setDocuments] = useState<DocumentWorkflow[]>(() => {
    const saved = localStorage.getItem('eqms_documents_v2');
    return saved ? JSON.parse(saved) : INITIAL_DOCUMENTS;
  });

  const [auditLogs, setAuditLogs] = useState<AuditTrailEntry[]>(() => {
    const saved = localStorage.getItem('eqms_audit_logs_v2');
    return saved ? JSON.parse(saved) : INITIAL_AUDIT_LOGS;
  });

  const [dcrnRequests, setDcrnRequests] = useState<DCRNRequest[]>(() => {
    const saved = localStorage.getItem('eqms_dcrn_requests_v1');
    return saved ? JSON.parse(saved) : [];
  });

  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('eqms_current_user_v2');
    return saved ? JSON.parse(saved) : null;
  });

  const [activeRole, setActiveRole] = useState<'Admin' | 'Preparer' | 'Reviewer' | 'Approver' | 'MR' | 'NoRole' | 'QaGateway'>(() => {
    const saved = localStorage.getItem('eqms_active_role_v2');
    if (saved) return saved as any;
    return 'NoRole';
  });

  // Navigation tab for the standard workspace (Dashboard view vs Ledgers view)
  const [activeNavTab, setActiveNavTab] = useState<'workspace' | 'audit'>('workspace');

  // States for the global popup mandatory departmental impact assessment
  const [globalDismissedPopupRequests, setGlobalDismissedPopupRequests] = useState<{ [key: string]: boolean }>({});
  const [globalSelectedImpact, setGlobalSelectedImpact] = useState<{ [reqId: string]: 'Yes' | 'No' | '' }>({});
  const [globalDepartmentDocs, setGlobalDepartmentDocs] = useState<{ [reqId: string]: DCRNDecDocument[] }>({});
  const [activeInlineAssessmentId, setActiveInlineAssessmentId] = useState<string | null>(null);

  // Popup Text Editor State for Impact Analysis Fields
  const [textEditorOpen, setTextEditorOpen] = useState(false);
  const [textEditorReqId, setTextEditorReqId] = useState<string>("");
  const [textEditorIndex, setTextEditorIndex] = useState<number | null>(null);
  const [textEditorField, setTextEditorField] = useState<'reasonForChange' | 'changesRequired' | null>(null);
  const [textEditorValue, setTextEditorValue] = useState("");
  const [textEditorTitle, setTextEditorTitle] = useState("");

  const openTextEditor = (reqId: string, index: number, field: 'reasonForChange' | 'changesRequired', initialValue: string, title: string) => {
    setTextEditorReqId(reqId);
    setTextEditorIndex(index);
    setTextEditorField(field);
    setTextEditorValue(initialValue);
    setTextEditorTitle(title);
    setTextEditorOpen(true);
  };

  const handleSaveTextEditor = () => {
    if (textEditorReqId && textEditorIndex !== null && textEditorField) {
      handleGlobalUpdateDeptDoc(textEditorReqId, textEditorIndex, textEditorField, textEditorValue);
    }
    setTextEditorOpen(false);
    setTextEditorIndex(null);
    setTextEditorField(null);
  };

  const handleGlobalAddDeptDoc = (reqId: string) => {
    setGlobalDepartmentDocs(prev => ({
      ...prev,
      [reqId]: [...(prev[reqId] || []), { docNumber: '', title: '', reasonForChange: '', changesRequired: '', actionType: 'Change' }]
    }));
  };

  const handleGlobalRemoveDeptDoc = (reqId: string, docIndex: number) => {
    setGlobalDepartmentDocs(prev => ({
      ...prev,
      [reqId]: (prev[reqId] || []).filter((_, idx) => idx !== docIndex)
    }));
  };

  const handleGlobalUpdateDeptDoc = (reqId: string, docIndex: number, field: keyof DCRNDecDocument, val: string) => {
    setGlobalDepartmentDocs(prev => ({
      ...prev,
      [reqId]: (prev[reqId] || []).map((doc, idx) => {
        if (idx === docIndex) {
          return { ...doc, [field]: val };
        }
        return doc;
      })
    }));
  };

  const handleGlobalDeptChoice = (reqId: string, choice: 'Yes' | 'No') => {
    setGlobalSelectedImpact(prev => ({ ...prev, [reqId]: choice }));
    if (choice === 'Yes') {
      setGlobalDepartmentDocs(prev => ({
        ...prev,
        [reqId]: [{ docNumber: '', title: '', reasonForChange: '', changesRequired: '' }]
      }));
    } else {
      setGlobalDepartmentDocs(prev => {
        const next = { ...prev };
        delete next[reqId];
        return next;
      });
    }
  };

  const handleGlobalDeptSubmit = (requestId: string, deptCode: string) => {
    const choice = globalSelectedImpact[requestId];
    if (!choice) {
      alert("Please select whether this change impacts your department.");
      return;
    }

    const addedDocs = globalDepartmentDocs[requestId] || [];
    if (choice === 'Yes') {
      // Validate inputs
      for (let i = 0; i < addedDocs.length; i++) {
        const doc = addedDocs[i];
        if (!doc.docNumber.trim() || !doc.reasonForChange.trim() || !doc.changesRequired.trim()) {
          alert(`Document #${i + 1} has outstanding empty parameters.`);
          return;
        }
      }
    }

    handleSubmitDepartmentAssessment(requestId, deptCode, choice, addedDocs);
    
    // Clear selection state
    setGlobalSelectedImpact(prev => {
      const next = { ...prev };
      delete next[requestId];
      return next;
    });
    setGlobalDepartmentDocs(prev => {
      const next = { ...prev };
      delete next[requestId];
      return next;
    });
  };

  // Unified Download Modal State
  const [downloadModalOpen, setDownloadModalOpen] = useState(false);
  const [downloadFileName, setDownloadFileName] = useState('');
  const [downloadFileSize, setDownloadFileSize] = useState('');
  const [downloadFileContent, setDownloadFileContent] = useState('');
  const [downloadChecksum, setDownloadChecksum] = useState('');

  // 1. Fetch initial database state from the LAN Office Server on system boot
  useEffect(() => {
    fetch('/api/data')
      .then(res => {
        if (!res.ok) throw new Error("LAN Server database unavailable");
        return res.json();
      })
      .then(data => {
        if (data && data.users && data.users.length > 0) {
          setUsers(bootstrapUserList(data.users));
          setDocuments(data.documents || []);
          setAuditLogs(data.auditLogs || []);
          setDcrnRequests(data.dcrnRequests || []);
        } else {
          // Empty database on host server - seed first-time standard initializers
          fetch('/api/sync', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ users, documents, auditLogs, dcrnRequests: [] })
          }).catch(err => console.error("Database seed failed", err));
        }
        setDbLoading(false);
      })
      .catch(err => {
        console.warn("LAN Server unresponsive. Operating on local cache fallback.", err);
        setDbLoading(false);
      });
  }, []);

  // 2. Synchronize active state modifications back to LAN host's filesystem database
  useEffect(() => {
    if (dbLoading) return;

    localStorage.setItem('eqms_users_v2', JSON.stringify(users));
    localStorage.setItem('eqms_documents_v2', JSON.stringify(documents));
    localStorage.setItem('eqms_audit_logs_v2', JSON.stringify(auditLogs));
    localStorage.setItem('eqms_dcrn_requests_v1', JSON.stringify(dcrnRequests));

    fetch('/api/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ users, documents, auditLogs, dcrnRequests })
    }).catch(err => console.error("LAN database synchronization failure", err));
  }, [users, documents, auditLogs, dcrnRequests, dbLoading]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('eqms_current_user_v2', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('eqms_current_user_v2');
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('eqms_active_role_v2', activeRole);
  }, [activeRole]);

  // ----------------------------------------------------
  // Audit Ledger Core Log Writer
  // ----------------------------------------------------
  const addAuditLog = (user: User, action: string, details: string) => {
    const nextLogId = 'aud_' + Math.floor(Math.random() * 900000 + 100000);
    const timestamp = new Date().toISOString();
    const fakeIp = '192.168.1.18'; // Simulated terminal local IP address
    const codeSource = `${nextLogId}-${action}-${user.name}-${details}`;
    const dynamicHash = generateChecksum(codeSource);

    const newLog: AuditTrailEntry = {
      id: nextLogId,
      timestamp,
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
      action,
      details,
      ipAddress: fakeIp,
      checksum: dynamicHash
    };

    setAuditLogs(prev => [newLog, ...prev]);
  };

  // Helper with no active user (e.g., initial system load)
  const addSystemLog = (action: string, details: string) => {
    const nextLogId = 'aud_sys' + Math.floor(Math.random() * 900000 + 100000);
    const timestamp = new Date().toISOString();
    const codeSource = `${nextLogId}-${action}-${details}`;
    const checksum = generateChecksum(codeSource);

    const newLog: AuditTrailEntry = {
      id: nextLogId,
      timestamp,
      userId: 'system_node',
      userName: 'PMC Shell',
      userEmail: 'system@company.internal',
      action,
      details,
      ipAddress: '127.0.0.1',
      checksum
    };

    setAuditLogs(prev => [newLog, ...prev]);
  };

  // ----------------------------------------------------
  // Authentication Actions
  // ----------------------------------------------------
  const handleLoginSuccess = (user: User) => {
    setCurrentUser(user);
    
    // Evaluate initial role defaults based on priority:
    if (isAuthorizedForQaGateway(user)) {
      setActiveRole('QaGateway');
    } else if (user.isAdmin) {
      setActiveRole('Admin');
    } else if (user.isPreparer) {
      setActiveRole('Preparer');
    } else if (user.isReviewer) {
      setActiveRole('Reviewer');
    } else if (user.isApprover) {
      setActiveRole('Approver');
    } else {
      setActiveRole('NoRole');
    }

    setActiveNavTab('workspace');
  };

  const handleLogout = () => {
    if (currentUser) {
      addAuditLog(currentUser, 'LOGOUT_SUCCESS', 'User disconnected. Closed desktop environment.');
    }
    setCurrentUser(null);
    setActiveRole('NoRole');
    localStorage.removeItem('eqms_current_user_v2');
    localStorage.removeItem('eqms_active_role_v2');
  };

  // ----------------------------------------------------
  // Administrative Operations (Admin Dashboard)
  // ----------------------------------------------------
  const handleUpdateUserRoles = (
    userId: string, 
    roles: { isPreparer: boolean; isReviewer: boolean; isApprover: boolean; isAdmin: boolean; isMR: boolean }
  ) => {
    if (!currentUser) return;

    setUsers(prev => prev.map(u => {
      if (u.id === userId) {
        // Enforce audit feedback describing exactly what changed
        const auditDetails = `Modified privileges for user "${u.name}" to: Prep=${roles.isPreparer}, Rev=${roles.isReviewer}, Appr=${roles.isApprover}, Admin=${roles.isAdmin}, MR=${roles.isMR}`;
        addAuditLog(currentUser, 'ROLE_MODIFIED', auditDetails);
        
        const assignedRoles: ('Admin' | 'Preparer' | 'Reviewer' | 'Approver')[] = [];
        if (roles.isAdmin) assignedRoles.push('Admin');
        if (roles.isPreparer) assignedRoles.push('Preparer');
        if (roles.isReviewer) assignedRoles.push('Reviewer');
        if (roles.isApprover) assignedRoles.push('Approver');

        return {
          ...u,
          isPreparer: roles.isPreparer,
          isReviewer: roles.isReviewer,
          isApprover: roles.isApprover,
          isAdmin: roles.isAdmin,
          isMR: roles.isMR,
          assignedRoles
        };
      }
      return u;
    }));
  };

  const handleUpdateUserCredentials = (
    userId: string, 
    email: string, 
    name: string, 
    jobTitle: string, 
    isActive: boolean, 
    password?: string,
    department?: string,
    owningQualityDepartment?: string
  ) => {
    if (!currentUser) return;

    setUsers(prev => prev.map(u => {
      if (u.id === userId) {
        const emailChange = u.email !== email ? ` Email: "${u.email}" to "${email}".` : '';
        const nameChange = u.name !== name ? ` Name: "${u.name}" to "${name}".` : '';
        const titleChange = u.jobTitle !== jobTitle ? ` Title: "${u.jobTitle}" to "${jobTitle}".` : '';
        const statusChange = u.isActive !== isActive ? ` Status: "${u.isActive !== false ? 'Active' : 'Inactive'}" to "${isActive ? 'Active' : 'Inactive'}".` : '';
        const passwordChange = password ? ` Password reset completed.` : '';
        const deptChange = u.department !== department ? ` Department: "${u.department || 'None'}" to "${department || 'None'}".` : '';
        
        const auditDetails = `Profile & Security edit for "${u.name}" (${userId}):${emailChange}${nameChange}${titleChange}${statusChange}${passwordChange}${deptChange}`;
        addAuditLog(currentUser, 'CREDENTIALS_MODIFIED', auditDetails);
        
        const updatedUser = {
          ...u,
          name: name.trim(),
          jobTitle: jobTitle.trim(),
          email: email.trim().toLowerCase(),
          isActive,
          password: password ? password.trim() : u.password,
          department,
          owningQualityDepartment
        };

        if (userId === currentUser.id) {
          setCurrentUser(updatedUser);
        }

        return updatedUser;
      }
      return u;
    }));
  };

  const handleAddUser = (newUserFields: Omit<User, 'id'>): boolean => {
    if (!currentUser) return false;

    // Reject duplicate email check
    const isDuplicate = users.some(u => u.email.toLowerCase() === newUserFields.email.toLowerCase());
    if (isDuplicate) return false;

    const nextUserId = 'usr_' + Math.floor(Math.random() * 90000 + 10000);
    
    const assignedRoles: ('Admin' | 'Preparer' | 'Reviewer' | 'Approver')[] = [];
    if (newUserFields.isAdmin) assignedRoles.push('Admin');
    if (newUserFields.isPreparer) assignedRoles.push('Preparer');
    if (newUserFields.isReviewer) assignedRoles.push('Reviewer');
    if (newUserFields.isApprover) assignedRoles.push('Approver');

    const finalUser: User = {
      ...newUserFields,
      id: nextUserId,
      isActive: true,
      assignedRoles
    };

    setUsers(prev => [...prev, finalUser]);
    addAuditLog(currentUser, 'USER_ENROLLED', `Registered new profile: ${finalUser.name} (${finalUser.email}) with job title ${finalUser.jobTitle}`);
    return true;
  };

  // ----------------------------------------------------
  // Document Change Control Workflows
  // ----------------------------------------------------
  const handleAddDocument = (docData: Omit<DocumentWorkflow, 'id' | 'createdAt' | 'preparedBy' | 'version' | 'comments'> & { file: File | null; referencedDcrn?: string }) => {
    if (!currentUser) return;

    const nextDocId = 'doc_' + Math.floor(Math.random() * 900 + 100);
    const newDoc: DocumentWorkflow = {
      id: nextDocId,
      title: docData.title,
      category: docData.category,
      department: docData.department,
      description: docData.description,
      fileName: docData.fileName,
      fileSize: docData.fileSize,
      preparedBy: {
        userId: currentUser.id,
        userName: currentUser.name,
        email: currentUser.email
      },
      status: docData.status,
      comments: [
        {
          id: 'c_' + Math.floor(Math.random() * 100000),
          userId: currentUser.id,
          userName: currentUser.name,
          role: 'Preparer',
          text: `Initialized record: ${docData.description.substring(0, 100)}...`,
          timestamp: new Date().toISOString()
        }
      ],
      draftContent: docData.draftContent,
      version: '1.0',
      referencedDcrn: docData.referencedDcrn,
      createdAt: new Date().toISOString(),
      submitTimestamp: docData.status === DocumentStatus.PendingReview ? new Date().toISOString() : undefined
    };

    setDocuments(prev => [newDoc, ...prev]);
    if (newDoc.status === DocumentStatus.RequestedMR) {
      addAuditLog(currentUser, 'SOFT_COPY_REQUESTED', `Requested official MR-department soft copy templates for standard: ${newDoc.title} (${newDoc.id})`);
    } else {
      addAuditLog(currentUser, 'DOCUMENT_CREATED', `Saved Draft Standard: ${newDoc.title} (${newDoc.id})`);
    }

    if (newDoc.status === DocumentStatus.PendingReview) {
      addAuditLog(currentUser, 'DOCUMENT_SUBMITTED', `Dispatched standard to review queue: ${newDoc.title}`);
    }
  };

  const handleUpdateDraftContent = (docId: string, newContent: string) => {
    if (!currentUser) return;

    setDocuments(prev => prev.map(doc => {
      if (doc.id === docId) {
        // Simple incremental comment to show audit revisions track
        const newCom: DocumentComment = {
          id: 'c_' + Math.floor(Math.random() * 100000),
          userId: currentUser.id,
          userName: currentUser.name,
          role: 'Preparer',
          text: `Revised body content during revision cycle stage.`,
          timestamp: new Date().toISOString()
        };

        return {
          ...doc,
          draftContent: newContent,
          comments: [...doc.comments, newCom]
        };
      }
      return doc;
    }));

    addAuditLog(currentUser, 'DOCUMENT_REVISED', `Saved manual text corrections for doc: ${docId}`);
  };

  const handleSubmitDocument = (docId: string, preparerDraftUrl?: string, fileName?: string, fileSize?: string, assignedReviewer?: { userId: string; userName: string; email: string }) => {
    if (!currentUser) return;

    setDocuments(prev => prev.map(doc => {
      if (doc.id === docId) {
        return {
          ...doc,
          status: DocumentStatus.PendingReview,
          submitTimestamp: new Date().toISOString(),
          preparerDraftUrl: preparerDraftUrl || `/vault/preparer-drafts/${fileName || doc.fileName}`,
          fileName: fileName || doc.fileName,
          fileSize: fileSize || doc.fileSize,
          assignedReviewer: assignedReviewer || doc.assignedReviewer,
          reviewerVerifiedUrl: undefined,
          finalApprovedCopyUrl: undefined
        };
      }
      return doc;
    }));

    const docRef = documents.find(d => d.id === docId);
    if (docRef && docRef.draftContent) {
      saveTextAsFileToServer(fileName || docRef.fileName, docRef.draftContent);
    }
    const reviewerNameStr = assignedReviewer ? ` (Assigned to: ${assignedReviewer.userName})` : '';
    addAuditLog(currentUser, 'DOCUMENT_SUBMITTED', `Transitioned status to Pending Reviewer: ${docRef ? docRef.title : docId}${reviewerNameStr}`);
  };

  const handlePassReview = (docId: string, commentText: string, reviewerVerifiedUrl?: string, fileName?: string, fileSize?: string, assignedApprover?: { userId: string; userName: string; email: string }) => {
    if (!currentUser) return;

    setDocuments(prev => prev.map(doc => {
      if (doc.id === docId) {
        const passComment: DocumentComment = {
          id: 'c_' + Math.floor(Math.random() * 100000),
          userId: currentUser.id,
          userName: currentUser.name,
          role: 'Reviewer',
          text: `Verified review and uploaded corrected copy: ${commentText}`,
          timestamp: new Date().toISOString()
        };

        return {
          ...doc,
          status: DocumentStatus.PendingApproval,
          reviewedBy: {
            userId: currentUser.id,
            userName: currentUser.name,
            email: currentUser.email,
            timestamp: new Date().toISOString()
          },
          reviewerVerifiedUrl: reviewerVerifiedUrl || `/vault/reviewer-verified/${fileName || doc.fileName}`,
          fileName: fileName || doc.fileName,
          fileSize: fileSize || doc.fileSize,
          comments: [...doc.comments, passComment],
          assignedApprover: assignedApprover || doc.assignedApprover,
          finalApprovedCopyUrl: undefined
        };
      }
      return doc;
    }));

    const docTarget = documents.find(d => d.id === docId);
    if (docTarget && docTarget.draftContent) {
      saveTextAsFileToServer(fileName || docTarget.fileName, docTarget.draftContent);
    }
    const approverNameStr = assignedApprover ? ` (Assigned to: ${assignedApprover.userName})` : '';
    addAuditLog(currentUser, 'SOP_VERIFIED_BY_REVIEWER', `Verified and corrected copy draft upload by Reviewer: ${docTarget ? docTarget.title : docId}. Passed to Approver queue.${approverNameStr}`);
  };

  const handleProvideSoftCopy = (docId: string, draftContent: string, fileName: string, fileSize: string, mrTemplateCopyUrl?: string) => {
    if (!currentUser) return;

    setDocuments(prev => prev.map(doc => {
      if (doc.id === docId) {
        const comment: DocumentComment = {
          id: 'c_' + Math.floor(Math.random() * 100000),
          userId: currentUser.id,
          userName: currentUser.name,
          role: 'MR Department',
          text: `Provisioned official template soft copy file: ${fileName} (${fileSize}). Ready for preparer update.`,
          timestamp: new Date().toISOString()
        };

        return {
          ...doc,
          status: DocumentStatus.SoftCopyProvided,
          draftContent: draftContent,
          fileName: fileName,
          fileSize: fileSize,
          mrTemplateCopyUrl: mrTemplateCopyUrl || `/vault/mr-templates/${fileName}`,
          comments: [...doc.comments, comment],
          version: '1.0'
        };
      }
      return doc;
    }));

    saveTextAsFileToServer(fileName, draftContent);
    const docTarget = documents.find(d => d.id === docId);
    addAuditLog(currentUser, 'SOFT_COPY_PROVIDED', `Uploaded corporate template soft copy for request ${docId} (${docTarget ? docTarget.title : ''})`);
  };

  const handleDownloadSOP = (docId: string) => {
    if (!currentUser) return;
    setDocuments(prev => prev.map(doc => {
      if (doc.id === docId && !doc.mrDownloaded) {
        return {
          ...doc,
          mrDownloaded: true,
          mrDownloadedAt: new Date().toISOString()
        };
      }
      return doc;
    }));
    addAuditLog(currentUser, 'SOP_DOWNLOADED', `Downloaded final approved copy of SOP: ${docId}`);
  };

  const handleRejectReview = (
    docId: string,
    commentText: string,
    reviewerVerifiedUrl?: string,
    fileName?: string,
    fileSize?: string
  ) => {
    if (!currentUser) return;

    setDocuments(prev => prev.map(doc => {
      if (doc.id === docId) {
        const extraText = fileName ? ` (Assigned marked-up file: ${fileName})` : '';
        const rejectComment: DocumentComment = {
          id: 'c_' + Math.floor(Math.random() * 100000),
          userId: currentUser.id,
          userName: currentUser.name,
          role: 'Reviewer',
          text: `REJECTED DEFICIENCY NOTE: ${commentText}${extraText}`,
          timestamp: new Date().toISOString()
        };

        return {
          ...doc,
          status: DocumentStatus.Rejected,
          rejectedBy: 'Reviewer',
          comments: [...doc.comments, rejectComment],
          reviewerVerifiedUrl: reviewerVerifiedUrl || doc.reviewerVerifiedUrl,
          fileName: fileName || doc.fileName,
          fileSize: fileSize || doc.fileSize
        };
      }
      return doc;
    }));

    const docTarget = documents.find(d => d.id === docId);
    addAuditLog(currentUser, 'REVIEW_FAILED', `Document review rejected: ${docTarget ? docTarget.title : docId}. Revision loop mandated.`);
  };

  const handleRejectApproval = (
    docId: string,
    commentText: string,
    reviewerVerifiedUrl?: string,
    fileName?: string,
    fileSize?: string
  ) => {
    if (!currentUser) return;

    setDocuments(prev => prev.map(doc => {
      if (doc.id === docId) {
        const extraText = fileName ? ` (Assigned marked-up file: ${fileName})` : '';
        const rejectComment: DocumentComment = {
          id: 'c_' + Math.floor(Math.random() * 100000),
          userId: currentUser.id,
          userName: currentUser.name,
          role: 'Approver',
          text: `REJECTED DEFICIENCY NOTE (APPROVER): ${commentText}${extraText}`,
          timestamp: new Date().toISOString()
        };

        return {
          ...doc,
          status: DocumentStatus.Rejected,
          rejectedBy: 'Approver',
          comments: [...doc.comments, rejectComment],
          reviewerVerifiedUrl: reviewerVerifiedUrl || doc.reviewerVerifiedUrl,
          fileName: fileName || doc.fileName,
          fileSize: fileSize || doc.fileSize
        };
      }
      return doc;
    }));

    const docTarget = documents.find(d => d.id === docId);
    addAuditLog(currentUser, 'APPROVAL_REJECTED', `Document approval rejected by Approver: ${docTarget ? docTarget.title : docId}. Revision loop mandated.`);
  };

  const handleApproveDocument = (docId: string, signatureBlock: SignatureLog, finalApprovedCopyUrl?: string, fileName?: string, fileSize?: string) => {
    if (!currentUser) return;

    setDocuments(prev => prev.map(doc => {
      if (doc.id === docId) {
        const approveComment: DocumentComment = {
          id: 'c_' + Math.floor(Math.random() * 100000),
          userId: currentUser.id,
          userName: currentUser.name,
          role: 'Approver',
          text: `Document signed off legally with e-sig meaning: "${signatureBlock.meaning}"`,
          timestamp: new Date().toISOString()
        };

        return {
          ...doc,
          status: DocumentStatus.Approved,
          approvedBy: signatureBlock,
          finalApprovedCopyUrl: finalApprovedCopyUrl || `/vault/final-approved/${fileName || doc.fileName}`,
          fileName: fileName || doc.fileName,
          fileSize: fileSize || doc.fileSize,
          comments: [...doc.comments, approveComment]
        };
      }
      return doc;
    }));

    const docTarget = documents.find(d => d.id === docId);
    if (docTarget && docTarget.draftContent) {
      saveTextAsFileToServer(fileName || docTarget.fileName, docTarget.draftContent);
    }
    addAuditLog(currentUser, 'E_SIGNED', `Certified legally-binding sign-off and uploaded absolute final authorized copy. SOP ${docTarget ? docTarget.title : docId} is active.`);
  };

  const handleDeleteDocument = (docId: string) => {
    if (!currentUser) return;

    const docTarget = documents.find(d => d.id === docId);
    if (!docTarget) return;

    setDocuments(prev => prev.filter(doc => doc.id !== docId));
    const logDetails = docTarget.status === DocumentStatus.RequestedMR 
      ? `Deleted pending document request entry: ${docTarget.title}`
      : `Deleted approved document: ${docTarget.title}`;
    addAuditLog(currentUser, 'DOCUMENT_DELETED', logDetails);
  };

  const handleRequestRemoval = (docId: string) => {
    if (!currentUser) return;
    setDocuments(prev => prev.map(doc => {
      if (doc.id === docId) {
        return {
          ...doc,
          stageBeforeDeletionRequest: doc.status,
          status: DocumentStatus.PendingDeletion
        };
      }
      return doc;
    }));
    const docTarget = documents.find(d => d.id === docId);
    addAuditLog(currentUser, 'REMOVAL_REQUESTED', `Requested administrative removal for SOP: ${docTarget ? docTarget.title : docId}`);
  };

  const handleApproveRemoval = (docId: string) => {
    if (!currentUser) return;
    setDocuments(prev => prev.map(doc => {
      if (doc.id === docId) {
        return {
          ...doc,
          status: DocumentStatus.Archived
        };
      }
      return doc;
    }));
    const docTarget = documents.find(d => d.id === docId);
    addAuditLog(currentUser, 'DOCUMENT_ARCHIVED', `Admin approved removal request. Archived document: ${docTarget ? docTarget.title : docId}`);
  };

  const handleRejectRemoval = (docId: string) => {
    if (!currentUser) return;
    setDocuments(prev => prev.map(doc => {
      if (doc.id === docId) {
        return {
          ...doc,
          status: doc.stageBeforeDeletionRequest || DocumentStatus.Draft,
          stageBeforeDeletionRequest: undefined
        };
      }
      return doc;
    }));
    const docTarget = documents.find(d => d.id === docId);
    addAuditLog(currentUser, 'REMOVAL_REJECTED', `Admin rejected removal request. Restored document to original stage: ${docTarget ? docTarget.title : docId}`);
  };

  const handleAddComment = (docId: string, commentText: string) => {
    if (!currentUser) return;

    const newComment: DocumentComment = {
      id: 'c_' + Math.floor(Math.random() * 100000),
      userId: currentUser.id,
      userName: currentUser.name,
      role: activeRole,
      text: commentText,
      timestamp: new Date().toISOString()
    };

    setDocuments(prev => prev.map(doc => {
      if (doc.id === docId) {
        return {
          ...doc,
          comments: [...doc.comments, newComment]
        };
      }
      return doc;
    }));

    addAuditLog(currentUser, 'COMMENT_ADDED', `Appended evaluation note to file: ${docId}`);
  };

  // ----------------------------------------------------
  // DCRN Change Control Workflows (CFR Part 11 Gateway)
  // ----------------------------------------------------
  const handleAddDcrnRequest = (initialDocs: DCRNDecDocument[]) => {
    if (!currentUser) return;

    const originDept = currentUser.department || 'QA';
    const serialNumber = (dcrnRequests.length + 1).toString().padStart(3, '0');
    const nextId = `DCRN-${originDept}-${serialNumber}`;
    
    // Tag initial documents with creator's department
    const taggedDocs = initialDocs.map(doc => ({
      ...doc,
      addedByDept: originDept,
      preparedAt: new Date().toISOString()
    }));

    const newReq: DCRNRequest = {
      id: nextId,
      status: 'Pending_QA_Evaluation',
      createdAt: new Date().toISOString(),
      preparedBy: {
        userId: currentUser.id,
        userName: currentUser.name,
        email: currentUser.email,
        department: originDept
      },
      initialDocs: taggedDocs,
      assessments: {}
    };

    setDcrnRequests(prev => [newReq, ...prev]);
    addAuditLog(
      currentUser,
      'DCRN_INITIATED',
      `Document Change Request Number packet ID "${nextId}" initiated with ${initialDocs.length} custom-procedural document items: ${initialDocs.map(d => `${d.docNumber} [${d.actionType || 'Change'}]`).join(', ')}.`
    );
  };

  const handleEvaluateDcrnRequest = (
    requestId: string,
    approved: boolean,
    remarks: string,
    registryNumber?: string,
    effectiveDate?: string
  ) => {
    if (!currentUser) return;

    setDcrnRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        // Find if this is a Stage 2 evaluation based on current status
        const isStage2 = req.status === 'Pending_QA_Stage2';

        if (isStage2) {
          // Stage 2 QA evaluation: Assign Final Effective Date and route to MR for Closure
          return {
            ...req,
            status: approved ? 'Pending_MR_Closure' as const : 'Rejected' as const,
            qaStage2Remarks: remarks,
            qaStage2EvaluatedBy: {
              userId: currentUser.id,
              userName: currentUser.name,
              email: currentUser.email
            },
            qaStage2EvaluatedAt: new Date().toISOString(),
            effectiveDate: approved ? effectiveDate : undefined
          };
        }

        // Stage 1 initial evaluation
        if (approved) {
          // Pre-populate empty assessments for all active tracking departments (except preparer's department)
          const nextAssessments: { [deptCode: string]: DCRNDepartmentAssessment } = {};
          const preparerDept = req.preparedBy?.department || '';

          const eligibleDepts = Object.keys(DEPARTMENT_MAP).filter(
            code => code !== preparerDept && code !== 'PK'
          );

          eligibleDepts.forEach(code => {
            nextAssessments[code] = {
              department: DEPARTMENT_MAP[code] || code,
              impacted: null,
              documents: [],
              previouslyAnalyzedDocs: []
            };
          });

          return {
            ...req,
            status: 'Pending_Impact_Assessment' as const,
            qaEvaluationRemarks: remarks,
            qaEvaluatedBy: {
              userId: currentUser.id,
              userName: currentUser.name,
              email: currentUser.email
            },
            qaEvaluatedAt: new Date().toISOString(),
            assessments: nextAssessments
          };
        } else {
          return {
            ...req,
            status: 'Rejected' as const,
            qaEvaluationRemarks: remarks,
            qaEvaluatedBy: {
              userId: currentUser.id,
              userName: currentUser.name,
              email: currentUser.email
            },
            qaEvaluatedAt: new Date().toISOString()
          };
        }
      }
      return req;
    }));

    addAuditLog(
      currentUser,
      approved ? 'DCRN_QA_APPROVED' : 'DCRN_QA_REJECTED',
      `QA Evaluated DCRN Request "${requestId}". Status set to ${
        approved 
          ? 'Approved / Handed off to next workflow stage' 
          : 'Rejected / Returned to preparer'
      }. Remarks: "${remarks}"`
    );
  };

  const handleSubmitDepartmentAssessment = (
    requestId: string,
    deptCode: string,
    impacted: 'Yes' | 'No',
    addedDocs: DCRNDecDocument[]
  ) => {
    if (!currentUser) return;

    setDcrnRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        let updatedDocs = [...req.initialDocs];
        let nextAssessments = { ...req.assessments };

        // Save a snapshot of what this department has analyzed in this turn.
        // They are signing off on all of the current documents in the request.
        const analyzedSnapshot = [...req.initialDocs];

        // Tag the added documents with this department
        const taggedAddedDocs = addedDocs.map(doc => ({
          ...doc,
          addedByDept: deptCode,
          preparedAt: new Date().toISOString()
        }));

        if (impacted === 'Yes' && taggedAddedDocs.length > 0) {
          updatedDocs = [...req.initialDocs, ...taggedAddedDocs];

          nextAssessments[deptCode] = {
            department: DEPARTMENT_MAP[deptCode] || deptCode,
            impacted,
            assessedBy: {
              userId: currentUser.id,
              userName: currentUser.name,
              email: currentUser.email
            },
            assessedAt: new Date().toISOString(),
            documents: taggedAddedDocs,
            previouslyAnalyzedDocs: analyzedSnapshot
          };

          const preparerDept = req.preparedBy?.department || '';
          if (preparerDept && preparerDept !== 'PK' && !nextAssessments[preparerDept]) {
            nextAssessments[preparerDept] = {
              department: DEPARTMENT_MAP[preparerDept] || preparerDept,
              impacted: null,
              documents: [],
              previouslyAnalyzedDocs: []
            };
          }

          // Reset all other departments so they MUST perform impact analysis again
          Object.keys(nextAssessments).forEach(code => {
            if (code !== deptCode && code !== 'PK') {
              const prevAss = nextAssessments[code];
              nextAssessments[code] = {
                ...prevAss,
                impacted: null, // Forces a new assessment
                assessedBy: undefined,
                assessedAt: undefined,
                // Keep their previouslyAnalyzedDocs intact for comparison in the separate table!
                previouslyAnalyzedDocs: prevAss ? prevAss.previouslyAnalyzedDocs : []
              };
            }
          });
        } else {
          // If Not impacted or no document added, we just register this department's assessment.
          nextAssessments[deptCode] = {
            department: DEPARTMENT_MAP[deptCode] || deptCode,
            impacted,
            assessedBy: {
              userId: currentUser.id,
              userName: currentUser.name,
              email: currentUser.email
            },
            assessedAt: new Date().toISOString(),
            documents: [],
            previouslyAnalyzedDocs: analyzedSnapshot
          };
        }

        return {
          ...req,
          initialDocs: updatedDocs,
          assessments: nextAssessments
        };
      }
      return req;
    }));

    addAuditLog(
      currentUser,
      'DCRN_DEPT_ASSESSMENT',
      `Department "${deptCode}" logged change control clearance assessment choice: "${impacted}" for DCRN ID "${requestId}" with ${addedDocs.length} localized modification items.`
    );
  };

  const handleAuthorizeDcrnRequest = (requestId: string, registryNumber: string) => {
    if (!currentUser) return;

    setDcrnRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        return {
          ...req,
          status: 'Completed' as const,
          mrRegistryNumber: registryNumber,
          mrAuthorizedBy: {
            userId: currentUser.id,
            userName: currentUser.name,
            email: currentUser.email
          },
          mrAuthorizedAt: new Date().toISOString()
        };
      }
      return req;
    }));

    addAuditLog(
      currentUser,
      'DCRN_AUTHORIZED',
      `MR Authoritative Signoff: DCRN ID "${requestId}" officially closed and locked. Assigned Official Registry DCRN Catalog Number: "${registryNumber}".`
    );
  };

  const handleAssignDcrnRegistryNumber = (requestId: string, registryNumber: string) => {
    if (!currentUser) return;

    setDcrnRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        return {
          ...req,
          mrRegistryNumber: registryNumber ? registryNumber : undefined,
          mrRegistryAssignedBy: registryNumber ? {
            userId: currentUser.id,
            userName: currentUser.name,
            email: currentUser.email
          } : undefined,
          mrRegistryAssignedAt: registryNumber ? new Date().toISOString() : undefined
        };
      }
      return req;
    }));

    if (registryNumber) {
      addAuditLog(
        currentUser,
        'DCRN_REGISTRY_ASSIGNED',
        `Official Registry DCRN Number Assigned: "${registryNumber}" for DCRN ID "${requestId}".`
      );
    } else {
      addAuditLog(
        currentUser,
        'DCRN_REGISTRY_RESET',
        `Official Registry DCRN Number Cleared/Unlocked on DCRN ID "${requestId}".`
      );
    }
  };

  const handleRejectDepartmentAssessment = (requestId: string, deptCode: string) => {
    if (!currentUser) return;

    setDcrnRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        const nextAssessments = { ...req.assessments };
        if (nextAssessments[deptCode]) {
          nextAssessments[deptCode] = {
            ...nextAssessments[deptCode],
            impacted: null,
            documents: [],
            assessedBy: undefined,
            assessedAt: undefined,
            previouslyAnalyzedDocs: nextAssessments[deptCode].previouslyAnalyzedDocs || []
          };

          const cleanedInitialDocs = req.initialDocs.filter(d => d.addedByDept !== deptCode);

          return {
            ...req,
            initialDocs: cleanedInitialDocs,
            assessments: nextAssessments
          };
        }
      }
      return req;
    }));

    addAuditLog(
      currentUser,
      'DCRN_DEPT_ASSESSMENT_REJECTED',
      `MR explicitly REJECTED and re-opened Department "${deptCode}" impact analysis for DCRN ID "${requestId}" during authorization. Department must re-initiate assessment.`
    );
  };

  const handleSubmitToQa = (requestId: string) => {
    if (!currentUser) return;

    setDcrnRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        const isTransitioningToStage2 = req.status === 'Pending_Impact_Assessment';
        return {
          ...req,
          status: isTransitioningToStage2 ? 'Pending_QA_Stage2' as const : 'Pending_QA_Evaluation' as const,
          // Keep Stage 1 tags if transitioning to Stage 2, or clear if resetting
          qaEvaluationRemarks: isTransitioningToStage2 ? req.qaEvaluationRemarks : '',
          qaEvaluatedBy: isTransitioningToStage2 ? req.qaEvaluatedBy : undefined,
          qaEvaluatedAt: isTransitioningToStage2 ? req.qaEvaluatedAt : undefined
        };
      }
      return req;
    }));

    addAuditLog(
      currentUser,
      'DCRN_SUBMITTED_TO_QA_FINAL',
      `Document Change Request (DCRN ID: "${requestId}") submitted to QA Board Gateway as all master documents are fully approved.`
    );
  };

  const handleDeleteDcrnRequest = (requestId: string) => {
    if (!currentUser) return;

    const reqToDelete = dcrnRequests.find(r => r.id === requestId);
    if (!reqToDelete) return;

    const isMR = activeRole === 'MR';

    if (isMR) {
      // MR directly deletes/archives permanently
      setDcrnRequests(prev => prev.filter(req => req.id !== requestId));

      addAuditLog(
        currentUser,
        'DCRN_DELETED',
        `Document Change Request (DCRN ID: "${requestId}") was permanently removed from authorized ledger entries following MR authorization.`
      );
    } else {
      // Normal user (original preparer) requests/proposes deletion
      setDcrnRequests(prev => prev.map(req => {
        if (req.id === requestId) {
          return { ...req, pendingDeletion: true };
        }
        return req;
      }));

      addAuditLog(
        currentUser,
        'DCRN_DELETION_REQUESTED',
        `Removal request submitted for Document Change Request (DCRN ID: "${requestId}"). Awaiting MR Deletion approval.`
      );
    }
  };

  const handleRejectDcrnDeletion = (requestId: string) => {
    if (!currentUser) return;

    setDcrnRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        return { ...req, pendingDeletion: false };
      }
      return req;
    }));

    addAuditLog(
      currentUser,
      'DCRN_DELETION_REJECTED',
      `Administrative Clearance Negative: Deletion proposal for DCRN ID "${requestId}" was rejected by MR. Request fully restored.`
    );
  };

  const handleUploadDcrnDocument = (requestId: string, docIndex: number, url: string, fileName: string, fileSize: string) => {
    if (!currentUser) return;

    setDcrnRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        const updatedDocs = [...req.initialDocs];
        let targetDocNumber = '';
        if (updatedDocs[docIndex]) {
          targetDocNumber = updatedDocs[docIndex].docNumber;
          updatedDocs[docIndex] = {
            ...updatedDocs[docIndex],
            uploadedUrl: url,
            uploadedFileName: fileName,
            uploadedAt: new Date().toISOString()
          };
        }

        const updatedAssessments = { ...req.assessments };
        if (targetDocNumber && req.assessments) {
          Object.keys(req.assessments).forEach(deptCode => {
            const ass = req.assessments[deptCode];
            if (ass && ass.documents) {
              const updatedAssDocs = ass.documents.map(doc => {
                if (doc.docNumber === targetDocNumber) {
                  return {
                    ...doc,
                    uploadedUrl: url,
                    uploadedFileName: fileName,
                    uploadedAt: new Date().toISOString()
                  };
                }
                return doc;
              });
              updatedAssessments[deptCode] = {
                ...ass,
                documents: updatedAssDocs
              };
            }
          });
        }

        return {
          ...req,
          initialDocs: updatedDocs,
          assessments: updatedAssessments
        };
      }
      return req;
    }));

    addAuditLog(
      currentUser,
      'DCRN_DOCUMENT_UPLOADED',
      `MR uploaded document "${fileName}" (${fileSize}) against DCRN ID "${requestId}".`
    );
  };

  const handleUpdateDcrnRequest = (requestId: string, docNumber: string, reviewerId: string, updatedUrl: string, fileName: string) => {
    if (!currentUser) return;

    setDcrnRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        const updatedDocs = req.initialDocs.map(doc => {
          if (doc.docNumber === docNumber) {
            return {
              ...doc,
              uploadedUrl: updatedUrl,
              uploadedFileName: fileName,
              uploadedAt: new Date().toISOString()
            };
          }
          return doc;
        });

        const updatedAssessments = { ...req.assessments };
        if (req.assessments) {
          Object.keys(req.assessments).forEach(deptCode => {
            const ass = req.assessments[deptCode];
            if (ass && ass.documents) {
              const updatedAssDocs = ass.documents.map(doc => {
                if (doc.docNumber === docNumber) {
                  return {
                    ...doc,
                    uploadedUrl: updatedUrl,
                    uploadedFileName: fileName,
                    uploadedAt: new Date().toISOString()
                  };
                }
                return doc;
              });
              updatedAssessments[deptCode] = {
                ...ass,
                documents: updatedAssDocs
              };
            }
          });
        }

        return {
          ...req,
          initialDocs: updatedDocs,
          assessments: updatedAssessments
        };
      }
      return req;
    }));

    const reviewerUser = users.find(u => u.id === reviewerId);
    const revName = reviewerUser ? reviewerUser.name : reviewerId;

    addAuditLog(
      currentUser,
      'DCRN_REVISION_SUBMITTED',
      `Revision of document "${docNumber}" (file: "${fileName}") submitted to Reviewer "${revName}" under DCRN ID "${requestId}".`
    );
  };

  const handleUpdateDcrnDocumentField = (
    requestId: string,
    docNumber: string,
    fields: Partial<DCRNDecDocument>,
    auditAction?: string,
    auditDetails?: string
  ) => {
    if (!currentUser) return;

    setDcrnRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        const updatedDocs = req.initialDocs.map(doc => {
          if (doc.docNumber === docNumber) {
            return {
              ...doc,
              ...fields
            };
          }
          return doc;
        });

        const updatedAssessments = { ...req.assessments };
        if (req.assessments) {
          Object.keys(req.assessments).forEach(deptCode => {
            const ass = req.assessments[deptCode];
            if (ass && ass.documents) {
              const updatedAssDocs = ass.documents.map(doc => {
                if (doc.docNumber === docNumber) {
                  return {
                    ...doc,
                    ...fields
                  };
                }
                return doc;
              });
              updatedAssessments[deptCode] = {
                ...ass,
                documents: updatedAssDocs
              };
            }
          });
        }

        return {
          ...req,
          initialDocs: updatedDocs,
          assessments: updatedAssessments
        };
      }
      return req;
    }));

    if (auditAction && auditDetails) {
      addAuditLog(currentUser, auditAction, auditDetails);
    }
  };

  // ----------------------------------------------------
  // CSV Activity Logs Export Generator
  // ----------------------------------------------------
  const handleExportAuditLogs = () => {
    const csvHeaders = 'LogID,Timestamp,UserID,UserName,UserEmail,Action,Details,IPAddress,LedgerChecksum\r\n';
    
    const csvContent = auditLogs.map(log => {
      const escapedDetails = `"${log.details.replace(/"/g, '""')}"`;
      const escapedName = `"${log.userName.replace(/"/g, '""')}"`;
      return `${log.id},${log.timestamp},${log.userId},${escapedName},${log.userEmail},${log.action},${escapedDetails},${log.ipAddress},${log.checksum}`;
    }).join('\r\n');

    const rawPayload = '\uFEFF' + csvHeaders + csvContent;
    const finalSize = `${Math.ceil(rawPayload.length / 1024)} KB`;

    setDownloadFileName(`PMC_eQMS_System_Activity_Logs_${new Date().toISOString().substring(0, 10)}.csv`);
    setDownloadFileSize(finalSize);
    setDownloadFileContent(rawPayload);
    setDownloadChecksum('csv_' + Math.floor(Math.random() * 90000000 + 10000000).toString(16));
    setDownloadModalOpen(true);

    if (currentUser) {
      addAuditLog(currentUser, 'LOGS_EXPORTED', 'Exported encrypted system auditing ledger CSV package.');
    }
  };

  // ----------------------------------------------------
  // Reset Database Utilities (Factory Reset)
  // ----------------------------------------------------
  const handleFactoryReset = () => {
    if (window.confirm('WARNING: Doing a factory reset will flush all custom reviews, draft documents, and e-signatures. Reset database to demo preloads?')) {
      localStorage.removeItem('eqms_users_v2');
      localStorage.removeItem('eqms_documents_v2');
      localStorage.removeItem('eqms_audit_logs_v2');
      localStorage.removeItem('eqms_dcrn_requests_v1');
      
      const defaultBootstrapped = bootstrapUserList(INITIAL_USERS);
      setUsers(defaultBootstrapped);
      setDocuments(INITIAL_DOCUMENTS);
      setAuditLogs(INITIAL_AUDIT_LOGS);

      // Attempt system log write
      addSystemLog('DATABASE_RESET', 'Factory reset triggered by local diagnostic console hook.');
      
      // Keep currentUser logged in but update active role selection in case privileges vanished
      if (currentUser) {
        const matched = defaultBootstrapped.find(u => u.email.toLowerCase() === currentUser.email.toLowerCase());
        if (matched) {
          setCurrentUser(matched);
          if (matched.isAdmin) setActiveRole('Admin');
          else if (matched.isPreparer) setActiveRole('Preparer');
          else if (matched.isReviewer) setActiveRole('Reviewer');
          else if (matched.isApprover) setActiveRole('Approver');
          else setActiveRole('NoRole');
        } else {
          setCurrentUser(null);
          setActiveRole('NoRole');
        }
      }
      setActiveNavTab('workspace');
      alert('Database restored successfully to demonstration preset files.');
    }
  };

  // ----------------------------------------------------
  // Guard Evaluators
  // ----------------------------------------------------
  if (!currentUser) {
    return (
      <LoginScreen 
        onLoginSuccess={handleLoginSuccess} 
        users={users} 
        addAuditLog={addAuditLog} 
      />
    );
  }

  // Evaluate if they have NO permissions at all assigned in DB (Account active but no roles assigned yet)
  const userInDB = users.find(u => u.id === currentUser.id) || currentUser;
  const hasNoRoles = !userInDB.isAdmin && !userInDB.isPreparer && !userInDB.isReviewer && !userInDB.isApprover;
  
  if (hasNoRoles) {
    return (
      <RoleGuardScreen 
        currentUser={userInDB} 
        onLogout={handleLogout} 
      />
    );
  }

  // ----------------------------------------------------
  // Dynamic Workspace Renderer selector
  // ----------------------------------------------------
  const renderWorkspaceContent = () => {
    // Determine all active roles for the user (dynamically fallback to fields if assignedRoles array is absent)
    const userRoles: ('Admin' | 'Preparer' | 'Reviewer' | 'Approver' | 'MR' | 'QaGateway')[] = [];
    if (userInDB.isAdmin) userRoles.push('Admin');
    if (userInDB.isPreparer) userRoles.push('Preparer');
    if (userInDB.isReviewer) userRoles.push('Reviewer');
    if (userInDB.isApprover) userRoles.push('Approver');
    if (userInDB.isMR) userRoles.push('MR');
    if (isAuthorizedForQaGateway(userInDB)) userRoles.push('QaGateway');

    // Enforce that activeRole is always one of their available roles
    const currentActiveRole = userRoles.includes(activeRole as any) ? activeRole : (userRoles[0] || 'NoRole');

    // Calculate specific document action counts relative to active session profiles
    const prepPendingCount = (() => {
      let downloadedIds: string[] = [];
      try {
        const saved = typeof window !== 'undefined' ? localStorage.getItem("dcrn_downloaded_ids") : null;
        if (saved) {
          downloadedIds = JSON.parse(saved);
        }
      } catch (e) {}

      // standard documents available for download from MR or approved
      const standardCount = documents.filter(doc => 
        doc.preparedBy.userId === userInDB.id && 
        (doc.status === DocumentStatus.SoftCopyProvided || doc.status === DocumentStatus.Approved)
      ).length;

      // DCRN documents
      let dcrnCount = 0;
      dcrnRequests.forEach(req => {
        const isUserPreparerOrSameDept = 
          userInDB.id === req.preparedBy?.userId || 
          (userInDB.department && userInDB.department === req.preparedBy?.department);

        if (isUserPreparerOrSameDept) {
          (req.initialDocs || []).forEach(doc => {
            const isMRDownloadPending = doc.uploadedUrl && (!doc.workflowStatus || doc.workflowStatus === 'None');
            const isApprovedDownloadPending = doc.approvedDocUrl && 
              doc.workflowStatus === 'ApprovalAccepted' &&
              !downloadedIds.includes(doc.docNumber + (doc.addedByDept || ""));
            if (isMRDownloadPending || isApprovedDownloadPending) {
              dcrnCount++;
            }
          });

          // Also check when All documents accepted and ready to submit to QA
          const masterDocs = req.initialDocs || [];
          const allApproved = masterDocs.length > 0 && masterDocs.every(d => d.actionType === "Removal" || d.workflowStatus === "ApprovalAccepted");
          const isNotYetSubmitted = req.status !== "Pending_QA_Evaluation" && req.status !== "Pending_QA_Stage2" && req.status !== "Pending_MR_Closure" && req.status !== "Completed" && req.status !== "Rejected";
          const canSubmit = req.preparedBy?.userId === userInDB.id || req.preparedBy?.email === userInDB.email;
          if (allApproved && isNotYetSubmitted && canSubmit) {
            dcrnCount++;
          }
        }
      });

      return standardCount + dcrnCount;
    })();

    const revPendingCount = (() => {
      // DCRN pending reviews only
      let dcrnCount = 0;
      dcrnRequests.forEach(req => {
        (req.initialDocs || []).forEach(doc => {
          if (doc.assignedReviewerId === userInDB.id && doc.workflowStatus === 'PendingReview') {
            dcrnCount++;
          }
        });
      });
      return dcrnCount;
    })();

    const apprPendingCount = (() => {
      // DCRN pending approvals only
      let dcrnCount = 0;
      dcrnRequests.forEach(req => {
        (req.initialDocs || []).forEach(doc => {
          if (doc.assignedApproverId === userInDB.id && doc.workflowStatus === 'PendingApproval') {
            dcrnCount++;
          }
        });
      });
      return dcrnCount;
    })();

    const userDeptCodeBadge = userInDB?.department || '';
    const pendingAssessmentsForDept = userDeptCodeBadge ? dcrnRequests.filter(req => {
      if (req.status !== 'Pending_Impact_Assessment') return false;
      const ass = req.assessments && req.assessments[userDeptCodeBadge];
      return ass && ass.impacted === null;
    }) : [];

    return (
      <div className="space-y-5" id="consolidated-dashboard-system">
        {/* If the user possesses multiple roles, show the tabbed workspace navigator */}
        {userRoles.length > 1 && (
          <div className="bg-white p-3.5 rounded-lg border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-3.5" id="workspace-navigator-bar">
            <div className="flex items-center gap-2">
              <span className="p-1 px-2.5 bg-slate-100 rounded text-slate-700 font-mono text-[10px] font-bold uppercase tracking-wider border border-slate-200">
                Responsibility Center
              </span>
              <h2 className="text-xs font-bold text-slate-800 tracking-tight">Select active workplace portal:</h2>
            </div>
            
            <div className="flex flex-wrap gap-2">
              {userRoles.map((role) => {
                let label = '';
                let badgeCount = 0;
                let activeColorTheme = '';

                if (role === 'Admin') {
                  label = 'Control Panel';
                  badgeCount = 0;
                  activeColorTheme = 'bg-slate-900 border-slate-950 text-white';
                } else if (role === 'Preparer') {
                  label = 'Preparer Workspace';
                  badgeCount = dcrnRequests.filter(req => {
                      if (req.status === "Completed") return false;
                      if (!userInDB.department) return true;
                      const isPreparerDept = req.preparedBy?.department === userInDB.department;
                      const hasAddedDocs = req.initialDocs.some(doc => doc.addedByDept === userInDB.department);
                      return isPreparerDept || hasAddedDocs;
                  }).length;
                  activeColorTheme = 'bg-blue-600 border-blue-700 text-white';
                } else if (role === 'Reviewer') {
                  label = 'Reviewer Board';
                  badgeCount = revPendingCount;
                  activeColorTheme = 'bg-emerald-600 border-emerald-700 text-white';
                } else if (role === 'Approver') {
                  label = 'Approver Vault';
                  badgeCount = apprPendingCount;
                  activeColorTheme = 'bg-indigo-600 border-indigo-700 text-white';
                } else if (role === 'MR') {
                  label = 'MR Workspace';
                  const unauthorizedCount = dcrnRequests.filter(r => 
                    r.status !== 'Completed' && r.status !== 'Rejected' && !r.mrRegistryNumber
                  ).length;
                  const openCount = dcrnRequests.filter(r => 
                    r.status !== 'Completed' && r.status !== 'Rejected' && !!r.mrRegistryNumber
                  ).length;
                  const closedPendingCount = dcrnRequests.filter(r => 
                    r.status === 'Completed' && r.initialDocs?.some(doc => doc.workflowStatus !== 'Downloaded')
                  ).length;
                  badgeCount = unauthorizedCount + openCount;
                  activeColorTheme = 'bg-pink-700 border-pink-800 text-white';
                } else if (role === 'QaGateway') {
                  label = 'QA Gateway';
                  badgeCount = dcrnRequests.filter(r => r.status === 'Pending_QA_Evaluation' || r.status === 'Pending_QA_Stage2').length;
                  activeColorTheme = 'bg-blue-600 border-blue-700 text-white';
                }

                const isCurrent = currentActiveRole === role;

                return (
                  <button
                    key={role}
                    type="button"
                    onClick={() => setActiveRole(role as any)}
                    className={`px-3.5 py-2 rounded-lg text-xs font-bold font-sans flex items-center gap-2 transition-all cursor-pointer border relative select-none shadow-xs ${
                      isCurrent
                        ? activeColorTheme
                        : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-650 hover:text-slate-900'
                    }`}
                    id={`workspace-tab-${role.toLowerCase()}`}
                  >
                    <span className="capitalize">{label}</span>
                    {badgeCount > 0 && (
                      <span className={`inline-flex items-center justify-center px-2 py-0.5 rounded-lg font-mono text-[10px] font-extrabold leading-none ${
                        role === 'Preparer' || role === 'Reviewer' || role === 'Approver' || role === 'QaGateway' || role === 'MR'
                          ? 'bg-red-600 text-white animate-pulse shadow-sm'
                          : isCurrent
                            ? 'bg-white/20 text-white font-extrabold'
                            : 'bg-slate-100 text-slate-600'
                      }`}>
                        {badgeCount}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Departmental Impact Assessments Panel */}
        {userDeptCodeBadge && pendingAssessmentsForDept.length > 0 && (
          <div className="bg-white rounded-xl border border-red-200/80 shadow-md p-5 space-y-4" id="postponed-dept-assessments-panel">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="p-0.5 px-2 bg-rose-50 border border-rose-250 text-rose-700 text-[10px] font-mono font-bold rounded animate-pulse">
                    MANDATORY COMPLIANCE ASSIGNMENT
                  </span>
                  <span className="text-slate-500 text-xs font-mono">({DEPARTMENT_MAP[userDeptCodeBadge] || userDeptCodeBadge} Department)</span>
                </div>
                <h3 className="text-sm font-bold text-slate-900 font-sans tracking-tight">
                  Outstanding Departmental Impact Assessments
                </h3>
              </div>
              <span className="text-xs bg-slate-105 text-slate-650 px-2.5 py-1 rounded-full font-bold">
                {pendingAssessmentsForDept.length} pending
              </span>
            </div>

            <div className="space-y-3">
              {pendingAssessmentsForDept.map((req) => {
                const isPostponed = globalDismissedPopupRequests[req.id + "-" + userDeptCodeBadge];
                const isExpanded = activeInlineAssessmentId === req.id;
                const { previouslyAnalyzed, newlyAdded, hasPrevious } = getDifferentiatedDocs(req, userDeptCodeBadge);

                return (
                  <div key={req.id} className={`border rounded-xl transition-all overflow-hidden ${isExpanded ? 'border-indigo-300 shadow-md bg-white' : 'border-slate-200 bg-slate-50/40 hover:bg-slate-50'}`}>
                    <div 
                      onClick={() => setActiveInlineAssessmentId(isExpanded ? null : req.id)}
                      className="p-3.5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 cursor-pointer select-none"
                    >
                      <div className="space-y-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-mono text-xs font-bold text-slate-800 bg-white border px-1.5 py-0.5 rounded">DCRN: {req.id}</span>
                          {isPostponed ? (
                            <span className="inline-flex px-1.5 py-0.5 bg-amber-100 text-amber-800 border border-amber-200 rounded text-[9.5px] font-mono font-bold uppercase tracking-tight">
                              Notification Postponed
                            </span>
                          ) : (
                            <span className="inline-flex px-1.5 py-0.5 bg-blue-100 text-blue-800 border border-blue-200 rounded text-[9.5px] font-mono font-bold uppercase tracking-tight">
                              Pending Review
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-500">
                          Prepared By: <strong className="text-slate-700">{req.preparedBy?.userName}</strong> | Date Requested: <strong>{req.createdAt.substring(0, 10)}</strong>
                        </p>
                      </div>

                      <div className="flex items-center gap-2 self-stretch sm:self-auto justify-end">
                        {isPostponed && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setGlobalDismissedPopupRequests(prev => ({ ...prev, [req.id + "-" + userDeptCodeBadge]: false }));
                            }}
                            className="px-2.5 py-1 hover:bg-slate-200 text-slate-650 border rounded-lg text-[11px] font-bold cursor-pointer transition-colors flex items-center gap-1 font-sans"
                            title="Bring back the full modal pop-up dialogue"
                          >
                            <AlertTriangle className="w-3 h-3 text-amber-600 shrink-0" />
                            <span>Show Popup</span>
                          </button>
                        )}
                        <span 
                          className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white border border-blue-700 rounded-lg text-[11px] font-bold shadow-xs cursor-pointer transition-colors"
                        >
                          {isExpanded ? 'Collapse Form' : 'Analyze Impact'}
                        </span>
                      </div>
                    </div>

                    {isExpanded && (
                      <div className="p-4 bg-white border-t border-slate-100 space-y-4 text-xs">
                        {/* Summary Block */}
                        <div className="space-y-3">
                          <div className="border border-slate-200 rounded-xl overflow-hidden bg-slate-50 shadow-sm">
                            <div className="bg-slate-100 px-3 py-1.5 border-b border-slate-200 flex justify-between items-center text-slate-800">
                              <span className="text-[10px] font-mono font-bold uppercase tracking-wider block">
                                {hasPrevious ? "Previously Analyzed Documents" : "Baseline Original Documents"}
                              </span>
                              <span className="text-[9px] bg-slate-200 text-slate-705 px-1.5 py-0.2 rounded font-semibold font-sans">
                                {previouslyAnalyzed.length} items
                              </span>
                            </div>
                            <div className="divide-y divide-slate-105 max-h-40 overflow-y-auto p-1.5 space-y-2 bg-white">
                              {previouslyAnalyzed.length === 0 ? (
                                <p className="p-3 text-xs italic text-slate-400 font-sans text-center">No baseline documents.</p>
                              ) : (
                                previouslyAnalyzed.map((mDoc, mIdx) => (
                                  <div key={mIdx} className="p-2 border border-slate-100 rounded-lg text-[11px] bg-slate-50/50">
                                    <span className="font-bold font-mono text-slate-800 select-all">
                                      📄 {mDoc.docNumber} (Rev: {mDoc.currentRevision || '-'}){" "}
                                      {mDoc.title && (
                                        <span className="text-[10px] text-indigo-755 font-bold bg-indigo-50 border border-indigo-150 rounded px-1.5 py-0.2 mx-1 inline-block font-sans normal-case">
                                          Title: {mDoc.title}
                                        </span>
                                      )}
                                      <span className="text-[9px] font-sans font-normal text-slate-500">[{mDoc.actionType || 'Change'}]</span>
                                    </span>
                                    <div className="grid grid-cols-2 gap-2 mt-1">
                                      <div>
                                        <span className="text-[8.5px] font-mono text-slate-400 font-bold block uppercase">Reason:</span>
                                        <p className="text-slate-650 font-sans mt-0.5">{mDoc.reasonForChange}</p>
                                      </div>
                                      <div>
                                        <span className="text-[8.5px] font-mono text-slate-400 font-bold block uppercase">Proposed Changes:</span>
                                        <p className="text-slate-650 font-sans mt-0.5">{mDoc.changesRequired}</p>
                                      </div>
                                    </div>
                                  </div>
                                ))
                              )}
                            </div>
                          </div>

                          {newlyAdded.length > 0 && (
                            <div className="border border-amber-250 rounded-xl overflow-hidden bg-amber-50/50 shadow-sm">
                              <div className="bg-amber-100 px-3 py-1.5 border-b border-amber-200 flex justify-between items-center text-amber-900">
                                <span className="text-[10px] font-mono font-bold uppercase tracking-wider block flex items-center gap-1">
                                  <AlertTriangle className="w-3.5 h-3.5 text-amber-700 shrink-0 animate-pulse pointer-events-none" />
                                  <span>NEWLY ADDED IMPACTED DOCUMENTS (NEEDS ASSESSMENT)</span>
                                </span>
                                <span className="text-[9px] bg-amber-200 text-amber-805 px-1.5 py-0.2 rounded font-mono font-bold">
                                  NEW: {newlyAdded.length}
                                </span>
                              </div>
                              <div className="divide-y divide-amber-105 max-h-40 overflow-y-auto p-1.5 space-y-2 bg-white">
                                {newlyAdded.map((mDoc, mIdx) => (
                                  <div key={mIdx} className="p-2 border border-amber-100 rounded-lg text-[11px] bg-amber-50/30">
                                    <div className="flex justify-between items-center mb-1">
                                      <span className="font-bold font-mono text-slate-800 select-all">
                                        📄 {mDoc.docNumber} (Rev: {mDoc.currentRevision || '-'}){" "}
                                        {mDoc.title && (
                                          <span className="text-[10px] text-amber-900 font-bold bg-amber-100 border border-amber-200 rounded px-1.5 py-0.2 mx-1 inline-block font-sans normal-case">
                                            Title: {mDoc.title}
                                          </span>
                                        )}
                                        <span className="text-[9px] font-sans font-normal text-slate-500">[{mDoc.actionType || 'Change'}]</span>
                                      </span>
                                      <span className="text-[8.5px] bg-indigo-50 text-indigo-700 border border-indigo-100 px-1.5 rounded font-bold font-mono uppercase">
                                        Added by: {DEPARTMENT_MAP[mDoc.addedByDept || ''] || mDoc.addedByDept || 'Unknown'}
                                      </span>
                                    </div>
                                    <div className="grid grid-cols-2 gap-2 mt-1">
                                      <div>
                                        <span className="text-[8.5px] font-mono text-slate-400 font-bold block uppercase">Reason:</span>
                                        <p className="text-slate-650 font-sans mt-0.5">{mDoc.reasonForChange}</p>
                                      </div>
                                      <div>
                                        <span className="text-[8.5px] font-mono text-slate-400 font-bold block uppercase">Proposed Changes:</span>
                                        <p className="text-slate-650 font-sans mt-0.5">{mDoc.changesRequired}</p>
                                      </div>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>

                        {/* Choice block */}
                        <div className="bg-[#fbfcff] border border-slate-200 p-4 rounded-xl space-y-4">
                          <div className="space-y-1.5">
                            <p className="text-xs font-bold text-slate-850">Does this Document Change/Introduction/Removal impact your department document?</p>
                            <div className="flex gap-5 mt-1">
                              <label className="inline-flex items-center gap-1.5 text-xs font-sans text-slate-700 cursor-pointer select-none">
                                <input
                                  type="radio"
                                  name={`dashboard-impact-choice-${req.id}`}
                                  checked={globalSelectedImpact[req.id] === 'No'}
                                  onChange={() => handleGlobalDeptChoice(req.id, 'No')}
                                  className="accent-emerald-600 cursor-pointer w-4 h-4"
                                />
                                <span><strong>No</strong> - No impact</span>
                              </label>

                              <label className="inline-flex items-center gap-1.5 text-xs font-sans text-slate-700 cursor-pointer select-none">
                                <input
                                  type="radio"
                                  name={`dashboard-impact-choice-${req.id}`}
                                  checked={globalSelectedImpact[req.id] === 'Yes'}
                                  onChange={() => handleGlobalDeptChoice(req.id, 'Yes')}
                                  className="accent-indigo-600 cursor-pointer w-4 h-4"
                                />
                                <span><strong>Yes</strong> - Impacted</span>
                              </label>
                            </div>
                          </div>

                          {globalSelectedImpact[req.id] === 'Yes' && (
                            <div className="space-y-3 border-t border-slate-200 pt-3">
                              <div className="flex justify-between items-center bg-white p-2 rounded border">
                                <span className="text-[9.5px] font-mono font-bold text-slate-500 uppercase font-sans">
                                  Impacted Files & Procedures for: {userDeptCodeBadge}
                                </span>
                                <button
                                  type="button"
                                  onClick={() => handleGlobalAddDeptDoc(req.id)}
                                  className="px-2 py-0.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border text-[10px] rounded font-bold cursor-pointer transition-all flex items-center gap-1 animate-pulse font-sans"
                                >
                                  <Plus className="w-3.5 h-3.5" />
                                  <span>+ Add Document</span>
                                </button>
                              </div>

                              <div className="grid gap-4 max-h-[460px] overflow-y-auto pr-1 grid-cols-1">
                                {(globalDepartmentDocs[req.id] || []).map((dDoc, idx) => (
                                  <div key={idx} className="bg-slate-50/50 border hover:border-slate-300 p-4 rounded-xl space-y-3 relative shadow-xs transition-all">
                                    <div className="flex justify-between items-center text-[10.5px] font-bold border-b pb-1.5 text-slate-650 font-sans">
                                      <span className="flex items-center gap-1.5">
                                        <FileText className="w-3.5 h-3.5 text-indigo-600" />
                                        <span>AFFECTED DOCUMENT #{idx + 1}</span>
                                      </span>
                                      {(globalDepartmentDocs[req.id] || []).length > 1 && (
                                        <button
                                          type="button"
                                          onClick={() => handleGlobalRemoveDeptDoc(req.id, idx)}
                                          className="text-rose-500 hover:text-rose-700 hover:bg-rose-50 p-1 rounded-md transition-colors cursor-pointer"
                                          title="Delete Record"
                                        >
                                          <Trash2 className="w-3.5 h-3.5" />
                                        </button>
                                      )}
                                    </div>

                                    <div className="grid gap-3 grid-cols-1 sm:grid-cols-3 text-xs">
                                      {/* Action Type */}
                                      <div>
                                        <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Action Type *</label>
                                        <select
                                          value={dDoc.actionType || 'Change'}
                                          onChange={(e) => {
                                            const newAction = e.target.value as 'Change' | 'Introduction' | 'Removal';
                                            handleGlobalUpdateDeptDoc(req.id, idx, 'actionType', newAction);
                                            if (newAction === 'Introduction') {
                                              handleGlobalUpdateDeptDoc(req.id, idx, 'currentRevision', '-');
                                            } else if (dDoc.currentRevision === '-') {
                                              handleGlobalUpdateDeptDoc(req.id, idx, 'currentRevision', '');
                                            }
                                            if (newAction === 'Removal') {
                                              handleGlobalUpdateDeptDoc(req.id, idx, 'nextRevision', '-');
                                            } else if (dDoc.nextRevision === '-') {
                                              handleGlobalUpdateDeptDoc(req.id, idx, 'nextRevision', '');
                                            }
                                          }}
                                          className="w-full bg-white border border-slate-200 focus:border-indigo-500 rounded p-1.5 outline-none text-[11px] font-medium"
                                          required
                                        >
                                          <option value="Change">Change</option>
                                          <option value="Introduction">Introduction</option>
                                          <option value="Removal">Removal</option>
                                        </select>
                                      </div>

                                      {/* Doc Number */}
                                      <div>
                                        <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Doc Number *</label>
                                        <input
                                          type="text"
                                          value={dDoc.docNumber}
                                          onChange={(e) => handleGlobalUpdateDeptDoc(req.id, idx, 'docNumber', e.target.value)}
                                          placeholder="e.g., SOP-MN-304"
                                          className="w-full bg-white border border-slate-200 focus:border-indigo-500 rounded p-1.5 outline-none text-[11px] font-mono font-bold"
                                          required
                                        />
                                      </div>

                                      {/* Document Title */}
                                      <div>
                                        <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Document Title *</label>
                                        <input
                                          type="text"
                                          value={dDoc.title || ""}
                                          onChange={(e) => handleGlobalUpdateDeptDoc(req.id, idx, 'title', e.target.value)}
                                          placeholder="e.g., Calibrator Work Instruction"
                                          className="w-full bg-white border border-slate-200 focus:border-indigo-500 rounded p-1.5 outline-none text-[11px] font-medium"
                                          required
                                        />
                                      </div>
                                    </div>

                                    <div className="grid gap-3 grid-cols-1 sm:grid-cols-2 text-xs">
                                      {/* Current Rev */}
                                      <div>
                                        <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Current Rev *</label>
                                        <input
                                          type="text"
                                          value={dDoc.actionType === 'Introduction' ? '-' : (dDoc.currentRevision || '')}
                                          disabled={dDoc.actionType === 'Introduction'}
                                          onChange={(e) => handleGlobalUpdateDeptDoc(req.id, idx, 'currentRevision', e.target.value.toUpperCase())}
                                          placeholder="e.g., AA"
                                          pattern="[A-Za-z]{2}"
                                          title="Must be exactly 2 letters"
                                          maxLength={2}
                                          className="w-full bg-white border border-slate-200 focus:border-indigo-500 rounded p-1.5 outline-none text-[11px] font-mono font-bold disabled:bg-slate-200"
                                          required
                                        />
                                      </div>

                                      {/* Next Rev */}
                                      <div>
                                        <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Next Rev *</label>
                                        <input
                                          type="text"
                                          value={dDoc.actionType === 'Removal' ? '-' : (dDoc.nextRevision || '')}
                                          disabled={dDoc.actionType === 'Removal'}
                                          onChange={(e) => handleGlobalUpdateDeptDoc(req.id, idx, 'nextRevision', e.target.value.toUpperCase())}
                                          placeholder="e.g., AB"
                                          pattern="[A-Za-z]{2}"
                                          title="Must be exactly 2 letters"
                                          maxLength={2}
                                          className="w-full bg-white border border-slate-200 focus:border-indigo-500 rounded p-1.5 outline-none text-[11px] font-mono font-bold disabled:bg-slate-200"
                                          required
                                        />
                                      </div>
                                    </div>

                                    <div className="grid gap-3 grid-cols-1 sm:grid-cols-2 text-xs">
                                      {/* Reason */}
                                      <div>
                                        <label className="block text-[10px] font-bold text-slate-500 uppercase flex justify-between items-center mb-1">
                                          <span>Reason for Change *</span>
                                          <span className="text-[8.5px] text-indigo-600 font-normal">Click chat button to expand</span>
                                        </label>
                                        <div className="relative flex items-center bg-white rounded border border-slate-200 focus-within:border-indigo-500">
                                          <input
                                            type="text"
                                            value={dDoc.reasonForChange}
                                            onChange={(e) => handleGlobalUpdateDeptDoc(req.id, idx, 'reasonForChange', e.target.value)}
                                            placeholder="Reason for change..."
                                            className="w-full bg-transparent p-1.5 pr-8 outline-none text-[11px]"
                                            required
                                          />
                                          <button
                                            type="button"
                                            onClick={() => openTextEditor(req.id, idx, 'reasonForChange', dDoc.reasonForChange || '', 'Reason')}
                                            title="Open rich text editor window"
                                            className="absolute right-1.5 p-1 text-slate-400 hover:text-indigo-600 hover:bg-slate-100 rounded transition-all cursor-pointer flex items-center justify-center animate-bounce"
                                          >
                                            <MessageSquare className="w-3.5 h-3.5 text-indigo-600" />
                                          </button>
                                        </div>
                                      </div>

                                      {/* Proposed Change */}
                                      <div>
                                        <label className="block text-[10px] font-bold text-slate-500 uppercase flex justify-between items-center mb-1">
                                          <span>Proposed Change *</span>
                                          <span className="text-[8.5px] text-indigo-600 font-normal">Click chat button to expand</span>
                                        </label>
                                        <div className="relative flex items-center bg-white rounded border border-slate-200 focus-within:border-indigo-500">
                                          <input
                                            type="text"
                                            value={dDoc.changesRequired}
                                            onChange={(e) => handleGlobalUpdateDeptDoc(req.id, idx, 'changesRequired', e.target.value)}
                                            placeholder="Technical specifications changed..."
                                            className="w-full bg-transparent p-1.5 pr-8 outline-none text-[11px]"
                                            required
                                          />
                                          <button
                                            type="button"
                                            onClick={() => openTextEditor(req.id, idx, 'changesRequired', dDoc.changesRequired || '', 'Proposed Change')}
                                            title="Open rich text editor window"
                                            className="absolute right-1.5 p-1 text-slate-400 hover:text-indigo-600 hover:bg-slate-100 rounded transition-all cursor-pointer flex items-center justify-center animate-bounce font-bold"
                                          >
                                            <MessageSquare className="w-3.5 h-3.5 text-indigo-600" />
                                          </button>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                          <div className="flex justify-end pt-3 border-t">
                            <button
                              type="button"
                              onClick={() => {
                                handleGlobalDeptSubmit(req.id, userDeptCodeBadge);
                                setActiveInlineAssessmentId(null);
                              }}
                              className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white border border-emerald-700 rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-sm cursor-pointer transition-colors font-sans"
                            >
                              <CheckCircle2 className="w-4 h-4" />
                              <span>Authorize & Submit Assessment</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Selected Workspace Panel rendering */}
        <div id={`isolated-context-container-${currentActiveRole.toLowerCase()}`}>
          {(() => {
            switch (currentActiveRole) {
              case 'QaGateway':
                return (
                  <QaGatewayWorkspace
                    currentUser={userInDB}
                    dcrnRequests={dcrnRequests}
                    onEvaluateDcrnRequest={handleEvaluateDcrnRequest}
                  />
                );
              case 'Admin':
                return (
                  <AdminPanel
                    currentUser={userInDB}
                    users={users}
                    onUpdateUserRoles={handleUpdateUserRoles}
                    onAddUser={handleAddUser}
                    onUpdateUserCredentials={handleUpdateUserCredentials}
                    documents={documents}
                    onApproveRemoval={handleApproveRemoval}
                    onRejectRemoval={handleRejectRemoval}
                  />
                );
              case 'Preparer':
                return (
                  <PreparerWorkspace
                    currentUser={userInDB}
                    documents={documents}
                    onAddDocument={handleAddDocument}
                    onUpdateDraftContent={handleUpdateDraftContent}
                    onSubmitDocument={handleSubmitDocument}
                    onDeleteDocument={handleDeleteDocument}
                    onRequestRemoval={handleRequestRemoval}
                    users={users}
                    dcrnRequests={dcrnRequests}
                    onDeleteDcrnRequest={handleDeleteDcrnRequest}
                    onAddDcrnRequest={handleAddDcrnRequest}
                    onEvaluateDcrnRequest={handleEvaluateDcrnRequest}
                    onSubmitDepartmentAssessment={handleSubmitDepartmentAssessment}
                    onAuthorizeDcrnRequest={handleAuthorizeDcrnRequest}
                    onRejectDcrnRemoval={handleRejectDcrnDeletion}
                    onUpdateDcrnRequest={handleUpdateDcrnRequest}
                    onUpdateDcrnDocumentField={handleUpdateDcrnDocumentField}
                    onSubmitToQa={handleSubmitToQa}
                    onDownloadSOP={handleDownloadSOP}
                  />
                );
              case 'Reviewer':
                return (
                  <ReviewerWorkspace
                    currentUser={userInDB}
                    documents={documents}
                    onPassReview={handlePassReview}
                    onRejectReview={handleRejectReview}
                    onAddComment={handleAddComment}
                    onProvideSoftCopy={handleProvideSoftCopy}
                    users={users}
                    dcrnRequests={dcrnRequests}
                    onUpdateDcrnDocumentField={handleUpdateDcrnDocumentField}
                  />
                );
              case 'Approver':
                return (
                  <ApproverWorkspace
                    currentUser={userInDB}
                    documents={documents}
                    onApproveDocument={handleApproveDocument}
                    onRejectApproval={handleRejectApproval}
                    onAddComment={handleAddComment}
                    auditLogs={auditLogs}
                    users={users}
                    dcrnRequests={dcrnRequests}
                    onUpdateDcrnDocumentField={handleUpdateDcrnDocumentField}
                  />
                );
              case 'MR':
                return (
                  <DocumentRequestQueue
                    currentUser={userInDB}
                    documents={documents}
                    onProvideSoftCopy={handleProvideSoftCopy}
                    onDownloadSOP={handleDownloadSOP}
                    onApproveRemoval={handleApproveRemoval}
                    onRejectRemoval={handleRejectRemoval}
                    dcrnRequests={dcrnRequests}
                    onApproveDcrnRemoval={handleDeleteDcrnRequest}
                    onRejectDcrnRemoval={handleRejectDcrnDeletion}
                    onAuthorizeDcrnRequest={handleAuthorizeDcrnRequest}
                    onAssignDcrnRegistryNumber={handleAssignDcrnRegistryNumber}
                    onRejectDepartmentAssessment={handleRejectDepartmentAssessment}
                    onUploadDcrnDocument={handleUploadDcrnDocument}
                  />
                );
              default:
                return (
                  <div className="bg-white p-8 rounded-lg border text-center text-slate-400">
                    Select a workspace view to display control procedures.
                  </div>
                );
            }
          })()}
        </div>
      </div>
    );
  };

  const prepCountForBadge = documents.filter(
    doc => doc.preparedBy.userId === userInDB.id && 
    (doc.status === DocumentStatus.Draft || doc.status === DocumentStatus.SoftCopyProvided || doc.status === DocumentStatus.Rejected)
  ).length;

  const revCountForBadge = documents.filter(
    doc => doc.status === DocumentStatus.PendingReview && doc.assignedReviewer?.userId === userInDB.id
  ).length;

  const apprCountForBadge = documents.filter(
    doc => doc.status === DocumentStatus.PendingApproval && doc.assignedApprover?.userId === userInDB.id
  ).length;

  const overallPendingBadgeCount = (userInDB.isPreparer ? prepCountForBadge : 0) +
                                   (userInDB.isReviewer ? revCountForBadge : 0) +
                                   (userInDB.isApprover ? apprCountForBadge : 0);

  // Active DCRN task notifications for the top tab badge
  const qaPendingCountBadge = dcrnRequests.filter(r => r.status === 'Pending_QA_Evaluation').length;
  const userDeptCodeBadge = userInDB?.department || '';
  
  // Any user with a non-empty department can assess if they have a pending slot in assessments
  const deptPendingCountBadge = userDeptCodeBadge ? dcrnRequests.filter(r => {
    if (r.status !== 'Pending_Impact_Assessment') return false;
    const ass = r.assessments && r.assessments[userDeptCodeBadge];
    return ass && ass.impacted === null;
  }).length : 0;

  // MR can authorize once all departments listed in assessments have signed off
  const mrPendingCountBadge = userInDB?.isMR ? dcrnRequests.filter(r => {
    if (r.status !== 'Pending_Impact_Assessment') return false;
    const assessments = r.assessments || {};
    const keys = Object.keys(assessments);
    if (keys.length === 0) return false;
    return keys.every(code => {
      const ass = assessments[code];
      return ass && ass.impacted !== null;
    });
  }).length : 0;

  const dcrnBadgeTotal = (userInDB?.department === 'QA' ? qaPendingCountBadge : 0) +
                       deptPendingCountBadge +
                       (userInDB?.isMR ? mrPendingCountBadge : 0);

  // Find a pending request requiring our department that hasn't been completed-signed or dismissed yet (global scope)
  const pendingGlobalPopupRequest = dcrnRequests.find(r => 
    r.status === 'Pending_Impact_Assessment' && 
    userDeptCodeBadge && 
    r.assessments && 
    r.assessments[userDeptCodeBadge] && 
    r.assessments[userDeptCodeBadge].impacted === null &&
    !globalDismissedPopupRequests[r.id + "-" + userDeptCodeBadge]
  );

  // ----------------------------------------------------
  // Base Electron Frame Layout Wrapper
  // ----------------------------------------------------
  return (
    <div className="min-h-screen bg-[#F3F4F6] flex flex-col items-stretch outline-none selection:bg-blue-105 font-sans text-[#111827]" id="secured-desktop-frame">
      {/* Title bar of the desktop app shell */}
      <DesktopHeader
        currentUser={userInDB}
        activeRole={activeRole}
        setActiveRole={setActiveRole}
        onLogout={handleLogout}
        systemConnected={true}
      />

      {/* Main Container Core layout */}
      <div className="flex-1 w-full max-w-7xl mx-auto px-4 py-5 flex flex-col gap-6">
        
        {/* Navigation Switch Tabs at upper scope */}
        <div className="flex items-center justify-between border-b border-gray-200 pb-2">
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setActiveNavTab('workspace')}
              className={`px-4 py-2.5 text-xs font-bold leading-none cursor-pointer border rounded-md transition-all flex items-center gap-1.5 ${
                activeNavTab === 'workspace'
                  ? 'bg-blue-50 border-blue-200 text-blue-700 shadow-sm border-l-4 border-l-blue-600'
                  : 'bg-white hover:bg-gray-50 border-gray-250 text-gray-550 hover:text-gray-800'
              }`}
              id="tab-active-workspace"
            >
              <LayoutDashboard className="w-4 h-4" />
              <span>{activeRole} Workspace Dashboard</span>
            </button>
          </div>

          <div className="hidden lg:flex items-center gap-2 text-xs font-mono font-medium text-slate-500 bg-white px-3 py-1.5 rounded-md border border-gray-200">
            <BookmarkCheck className="w-4 h-4 text-emerald-600" />
            <span>ENFORCED SYSTEM MODULE: {activeRole.toUpperCase()} CONNECTED</span>
          </div>
        </div>

        {/* Selected Area Content render */}
        <div className="flex-1">
          {activeNavTab === 'workspace' ? (
            renderWorkspaceContent()
          ) : (
            <AuditTrailConsole
              auditLogs={auditLogs}
              onExportAuditLogs={handleExportAuditLogs}
            />
          )}
        </div>
      </div>

      {/* FOOTER DESK DIAGNOSTIC BAR AND SYSTEM LAUNCHER */}
      <footer className="bg-slate-900 text-slate-400 text-[11px] border-t border-slate-800 p-3 flex flex-col md:flex-row justify-between items-center gap-3 select-none">
        <div className="flex items-center gap-4 text-center md:text-left font-mono">
          <div className="flex items-center gap-1.5 text-blue-400">
            <Building2 className="w-3.5 h-3.5" />
            <span>PMC CONTROL LEDGER NETWORK</span>
          </div>
          <span className="hidden md:inline text-slate-600">|</span>
          <span className="text-[10px]">Validated Desktop Build Code: <span className="text-slate-200">A41-CFR-P11-OK</span></span>
        </div>

        <div className="flex items-center gap-4">
          <span className="text-[10px] italic text-slate-500 hidden sm:inline">Regulatory computer system validation certified under GAMP-5 protocols.</span>
          <button
            onClick={handleFactoryReset}
            className="p-1 px-2.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-slate-705 text-amber-500 rounded font-bold font-mono text-[9px] flex items-center gap-1 cursor-pointer transition-colors"
            title="Wipe database modifications and restore demo defaults"
            id="btn-factory-reset"
          >
            <RefreshCw className="w-2.5 h-2.5" />
            <span>Demo DB Reset</span>
          </button>
        </div>
      </footer>

      <DownloadVaultModal
        isOpen={downloadModalOpen}
        onClose={() => setDownloadModalOpen(false)}
        fileName={downloadFileName}
        fileSize={downloadFileSize}
        fileContent={downloadFileContent}
        fileType="csv"
        checksum={downloadChecksum}
      />

      {/* 21 CFR Part 11 Dynamic Impact Assessment Pop-up modal */}
      {pendingGlobalPopupRequest && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 max-w-2xl w-full shadow-2xl relative space-y-5 my-8">
            
            {/* Header Compliance Flag */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b pb-4">
              <div className="space-y-1">
                <h3 className="text-base font-bold text-slate-900 font-sans tracking-tight">
                  Mandatory Departmental Impact Assessment
                </h3>
              </div>
            </div>

            {/* Explanatory Description */}
            <div className="text-xs text-slate-500 space-y-2 leading-relaxed">
              <p>
                A Document Change Request, prepared by <strong className="text-slate-800 font-bold">{pendingGlobalPopupRequest.preparedBy?.userName} ({pendingGlobalPopupRequest.preparedBy?.department})</strong>, has been successfully approved by the QA Gateway. 
              </p>
            </div>

            {/* Master Document Packet summary with separate tables */}
            {(() => {
              const { previouslyAnalyzed, newlyAdded, hasPrevious } = getDifferentiatedDocs(pendingGlobalPopupRequest, userDeptCodeBadge);
              
              return (
                <div className="space-y-4">
                  {/* Table 1: Previously Analyzed / Baseline Documents */}
                  <div className="border border-slate-200 rounded-xl overflow-hidden bg-slate-50 shadow-sm">
                    <div className="bg-slate-100 px-3 py-2 border-b border-slate-200 flex justify-between items-center text-slate-800">
                      <span className="text-[10px] font-mono font-bold uppercase tracking-wider block">
                        {hasPrevious ? "Previously Analyzed Documents" : "Baseline Original Documents"}
                      </span>
                      <span className="text-[9px] bg-slate-200 text-slate-705 px-1.5 py-0.2 rounded font-semibold font-sans">
                        {previouslyAnalyzed.length} items
                      </span>
                    </div>
                    {previouslyAnalyzed.length === 0 ? (
                      <div className="p-3 text-xs italic text-slate-400 font-sans text-center">No baseline documents.</div>
                    ) : (
                      <div className="divide-y divide-slate-105 max-h-40 overflow-y-auto p-1.5 space-y-2 bg-white">
                        {previouslyAnalyzed.map((mDoc, mIdx) => (
                          <div key={mIdx} className="p-2 border border-slate-100 rounded-lg text-[11px] bg-slate-50/50">
                            <span className="font-bold font-mono text-slate-800 select-all">
                              📄 {mDoc.docNumber} (Rev: {mDoc.currentRevision || '-'}){" "}
                              {mDoc.title && (
                                <span className="text-[10px] text-indigo-755 font-bold bg-indigo-50 border border-indigo-150 rounded px-1.5 py-0.2 mx-1 inline-block font-sans normal-case">
                                  Title: {mDoc.title}
                                </span>
                              )}
                              <span className="text-[9px] font-sans font-normal text-slate-500">[{mDoc.actionType || 'Change'}]</span>
                            </span>
                            <div className="grid grid-cols-2 gap-2 mt-1">
                              <div>
                                <span className="text-[8.5px] font-mono text-slate-400 font-bold block uppercase">Reason:</span>
                                <p className="text-slate-650 font-sans mt-0.5">{mDoc.reasonForChange}</p>
                              </div>
                              <div>
                                <span className="text-[8.5px] font-mono text-slate-400 font-bold block uppercase">Proposed Change:</span>
                                <p className="text-slate-650 font-sans mt-0.5">{mDoc.changesRequired}</p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Table 2: Newly Added Impacted Documents */}
                  {newlyAdded.length > 0 && (
                    <div className="border border-amber-250 rounded-xl overflow-hidden bg-amber-50/50 shadow-sm">
                      <div className="bg-amber-100 px-3 py-2 border-b border-amber-200 flex justify-between items-center text-amber-900">
                        <span className="text-[10px] font-mono font-bold uppercase tracking-wider block flex items-center gap-1">
                          <AlertTriangle className="w-3.5 h-3.5 text-amber-700 font-bold shrink-0 animate-pulse pointer-events-none" />
                          <span>NEWLY ADDED IMPACTED DOCUMENTS (NEEDS ASSESSMENT)</span>
                        </span>
                        <span className="text-[9px] bg-amber-200 text-amber-805 px-1.5 py-0.2 rounded font-mono font-bold">
                          NEW: {newlyAdded.length}
                        </span>
                      </div>
                      <div className="divide-y divide-amber-105 max-h-40 overflow-y-auto p-1.5 space-y-2 bg-white">
                        {newlyAdded.map((mDoc, mIdx) => (
                          <div key={mIdx} className="p-2 border border-amber-100 rounded-lg text-[11px] bg-amber-50/30">
                            <div className="flex justify-between items-center mb-1">
                              <span className="font-bold font-mono text-slate-800 select-all">
                                📄 {mDoc.docNumber} (Rev: {mDoc.currentRevision || '-'}){" "}
                                {mDoc.title && (
                                  <span className="text-[10px] text-amber-900 font-bold bg-amber-100 border border-amber-200 rounded px-1.5 py-0.2 mx-1 inline-block font-sans normal-case">
                                    Title: {mDoc.title}
                                  </span>
                                )}
                                <span className="text-[9px] font-sans font-normal text-slate-500">[{mDoc.actionType || 'Change'}]</span>
                              </span>
                              <span className="text-[8.5px] bg-indigo-50 text-indigo-700 border border-indigo-100 px-1.5 rounded font-bold font-mono uppercase">
                                Added by: {DEPARTMENT_MAP[mDoc.addedByDept || ''] || mDoc.addedByDept || 'Unknown'}
                              </span>
                            </div>
                            <div className="grid grid-cols-2 gap-2 mt-1">
                              <div>
                                <span className="text-[8.5px] font-mono text-slate-400 font-bold block uppercase">Reason:</span>
                                <p className="text-slate-650 font-sans mt-0.5">{mDoc.reasonForChange}</p>
                              </div>
                              <div>
                                <span className="text-[8.5px] font-mono text-slate-400 font-bold block uppercase">Proposed Change:</span>
                                <p className="text-slate-650 font-sans mt-0.5">{mDoc.changesRequired}</p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              );
            })()}

            {/* Assessment Choice */}
            <div className="bg-[#fbfcff] border border-slate-200 p-4 rounded-xl space-y-4">
              <div className="space-y-1.5">
                <p className="text-xs font-bold text-slate-850">Does this Document Change/Introduction/Removal impact your department document?</p>
                <div className="flex gap-5 mt-1">
                  <label className="inline-flex items-center gap-1.5 text-xs font-sans text-slate-700 cursor-pointer select-none">
                    <input
                      type="radio"
                      name={`global-popup-impact-choice-${pendingGlobalPopupRequest.id}`}
                      checked={globalSelectedImpact[pendingGlobalPopupRequest.id] === 'No'}
                      onChange={() => handleGlobalDeptChoice(pendingGlobalPopupRequest.id, 'No')}
                      className="accent-emerald-600 cursor-pointer w-4 h-4"
                    />
                    <span><strong>No</strong> - No impact</span>
                  </label>

                  <label className="inline-flex items-center gap-1.5 text-xs font-sans text-slate-700 cursor-pointer select-none">
                    <input
                      type="radio"
                      name={`global-popup-impact-choice-${pendingGlobalPopupRequest.id}`}
                      checked={globalSelectedImpact[pendingGlobalPopupRequest.id] === 'Yes'}
                      onChange={() => handleGlobalDeptChoice(pendingGlobalPopupRequest.id, 'Yes')}
                      className="accent-indigo-600 cursor-pointer w-4 h-4"
                    />
                    <span><strong>Yes</strong> - Impacted</span>
                  </label>
                </div>
              </div>

              {/* Yes choice: Show Dynamic Document Editor */}
              {globalSelectedImpact[pendingGlobalPopupRequest.id] === 'Yes' && (
                <div className="space-y-3 border-t border-slate-200 pt-3">
                  <div className="flex justify-between items-center bg-white p-2 rounded border">
                    <span className="text-[9.5px] font-mono font-bold text-slate-500 uppercase">
                      Impacted Files & Procedures for: {userDeptCodeBadge}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleGlobalAddDeptDoc(pendingGlobalPopupRequest.id)}
                      className="px-2 py-0.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border text-[10px] rounded font-bold cursor-pointer transition-all flex items-center gap-1 animate-pulse"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>+ Add Document</span>
                    </button>
                  </div>

                  <div className="grid gap-4 max-h-[460px] overflow-y-auto pr-1 grid-cols-1">
                    {(globalDepartmentDocs[pendingGlobalPopupRequest.id] || []).map((dDoc, idx) => (
                      <div key={idx} className="bg-slate-50/50 border hover:border-slate-300 p-4 rounded-xl space-y-3 relative shadow-xs transition-all">
                        <div className="flex justify-between items-center text-[10.5px] font-bold border-b pb-1.5 text-slate-650">
                          <span className="flex items-center gap-1.5">
                            <FileText className="w-3.5 h-3.5 text-indigo-600" />
                            <span>AFFECTED DOCUMENT #{idx + 1}</span>
                          </span>
                          {(globalDepartmentDocs[pendingGlobalPopupRequest.id] || []).length > 1 && (
                            <button
                              type="button"
                              onClick={() => handleGlobalRemoveDeptDoc(pendingGlobalPopupRequest.id, idx)}
                              className="text-rose-500 hover:text-rose-700 hover:bg-rose-50 p-1 rounded-md transition-colors cursor-pointer"
                              title="Delete Record"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>

                        <div className="space-y-4">
                          {/* Row 1: Action Type & Doc Number */}
                          <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 text-xs">
                            {/* Action Type */}
                            <div>
                              <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Action Type *</label>
                              <select
                                value={dDoc.actionType || 'Change'}
                                onChange={(e) => {
                                  const newAction = e.target.value as 'Change' | 'Introduction' | 'Removal';
                                  handleGlobalUpdateDeptDoc(pendingGlobalPopupRequest.id, idx, 'actionType', newAction);
                                  if (newAction === 'Introduction') {
                                    handleGlobalUpdateDeptDoc(pendingGlobalPopupRequest.id, idx, 'currentRevision', '-');
                                  } else if (dDoc.currentRevision === '-') {
                                    handleGlobalUpdateDeptDoc(pendingGlobalPopupRequest.id, idx, 'currentRevision', '');
                                  }
                                  if (newAction === 'Removal') {
                                    handleGlobalUpdateDeptDoc(pendingGlobalPopupRequest.id, idx, 'nextRevision', '-');
                                  } else if (dDoc.nextRevision === '-') {
                                    handleGlobalUpdateDeptDoc(pendingGlobalPopupRequest.id, idx, 'nextRevision', '');
                                  }
                                }}
                                className="w-full bg-white border border-slate-200 focus:border-indigo-500 rounded p-1.5 outline-none text-[11px] font-medium"
                                required
                              >
                                <option value="Change">Change</option>
                                <option value="Introduction">Introduction</option>
                                <option value="Removal">Removal</option>
                              </select>
                            </div>

                            {/* Doc Number */}
                            <div>
                              <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Doc Number *</label>
                              <input
                                type="text"
                                value={dDoc.docNumber}
                                onChange={(e) => handleGlobalUpdateDeptDoc(pendingGlobalPopupRequest.id, idx, 'docNumber', e.target.value)}
                                placeholder="e.g., SOP-MN-304"
                                className="w-full bg-white border border-slate-200 focus:border-indigo-500 rounded p-1.5 outline-none text-[11px] font-mono font-bold"
                                required
                              />
                            </div>
                          </div>

                          {/* Row 2: Document Title - full width! */}
                          <div className="text-xs">
                            <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Document Title *</label>
                            <input
                              type="text"
                              value={dDoc.title || ""}
                              onChange={(e) => handleGlobalUpdateDeptDoc(pendingGlobalPopupRequest.id, idx, 'title', e.target.value)}
                              placeholder="e.g., Calibrator Work Instruction"
                              className="w-full bg-white border border-slate-200 focus:border-indigo-500 rounded p-1.5 outline-none text-[11px] font-medium"
                              required
                            />
                          </div>

                          {/* Row 3: Current Rev & Next Rev */}
                          <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 text-xs">
                            {/* Current Rev */}
                            <div>
                              <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Current Rev *</label>
                              <input
                                type="text"
                                value={dDoc.actionType === 'Introduction' ? '-' : (dDoc.currentRevision || '')}
                                disabled={dDoc.actionType === 'Introduction'}
                                onChange={(e) => handleGlobalUpdateDeptDoc(pendingGlobalPopupRequest.id, idx, 'currentRevision', e.target.value.toUpperCase())}
                                placeholder="e.g., AA"
                                pattern="[A-Za-z]{2}"
                                title="Must be exactly 2 letters"
                                maxLength={2}
                                className="w-full bg-white border border-slate-200 focus:border-indigo-500 rounded p-1.5 outline-none text-[11px] font-mono font-bold disabled:bg-slate-200"
                                required
                              />
                            </div>

                            {/* Next Rev */}
                            <div>
                              <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Next Rev *</label>
                              <input
                                type="text"
                                value={dDoc.actionType === 'Removal' ? '-' : (dDoc.nextRevision || '')}
                                disabled={dDoc.actionType === 'Removal'}
                                onChange={(e) => handleGlobalUpdateDeptDoc(pendingGlobalPopupRequest.id, idx, 'nextRevision', e.target.value.toUpperCase())}
                                placeholder="e.g., AB"
                                pattern="[A-Za-z]{2}"
                                title="Must be exactly 2 letters"
                                maxLength={2}
                                className="w-full bg-white border border-slate-200 focus:border-indigo-500 rounded p-1.5 outline-none text-[11px] font-mono font-bold disabled:bg-slate-200"
                                required
                              />
                            </div>
                          </div>

                          {/* Row 4: Reason for Change - full width! */}
                          <div className="text-xs">
                            <label className="block text-[10px] font-bold text-slate-500 uppercase flex justify-between items-center mb-1">
                              <span>Reason for Change *</span>
                              <span className="text-[8.5px] text-indigo-600 font-normal font-sans">Click chat button to expand</span>
                            </label>
                            <div className="relative flex items-center bg-white rounded border border-slate-200 focus-within:border-indigo-500">
                              <input
                                type="text"
                                value={dDoc.reasonForChange}
                                onChange={(e) => handleGlobalUpdateDeptDoc(pendingGlobalPopupRequest.id, idx, 'reasonForChange', e.target.value)}
                                placeholder="Reason for change..."
                                className="w-full bg-transparent p-1.5 pr-8 outline-none text-[11px]"
                                required
                              />
                              <button
                                type="button"
                                onClick={() => openTextEditor(pendingGlobalPopupRequest.id, idx, 'reasonForChange', dDoc.reasonForChange || '', 'Reason')}
                                title="Open rich text editor window"
                                className="absolute right-1.5 p-1 text-slate-400 hover:text-indigo-600 hover:bg-slate-100 rounded transition-all cursor-pointer flex items-center justify-center"
                              >
                                <MessageSquare className="w-3.5 h-3.5 text-indigo-600" />
                              </button>
                            </div>
                          </div>

                          {/* Row 5: Proposed Change - full width! */}
                          <div className="text-xs">
                            <label className="block text-[10px] font-bold text-slate-500 uppercase flex justify-between items-center mb-1">
                              <span>Proposed Change *</span>
                              <span className="text-[8.5px] text-indigo-600 font-normal font-sans">Click chat button to expand</span>
                            </label>
                            <div className="relative flex items-center bg-white rounded border border-slate-200 focus-within:border-indigo-500">
                              <input
                                type="text"
                                value={dDoc.changesRequired}
                                onChange={(e) => handleGlobalUpdateDeptDoc(pendingGlobalPopupRequest.id, idx, 'changesRequired', e.target.value)}
                                placeholder="Technical specifications changed..."
                                className="w-full bg-transparent p-1.5 pr-8 outline-none text-[11px]"
                                required
                              />
                              <button
                                type="button"
                                onClick={() => openTextEditor(pendingGlobalPopupRequest.id, idx, 'changesRequired', dDoc.changesRequired || '', 'Proposed Change')}
                                title="Open rich text editor window"
                                className="absolute right-1.5 p-1 text-slate-400 hover:text-indigo-600 hover:bg-slate-100 rounded transition-all cursor-pointer flex items-center justify-center font-bold"
                              >
                                <MessageSquare className="w-3.5 h-3.5 text-indigo-600" />
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Modal Dialog Footer actions */}
            <div className="flex justify-between items-center pt-3 border-t">
              <button
                type="button"
                onClick={() => setGlobalDismissedPopupRequests(prev => ({ ...prev, [pendingGlobalPopupRequest.id + "-" + userDeptCodeBadge]: true }))}
                className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-600 border rounded-lg text-xs font-bold cursor-pointer transition-colors"
              >
                Postpone Notification
              </button>

              <button
                type="button"
                onClick={() => handleGlobalDeptSubmit(pendingGlobalPopupRequest.id, userDeptCodeBadge)}
                className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white border border-emerald-700 rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-sm cursor-pointer transition-colors"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Authorize & Submit</span>
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Rich Text Editor Popup */}
      {textEditorOpen && (
        <div className="fixed inset-0 bg-slate-900/65 backdrop-blur-xs flex items-center justify-center p-4 z-[9999]">
          <div className="bg-white border border-slate-200 rounded-xl max-w-lg w-full shadow-2xl overflow-hidden flex flex-col">
            {/* Header */}
            <div className="bg-indigo-50 border-b border-indigo-100 p-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-indigo-600 animate-bounce" />
                <span className="font-bold text-slate-800 text-sm">
                  Detailed Input: {textEditorTitle}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setTextEditorOpen(false)}
                className="text-slate-400 hover:text-slate-600 hover:bg-slate-100 w-6 h-6 flex items-center justify-center rounded-full transition-colors font-mono font-bold text-xs"
              >
                ✕
              </button>
            </div>

            {/* Body */}
            <div className="p-4 flex-1">
              <p className="text-[11px] text-slate-500 mb-2">
                Type or paste your detailed specifications, reason for modification, or proposed guidelines below. Press "Save & Apply" when finished.
              </p>
              <textarea
                rows={8}
                value={textEditorValue}
                onChange={(e) => setTextEditorValue(e.target.value)}
                placeholder={`Provide precise detailed context for ${textEditorTitle.toLowerCase()}...`}
                className="w-full bg-slate-50 border border-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 rounded-lg p-3 text-xs outline-none text-slate-800 leading-relaxed font-sans"
                autoFocus
              />
            </div>

            {/* Footer */}
            <div className="bg-slate-50 border-t p-3 flex justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setTextEditorOpen(false)}
                className="px-3.5 py-1.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-605 font-bold rounded-md text-xs cursor-pointer transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveTextEditor}
                className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-md text-xs cursor-pointer shadow-sm hover:scale-101 transition-all"
              >
                Save & Apply
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
