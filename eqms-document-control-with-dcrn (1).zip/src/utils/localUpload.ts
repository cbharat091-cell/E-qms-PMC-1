/**
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Utility to upload files to the self-hosted office LAN server.
 * Reads the raw selected File, converts it to base64, and POSTs it to /api/upload.
 */
export async function uploadFileToServer(file: File): Promise<{ success: boolean; url: string; fileName: string; fileSize: string }> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const base64Data = reader.result as string;
        // Split meta from base64 if present
        const base64Clean = base64Data.includes('base64,') 
          ? base64Data.split('base64,')[1] 
          : base64Data;

        const response = await fetch('/api/upload', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            fileName: file.name,
            base64Data: base64Clean
          })
        });

        if (!response.ok) {
          throw new Error('Host machine refused file write.');
        }

        const resData = await response.json();
        resolve({
          success: true,
          url: resData.url,
          fileName: resData.fileName,
          fileSize: resData.fileSize
        });
      } catch (err: any) {
        reject(err);
      }
    };
    reader.onerror = () => reject(new Error('Failed reading client file binary.'));
    reader.readAsDataURL(file);
  });
}

/**
 * Utility to save virtual document drafts (plain text procedural contents)
 * as actual files directly in the server's local /uploads folder.
 */
export async function saveTextAsFileToServer(fileName: string, content: string): Promise<{ success: boolean; url: string; fileName: string; fileSize: string }> {
  try {
    // Convert plain text to base64 bytes
    const base64Clean = btoa(unescape(encodeURIComponent(content)));
    const response = await fetch('/api/upload', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        fileName,
        base64Data: base64Clean
      })
    });

    if (!response.ok) {
      throw new Error('Host machine refused text draft write.');
    }

    const resData = await response.json();
    return {
      success: true,
      url: resData.url,
      fileName: resData.fileName,
      fileSize: resData.fileSize
    };
  } catch (err: any) {
    console.error("saveTextAsFileToServer failed", err);
    // Silent fallback to virtual path to ensure frontend never breaks even in recovery boots
    return {
      success: false,
      url: `/uploads/${fileName}`,
      fileName,
      fileSize: '128 KB'
    };
  }
}
