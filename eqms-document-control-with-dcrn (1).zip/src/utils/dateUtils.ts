export const formatToIST = (dateString: string): string => {
  if (!dateString) return '';
  const date = new Date(dateString);
  if (isNaN(date.getTime())) return dateString;
  
  // Convert to IST (UTC + 5.5 hours) for consistent visual representation
  const utc = date.getTime() + (date.getTimezoneOffset() * 60000);
  const istDate = new Date(utc + (3600000 * 5.5));
  
  const yyyy = istDate.getFullYear();
  const mm = String(istDate.getMonth() + 1).padStart(2, '0');
  const dd = String(istDate.getDate()).padStart(2, '0');
  const hh = String(istDate.getHours()).padStart(2, '0');
  const min = String(istDate.getMinutes()).padStart(2, '0');
  
  return `${yyyy}/${mm}/${dd} ${hh}:${min}`;
};

export const formatTimeToIST = (dateString: string): string => {
  if (!dateString) return '';
  const date = new Date(dateString);
  if (isNaN(date.getTime())) return dateString;
  
  const utc = date.getTime() + (date.getTimezoneOffset() * 60000);
  const istDate = new Date(utc + (3600000 * 5.5));
  
  const hh = String(istDate.getHours()).padStart(2, '0');
  const min = String(istDate.getMinutes()).padStart(2, '0');
  return `${hh}:${min}`;
};

export const formatEffectiveDate = (dateString: string): string => {
  if (!dateString) return '';
  
  // Directly clean up already-structured dates (e.g. 2026-06-18 -> 2026/06/18)
  if (/^\d{4}[-/]\d{2}[-/]\d{2}$/.test(dateString)) {
    return dateString.replace(/-/g, '/');
  }
  
  const date = new Date(dateString);
  if (isNaN(date.getTime())) return dateString;
  
  // If it's a date-only string (no time segment), use UTC components to avoid timezone shift
  const hasTime = dateString.includes('T') || dateString.includes(':');
  const yyyy = hasTime ? date.getFullYear() : date.getUTCFullYear();
  const mm = String((hasTime ? date.getMonth() : date.getUTCMonth()) + 1).padStart(2, '0');
  const dd = String(hasTime ? date.getDate() : date.getUTCDate()).padStart(2, '0');
  
  return `${yyyy}/${mm}/${dd}`;
};
