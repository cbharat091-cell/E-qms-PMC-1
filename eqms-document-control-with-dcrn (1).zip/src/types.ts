export enum DocumentStatus {
  Draft = 'Draft',
  PendingReview = 'Pending_Reviewer',
  Rejected = 'Rejected',
  PendingApproval = 'Pending_Approval',
  Approved = 'Approved & Signed',
  RequestedMR = 'Pending_MR_Request',
  SoftCopyProvided = 'Soft_Copy_Provided',
  PendingDeletion = 'Pending_Deletion',
  Archived = 'Archived'
}

export enum DocumentCategory {
  SOP = 'SOP (Standard Operating Procedure)',
  Policy = 'Policy Directive',
  Form = 'Form Control',
  WorkInstruction = 'Work Instruction'
}

export enum Department {
  Quality = 'Quality Assurance (QA)',
  Engineering = 'Engineering & Tech',
  Operations = 'Clinical Operations',
  Regulatory = 'Regulatory Affairs (RA)',
  Management = 'Executive Management'
}

export interface User {
  id: string;
  email: string;
  name: string;
  jobTitle: string;
  isAdmin: boolean;
  isPreparer: boolean;
  isReviewer: boolean;
  isApprover: boolean;
  assignedRoles?: ('Admin' | 'Preparer' | 'Reviewer' | 'Approver')[];
  isMR?: boolean;
  isActive?: boolean;
  createdAt: string;
  lastActive: string;
  password?: string;
  department?: string;
  owningQualityDepartment?: string;
}

export interface DocumentComment {
  id: string;
  userId: string;
  userName: string;
  role: string;
  text: string;
  timestamp: string;
}

export interface SignatureLog {
  signerId: string;
  signerName: string;
  signerEmail: string;
  signerTitle: string;
  timestamp: string;
  meaning: string; // e.g., "Review Confirmation", "Final Approving Authority"
  ipAddress: string;
  hash: string;
}

export interface DocumentWorkflow {
  id: string;
  title: string;
  category: DocumentCategory;
  department: Department;
  description: string;
  fileName: string;
  fileSize: string;
  preparedBy: {
    userId: string;
    userName: string;
    email: string;
  };
  status: DocumentStatus;
  submitTimestamp?: string;
  reviewedBy?: {
    userId: string;
    userName: string;
    email: string;
    timestamp: string;
  };
  approvedBy?: SignatureLog;
  comments: DocumentComment[];
  draftContent?: string; // Simulated DOCX content
  mrTemplateCopyUrl?: string;
  preparerDraftUrl?: string;
  reviewerVerifiedUrl?: string;
  finalApprovedCopyUrl?: string;
  assignedReviewer?: {
    userId: string;
    userName: string;
    email: string;
  };
  assignedApprover?: {
    userId: string;
    userName: string;
    email: string;
  };
  rejectedBy?: 'Reviewer' | 'Approver';
  mrDownloaded?: boolean;
  mrDownloadedAt?: string;
  version: string;
  stageBeforeDeletionRequest?: DocumentStatus;
  referencedDcrn?: string;
  createdAt: string;
}

export interface AuditTrailEntry {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  userEmail: string;
  action: string;
  details: string;
  ipAddress: string;
  checksum: string; // Dynamic simulated secure hash
}

export const DEPARTMENT_MAP: { [key: string]: string } = {
  MR: 'MANAGEMENT REPRESENTATIVE',
  QA: 'QUALITY ASSURANCE',
  DD: 'DESIGN AND DEVELOPMENT',
  QC: 'QUALITY CONTROL',
  MK: 'LOGISTICS & MARKETING',
  PD: 'PRODUCTION',
  PK: 'PACKING',
  ST: 'STORE',
  MN: 'MAINTENANCE',
  PU: 'PURCHASE',
  HR: 'HUMAN RESOURCE',
  RP: 'RAW MATERIAL PRODUCTION',
  MS: 'MARKETING AND SALES',
  VC: 'VALIDATION CELL'
};

export interface DCRNDecDocument {
  docNumber: string;
  currentRevision: string;
  nextRevision: string;
  reasonForChange: string;
  changesRequired: string;
  actionType?: 'Change' | 'Introduction' | 'Removal';
  addedByDept?: string;
  uploadedUrl?: string;
  uploadedFileName?: string;
  uploadedAt?: string;
  title?: string;

  // Custom DCRN Reviewer/Approver sub-workflow fields
  workflowStatus?: 'Downloaded' | 'PendingReview' | 'ReviewRejected' | 'ReviewAccepted' | 'PendingApproval' | 'ApprovalRejected' | 'ApprovalAccepted';
  assignedReviewerId?: string;
  assignedReviewerName?: string;
  assignedApproverId?: string;
  assignedApproverName?: string;
  updatedDocUrl?: string;
  updatedDocName?: string;
  reviewedDocUrl?: string;
  reviewedDocName?: string;
  approvedDocUrl?: string;
  approvedDocName?: string;
  reviewerComments?: string;
  approverComments?: string;
  preparedAt?: string;
  reviewedAt?: string;
  approvedAt?: string;
}

export interface DCRNDepartmentAssessment {
  department: string;
  impacted: 'Yes' | 'No' | null;
  assessedBy?: {
    userId: string;
    userName: string;
    email: string;
  };
  assessedAt?: string;
  documents: DCRNDecDocument[];
  previouslyAnalyzedDocs?: DCRNDecDocument[];
}

export interface DCRNRequest {
  id: string;
  status: 'Pending_QA_Evaluation' | 'Rejected' | 'Pending_Impact_Assessment' | 'Pending_QA_Stage2' | 'Pending_MR_Closure' | 'Completed';
  createdAt: string;
  preparedBy: {
    userId: string;
    userName: string;
    email: string;
    department: string;
  };
  initialDocs: DCRNDecDocument[];
  qaEvaluationRemarks?: string;
  qaEvaluatedBy?: {
    userId: string;
    userName: string;
    email: string;
  };
  qaEvaluatedAt?: string;
  qaStage2Remarks?: string;
  qaStage2EvaluatedBy?: {
    userId: string;
    userName: string;
    email: string;
  };
  qaStage2EvaluatedAt?: string;
  effectiveDate?: string;
  assessments: { [deptCode: string]: DCRNDepartmentAssessment };
  mrRegistryNumber?: string;
  mrRegistryAssignedBy?: {
    userId: string;
    userName: string;
    email: string;
  };
  mrRegistryAssignedAt?: string;
  mrAuthorizedBy?: {
    userId: string;
    userName: string;
    email: string;
  };
  mrAuthorizedAt?: string;
  pendingDeletion?: boolean;
}


